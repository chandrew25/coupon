/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80018
 Source Host           : localhost:3306
 Source Schema         : we7

 Target Server Type    : MySQL
 Target Server Version : 80018
 File Encoding         : 65001

 Date: 28/12/2019 22:03:35
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ims_account
-- ----------------------------
DROP TABLE IF EXISTS `ims_account`;
CREATE TABLE `ims_account` (
  `acid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `hash` varchar(8) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `isconnect` tinyint(4) NOT NULL,
  `isdeleted` tinyint(3) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`acid`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_account
-- ----------------------------
BEGIN;
INSERT INTO `ims_account` VALUES (1, 1, 'uRr8qvQV', 1, 0, 0, 0);
INSERT INTO `ims_account` VALUES (2, 2, 'gWSDSUMW', 1, 1, 0, 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_account_aliapp
-- ----------------------------
DROP TABLE IF EXISTS `ims_account_aliapp`;
CREATE TABLE `ims_account_aliapp` (
  `acid` int(10) unsigned NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `level` tinyint(4) unsigned NOT NULL,
  `name` varchar(30) NOT NULL,
  `description` varchar(255) NOT NULL,
  `key` varchar(16) NOT NULL,
  PRIMARY KEY (`acid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_account_baiduapp
-- ----------------------------
DROP TABLE IF EXISTS `ims_account_baiduapp`;
CREATE TABLE `ims_account_baiduapp` (
  `acid` int(10) unsigned NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `name` varchar(30) NOT NULL,
  `appid` varchar(32) NOT NULL,
  `key` varchar(32) NOT NULL,
  `secret` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`acid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_account_phoneapp
-- ----------------------------
DROP TABLE IF EXISTS `ims_account_phoneapp`;
CREATE TABLE `ims_account_phoneapp` (
  `acid` int(11) NOT NULL,
  `uniacid` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`acid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_account_toutiaoapp
-- ----------------------------
DROP TABLE IF EXISTS `ims_account_toutiaoapp`;
CREATE TABLE `ims_account_toutiaoapp` (
  `acid` int(10) unsigned NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `name` varchar(30) NOT NULL,
  `appid` varchar(32) NOT NULL,
  `key` varchar(32) NOT NULL,
  `secret` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`acid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_account_webapp
-- ----------------------------
DROP TABLE IF EXISTS `ims_account_webapp`;
CREATE TABLE `ims_account_webapp` (
  `acid` int(11) NOT NULL,
  `uniacid` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT '',
  PRIMARY KEY (`acid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_account_wechats
-- ----------------------------
DROP TABLE IF EXISTS `ims_account_wechats`;
CREATE TABLE `ims_account_wechats` (
  `acid` int(10) unsigned NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `token` varchar(32) NOT NULL,
  `encodingaeskey` varchar(255) NOT NULL,
  `level` tinyint(4) unsigned NOT NULL,
  `name` varchar(30) NOT NULL,
  `account` varchar(30) NOT NULL,
  `original` varchar(50) NOT NULL,
  `signature` varchar(100) NOT NULL,
  `country` varchar(10) NOT NULL,
  `province` varchar(3) NOT NULL,
  `city` varchar(15) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL,
  `key` varchar(50) NOT NULL,
  `secret` varchar(50) NOT NULL,
  `styleid` int(10) unsigned NOT NULL,
  `subscribeurl` varchar(120) NOT NULL,
  `auth_refresh_token` varchar(255) NOT NULL,
  PRIMARY KEY (`acid`),
  KEY `idx_key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_account_wechats
-- ----------------------------
BEGIN;
INSERT INTO `ims_account_wechats` VALUES (1, 1, 'omJNpZEhZeHj1ZxFECKkP48B5VFbk1HP', '', 1, 'efwww', '', '', '', '', '', '', '', '', 0, '', '', 1, '', '');
INSERT INTO `ims_account_wechats` VALUES (2, 2, 'Nlru68yh2jjJZ6FLsue7JDzsjjlRHI8u', 'DBUP17Z244WSqWS9s9299S2u2pzDbPU9272Ui7925P4', 4, '淘宝客', '13310015380@163.com', 'gh_1d0bcc6ca900', '', '', '', '', '', '', 0, 'wx4ce1248fee1b6d3d', '1e2f6a4a33d751e23f817065607a60eb', 0, '', '');
COMMIT;

-- ----------------------------
-- Table structure for ims_account_wxapp
-- ----------------------------
DROP TABLE IF EXISTS `ims_account_wxapp`;
CREATE TABLE `ims_account_wxapp` (
  `acid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `token` varchar(32) NOT NULL,
  `encodingaeskey` varchar(43) NOT NULL,
  `level` tinyint(4) NOT NULL,
  `account` varchar(30) NOT NULL,
  `original` varchar(50) NOT NULL,
  `key` varchar(50) NOT NULL,
  `secret` varchar(50) NOT NULL,
  `name` varchar(30) NOT NULL,
  `appdomain` varchar(255) NOT NULL,
  `auth_refresh_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`acid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_account_xzapp
-- ----------------------------
DROP TABLE IF EXISTS `ims_account_xzapp`;
CREATE TABLE `ims_account_xzapp` (
  `acid` int(11) NOT NULL,
  `uniacid` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `original` varchar(50) NOT NULL,
  `lastupdate` int(10) NOT NULL,
  `styleid` int(10) NOT NULL,
  `createtime` int(10) NOT NULL,
  `token` varchar(32) NOT NULL,
  `encodingaeskey` varchar(255) NOT NULL,
  `xzapp_id` varchar(30) NOT NULL,
  `level` tinyint(4) unsigned NOT NULL,
  `key` varchar(80) NOT NULL,
  `secret` varchar(80) NOT NULL,
  PRIMARY KEY (`acid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_activity_clerk_menu
-- ----------------------------
DROP TABLE IF EXISTS `ims_activity_clerk_menu`;
CREATE TABLE `ims_activity_clerk_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `displayorder` int(4) NOT NULL,
  `pid` int(6) NOT NULL,
  `group_name` varchar(20) NOT NULL,
  `title` varchar(20) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `permission` varchar(50) NOT NULL,
  `system` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_activity_clerks
-- ----------------------------
DROP TABLE IF EXISTS `ims_activity_clerks`;
CREATE TABLE `ims_activity_clerks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `storeid` int(10) unsigned NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `openid` varchar(50) NOT NULL,
  `nickname` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `password` (`password`),
  KEY `openid` (`openid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_article_category
-- ----------------------------
DROP TABLE IF EXISTS `ims_article_category`;
CREATE TABLE `ims_article_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `type` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_article_comment
-- ----------------------------
DROP TABLE IF EXISTS `ims_article_comment`;
CREATE TABLE `ims_article_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `articleid` int(10) unsigned NOT NULL,
  `parentid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `content` varchar(500) DEFAULT NULL,
  `is_like` tinyint(1) NOT NULL,
  `is_reply` tinyint(1) NOT NULL,
  `like_num` int(10) unsigned NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `articleid` (`articleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_article_news
-- ----------------------------
DROP TABLE IF EXISTS `ims_article_news`;
CREATE TABLE `ims_article_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cateid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `source` varchar(255) NOT NULL,
  `author` varchar(50) NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `is_display` tinyint(3) unsigned NOT NULL,
  `is_show_home` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `click` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `cateid` (`cateid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_article_notice
-- ----------------------------
DROP TABLE IF EXISTS `ims_article_notice`;
CREATE TABLE `ims_article_notice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cateid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `is_display` tinyint(3) unsigned NOT NULL,
  `is_show_home` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `click` int(10) unsigned NOT NULL,
  `style` varchar(200) NOT NULL,
  `group` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `cateid` (`cateid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_article_unread_notice
-- ----------------------------
DROP TABLE IF EXISTS `ims_article_unread_notice`;
CREATE TABLE `ims_article_unread_notice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notice_id` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `is_new` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `notice_id` (`notice_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_attachment_group
-- ----------------------------
DROP TABLE IF EXISTS `ims_attachment_group`;
CREATE TABLE `ims_attachment_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `uniacid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `type` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_basic_reply
-- ----------------------------
DROP TABLE IF EXISTS `ims_basic_reply`;
CREATE TABLE `ims_basic_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `content` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_business
-- ----------------------------
DROP TABLE IF EXISTS `ims_business`;
CREATE TABLE `ims_business` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `province` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `dist` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `lng` varchar(10) NOT NULL,
  `lat` varchar(10) NOT NULL,
  `industry1` varchar(10) NOT NULL,
  `industry2` varchar(10) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lat_lng` (`lng`,`lat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_core_attachment
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_attachment`;
CREATE TABLE `ims_core_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `module_upload_dir` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_core_attachment
-- ----------------------------
BEGIN;
INSERT INTO `ims_core_attachment` VALUES (1, 2, 1, '微信图片_20191120174323.jpg', 'images/2/2019/11/EIJBy2f6jfxjXQgxWthTBcc2qjCplF.jpg', 1, 1574848990, '', -1);
INSERT INTO `ims_core_attachment` VALUES (2, 2, 1, '5.jpg', 'images/2/2019/11/dU8tUJkdyYIoUuDzS1DdOkI4Sdtugc.jpg', 1, 1574849011, '', -1);
INSERT INTO `ims_core_attachment` VALUES (3, 2, 1, '1233.png', 'images/2/2019/11/aWghNnINRsNBRzmPmTBwWs7unR4Tr9.png', 1, 1574849075, '', -1);
INSERT INTO `ims_core_attachment` VALUES (4, 2, 1, 'default_tmall.png', 'images/2/2019/11/HgfxTsgz2vuZuUy7DX7Y73U6S44XX9.png', 1, 1574849249, '', -1);
INSERT INTO `ims_core_attachment` VALUES (5, 2, 1, 'default_taobao.png', 'images/2/2019/11/Mw7poqkV1QX29uxxAGMmXWn82o0pXD.png', 1, 1574849347, '', -1);
INSERT INTO `ims_core_attachment` VALUES (6, 2, 1, 'default_jd.png', 'images/2/2019/11/SJJ64Ojj77oLps6l0shl1Jzc7sfhhJ.png', 1, 1574849542, '', -1);
INSERT INTO `ims_core_attachment` VALUES (7, 2, 1, 'default_pdd.png', 'images/2/2019/11/guczpic5s43uO4Cs9ms4uiw304W44z.png', 1, 1574849621, '', -1);
INSERT INTO `ims_core_attachment` VALUES (8, 2, 1, '微信图片_20191120174342.jpg', 'images/2/2019/11/DcMRCerzp9DDVa9sYcReRZOXSpkdDY.jpg', 1, 1574849923, '', -1);
INSERT INTO `ims_core_attachment` VALUES (9, 2, 1, '微信图片_20191120174330.jpg', 'images/2/2019/11/G1mAVrkBKVoMAGke5CKcFGeRE2qoKB.jpg', 1, 1574850053, '', -1);
INSERT INTO `ims_core_attachment` VALUES (10, 2, 1, '微信图片_20191120174336.jpg', 'images/2/2019/11/clB45OoBS8Sdbbvjf04CLWdo8W8bx0.jpg', 1, 1574850100, '', -1);
INSERT INTO `ims_core_attachment` VALUES (11, 2, 1, '微信图片_20191120174346.jpg', 'images/2/2019/11/pX0Ke4Bjd04PDJpbyLBPDjGGkLKjGd.jpg', 1, 1574850157, '', -1);
INSERT INTO `ims_core_attachment` VALUES (12, 2, 1, 'wqXwM0N0Zs00k4sz0wVoIUyPlyO4wN.jpg', 'images/2/2019/11/d2922E9Mmm3zTm26MOz32mm77msmr2.jpg', 1, 1574850502, '', -1);
INSERT INTO `ims_core_attachment` VALUES (13, 2, 1, 'Gfv9vI8af9P0v78MpWEFhw7wGIcm5m.png', 'images/2/2019/11/k8uCku56Kn6QZA9JuC2Q35jm2328AZ.png', 1, 1574850566, '', -1);
INSERT INTO `ims_core_attachment` VALUES (14, 2, 1, '微信图片_20191127175250.jpg', 'images/2/2019/11/RMeJJ1E7q24q11ZZ72M2X653Gccjzm.jpg', 1, 1574850798, '', -1);
INSERT INTO `ims_core_attachment` VALUES (15, 2, 1, '微信图片_20191120170344.png', 'images/2/2019/11/IKFqIAqzAKXHKefFI0Ux6x8GixXgq4.png', 1, 1574851471, '', -1);
INSERT INTO `ims_core_attachment` VALUES (16, 2, 1, '微信图片_20191120170418.png', 'images/2/2019/11/YnQ7Pef096TtqnfPN070zAmGQN06fF.png', 1, 1574851538, '', -1);
INSERT INTO `ims_core_attachment` VALUES (17, 2, 1, '微信图片_20191120174043.png', 'images/2/2019/11/b0SlllKjj81dWrc01D81lDcPJ6168P.png', 1, 1574851611, '', -1);
INSERT INTO `ims_core_attachment` VALUES (18, 2, 1, 'default_9.9.png', 'images/2/2019/11/UQOs9seIOYYZx66hfqxe6eQqYxtM99.png', 1, 1574851688, '', -1);
INSERT INTO `ims_core_attachment` VALUES (19, 1, 1, '4f.gif', 'images/1/2019/11/Jlx5nXxQlCAYqVQcZ7UuIZindPzCuz.gif', 1, 1574852908, '', -1);
INSERT INTO `ims_core_attachment` VALUES (20, 2, 1, '4f.gif', 'images/2/2019/11/yQcqjMqBHCbM1xolcb8j21TcqmJEqx.gif', 1, 1574853106, '', -1);
INSERT INTO `ims_core_attachment` VALUES (21, 2, 1, '18.jpg', 'images/2/2019/11/OrLf5A8C41jg0mGN558J15U0GU47L4.jpg', 1, 1574904791, '', -1);
COMMIT;

-- ----------------------------
-- Table structure for ims_core_cache
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_cache`;
CREATE TABLE `ims_core_cache` (
  `key` varchar(100) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_core_cache
-- ----------------------------
BEGIN;
INSERT INTO `ims_core_cache` VALUES ('we7:account_ticket', 's:0:\"\";');
INSERT INTO `ims_core_cache` VALUES ('we7:setting', 'a:8:{s:9:\"copyright\";a:1:{s:6:\"slides\";a:3:{i:0;s:58:\"https://img.alicdn.com/tps/TB1pfG4IFXXXXc6XXXXXXXXXXXX.jpg\";i:1;s:58:\"https://img.alicdn.com/tps/TB1sXGYIFXXXXc5XpXXXXXXXXXX.jpg\";i:2;s:58:\"https://img.alicdn.com/tps/TB1h9xxIFXXXXbKXXXXXXXXXXXX.jpg\";}}s:8:\"authmode\";i:1;s:5:\"close\";a:2:{s:6:\"status\";s:1:\"0\";s:6:\"reason\";s:0:\"\";}s:8:\"register\";a:4:{s:4:\"open\";i:1;s:6:\"verify\";i:0;s:4:\"code\";i:1;s:7:\"groupid\";i:1;}s:10:\"thirdlogin\";a:4:{s:6:\"system\";a:3:{s:5:\"appid\";s:0:\"\";s:9:\"appsecret\";s:0:\"\";s:9:\"authstate\";s:0:\"\";}s:2:\"qq\";a:3:{s:5:\"appid\";s:0:\"\";s:9:\"appsecret\";s:0:\"\";s:9:\"authstate\";i:0;}s:6:\"wechat\";a:3:{s:5:\"appid\";s:0:\"\";s:9:\"appsecret\";s:0:\"\";s:9:\"authstate\";s:0:\"\";}s:6:\"mobile\";a:3:{s:5:\"appid\";s:0:\"\";s:9:\"appsecret\";s:0:\"\";s:9:\"authstate\";s:0:\"\";}}s:7:\"cloudip\";a:0:{}s:8:\"platform\";a:5:{s:5:\"token\";s:32:\"SLZdvo61blXbhzYZXdsAaHsyY8z31HBV\";s:14:\"encodingaeskey\";s:43:\"vEyLkSIQqdDZslZyizCSLtZHSSpIIDjSeKdSZUlkkcS\";s:9:\"appsecret\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:9:\"authstate\";i:1;}s:18:\"module_receive_ban\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:userbasefields', 'a:46:{s:7:\"uniacid\";s:17:\"同一公众号id\";s:7:\"groupid\";s:8:\"分组id\";s:7:\"credit1\";s:6:\"积分\";s:7:\"credit2\";s:6:\"余额\";s:7:\"credit3\";s:19:\"预留积分类型3\";s:7:\"credit4\";s:19:\"预留积分类型4\";s:7:\"credit5\";s:19:\"预留积分类型5\";s:7:\"credit6\";s:19:\"预留积分类型6\";s:10:\"createtime\";s:12:\"加入时间\";s:6:\"mobile\";s:12:\"手机号码\";s:5:\"email\";s:12:\"电子邮箱\";s:8:\"realname\";s:12:\"真实姓名\";s:8:\"nickname\";s:6:\"昵称\";s:6:\"avatar\";s:6:\"头像\";s:2:\"qq\";s:5:\"QQ号\";s:6:\"gender\";s:6:\"性别\";s:5:\"birth\";s:6:\"生日\";s:13:\"constellation\";s:6:\"星座\";s:6:\"zodiac\";s:6:\"生肖\";s:9:\"telephone\";s:12:\"固定电话\";s:6:\"idcard\";s:12:\"证件号码\";s:9:\"studentid\";s:6:\"学号\";s:5:\"grade\";s:6:\"班级\";s:7:\"address\";s:6:\"地址\";s:7:\"zipcode\";s:6:\"邮编\";s:11:\"nationality\";s:6:\"国籍\";s:6:\"reside\";s:9:\"居住地\";s:14:\"graduateschool\";s:12:\"毕业学校\";s:7:\"company\";s:6:\"公司\";s:9:\"education\";s:6:\"学历\";s:10:\"occupation\";s:6:\"职业\";s:8:\"position\";s:6:\"职位\";s:7:\"revenue\";s:9:\"年收入\";s:15:\"affectivestatus\";s:12:\"情感状态\";s:10:\"lookingfor\";s:13:\" 交友目的\";s:9:\"bloodtype\";s:6:\"血型\";s:6:\"height\";s:6:\"身高\";s:6:\"weight\";s:6:\"体重\";s:6:\"alipay\";s:15:\"支付宝帐号\";s:3:\"msn\";s:3:\"MSN\";s:6:\"taobao\";s:12:\"阿里旺旺\";s:4:\"site\";s:6:\"主页\";s:3:\"bio\";s:12:\"自我介绍\";s:8:\"interest\";s:12:\"兴趣爱好\";s:8:\"password\";s:6:\"密码\";s:12:\"pay_password\";s:12:\"支付密码\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:usersfields', 'a:49:{s:8:\"realname\";s:12:\"真实姓名\";s:8:\"nickname\";s:6:\"昵称\";s:6:\"avatar\";s:6:\"头像\";s:2:\"qq\";s:5:\"QQ号\";s:6:\"mobile\";s:12:\"手机号码\";s:3:\"vip\";s:9:\"VIP级别\";s:6:\"gender\";s:6:\"性别\";s:9:\"birthyear\";s:12:\"出生生日\";s:13:\"constellation\";s:6:\"星座\";s:6:\"zodiac\";s:6:\"生肖\";s:9:\"telephone\";s:12:\"固定电话\";s:6:\"idcard\";s:12:\"证件号码\";s:9:\"studentid\";s:6:\"学号\";s:5:\"grade\";s:6:\"班级\";s:7:\"address\";s:12:\"邮寄地址\";s:7:\"zipcode\";s:6:\"邮编\";s:11:\"nationality\";s:6:\"国籍\";s:14:\"resideprovince\";s:12:\"居住地址\";s:14:\"graduateschool\";s:12:\"毕业学校\";s:7:\"company\";s:6:\"公司\";s:9:\"education\";s:6:\"学历\";s:10:\"occupation\";s:6:\"职业\";s:8:\"position\";s:6:\"职位\";s:7:\"revenue\";s:9:\"年收入\";s:15:\"affectivestatus\";s:12:\"情感状态\";s:10:\"lookingfor\";s:13:\" 交友目的\";s:9:\"bloodtype\";s:6:\"血型\";s:6:\"height\";s:6:\"身高\";s:6:\"weight\";s:6:\"体重\";s:6:\"alipay\";s:15:\"支付宝帐号\";s:3:\"msn\";s:3:\"MSN\";s:5:\"email\";s:12:\"电子邮箱\";s:6:\"taobao\";s:12:\"阿里旺旺\";s:4:\"site\";s:6:\"主页\";s:3:\"bio\";s:12:\"自我介绍\";s:8:\"interest\";s:12:\"兴趣爱好\";s:10:\"birthmonth\";s:12:\"出生月份\";s:8:\"birthday\";s:12:\"出生日期\";s:7:\"credit1\";s:6:\"积分\";s:7:\"credit2\";s:6:\"余额\";s:7:\"uniacid\";s:17:\"同一公众号id\";s:7:\"groupid\";s:8:\"分组id\";s:7:\"credit3\";s:19:\"预留积分类型3\";s:7:\"credit4\";s:19:\"预留积分类型4\";s:7:\"credit5\";s:19:\"预留积分类型5\";s:7:\"credit6\";s:19:\"预留积分类型6\";s:10:\"createtime\";s:12:\"加入时间\";s:8:\"password\";s:12:\"用户密码\";s:12:\"pay_password\";s:12:\"支付密码\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_receive_enable', 'a:2:{s:9:\"subscribe\";a:1:{i:0;s:11:\"tiger_newhu\";}s:11:\"unsubscribe\";a:1:{i:0;s:11:\"tiger_newhu\";}}');
INSERT INTO `ims_core_cache` VALUES ('we7:system_frame:0', 'a:21:{s:8:\"phoneapp\";a:7:{s:5:\"title\";s:3:\"APP\";s:4:\"icon\";s:18:\"wi wi-white-collar\";s:3:\"url\";s:41:\"./index.php?c=phoneapp&a=display&do=home&\";s:7:\"section\";a:2:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:16:\"phoneapp_profile\";a:4:{s:5:\"title\";s:6:\"配置\";s:4:\"menu\";a:2:{s:28:\"profile_phoneapp_module_link\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:1:{i:0;i:6;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"数据同步\";s:3:\"url\";s:42:\"./index.php?c=wxapp&a=module-link-uniacid&\";s:15:\"permission_name\";s:28:\"profile_phoneapp_module_link\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:14:\"front_download\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";b:1;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"下载APP\";s:3:\"url\";s:40:\"./index.php?c=phoneapp&a=front-download&\";s:15:\"permission_name\";s:23:\"phoneapp_front_download\";s:4:\"icon\";s:13:\"wi wi-examine\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:10:\"is_display\";b:1;s:18:\"permission_display\";a:1:{i:0;i:6;}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:0;s:12:\"displayorder\";i:0;}s:7:\"welcome\";a:7:{s:5:\"title\";s:6:\"首页\";s:4:\"icon\";s:10:\"wi wi-home\";s:3:\"url\";s:48:\"./index.php?c=home&a=welcome&do=system&page=home\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:2;}s:8:\"platform\";a:8:{s:5:\"title\";s:12:\"平台入口\";s:4:\"icon\";s:14:\"wi wi-platform\";s:9:\"dimension\";i:2;s:3:\"url\";s:44:\"./index.php?c=account&a=display&do=platform&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:3;}s:6:\"module\";a:8:{s:5:\"title\";s:12:\"应用入口\";s:4:\"icon\";s:11:\"wi wi-apply\";s:9:\"dimension\";i:2;s:3:\"url\";s:53:\"./index.php?c=module&a=display&do=switch_last_module&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:4;}s:14:\"account_manage\";a:8:{s:5:\"title\";s:12:\"平台管理\";s:4:\"icon\";s:21:\"wi wi-platform-manage\";s:9:\"dimension\";i:2;s:3:\"url\";s:31:\"./index.php?c=account&a=manage&\";s:7:\"section\";a:1:{s:14:\"account_manage\";a:2:{s:5:\"title\";s:12:\"平台管理\";s:4:\"menu\";a:4:{s:22:\"account_manage_display\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"平台列表\";s:3:\"url\";s:31:\"./index.php?c=account&a=manage&\";s:15:\"permission_name\";s:22:\"account_manage_display\";s:4:\"icon\";N;s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:1:{i:0;a:2:{s:5:\"title\";s:12:\"帐号停用\";s:15:\"permission_name\";s:19:\"account_manage_stop\";}}}s:22:\"account_manage_recycle\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"回收站\";s:3:\"url\";s:32:\"./index.php?c=account&a=recycle&\";s:15:\"permission_name\";s:22:\"account_manage_recycle\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:12:\"帐号删除\";s:15:\"permission_name\";s:21:\"account_manage_delete\";}i:1;a:2:{s:5:\"title\";s:12:\"帐号恢复\";s:15:\"permission_name\";s:22:\"account_manage_recover\";}}}s:30:\"account_manage_system_platform\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:19:\" 微信开放平台\";s:3:\"url\";s:32:\"./index.php?c=system&a=platform&\";s:15:\"permission_name\";s:30:\"account_manage_system_platform\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:30:\"account_manage_expired_message\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:22:\" 自定义到期提示\";s:3:\"url\";s:40:\"./index.php?c=account&a=expired-message&\";s:15:\"permission_name\";s:30:\"account_manage_expired_message\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:5;}s:13:\"module_manage\";a:8:{s:5:\"title\";s:12:\"应用管理\";s:4:\"icon\";s:19:\"wi wi-module-manage\";s:9:\"dimension\";i:2;s:3:\"url\";s:50:\"./index.php?c=module&a=manage-system&do=installed&\";s:7:\"section\";a:1:{s:13:\"module_manage\";a:2:{s:5:\"title\";s:12:\"应用管理\";s:4:\"menu\";a:5:{s:23:\"module_manage_installed\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"已安装列表\";s:3:\"url\";s:50:\"./index.php?c=module&a=manage-system&do=installed&\";s:15:\"permission_name\";s:23:\"module_manage_installed\";s:4:\"icon\";N;s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:20:\"module_manage_stoped\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"已停用列表\";s:3:\"url\";s:54:\"./index.php?c=module&a=manage-system&do=recycle&type=1\";s:15:\"permission_name\";s:20:\"module_manage_stoped\";s:4:\"icon\";N;s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:27:\"module_manage_not_installed\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"未安装列表\";s:3:\"url\";s:54:\"./index.php?c=module&a=manage-system&do=not_installed&\";s:15:\"permission_name\";s:27:\"module_manage_not_installed\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:21:\"module_manage_recycle\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"回收站\";s:3:\"url\";s:54:\"./index.php?c=module&a=manage-system&do=recycle&type=2\";s:15:\"permission_name\";s:21:\"module_manage_recycle\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:23:\"module_manage_subscribe\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"订阅管理\";s:3:\"url\";s:50:\"./index.php?c=module&a=manage-system&do=subscribe&\";s:15:\"permission_name\";s:23:\"module_manage_subscribe\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:6;}s:11:\"user_manage\";a:8:{s:5:\"title\";s:12:\"用户管理\";s:4:\"icon\";s:16:\"wi wi-user-group\";s:9:\"dimension\";i:2;s:3:\"url\";s:29:\"./index.php?c=user&a=display&\";s:7:\"section\";a:1:{s:11:\"user_manage\";a:2:{s:5:\"title\";s:12:\"用户管理\";s:4:\"menu\";a:7:{s:19:\"user_manage_display\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"普通用户\";s:3:\"url\";s:29:\"./index.php?c=user&a=display&\";s:15:\"permission_name\";s:19:\"user_manage_display\";s:4:\"icon\";N;s:12:\"displayorder\";i:7;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:19:\"user_manage_founder\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"副站长\";s:3:\"url\";s:32:\"./index.php?c=founder&a=display&\";s:15:\"permission_name\";s:19:\"user_manage_founder\";s:4:\"icon\";N;s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:17:\"user_manage_clerk\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"店员管理\";s:3:\"url\";s:39:\"./index.php?c=user&a=display&type=clerk\";s:15:\"permission_name\";s:17:\"user_manage_clerk\";s:4:\"icon\";N;s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:17:\"user_manage_check\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"审核用户\";s:3:\"url\";s:39:\"./index.php?c=user&a=display&type=check\";s:15:\"permission_name\";s:17:\"user_manage_check\";s:4:\"icon\";N;s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:19:\"user_manage_recycle\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"回收站\";s:3:\"url\";s:41:\"./index.php?c=user&a=display&type=recycle\";s:15:\"permission_name\";s:19:\"user_manage_recycle\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:18:\"user_manage_fields\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"用户属性设置\";s:3:\"url\";s:39:\"./index.php?c=user&a=fields&do=display&\";s:15:\"permission_name\";s:18:\"user_manage_fields\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:18:\"user_manage_expire\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"用户过期设置\";s:3:\"url\";s:28:\"./index.php?c=user&a=expire&\";s:15:\"permission_name\";s:18:\"user_manage_expire\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:7;}s:10:\"permission\";a:8:{s:5:\"title\";s:9:\"权限组\";s:4:\"icon\";s:22:\"wi wi-userjurisdiction\";s:9:\"dimension\";i:2;s:3:\"url\";s:29:\"./index.php?c=module&a=group&\";s:7:\"section\";a:1:{s:10:\"permission\";a:2:{s:5:\"title\";s:9:\"权限组\";s:4:\"menu\";a:4:{s:23:\"permission_module_group\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"应用权限组\";s:3:\"url\";s:29:\"./index.php?c=module&a=group&\";s:15:\"permission_name\";s:23:\"permission_module_group\";s:4:\"icon\";N;s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:31:\"permission_create_account_group\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"账号权限组\";s:3:\"url\";s:34:\"./index.php?c=user&a=create-group&\";s:15:\"permission_name\";s:31:\"permission_create_account_group\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:21:\"permission_user_group\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"用户权限组合\";s:3:\"url\";s:27:\"./index.php?c=user&a=group&\";s:15:\"permission_name\";s:21:\"permission_user_group\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:24:\"permission_founder_group\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:21:\"副站长权限组合\";s:3:\"url\";s:30:\"./index.php?c=founder&a=group&\";s:15:\"permission_name\";s:24:\"permission_founder_group\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:8;}s:6:\"system\";a:8:{s:5:\"title\";s:12:\"系统功能\";s:4:\"icon\";s:13:\"wi wi-setting\";s:9:\"dimension\";i:3;s:3:\"url\";s:31:\"./index.php?c=article&a=notice&\";s:7:\"section\";a:5:{s:7:\"article\";a:3:{s:5:\"title\";s:12:\"站内公告\";s:4:\"menu\";a:1:{s:14:\"system_article\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"站内公告\";s:3:\"url\";s:31:\"./index.php?c=article&a=notice&\";s:15:\"permission_name\";s:14:\"system_article\";s:4:\"icon\";s:13:\"wi wi-article\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:12:\"公告列表\";s:15:\"permission_name\";s:26:\"system_article_notice_list\";}i:1;a:2:{s:5:\"title\";s:12:\"公告分类\";s:15:\"permission_name\";s:30:\"system_article_notice_category\";}}}}s:7:\"founder\";b:1;}s:15:\"system_template\";a:3:{s:5:\"title\";s:6:\"模板\";s:4:\"menu\";a:1:{s:15:\"system_template\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"微官网模板\";s:3:\"url\";s:32:\"./index.php?c=system&a=template&\";s:15:\"permission_name\";s:15:\"system_template\";s:4:\"icon\";s:17:\"wi wi-wx-template\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:7:\"founder\";b:1;}s:14:\"system_welcome\";a:3:{s:5:\"title\";s:12:\"系统首页\";s:4:\"menu\";a:2:{s:14:\"system_welcome\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"系统首页应用\";s:3:\"url\";s:60:\"./index.php?c=module&a=manage-system&support=welcome_support\";s:15:\"permission_name\";s:14:\"system_welcome\";s:4:\"icon\";s:20:\"wi wi-system-welcome\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:11:\"system_news\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"系统新闻\";s:3:\"url\";s:29:\"./index.php?c=article&a=news&\";s:15:\"permission_name\";s:11:\"system_news\";s:4:\"icon\";s:13:\"wi wi-article\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:13:\"新闻列表 \";s:15:\"permission_name\";s:24:\"system_article_news_list\";}i:1;a:2:{s:5:\"title\";s:13:\"新闻分类 \";s:15:\"permission_name\";s:28:\"system_article_news_category\";}}}}s:7:\"founder\";b:1;}s:17:\"system_statistics\";a:3:{s:5:\"title\";s:6:\"统计\";s:4:\"menu\";a:1:{s:23:\"system_account_analysis\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"访问统计\";s:3:\"url\";s:35:\"./index.php?c=statistics&a=account&\";s:15:\"permission_name\";s:23:\"system_account_analysis\";s:4:\"icon\";s:17:\"wi wi-statistical\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:7:\"founder\";b:1;}s:5:\"cache\";a:2:{s:5:\"title\";s:6:\"缓存\";s:4:\"menu\";a:1:{s:26:\"system_setting_updatecache\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"更新缓存\";s:3:\"url\";s:35:\"./index.php?c=system&a=updatecache&\";s:15:\"permission_name\";s:26:\"system_setting_updatecache\";s:4:\"icon\";s:12:\"wi wi-update\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:9;}s:4:\"site\";a:9:{s:5:\"title\";s:12:\"站点设置\";s:4:\"icon\";s:17:\"wi wi-system-site\";s:9:\"dimension\";i:3;s:3:\"url\";s:28:\"./index.php?c=system&a=site&\";s:7:\"section\";a:4:{s:5:\"cloud\";a:2:{s:5:\"title\";s:9:\"云服务\";s:4:\"menu\";a:3:{s:14:\"system_profile\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"系统升级\";s:3:\"url\";s:30:\"./index.php?c=cloud&a=upgrade&\";s:15:\"permission_name\";s:20:\"system_cloud_upgrade\";s:4:\"icon\";s:11:\"wi wi-cache\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:21:\"system_cloud_register\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"注册站点\";s:3:\"url\";s:30:\"./index.php?c=cloud&a=profile&\";s:15:\"permission_name\";s:21:\"system_cloud_register\";s:4:\"icon\";s:18:\"wi wi-registersite\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:21:\"system_cloud_diagnose\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"云服务诊断\";s:3:\"url\";s:31:\"./index.php?c=cloud&a=diagnose&\";s:15:\"permission_name\";s:21:\"system_cloud_diagnose\";s:4:\"icon\";s:14:\"wi wi-diagnose\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"setting\";a:2:{s:5:\"title\";s:6:\"设置\";s:4:\"menu\";a:9:{s:19:\"system_setting_site\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"站点设置\";s:3:\"url\";s:28:\"./index.php?c=system&a=site&\";s:15:\"permission_name\";s:19:\"system_setting_site\";s:4:\"icon\";s:18:\"wi wi-site-setting\";s:12:\"displayorder\";i:9;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_setting_menu\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"菜单设置\";s:3:\"url\";s:28:\"./index.php?c=system&a=menu&\";s:15:\"permission_name\";s:19:\"system_setting_menu\";s:4:\"icon\";s:18:\"wi wi-menu-setting\";s:12:\"displayorder\";i:8;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_attachment\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"附件设置\";s:3:\"url\";s:34:\"./index.php?c=system&a=attachment&\";s:15:\"permission_name\";s:25:\"system_setting_attachment\";s:4:\"icon\";s:16:\"wi wi-attachment\";s:12:\"displayorder\";i:7;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_systeminfo\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"系统信息\";s:3:\"url\";s:34:\"./index.php?c=system&a=systeminfo&\";s:15:\"permission_name\";s:25:\"system_setting_systeminfo\";s:4:\"icon\";s:17:\"wi wi-system-info\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_setting_logs\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"查看日志\";s:3:\"url\";s:28:\"./index.php?c=system&a=logs&\";s:15:\"permission_name\";s:19:\"system_setting_logs\";s:4:\"icon\";s:9:\"wi wi-log\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:26:\"system_setting_ipwhitelist\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:11:\"IP白名单\";s:3:\"url\";s:35:\"./index.php?c=system&a=ipwhitelist&\";s:15:\"permission_name\";s:26:\"system_setting_ipwhitelist\";s:4:\"icon\";s:8:\"wi wi-ip\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:28:\"system_setting_sensitiveword\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"过滤敏感词\";s:3:\"url\";s:37:\"./index.php?c=system&a=sensitiveword&\";s:15:\"permission_name\";s:28:\"system_setting_sensitiveword\";s:4:\"icon\";s:15:\"wi wi-sensitive\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_thirdlogin\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:25:\"用户登录/注册设置\";s:3:\"url\";s:33:\"./index.php?c=user&a=registerset&\";s:15:\"permission_name\";s:25:\"system_setting_thirdlogin\";s:4:\"icon\";s:10:\"wi wi-user\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:20:\"system_setting_oauth\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"全局借用权限\";s:3:\"url\";s:29:\"./index.php?c=system&a=oauth&\";s:15:\"permission_name\";s:20:\"system_setting_oauth\";s:4:\"icon\";s:11:\"wi wi-oauth\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"utility\";a:2:{s:5:\"title\";s:12:\"常用工具\";s:4:\"menu\";a:6:{s:24:\"system_utility_filecheck\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"系统文件校验\";s:3:\"url\";s:33:\"./index.php?c=system&a=filecheck&\";s:15:\"permission_name\";s:24:\"system_utility_filecheck\";s:4:\"icon\";s:10:\"wi wi-file\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:23:\"system_utility_optimize\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"性能优化\";s:3:\"url\";s:32:\"./index.php?c=system&a=optimize&\";s:15:\"permission_name\";s:23:\"system_utility_optimize\";s:4:\"icon\";s:14:\"wi wi-optimize\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:23:\"system_utility_database\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"数据库\";s:3:\"url\";s:32:\"./index.php?c=system&a=database&\";s:15:\"permission_name\";s:23:\"system_utility_database\";s:4:\"icon\";s:9:\"wi wi-sql\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_utility_scan\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"木马查杀\";s:3:\"url\";s:28:\"./index.php?c=system&a=scan&\";s:15:\"permission_name\";s:19:\"system_utility_scan\";s:4:\"icon\";s:12:\"wi wi-safety\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:18:\"system_utility_bom\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"检测文件BOM\";s:3:\"url\";s:27:\"./index.php?c=system&a=bom&\";s:15:\"permission_name\";s:18:\"system_utility_bom\";s:4:\"icon\";s:9:\"wi wi-bom\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:20:\"system_utility_check\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"系统常规检测\";s:3:\"url\";s:29:\"./index.php?c=system&a=check&\";s:15:\"permission_name\";s:20:\"system_utility_check\";s:4:\"icon\";s:9:\"wi wi-bom\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"backjob\";a:2:{s:5:\"title\";s:12:\"后台任务\";s:4:\"menu\";a:1:{s:10:\"system_job\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"后台任务\";s:3:\"url\";s:38:\"./index.php?c=system&a=job&do=display&\";s:15:\"permission_name\";s:10:\"system_job\";s:4:\"icon\";s:9:\"wi wi-job\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:7:\"founder\";b:1;s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:10;}s:6:\"myself\";a:8:{s:5:\"title\";s:12:\"我的账户\";s:4:\"icon\";s:10:\"wi wi-bell\";s:9:\"dimension\";i:2;s:3:\"url\";s:29:\"./index.php?c=user&a=profile&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:11;}s:7:\"message\";a:8:{s:5:\"title\";s:12:\"消息管理\";s:4:\"icon\";s:10:\"wi wi-bell\";s:9:\"dimension\";i:2;s:3:\"url\";s:31:\"./index.php?c=message&a=notice&\";s:7:\"section\";a:1:{s:7:\"message\";a:2:{s:5:\"title\";s:12:\"消息管理\";s:4:\"menu\";a:3:{s:14:\"message_notice\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"消息提醒\";s:3:\"url\";s:31:\"./index.php?c=message&a=notice&\";s:15:\"permission_name\";s:14:\"message_notice\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:15:\"message_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"消息设置\";s:3:\"url\";s:42:\"./index.php?c=message&a=notice&do=setting&\";s:15:\"permission_name\";s:15:\"message_setting\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:22:\"message_wechat_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"微信提醒设置\";s:3:\"url\";s:49:\"./index.php?c=message&a=notice&do=wechat_setting&\";s:15:\"permission_name\";s:22:\"message_wechat_setting\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:12;}s:7:\"account\";a:8:{s:5:\"title\";s:9:\"公众号\";s:4:\"icon\";s:18:\"wi wi-white-collar\";s:9:\"dimension\";i:3;s:3:\"url\";s:41:\"./index.php?c=home&a=welcome&do=platform&\";s:7:\"section\";a:5:{s:8:\"platform\";a:4:{s:5:\"title\";s:12:\"增强功能\";s:4:\"menu\";a:6:{s:14:\"platform_reply\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"自动回复\";s:3:\"url\";s:31:\"./index.php?c=platform&a=reply&\";s:15:\"permission_name\";s:14:\"platform_reply\";s:4:\"icon\";s:11:\"wi wi-reply\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";a:7:{s:22:\"platform_reply_keyword\";a:4:{s:5:\"title\";s:21:\"关键字自动回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=keyword\";s:15:\"permission_name\";s:22:\"platform_reply_keyword\";s:6:\"active\";s:7:\"keyword\";}s:22:\"platform_reply_special\";a:4:{s:5:\"title\";s:24:\"非关键字自动回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=special\";s:15:\"permission_name\";s:22:\"platform_reply_special\";s:6:\"active\";s:7:\"special\";}s:22:\"platform_reply_welcome\";a:4:{s:5:\"title\";s:24:\"首次访问自动回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=welcome\";s:15:\"permission_name\";s:22:\"platform_reply_welcome\";s:6:\"active\";s:7:\"welcome\";}s:22:\"platform_reply_default\";a:4:{s:5:\"title\";s:12:\"默认回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=default\";s:15:\"permission_name\";s:22:\"platform_reply_default\";s:6:\"active\";s:7:\"default\";}s:22:\"platform_reply_service\";a:4:{s:5:\"title\";s:12:\"常用服务\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=service\";s:15:\"permission_name\";s:22:\"platform_reply_service\";s:6:\"active\";s:7:\"service\";}s:22:\"platform_reply_userapi\";a:5:{s:5:\"title\";s:21:\"自定义接口回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=userapi\";s:15:\"permission_name\";s:22:\"platform_reply_userapi\";s:6:\"active\";s:7:\"userapi\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:22:\"platform_reply_setting\";a:4:{s:5:\"title\";s:12:\"回复设置\";s:3:\"url\";s:38:\"./index.php?c=profile&a=reply-setting&\";s:15:\"permission_name\";s:22:\"platform_reply_setting\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}}}s:13:\"platform_menu\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:0;s:5:\"title\";s:15:\"自定义菜单\";s:3:\"url\";s:38:\"./index.php?c=platform&a=menu&do=post&\";s:15:\"permission_name\";s:13:\"platform_menu\";s:4:\"icon\";s:16:\"wi wi-custommenu\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:21:\"platform_menu_default\";a:4:{s:5:\"title\";s:12:\"默认菜单\";s:3:\"url\";s:38:\"./index.php?c=platform&a=menu&do=post&\";s:15:\"permission_name\";s:21:\"platform_menu_default\";s:6:\"active\";s:4:\"post\";}s:25:\"platform_menu_conditional\";a:5:{s:5:\"title\";s:15:\"个性化菜单\";s:3:\"url\";s:47:\"./index.php?c=platform&a=menu&do=display&type=3\";s:15:\"permission_name\";s:25:\"platform_menu_conditional\";s:6:\"active\";s:7:\"display\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}}}s:11:\"platform_qr\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:2:{i:0;i:1;i:1;i:3;}s:10:\"is_display\";i:0;s:5:\"title\";s:22:\"二维码/转化链接\";s:3:\"url\";s:28:\"./index.php?c=platform&a=qr&\";s:15:\"permission_name\";s:11:\"platform_qr\";s:4:\"icon\";s:12:\"wi wi-qrcode\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:14:\"platform_qr_qr\";a:4:{s:5:\"title\";s:9:\"二维码\";s:3:\"url\";s:36:\"./index.php?c=platform&a=qr&do=list&\";s:15:\"permission_name\";s:14:\"platform_qr_qr\";s:6:\"active\";s:4:\"list\";}s:22:\"platform_qr_statistics\";a:4:{s:5:\"title\";s:21:\"二维码扫描统计\";s:3:\"url\";s:39:\"./index.php?c=platform&a=qr&do=display&\";s:15:\"permission_name\";s:22:\"platform_qr_statistics\";s:6:\"active\";s:7:\"display\";}}}s:17:\"platform_masstask\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"定时群发\";s:3:\"url\";s:30:\"./index.php?c=platform&a=mass&\";s:15:\"permission_name\";s:17:\"platform_masstask\";s:4:\"icon\";s:13:\"wi wi-crontab\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:22:\"platform_masstask_post\";a:4:{s:5:\"title\";s:12:\"定时群发\";s:3:\"url\";s:38:\"./index.php?c=platform&a=mass&do=post&\";s:15:\"permission_name\";s:22:\"platform_masstask_post\";s:6:\"active\";s:4:\"post\";}s:22:\"platform_masstask_send\";a:4:{s:5:\"title\";s:12:\"群发记录\";s:3:\"url\";s:38:\"./index.php?c=platform&a=mass&do=send&\";s:15:\"permission_name\";s:22:\"platform_masstask_send\";s:6:\"active\";s:4:\"send\";}}}s:17:\"platform_material\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:0;s:5:\"title\";s:16:\"素材/编辑器\";s:3:\"url\";s:34:\"./index.php?c=platform&a=material&\";s:15:\"permission_name\";s:17:\"platform_material\";s:4:\"icon\";s:12:\"wi wi-redact\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:5:{s:22:\"platform_material_news\";a:4:{s:5:\"title\";s:6:\"图文\";s:3:\"url\";s:43:\"./index.php?c=platform&a=material&type=news\";s:15:\"permission_name\";s:22:\"platform_material_news\";s:6:\"active\";s:4:\"news\";}s:23:\"platform_material_image\";a:4:{s:5:\"title\";s:6:\"图片\";s:3:\"url\";s:44:\"./index.php?c=platform&a=material&type=image\";s:15:\"permission_name\";s:23:\"platform_material_image\";s:6:\"active\";s:5:\"image\";}s:23:\"platform_material_voice\";a:4:{s:5:\"title\";s:6:\"语音\";s:3:\"url\";s:44:\"./index.php?c=platform&a=material&type=voice\";s:15:\"permission_name\";s:23:\"platform_material_voice\";s:6:\"active\";s:5:\"voice\";}s:23:\"platform_material_video\";a:5:{s:5:\"title\";s:6:\"视频\";s:3:\"url\";s:44:\"./index.php?c=platform&a=material&type=video\";s:15:\"permission_name\";s:23:\"platform_material_video\";s:6:\"active\";s:5:\"video\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:24:\"platform_material_delete\";a:3:{s:5:\"title\";s:6:\"删除\";s:15:\"permission_name\";s:24:\"platform_material_delete\";s:10:\"is_display\";b:0;}}}s:13:\"platform_site\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:2:{i:0;i:1;i:1;i:3;}s:10:\"is_display\";i:0;s:5:\"title\";s:16:\"微官网-文章\";s:3:\"url\";s:27:\"./index.php?c=site&a=multi&\";s:15:\"permission_name\";s:13:\"platform_site\";s:4:\"icon\";s:10:\"wi wi-home\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:4:{s:19:\"platform_site_multi\";a:4:{s:5:\"title\";s:9:\"微官网\";s:3:\"url\";s:38:\"./index.php?c=site&a=multi&do=display&\";s:15:\"permission_name\";s:19:\"platform_site_multi\";s:6:\"active\";s:5:\"multi\";}s:19:\"platform_site_style\";a:4:{s:5:\"title\";s:15:\"微官网模板\";s:3:\"url\";s:39:\"./index.php?c=site&a=style&do=template&\";s:15:\"permission_name\";s:19:\"platform_site_style\";s:6:\"active\";s:5:\"style\";}s:21:\"platform_site_article\";a:4:{s:5:\"title\";s:12:\"文章管理\";s:3:\"url\";s:40:\"./index.php?c=site&a=article&do=display&\";s:15:\"permission_name\";s:21:\"platform_site_article\";s:6:\"active\";s:7:\"article\";}s:22:\"platform_site_category\";a:4:{s:5:\"title\";s:18:\"文章分类管理\";s:3:\"url\";s:41:\"./index.php?c=site&a=category&do=display&\";s:15:\"permission_name\";s:22:\"platform_site_category\";s:6:\"active\";s:8:\"category\";}}}}s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:0;}s:15:\"platform_module\";a:3:{s:5:\"title\";s:12:\"应用模块\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:2:\"mc\";a:4:{s:5:\"title\";s:6:\"粉丝\";s:4:\"menu\";a:3:{s:7:\"mc_fans\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"粉丝管理\";s:3:\"url\";s:24:\"./index.php?c=mc&a=fans&\";s:15:\"permission_name\";s:7:\"mc_fans\";s:4:\"icon\";s:16:\"wi wi-fansmanage\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:15:\"mc_fans_display\";a:4:{s:5:\"title\";s:12:\"全部粉丝\";s:3:\"url\";s:35:\"./index.php?c=mc&a=fans&do=display&\";s:15:\"permission_name\";s:15:\"mc_fans_display\";s:6:\"active\";s:7:\"display\";}s:21:\"mc_fans_fans_sync_set\";a:4:{s:5:\"title\";s:18:\"粉丝同步设置\";s:3:\"url\";s:41:\"./index.php?c=mc&a=fans&do=fans_sync_set&\";s:15:\"permission_name\";s:21:\"mc_fans_fans_sync_set\";s:6:\"active\";s:13:\"fans_sync_set\";}}}s:9:\"mc_member\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"会员管理\";s:3:\"url\";s:26:\"./index.php?c=mc&a=member&\";s:15:\"permission_name\";s:9:\"mc_member\";s:4:\"icon\";s:10:\"wi wi-fans\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:7:{s:17:\"mc_member_diaplsy\";a:4:{s:5:\"title\";s:12:\"会员管理\";s:3:\"url\";s:37:\"./index.php?c=mc&a=member&do=display&\";s:15:\"permission_name\";s:17:\"mc_member_diaplsy\";s:6:\"active\";s:7:\"display\";}s:15:\"mc_member_group\";a:4:{s:5:\"title\";s:9:\"会员组\";s:3:\"url\";s:36:\"./index.php?c=mc&a=group&do=display&\";s:15:\"permission_name\";s:15:\"mc_member_group\";s:6:\"active\";s:7:\"display\";}s:12:\"mc_member_uc\";a:5:{s:5:\"title\";s:12:\"会员中心\";s:3:\"url\";s:34:\"./index.php?c=site&a=editor&do=uc&\";s:15:\"permission_name\";s:12:\"mc_member_uc\";s:6:\"active\";s:2:\"uc\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:19:\"mc_member_quickmenu\";a:5:{s:5:\"title\";s:12:\"快捷菜单\";s:3:\"url\";s:41:\"./index.php?c=site&a=editor&do=quickmenu&\";s:15:\"permission_name\";s:19:\"mc_member_quickmenu\";s:6:\"active\";s:9:\"quickmenu\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:25:\"mc_member_register_seting\";a:5:{s:5:\"title\";s:12:\"注册设置\";s:3:\"url\";s:46:\"./index.php?c=mc&a=member&do=register_setting&\";s:15:\"permission_name\";s:25:\"mc_member_register_seting\";s:6:\"active\";s:16:\"register_setting\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:24:\"mc_member_credit_setting\";a:4:{s:5:\"title\";s:12:\"积分设置\";s:3:\"url\";s:44:\"./index.php?c=mc&a=member&do=credit_setting&\";s:15:\"permission_name\";s:24:\"mc_member_credit_setting\";s:6:\"active\";s:14:\"credit_setting\";}s:16:\"mc_member_fields\";a:4:{s:5:\"title\";s:18:\"会员字段管理\";s:3:\"url\";s:34:\"./index.php?c=mc&a=fields&do=list&\";s:15:\"permission_name\";s:16:\"mc_member_fields\";s:6:\"active\";s:4:\"list\";}}}s:10:\"mc_message\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"留言管理\";s:3:\"url\";s:27:\"./index.php?c=mc&a=message&\";s:15:\"permission_name\";s:10:\"mc_message\";s:4:\"icon\";s:13:\"wi wi-message\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}s:10:\"is_display\";i:0;}s:7:\"profile\";a:4:{s:5:\"title\";s:6:\"配置\";s:4:\"menu\";a:7:{s:15:\"profile_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"参数配置\";s:3:\"url\";s:31:\"./index.php?c=profile&a=remote&\";s:15:\"permission_name\";s:15:\"profile_setting\";s:4:\"icon\";s:23:\"wi wi-parameter-setting\";s:12:\"displayorder\";i:7;s:2:\"id\";N;s:14:\"sub_permission\";a:6:{s:22:\"profile_setting_remote\";a:4:{s:5:\"title\";s:12:\"远程附件\";s:3:\"url\";s:42:\"./index.php?c=profile&a=remote&do=display&\";s:15:\"permission_name\";s:22:\"profile_setting_remote\";s:6:\"active\";s:7:\"display\";}s:24:\"profile_setting_passport\";a:5:{s:5:\"title\";s:12:\"借用权限\";s:3:\"url\";s:42:\"./index.php?c=profile&a=passport&do=oauth&\";s:15:\"permission_name\";s:24:\"profile_setting_passport\";s:6:\"active\";s:5:\"oauth\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:25:\"profile_setting_tplnotice\";a:5:{s:5:\"title\";s:18:\"微信通知设置\";s:3:\"url\";s:42:\"./index.php?c=profile&a=tplnotice&do=list&\";s:15:\"permission_name\";s:25:\"profile_setting_tplnotice\";s:6:\"active\";s:4:\"list\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:22:\"profile_setting_notify\";a:5:{s:5:\"title\";s:18:\"邮件通知参数\";s:3:\"url\";s:39:\"./index.php?c=profile&a=notify&do=mail&\";s:15:\"permission_name\";s:22:\"profile_setting_notify\";s:6:\"active\";s:4:\"mail\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:26:\"profile_setting_uc_setting\";a:5:{s:5:\"title\";s:14:\"UC站点整合\";s:3:\"url\";s:45:\"./index.php?c=profile&a=common&do=uc_setting&\";s:15:\"permission_name\";s:26:\"profile_setting_uc_setting\";s:6:\"active\";s:10:\"uc_setting\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:27:\"profile_setting_upload_file\";a:5:{s:5:\"title\";s:20:\"上传JS接口文件\";s:3:\"url\";s:46:\"./index.php?c=profile&a=common&do=upload_file&\";s:15:\"permission_name\";s:27:\"profile_setting_upload_file\";s:6:\"active\";s:11:\"upload_file\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}}}s:15:\"profile_payment\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:2:{i:0;i:1;i:1;i:3;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"支付参数\";s:3:\"url\";s:32:\"./index.php?c=profile&a=payment&\";s:15:\"permission_name\";s:15:\"profile_payment\";s:4:\"icon\";s:17:\"wi wi-pay-setting\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:19:\"profile_payment_pay\";a:4:{s:5:\"title\";s:12:\"支付配置\";s:3:\"url\";s:32:\"./index.php?c=profile&a=payment&\";s:15:\"permission_name\";s:19:\"profile_payment_pay\";s:6:\"active\";s:7:\"payment\";}s:22:\"profile_payment_refund\";a:4:{s:5:\"title\";s:12:\"退款配置\";s:3:\"url\";s:42:\"./index.php?c=profile&a=refund&do=display&\";s:15:\"permission_name\";s:22:\"profile_payment_refund\";s:6:\"active\";s:6:\"refund\";}}}s:23:\"profile_app_module_link\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"数据同步\";s:3:\"url\";s:44:\"./index.php?c=profile&a=module-link-uniacid&\";s:15:\"permission_name\";s:31:\"profile_app_module_link_uniacid\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"profile_bind_domain\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"域名绑定\";s:3:\"url\";s:36:\"./index.php?c=profile&a=bind-domain&\";s:15:\"permission_name\";s:19:\"profile_bind_domain\";s:4:\"icon\";s:17:\"wi wi-bind-domain\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:18:\"webapp_module_link\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:1:{i:0;i:5;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"数据同步\";s:3:\"url\";s:44:\"./index.php?c=profile&a=module-link-uniacid&\";s:15:\"permission_name\";s:18:\"webapp_module_link\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:14:\"webapp_rewrite\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:1:{i:0;i:5;}s:10:\"is_display\";i:0;s:5:\"title\";s:9:\"伪静态\";s:3:\"url\";s:31:\"./index.php?c=webapp&a=rewrite&\";s:15:\"permission_name\";s:14:\"webapp_rewrite\";s:4:\"icon\";s:13:\"wi wi-rewrite\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:18:\"webapp_bind_domain\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:1:{i:0;i:5;}s:10:\"is_display\";i:0;s:5:\"title\";s:18:\"域名访问设置\";s:3:\"url\";s:35:\"./index.php?c=webapp&a=bind-domain&\";s:15:\"permission_name\";s:18:\"webapp_bind_domain\";s:4:\"icon\";s:17:\"wi wi-bind-domain\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}s:10:\"is_display\";i:0;}s:10:\"statistics\";a:4:{s:5:\"title\";s:6:\"统计\";s:4:\"menu\";a:2:{s:16:\"statistics_visit\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"访问统计\";s:3:\"url\";s:31:\"./index.php?c=statistics&a=app&\";s:15:\"permission_name\";s:16:\"statistics_visit\";s:4:\"icon\";s:17:\"wi wi-statistical\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:3:{s:20:\"statistics_visit_app\";a:4:{s:5:\"title\";s:24:\"app端访问统计信息\";s:3:\"url\";s:42:\"./index.php?c=statistics&a=app&do=display&\";s:15:\"permission_name\";s:20:\"statistics_visit_app\";s:6:\"active\";s:3:\"app\";}s:21:\"statistics_visit_site\";a:4:{s:5:\"title\";s:24:\"所有用户访问统计\";s:3:\"url\";s:51:\"./index.php?c=statistics&a=site&do=current_account&\";s:15:\"permission_name\";s:21:\"statistics_visit_site\";s:6:\"active\";s:4:\"site\";}s:24:\"statistics_visit_setting\";a:4:{s:5:\"title\";s:18:\"访问统计设置\";s:3:\"url\";s:46:\"./index.php?c=statistics&a=setting&do=display&\";s:15:\"permission_name\";s:24:\"statistics_visit_setting\";s:6:\"active\";s:7:\"setting\";}}}s:15:\"statistics_fans\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"用户统计\";s:3:\"url\";s:32:\"./index.php?c=statistics&a=fans&\";s:15:\"permission_name\";s:15:\"statistics_fans\";s:4:\"icon\";s:17:\"wi wi-statistical\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}s:10:\"is_display\";i:0;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:13;}s:5:\"wxapp\";a:8:{s:5:\"title\";s:15:\"微信小程序\";s:4:\"icon\";s:19:\"wi wi-small-routine\";s:9:\"dimension\";i:3;s:3:\"url\";s:38:\"./index.php?c=wxapp&a=display&do=home&\";s:7:\"section\";a:5:{s:14:\"wxapp_entrance\";a:4:{s:5:\"title\";s:15:\"小程序入口\";s:4:\"menu\";a:1:{s:20:\"module_entrance_link\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"入口页面\";s:3:\"url\";s:36:\"./index.php?c=wxapp&a=entrance-link&\";s:15:\"permission_name\";s:19:\"wxapp_entrance_link\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;}s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:2:\"mc\";a:4:{s:5:\"title\";s:6:\"粉丝\";s:4:\"menu\";a:1:{s:9:\"mc_member\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:6:\"会员\";s:3:\"url\";s:26:\"./index.php?c=mc&a=member&\";s:15:\"permission_name\";s:15:\"mc_wxapp_member\";s:4:\"icon\";s:10:\"wi wi-fans\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:4:{s:17:\"mc_member_diaplsy\";a:4:{s:5:\"title\";s:12:\"会员管理\";s:3:\"url\";s:37:\"./index.php?c=mc&a=member&do=display&\";s:15:\"permission_name\";s:17:\"mc_member_diaplsy\";s:6:\"active\";s:7:\"display\";}s:15:\"mc_member_group\";a:4:{s:5:\"title\";s:9:\"会员组\";s:3:\"url\";s:36:\"./index.php?c=mc&a=group&do=display&\";s:15:\"permission_name\";s:15:\"mc_member_group\";s:6:\"active\";s:7:\"display\";}s:24:\"mc_member_credit_setting\";a:4:{s:5:\"title\";s:12:\"积分设置\";s:3:\"url\";s:44:\"./index.php?c=mc&a=member&do=credit_setting&\";s:15:\"permission_name\";s:24:\"mc_member_credit_setting\";s:6:\"active\";s:14:\"credit_setting\";}s:16:\"mc_member_fields\";a:4:{s:5:\"title\";s:18:\"会员字段管理\";s:3:\"url\";s:34:\"./index.php?c=mc&a=fields&do=list&\";s:15:\"permission_name\";s:16:\"mc_member_fields\";s:6:\"active\";s:4:\"list\";}}}}s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;}s:13:\"wxapp_profile\";a:3:{s:5:\"title\";s:6:\"配置\";s:4:\"menu\";a:5:{s:33:\"wxapp_profile_module_link_uniacid\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:7:{i:0;i:4;i:1;i:7;i:2;i:8;i:3;i:6;i:4;i:11;i:5;i:12;i:6;i:13;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"数据同步\";s:3:\"url\";s:42:\"./index.php?c=wxapp&a=module-link-uniacid&\";s:15:\"permission_name\";s:33:\"wxapp_profile_module_link_uniacid\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:21:\"wxapp_profile_payment\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"支付参数\";s:3:\"url\";s:30:\"./index.php?c=wxapp&a=payment&\";s:15:\"permission_name\";s:21:\"wxapp_profile_payment\";s:4:\"icon\";s:16:\"wi wi-appsetting\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:17:\"wxapp_payment_pay\";a:4:{s:5:\"title\";s:12:\"支付参数\";s:3:\"url\";s:41:\"./index.php?c=wxapp&a=payment&do=display&\";s:15:\"permission_name\";s:17:\"wxapp_payment_pay\";s:6:\"active\";s:7:\"payment\";}s:20:\"wxapp_payment_refund\";a:4:{s:5:\"title\";s:12:\"退款配置\";s:3:\"url\";s:40:\"./index.php?c=wxapp&a=refund&do=display&\";s:15:\"permission_name\";s:20:\"wxapp_payment_refund\";s:6:\"active\";s:6:\"refund\";}}}s:28:\"wxapp_profile_front_download\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"下载程序包\";s:3:\"url\";s:37:\"./index.php?c=wxapp&a=front-download&\";s:15:\"permission_name\";s:28:\"wxapp_profile_front_download\";s:4:\"icon\";s:13:\"wi wi-examine\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:23:\"wxapp_profile_domainset\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"域名设置\";s:3:\"url\";s:32:\"./index.php?c=wxapp&a=domainset&\";s:15:\"permission_name\";s:23:\"wxapp_profile_domainset\";s:4:\"icon\";s:13:\"wi wi-examine\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:22:\"profile_setting_remote\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"参数配置\";s:3:\"url\";s:31:\"./index.php?c=profile&a=remote&\";s:15:\"permission_name\";s:22:\"profile_setting_remote\";s:4:\"icon\";s:23:\"wi wi-parameter-setting\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:7:{i:0;i:4;i:1;i:7;i:2;i:8;i:3;i:6;i:4;i:11;i:5;i:12;i:6;i:13;}}s:10:\"statistics\";a:4:{s:5:\"title\";s:6:\"统计\";s:4:\"menu\";a:1:{s:16:\"statistics_visit\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:7:{i:0;i:4;i:1;i:7;i:2;i:8;i:3;i:6;i:4;i:11;i:5;i:12;i:6;i:13;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"访问统计\";s:3:\"url\";s:31:\"./index.php?c=statistics&a=app&\";s:15:\"permission_name\";s:22:\"statistics_visit_wxapp\";s:4:\"icon\";s:17:\"wi wi-statistical\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:3:{s:20:\"statistics_visit_app\";a:4:{s:5:\"title\";s:24:\"app端访问统计信息\";s:3:\"url\";s:42:\"./index.php?c=statistics&a=app&do=display&\";s:15:\"permission_name\";s:20:\"statistics_visit_app\";s:6:\"active\";s:3:\"app\";}s:21:\"statistics_visit_site\";a:4:{s:5:\"title\";s:24:\"所有用户访问统计\";s:3:\"url\";s:51:\"./index.php?c=statistics&a=site&do=current_account&\";s:15:\"permission_name\";s:21:\"statistics_visit_site\";s:6:\"active\";s:4:\"site\";}s:24:\"statistics_visit_setting\";a:4:{s:5:\"title\";s:18:\"访问统计设置\";s:3:\"url\";s:46:\"./index.php?c=statistics&a=setting&do=display&\";s:15:\"permission_name\";s:24:\"statistics_visit_setting\";s:6:\"active\";s:7:\"setting\";}}}}s:18:\"permission_display\";a:7:{i:0;i:4;i:1;i:7;i:2;i:8;i:3;i:6;i:4;i:11;i:5;i:12;i:6;i:13;}s:10:\"is_display\";i:0;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:14;}s:6:\"webapp\";a:7:{s:5:\"title\";s:2:\"PC\";s:4:\"icon\";s:8:\"wi wi-pc\";s:3:\"url\";s:39:\"./index.php?c=webapp&a=home&do=display&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:15;}s:5:\"xzapp\";a:7:{s:5:\"title\";s:9:\"熊掌号\";s:4:\"icon\";s:11:\"wi wi-xzapp\";s:3:\"url\";s:38:\"./index.php?c=xzapp&a=home&do=display&\";s:7:\"section\";a:1:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:12:\"应用模块\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:16;}s:6:\"aliapp\";a:7:{s:5:\"title\";s:18:\"支付宝小程序\";s:4:\"icon\";s:12:\"wi wi-aliapp\";s:3:\"url\";s:40:\"./index.php?c=miniapp&a=display&do=home&\";s:7:\"section\";a:1:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:17;}s:8:\"baiduapp\";a:7:{s:5:\"title\";s:15:\"百度小程序\";s:4:\"icon\";s:14:\"wi wi-baiduapp\";s:3:\"url\";s:40:\"./index.php?c=miniapp&a=display&do=home&\";s:7:\"section\";a:1:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:18;}s:10:\"toutiaoapp\";a:7:{s:5:\"title\";s:15:\"头条小程序\";s:4:\"icon\";s:16:\"wi wi-toutiaoapp\";s:3:\"url\";s:40:\"./index.php?c=miniapp&a=display&do=home&\";s:7:\"section\";a:1:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:19;}s:5:\"store\";a:7:{s:5:\"title\";s:6:\"商城\";s:4:\"icon\";s:11:\"wi wi-store\";s:3:\"url\";s:43:\"./index.php?c=home&a=welcome&do=ext&m=store\";s:7:\"section\";a:6:{s:11:\"store_goods\";a:2:{s:5:\"title\";s:12:\"商品分类\";s:4:\"menu\";a:6:{s:18:\"store_goods_module\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"应用模块\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=1\";s:15:\"permission_name\";s:18:\"store_goods_module\";s:4:\"icon\";s:11:\"wi wi-apply\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"store_goods_account\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"平台个数\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=2\";s:15:\"permission_name\";s:19:\"store_goods_account\";s:4:\"icon\";s:13:\"wi wi-account\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"store_goods_account_renew\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"平台续费\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=7\";s:15:\"permission_name\";s:25:\"store_goods_account_renew\";s:4:\"icon\";s:21:\"wi wi-appjurisdiction\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"store_goods_package\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"应用权限组\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=5\";s:15:\"permission_name\";s:19:\"store_goods_package\";s:4:\"icon\";s:21:\"wi wi-appjurisdiction\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"store_goods_users_package\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"用户权限组\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=9\";s:15:\"permission_name\";s:25:\"store_goods_users_package\";s:4:\"icon\";s:22:\"wi wi-userjurisdiction\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:15:\"store_goods_api\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:23:\"应用访问流量(API)\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=6\";s:15:\"permission_name\";s:15:\"store_goods_api\";s:4:\"icon\";s:9:\"wi wi-api\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:12:\"store_manage\";a:3:{s:5:\"title\";s:12:\"商城管理\";s:7:\"founder\";b:1;s:4:\"menu\";a:4:{s:18:\"store_manage_goods\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"添加商品\";s:3:\"url\";s:58:\"./index.php?c=site&a=entry&do=goodsSeller&m=store&direct=1\";s:15:\"permission_name\";s:18:\"store_manage_goods\";s:4:\"icon\";s:15:\"wi wi-goods-add\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:20:\"store_manage_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"商城设置\";s:3:\"url\";s:54:\"./index.php?c=site&a=entry&do=setting&m=store&direct=1\";s:15:\"permission_name\";s:20:\"store_manage_setting\";s:4:\"icon\";s:11:\"wi wi-store\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"store_manage_payset\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"支付设置\";s:3:\"url\";s:57:\"./index.php?c=site&a=entry&do=paySetting&m=store&direct=1\";s:15:\"permission_name\";s:19:\"store_manage_payset\";s:4:\"icon\";s:11:\"wi wi-money\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:23:\"store_manage_permission\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"商城访问权限\";s:3:\"url\";s:57:\"./index.php?c=site&a=entry&do=permission&m=store&direct=1\";s:15:\"permission_name\";s:23:\"store_manage_permission\";s:4:\"icon\";s:15:\"wi wi-blacklist\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:12:\"store_orders\";a:2:{s:5:\"title\";s:12:\"订单管理\";s:4:\"menu\";a:2:{s:15:\"store_orders_my\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"我的订单\";s:3:\"url\";s:53:\"./index.php?c=site&a=entry&do=orders&m=store&direct=1\";s:15:\"permission_name\";s:15:\"store_orders_my\";s:4:\"icon\";s:17:\"wi wi-sale-record\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:17:\"store_cash_orders\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"分销订单\";s:3:\"url\";s:71:\"./index.php?c=site&a=entry&do=cash&m=store&operate=cash_orders&direct=1\";s:15:\"permission_name\";s:17:\"store_cash_orders\";s:4:\"icon\";s:11:\"wi wi-order\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:14:\"store_payments\";a:2:{s:5:\"title\";s:12:\"收入明细\";s:4:\"menu\";a:1:{s:8:\"payments\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"收入明细\";s:3:\"url\";s:55:\"./index.php?c=site&a=entry&do=payments&m=store&direct=1\";s:15:\"permission_name\";s:8:\"payments\";s:4:\"icon\";s:17:\"wi wi-sale-record\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:17:\"store_cash_manage\";a:2:{s:5:\"title\";s:12:\"分销管理\";s:4:\"menu\";a:2:{s:25:\"store_manage_cash_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"分销设置\";s:3:\"url\";s:58:\"./index.php?c=site&a=entry&do=cashsetting&m=store&direct=1\";s:15:\"permission_name\";s:25:\"store_manage_cash_setting\";s:4:\"icon\";s:18:\"wi wi-site-setting\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:16:\"store_check_cash\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"提现审核\";s:3:\"url\";s:73:\"./index.php?c=site&a=entry&do=cash&m=store&operate=consume_order&direct=1\";s:15:\"permission_name\";s:16:\"store_check_cash\";s:4:\"icon\";s:18:\"wi wi-check-select\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:10:\"store_cash\";a:2:{s:5:\"title\";s:12:\"佣金管理\";s:4:\"menu\";a:1:{s:8:\"payments\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"我的佣金\";s:3:\"url\";s:66:\"./index.php?c=site&a=entry&do=cash&m=store&operate=mycash&direct=1\";s:15:\"permission_name\";s:8:\"payments\";s:4:\"icon\";s:10:\"wi wi-list\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:20;}s:11:\"custom_help\";a:7:{s:5:\"title\";s:12:\"本站帮助\";s:4:\"icon\";s:12:\"wi wi-market\";s:3:\"url\";s:39:\"./index.php?c=help&a=display&do=custom&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:21;}}');
INSERT INTO `ims_core_cache` VALUES ('we7:uni_groups:0', 'a:1:{i:1;a:8:{s:2:\"id\";s:1:\"1\";s:9:\"owner_uid\";s:1:\"0\";s:4:\"name\";s:18:\"体验套餐服务\";s:7:\"modules\";s:2:\"N;\";s:9:\"templates\";a:0:{}s:7:\"uniacid\";s:1:\"0\";s:3:\"uid\";s:1:\"0\";s:11:\"modules_all\";a:0:{}}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:tiger_newhu:2', 'a:7:{s:2:\"id\";s:1:\"1\";s:7:\"uniacid\";s:1:\"2\";s:6:\"module\";s:11:\"tiger_newhu\";s:7:\"enabled\";s:1:\"1\";s:8:\"settings\";s:8755:\"a:237:{s:6:\"ddcjxz\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:6:\"ddcjjl\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:5:\"fyrmb\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:4:\"zgfa\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:4:\"yjfa\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:4:\"ejfa\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:9:\"diyyjtype\";s:1:\"0\";s:10:\"dlgzsdtype\";s:1:\"1\";s:8:\"cjlxtype\";s:1:\"0\";s:8:\"dztypelx\";s:1:\"0\";s:19:\"tiger_newhu_fansnum\";N;s:15:\"tiger_newhu_usr\";s:361:\"认证订阅号设置：#领取积分# \r\n链接设置例如:<a href=\'#领取积分#\'>点我领取积分</a> \r\n粉丝昵称：#昵称# \r\n粉丝姓别：#性别# \r\n粉丝积分：#积分# \r\n粉丝余额：#余额# \r\n公众号名称：#公众号名称# \r\n国家：#国家# \r\n省份：#省# \r\n市/县：#市# \r\n链接:<a href=\'http://www.baidu.com\'>点击进入</a>\";s:14:\"nbfchangemoney\";N;s:13:\"nbfhelpgeturl\";N;s:12:\"nbfwxpaypath\";N;s:5:\"mchid\";s:0:\"\";s:6:\"apikey\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:6:\"secret\";s:0:\"\";s:6:\"txtype\";s:1:\"0\";s:10:\"jdppddtype\";s:1:\"0\";s:5:\"szurl\";N;s:9:\"client_ip\";s:0:\"\";s:7:\"szcolor\";N;s:7:\"rmb_num\";N;s:7:\"day_num\";N;s:6:\"tx_num\";N;s:7:\"tklleft\";s:0:\"\";s:8:\"tklright\";s:0:\"\";s:6:\"hztype\";s:0:\"\";s:6:\"qdcode\";N;s:8:\"regurlxy\";s:0:\"\";s:5:\"qdpid\";s:0:\"\";s:6:\"btjzcq\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:6:\"txinfo\";s:0:\"\";s:12:\"locationtype\";s:1:\"3\";s:7:\"jiequan\";s:1:\"0\";s:7:\"paihang\";s:1:\"0\";s:5:\"style\";s:6:\"style2\";s:4:\"head\";N;s:4:\"txon\";N;s:7:\"gztitle\";s:0:\"\";s:8:\"gzpicurl\";s:0:\"\";s:13:\"gzdescription\";s:0:\"\";s:5:\"gzurl\";s:0:\"\";s:6:\"towurl\";N;s:4:\"cjss\";N;s:9:\"serackkey\";s:42:\"长袖衬衫|连衣裙|内衣|毛绒衬衫\";s:9:\"logintype\";s:1:\"0\";s:8:\"hlAppKey\";s:0:\"\";s:6:\"cjddgz\";s:0:\"\";s:8:\"gdfxtype\";s:1:\"0\";s:13:\"choujiangtype\";s:1:\"0\";s:7:\"pddtjdd\";s:1:\"0\";s:8:\"pddwenan\";s:253:\"商品名称：#名称##换行#\r\n推荐理由：#推荐理由##换行#\r\n商品原价：#原价#元#换行#\r\n券后价：#券后价#元#换行#\r\n优惠券：#优惠券#元#换行#\r\n奖励：#奖励##换行#\r\n拼多多链接：#拼多多短网址##换行#\";s:11:\"jdviewwenan\";s:205:\"商品名称：#名称##换行#\r\n推荐理由：#推荐理由##换行#\r\n商品原价：#原价#元#换行#\r\n券后价：#券后价#元#换行#\r\n优惠券：#优惠券#元#换行#\r\n链接：#网址##换行#\";s:12:\"pddviewwenan\";s:205:\"商品名称：#名称##换行#\r\n推荐理由：#推荐理由##换行#\r\n商品原价：#原价#元#换行#\r\n券后价：#券后价#元#换行#\r\n优惠券：#优惠券#元#换行#\r\n链接：#网址##换行#\";s:11:\"yqycjiangli\";s:1:\"0\";s:11:\"kuaizhanurl\";s:0:\"\";s:5:\"tljfl\";s:0:\"\";s:6:\"qdtype\";s:1:\"0\";s:7:\"qdtgurl\";s:0:\"\";s:6:\"dxtype\";s:1:\"0\";s:7:\"smstype\";s:4:\"dayu\";s:6:\"juhesj\";N;s:8:\"cxsqtype\";i:2;s:8:\"dyAppKey\";s:0:\"\";s:11:\"dyAppSecret\";s:0:\"\";s:20:\"dysms_free_sign_name\";s:0:\"\";s:19:\"dysms_template_code\";s:0:\"\";s:8:\"jhappkey\";s:0:\"\";s:6:\"jhcode\";s:0:\"\";s:6:\"gzljcj\";s:1:\"2\";s:10:\"qiandaormb\";s:1:\"3\";s:6:\"hmyxtp\";s:0:\"\";s:5:\"pddcq\";s:1:\"1\";s:4:\"jdcq\";s:1:\"1\";s:10:\"appfxtltle\";N;s:12:\"appfxcontent\";N;s:5:\"ygzhf\";s:197:\"粉丝昵称：#昵称# \r\n粉丝积分：#积分# \r\n粉丝余额：#余额# \r\n公众号名称：#公众号名称# \r\n如：#昵称#您已经是#公众号名称#的粉丝了！当前积分是#积分#\";s:11:\"tbviewwenan\";N;s:5:\"gzewm\";s:0:\"\";s:5:\"kfewm\";s:0:\"\";s:7:\"hdtitle\";N;s:9:\"hdcontent\";N;s:7:\"qtstyle\";s:7:\"style99\";s:9:\"dhcontent\";N;s:9:\"dtkAppKey\";s:0:\"\";s:5:\"ptpid\";s:36:\"mm_711720113_1065450073_109733950492\";s:5:\"qqpid\";s:0:\"\";s:8:\"tkAppKey\";s:8:\"28111962\";s:11:\"tksecretKey\";s:32:\"654f07152ae3af11c7e4a84feb1df9b4\";s:10:\"jqtkAppKey\";s:0:\"\";s:13:\"jqtksecretKey\";s:0:\"\";s:6:\"sdjltx\";s:38:\"晒单成功!\\n奖励您#积分#积分\";s:6:\"sjjltx\";s:58:\"您的朋友#昵称#晒单成功!\\n奖励您#积分#积分\";s:5:\"miyao\";s:2:\"18\";s:10:\"qiandaourl\";s:0:\"\";s:7:\"jfscurl\";s:0:\"\";s:6:\"fxtype\";s:1:\"2\";s:3:\"zgf\";s:2:\"40\";s:3:\"yjf\";s:2:\"30\";s:3:\"ejf\";s:2:\"20\";s:4:\"fxkg\";s:1:\"1\";s:6:\"yjtype\";s:3:\"100\";s:9:\"cjssclass\";N;s:7:\"fxtitle\";s:0:\"\";s:9:\"fxcontent\";s:0:\"\";s:8:\"fxpicurl\";s:0:\"\";s:4:\"lbtx\";s:1:\"0\";s:5:\"gzhfl\";s:1:\"1\";s:5:\"flmsg\";s:396:\"昵称：#昵称#\r\n商品名称：#名称#\r\n商品原价：#原价#\r\n券后价：#券后价#\r\n总优惠后价：#惠后价# (选择返积分无效)\r\n总优惠金额：#总优惠# (选择返积分无效)\r\n优惠券：#优惠券# (优惠券如果没有提示，暂无优惠券)\r\n好评后优惠约：#返现金额#\r\n淘口令：#淘口令#\r\n购买地址：#短网址#\r\n同类产品：#同类产品#\";s:6:\"flmsg1\";s:0:\"\";s:5:\"jzcjq\";s:1:\"0\";s:8:\"newflmsg\";s:100:\"昵称：#昵称#你好\r\n你要找【#名称#】吗？\r\n点击查看更多相关内容：#短网址#\";s:8:\"adzoneid\";s:12:\"109733950492\";s:6:\"siteid\";s:10:\"1065450073\";s:5:\"ermsg\";s:70:\"http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=newhelp&m=tiger_newhu\";s:7:\"zgtxmsg\";s:155:\"#昵称# 如：#昵称#，订单提交成功，客服会在24小时内审核订单，您奖获得#金额#奖励，请耐性等待。订单号：#订单号#\";s:7:\"yjtxmsg\";s:129:\"#昵称# 如：您的朋友#昵称#成功下单了，订单确认收货后，您奖获得#金额#奖励。订单号：#订单号#\";s:7:\"ejtxmsg\";s:138:\"#昵称# 如：您的朋友的朋友#昵称#成功下单了，订单确认收货后，您奖获得#金额#奖励。订单号：#订单号#\";s:4:\"jfbl\";s:1:\"1\";s:6:\"tttype\";s:1:\"1\";s:7:\"tttitle\";s:0:\"\";s:8:\"ttpicurl\";s:0:\"\";s:5:\"tturl\";s:0:\"\";s:5:\"ttsum\";s:0:\"\";s:9:\"yongjinjs\";s:1:\"2\";s:4:\"tkzs\";N;s:8:\"jqrflmsg\";s:398:\"HI，#昵称#\r\n【商品名称】\r\n商品名称#名称#\r\n原价：#原价# 元\r\n总优惠后价：#惠后价# 元\r\n券后价：#券后价#\r\n购买地址：#短网址#\r\n【优惠详情】\r\n优惠券：#优惠券#\r\n总优惠金额：#总优惠# 元\r\n好评后奖励：#返现金额#\r\n【下单】\r\n长按复制本条消息，打开【淘宝客户端】下单#淘口令#\r\n同类产品：#同类产品#\";s:4:\"wzcj\";s:1:\"0\";s:6:\"yetype\";s:0:\"\";s:7:\"phbtype\";s:1:\"0\";s:4:\"tbid\";s:13:\"2206787978133\";s:10:\"huiyuanurl\";s:0:\"\";s:3:\"hpx\";s:1:\"0\";s:10:\"hongbaourl\";s:0:\"\";s:6:\"yhlist\";s:1:\"0\";s:8:\"cjpicurl\";s:0:\"\";s:6:\"rxyjxs\";s:1:\"1\";s:10:\"hongbaoykg\";s:1:\"0\";s:10:\"cjsstypesy\";s:1:\"0\";s:10:\"cjsswzxsgs\";s:2:\"20\";s:9:\"glyopenid\";s:0:\"\";s:10:\"khgetorder\";s:1:\"0\";s:7:\"khgettx\";s:1:\"0\";s:5:\"ljcjk\";s:1:\"0\";s:6:\"sdtype\";N;s:7:\"fsjldsz\";N;s:7:\"llqtype\";s:1:\"0\";s:8:\"sdguangc\";s:1:\"0\";s:6:\"qfmbid\";s:1:\"0\";s:4:\"fcss\";s:1:\"1\";s:7:\"tkltype\";s:1:\"0\";s:4:\"cxrk\";s:1:\"0\";s:5:\"gzhtp\";s:1:\"1\";s:6:\"mmtype\";s:1:\"2\";s:13:\"dtkapp_secret\";s:32:\"ae039b1c9abe135952ae0a10d14cd157\";s:10:\"dtkapp_key\";s:13:\"5dc410eeaeb0c\";s:6:\"error1\";s:0:\"\";s:6:\"error2\";s:0:\"\";s:6:\"error3\";s:0:\"\";s:6:\"error4\";s:0:\"\";s:8:\"zbjgtime\";s:3:\"120\";s:10:\"zbtouxiang\";s:51:\"images/2/2019/11/RMeJJ1E7q24q11ZZ72M2X653Gccjzm.jpg\";s:5:\"wsurl\";s:24:\"ws://172.19.151.240:9502\";s:6:\"zblive\";s:1:\"0\";s:6:\"yktype\";s:1:\"1\";s:5:\"tbuid\";s:0:\"\";s:7:\"sylmkey\";N;s:6:\"cjsszn\";s:1:\"0\";s:5:\"jqrss\";N;s:6:\"gyspsj\";s:0:\"\";s:11:\"newflmsgjqr\";s:75:\"你要找【#名称#】吗？\r\n点击查看更多相关内容：#短网址#\";s:10:\"lbratetype\";s:1:\"1\";s:7:\"ldgzurl\";s:0:\"\";s:9:\"gzhcjtype\";s:1:\"1\";s:4:\"kfqq\";s:0:\"\";s:6:\"kftime\";s:0:\"\";s:8:\"mspicurl\";s:0:\"\";s:6:\"mstime\";N;s:5:\"cqmsg\";s:24:\"查券功能已关闭！\";s:8:\"topcolor\";s:7:\"#00ff00\";s:4:\"sy99\";s:1:\"1\";s:5:\"syjhs\";s:1:\"1\";s:4:\"syms\";s:1:\"1\";s:6:\"sybmmk\";s:1:\"1\";s:5:\"syddq\";N;s:9:\"newsstyle\";s:3:\"lb3\";s:5:\"tklmb\";s:321:\"商品名称：#名称##换行#\r\n推荐理由：#推荐理由##换行#\r\n商品原价：#原价#元#换行#\r\n券后价：#券后价#元#换行#\r\n优惠券：#优惠券#元#换行#\r\n淘口令：#淘口令##换行#\r\n拼多多链接：#拼多多短网址##换行#\r\n二合一链接：#二合一链接#\r\n短链接：#短链接#\";s:6:\"sinkey\";s:20:\"http://tbk.5ikh.com/\";s:5:\"dwzlj\";s:1:\"2\";s:8:\"zdgdtype\";s:1:\"1\";s:7:\"appname\";s:0:\"\";s:6:\"appico\";s:0:\"\";s:5:\"azurl\";s:0:\"\";s:6:\"iosurl\";s:0:\"\";s:6:\"apptxt\";s:0:\"\";s:8:\"qqtongji\";s:0:\"\";s:6:\"mftype\";s:1:\"1\";s:8:\"mfhhtype\";s:1:\"1\";s:11:\"unionidtype\";s:1:\"0\";s:4:\"logo\";s:51:\"images/2/2019/11/RMeJJ1E7q24q11ZZ72M2X653Gccjzm.jpg\";s:7:\"tljtype\";s:1:\"0\";s:5:\"tljyj\";s:0:\"\";s:6:\"tljsum\";s:0:\"\";s:5:\"tljsx\";s:0:\"\";s:8:\"tljtitle\";s:0:\"\";s:10:\"tljendtime\";N;s:12:\"tljadzone_id\";N;s:9:\"smskgtype\";s:1:\"0\";s:7:\"xqdwzxs\";s:1:\"1\";s:9:\"jhspicurl\";s:0:\"\";s:9:\"tqgpicurl\";s:0:\"\";s:6:\"dlhead\";s:1:\"1\";s:5:\"rjqqq\";N;s:6:\"viewtk\";s:1:\"1\";s:8:\"zhaotype\";s:1:\"0\";s:6:\"dlddfx\";s:1:\"0\";s:7:\"itemewm\";s:1:\"0\";s:8:\"ljqtzapp\";s:1:\"1\";s:10:\"tklnewtype\";N;s:8:\"tknewurl\";s:0:\"\";s:5:\"zydwz\";s:20:\"http://tbk.5ikh.com/\";s:6:\"zhaoxs\";s:1:\"0\";s:5:\"ewmlj\";N;s:12:\"hongbaoytype\";s:1:\"0\";s:4:\"mypy\";s:1:\"0\";s:8:\"cjsstype\";s:1:\"1\";s:8:\"hbsctime\";s:2:\"60\";s:7:\"hbcsmsg\";s:96:\"尊敬的粉丝：\\n1分钟之内只能生成1次海报\\n请稍后在试，感谢您的参与！\";s:5:\"rwurl\";N;s:6:\"AppKey\";s:0:\"\";s:9:\"appSecret\";s:0:\"\";s:6:\"jdtjdd\";s:1:\"0\";s:4:\"city\";s:0:\"\";}\";s:8:\"shortcut\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:tiger_wxdaili:2', 'a:7:{s:2:\"id\";s:1:\"3\";s:7:\"uniacid\";s:1:\"2\";s:6:\"module\";s:13:\"tiger_wxdaili\";s:7:\"enabled\";s:1:\"1\";s:8:\"settings\";s:1683:\"a:59:{s:5:\"appid\";s:18:\"wx4ce1248fee1b6d3d\";s:6:\"secret\";s:32:\"1e2f6a4a33d751e23f817065607a60eb\";s:5:\"mchid\";N;s:6:\"apikey\";N;s:2:\"ip\";s:0:\"\";s:6:\"fytype\";s:1:\"0\";s:8:\"zdshtype\";s:1:\"0\";s:6:\"yjtype\";s:1:\"0\";s:8:\"adzoneid\";s:12:\"109733950492\";s:6:\"siteid\";s:10:\"1065450073\";s:5:\"flmsg\";s:288:\"商品名称：#名称##换行# \r\n推荐理由：#推荐理由##换行# \r\n商品原价：#原价#元#换行# \r\n券后价：#券后价#元#换行# \r\n优惠券：#优惠券#元#换行# \r\n淘口令：#淘口令##换行# \r\n二合一链接：#二合一链接##换行# \r\n短链接：#短链接#\";s:8:\"tkAppKey\";s:8:\"28111962\";s:11:\"tksecretKey\";s:32:\"654f07152ae3af11c7e4a84feb1df9b4\";s:4:\"tbid\";s:13:\"2206787978133\";s:4:\"jqzs\";N;s:5:\"jqmsg\";s:0:\"\";s:6:\"jlqmsg\";s:0:\"\";s:5:\"ptpid\";s:36:\"mm_711720113_1065450073_109733950492\";s:5:\"qqpid\";s:0:\"\";s:3:\"zgf\";s:0:\"\";s:8:\"dlpicurl\";s:0:\"\";s:8:\"dlmmtype\";s:1:\"2\";s:8:\"tknewurl\";s:0:\"\";s:7:\"orderys\";s:1:\"0\";s:5:\"dlnum\";N;s:5:\"fsnum\";s:0:\"\";s:8:\"dlsqtype\";s:1:\"0\";s:6:\"dlsqtx\";s:1:\"0\";s:9:\"glyopenid\";s:0:\"\";s:8:\"dlshtgtx\";s:1:\"0\";s:6:\"yktype\";s:1:\"0\";s:5:\"tbuid\";s:13:\"2206787978133\";s:9:\"ggcontent\";s:0:\"\";s:6:\"gglink\";s:0:\"\";s:4:\"jsms\";s:1:\"1\";s:7:\"sylmkey\";N;s:6:\"gyspsj\";s:0:\"\";s:9:\"txxzprice\";s:0:\"\";s:6:\"kqbdsj\";s:1:\"0\";s:7:\"bdteljl\";s:0:\"\";s:10:\"tklnewtype\";N;s:7:\"khgettx\";s:1:\"0\";s:7:\"pdddlxs\";s:1:\"0\";s:6:\"qdtype\";s:1:\"0\";s:5:\"qdpid\";s:0:\"\";s:6:\"qdcode\";N;s:7:\"qdtgurl\";s:0:\"\";s:5:\"zydwz\";s:0:\"\";s:6:\"sinkey\";s:0:\"\";s:5:\"dwzlj\";s:1:\"2\";s:7:\"xqdwzxs\";s:1:\"1\";s:9:\"logintype\";s:1:\"0\";s:8:\"lxddtype\";s:1:\"0\";s:7:\"lxjlrmb\";s:0:\"\";s:8:\"kfpicurl\";s:0:\"\";s:9:\"newdltype\";s:1:\"2\";s:8:\"dbcdtype\";s:1:\"0\";s:11:\"newdlxjtype\";s:1:\"0\";s:6:\"jddlxs\";s:1:\"0\";}\";s:8:\"shortcut\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:tuike_jd', 'a:35:{s:3:\"mid\";s:2:\"15\";s:4:\"name\";s:8:\"tuike_jd\";s:4:\"type\";s:8:\"business\";s:5:\"title\";s:25:\"推京客_京东优惠券\";s:7:\"version\";s:6:\"1.1.19\";s:7:\"ability\";s:25:\"推京客_京东优惠券\";s:11:\"description\";s:25:\"推京客_京东优惠券\";s:6:\"author\";s:12:\"创心团队\";s:3:\"url\";s:46:\"http://https://www.huzhan.com/ishop31919/code/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";a:0:{}s:7:\"handles\";a:12:{i:0;s:5:\"image\";i:1;s:5:\"voice\";i:2;s:5:\"video\";i:3;s:10:\"shortvideo\";i:4;s:8:\"location\";i:5;s:4:\"link\";i:6;s:9:\"subscribe\";i:7;s:2:\"qr\";i:8;s:5:\"trace\";i:9;s:5:\"click\";i:10;s:14:\"merchant_order\";i:11;s:4:\"text\";}s:12:\"isrulefields\";s:1:\"0\";s:8:\"issystem\";s:1:\"0\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:6:\"a:0:{}\";s:13:\"title_initial\";s:1:\"T\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"0\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"1\";s:10:\"oauth_type\";s:1:\"1\";s:16:\"phoneapp_support\";s:1:\"1\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"1\";s:14:\"aliapp_support\";s:1:\"1\";s:4:\"logo\";s:44:\"http://tbk.5ikh.com/addons/tuike_jd/icon.jpg\";s:16:\"baiduapp_support\";s:1:\"1\";s:18:\"toutiaoapp_support\";s:1:\"1\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:60:\"http://tbk.5ikh.com/addons/tuike_jd/preview.jpg?v=1574840753\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:user_accounts:wechats:1', 'a:1:{i:1;a:8:{s:4:\"acid\";s:1:\"1\";s:7:\"uniacid\";s:1:\"1\";s:4:\"name\";s:5:\"efwww\";s:4:\"type\";s:1:\"1\";s:5:\"level\";s:1:\"1\";s:3:\"key\";s:0:\"\";s:6:\"secret\";s:0:\"\";s:5:\"token\";s:32:\"omJNpZEhZeHj1ZxFECKkP48B5VFbk1HP\";}}');
INSERT INTO `ims_core_cache` VALUES ('we7:user_accounts:wxapp:1', 'a:0:{}');
INSERT INTO `ims_core_cache` VALUES ('we7:user_accounts:webapp:1', 'a:0:{}');
INSERT INTO `ims_core_cache` VALUES ('we7:user_accounts:phoneapp:1', 'a:0:{}');
INSERT INTO `ims_core_cache` VALUES ('we7:user_accounts:xzapp:1', 'a:0:{}');
INSERT INTO `ims_core_cache` VALUES ('we7:user_accounts:aliapp:1', 'a:0:{}');
INSERT INTO `ims_core_cache` VALUES ('we7:user_accounts:baiduapp:1', 'a:0:{}');
INSERT INTO `ims_core_cache` VALUES ('we7:user_accounts:toutiaoapp:1', 'a:0:{}');
INSERT INTO `ims_core_cache` VALUES ('we7:uniaccount:1', 'a:21:{s:4:\"acid\";s:1:\"1\";s:7:\"uniacid\";s:1:\"1\";s:5:\"token\";s:32:\"omJNpZEhZeHj1ZxFECKkP48B5VFbk1HP\";s:14:\"encodingaeskey\";s:0:\"\";s:5:\"level\";s:1:\"1\";s:4:\"name\";s:5:\"efwww\";s:7:\"account\";s:0:\"\";s:8:\"original\";s:0:\"\";s:9:\"signature\";s:0:\"\";s:7:\"country\";s:0:\"\";s:8:\"province\";s:0:\"\";s:4:\"city\";s:0:\"\";s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:10:\"lastupdate\";s:1:\"0\";s:3:\"key\";s:0:\"\";s:6:\"secret\";s:0:\"\";s:7:\"styleid\";s:1:\"1\";s:12:\"subscribeurl\";s:0:\"\";s:18:\"auth_refresh_token\";s:0:\"\";s:11:\"encrypt_key\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:unisetting:1', 'a:30:{s:7:\"uniacid\";s:1:\"1\";s:8:\"passport\";a:3:{s:8:\"focusreg\";i:0;s:4:\"item\";s:5:\"email\";s:4:\"type\";s:8:\"password\";}s:5:\"oauth\";s:0:\"\";s:11:\"jsauth_acid\";s:1:\"0\";s:2:\"uc\";a:1:{s:6:\"status\";i:0;}s:6:\"notify\";a:1:{s:3:\"sms\";a:2:{s:7:\"balance\";i:0;s:9:\"signature\";s:0:\"\";}}s:11:\"creditnames\";a:5:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}s:7:\"credit3\";a:2:{s:5:\"title\";s:0:\"\";s:7:\"enabled\";i:0;}s:7:\"credit4\";a:2:{s:5:\"title\";s:0:\"\";s:7:\"enabled\";i:0;}s:7:\"credit5\";a:2:{s:5:\"title\";s:0:\"\";s:7:\"enabled\";i:0;}}s:15:\"creditbehaviors\";a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}s:7:\"welcome\";s:0:\"\";s:7:\"default\";s:0:\"\";s:15:\"default_message\";s:0:\"\";s:7:\"payment\";a:4:{s:6:\"credit\";a:3:{s:6:\"switch\";b:0;s:15:\"recharge_switch\";b:0;s:10:\"pay_switch\";b:0;}s:6:\"alipay\";a:6:{s:6:\"switch\";b:0;s:7:\"account\";s:0:\"\";s:7:\"partner\";s:0:\"\";s:6:\"secret\";s:0:\"\";s:15:\"recharge_switch\";b:0;s:10:\"pay_switch\";b:0;}s:6:\"wechat\";a:7:{s:6:\"switch\";b:0;s:7:\"account\";b:0;s:7:\"signkey\";s:0:\"\";s:7:\"partner\";s:0:\"\";s:3:\"key\";s:0:\"\";s:15:\"recharge_switch\";b:0;s:10:\"pay_switch\";b:0;}s:8:\"delivery\";a:3:{s:6:\"switch\";b:0;s:15:\"recharge_switch\";b:0;s:10:\"pay_switch\";b:0;}}s:4:\"stat\";s:0:\"\";s:12:\"default_site\";s:1:\"1\";s:4:\"sync\";s:1:\"0\";s:8:\"recharge\";s:0:\"\";s:9:\"tplnotice\";s:0:\"\";s:10:\"grouplevel\";s:1:\"0\";s:8:\"mcplugin\";s:0:\"\";s:15:\"exchange_enable\";s:1:\"0\";s:11:\"coupon_type\";s:1:\"0\";s:7:\"menuset\";s:0:\"\";s:10:\"statistics\";s:0:\"\";s:11:\"bind_domain\";s:0:\"\";s:14:\"comment_status\";s:1:\"0\";s:13:\"reply_setting\";s:1:\"0\";s:14:\"default_module\";s:0:\"\";s:16:\"attachment_limit\";N;s:15:\"attachment_size\";d:88;s:11:\"sync_member\";s:1:\"0\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:uniaccount:', 'a:1:{s:11:\"encrypt_key\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:tuike_pdd', 'a:35:{s:3:\"mid\";s:2:\"16\";s:4:\"name\";s:9:\"tuike_pdd\";s:4:\"type\";s:8:\"business\";s:5:\"title\";s:15:\"拼多多进宝\";s:7:\"version\";s:6:\"1.2.91\";s:7:\"ability\";s:15:\"拼多多进宝\";s:11:\"description\";s:15:\"拼多多进宝\";s:6:\"author\";s:12:\"创心团队\";s:3:\"url\";s:39:\"https://www.huzhan.com/ishop31919/code/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";a:0:{}s:7:\"handles\";a:12:{i:0;s:5:\"image\";i:1;s:5:\"voice\";i:2;s:5:\"video\";i:3;s:10:\"shortvideo\";i:4;s:8:\"location\";i:5;s:4:\"link\";i:6;s:9:\"subscribe\";i:7;s:2:\"qr\";i:8;s:5:\"trace\";i:9;s:5:\"click\";i:10;s:14:\"merchant_order\";i:11;s:4:\"text\";}s:12:\"isrulefields\";s:1:\"0\";s:8:\"issystem\";s:1:\"0\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:6:\"a:0:{}\";s:13:\"title_initial\";s:1:\"P\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"0\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"1\";s:10:\"oauth_type\";s:1:\"1\";s:16:\"phoneapp_support\";s:1:\"1\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"1\";s:14:\"aliapp_support\";s:1:\"1\";s:4:\"logo\";s:45:\"http://tbk.5ikh.com/addons/tuike_pdd/icon.jpg\";s:16:\"baiduapp_support\";s:1:\"1\";s:18:\"toutiaoapp_support\";s:1:\"1\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:61:\"http://tbk.5ikh.com/addons/tuike_pdd/preview.jpg?v=1574840816\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:user_modules:1', 'a:4:{s:9:\"tuike_pdd\";s:3:\"all\";s:8:\"tuike_jd\";s:3:\"all\";s:13:\"tiger_wxdaili\";s:3:\"all\";s:11:\"tiger_newhu\";s:3:\"all\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:unisetting:2', 'a:30:{s:7:\"uniacid\";s:1:\"2\";s:8:\"passport\";s:0:\"\";s:5:\"oauth\";s:0:\"\";s:11:\"jsauth_acid\";s:1:\"0\";s:2:\"uc\";s:0:\"\";s:6:\"notify\";s:0:\"\";s:11:\"creditnames\";a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}s:15:\"creditbehaviors\";a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}s:7:\"welcome\";s:0:\"\";s:7:\"default\";s:0:\"\";s:15:\"default_message\";s:0:\"\";s:7:\"payment\";s:0:\"\";s:4:\"stat\";s:0:\"\";s:12:\"default_site\";s:1:\"2\";s:4:\"sync\";s:1:\"0\";s:8:\"recharge\";s:0:\"\";s:9:\"tplnotice\";s:0:\"\";s:10:\"grouplevel\";s:1:\"0\";s:8:\"mcplugin\";s:0:\"\";s:15:\"exchange_enable\";s:1:\"0\";s:11:\"coupon_type\";s:1:\"0\";s:7:\"menuset\";s:0:\"\";s:10:\"statistics\";s:0:\"\";s:11:\"bind_domain\";s:0:\"\";s:14:\"comment_status\";s:1:\"0\";s:13:\"reply_setting\";s:1:\"0\";s:14:\"default_module\";s:0:\"\";s:16:\"attachment_limit\";N;s:15:\"attachment_size\";N;s:11:\"sync_member\";s:1:\"0\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:system_frame:2', 'a:21:{s:8:\"phoneapp\";a:7:{s:5:\"title\";s:3:\"APP\";s:4:\"icon\";s:18:\"wi wi-white-collar\";s:3:\"url\";s:41:\"./index.php?c=phoneapp&a=display&do=home&\";s:7:\"section\";a:2:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:16:\"phoneapp_profile\";a:4:{s:5:\"title\";s:6:\"配置\";s:4:\"menu\";a:2:{s:28:\"profile_phoneapp_module_link\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:1:{i:0;i:6;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"数据同步\";s:3:\"url\";s:42:\"./index.php?c=wxapp&a=module-link-uniacid&\";s:15:\"permission_name\";s:28:\"profile_phoneapp_module_link\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:14:\"front_download\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";b:1;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"下载APP\";s:3:\"url\";s:40:\"./index.php?c=phoneapp&a=front-download&\";s:15:\"permission_name\";s:23:\"phoneapp_front_download\";s:4:\"icon\";s:13:\"wi wi-examine\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:10:\"is_display\";b:1;s:18:\"permission_display\";a:1:{i:0;i:6;}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:0;s:12:\"displayorder\";i:0;}s:7:\"welcome\";a:7:{s:5:\"title\";s:6:\"首页\";s:4:\"icon\";s:10:\"wi wi-home\";s:3:\"url\";s:48:\"./index.php?c=home&a=welcome&do=system&page=home\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:2;}s:8:\"platform\";a:8:{s:5:\"title\";s:12:\"平台入口\";s:4:\"icon\";s:14:\"wi wi-platform\";s:9:\"dimension\";i:2;s:3:\"url\";s:44:\"./index.php?c=account&a=display&do=platform&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:3;}s:6:\"module\";a:8:{s:5:\"title\";s:12:\"应用入口\";s:4:\"icon\";s:11:\"wi wi-apply\";s:9:\"dimension\";i:2;s:3:\"url\";s:53:\"./index.php?c=module&a=display&do=switch_last_module&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:4;}s:14:\"account_manage\";a:8:{s:5:\"title\";s:12:\"平台管理\";s:4:\"icon\";s:21:\"wi wi-platform-manage\";s:9:\"dimension\";i:2;s:3:\"url\";s:31:\"./index.php?c=account&a=manage&\";s:7:\"section\";a:1:{s:14:\"account_manage\";a:2:{s:5:\"title\";s:12:\"平台管理\";s:4:\"menu\";a:4:{s:22:\"account_manage_display\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"平台列表\";s:3:\"url\";s:31:\"./index.php?c=account&a=manage&\";s:15:\"permission_name\";s:22:\"account_manage_display\";s:4:\"icon\";N;s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:1:{i:0;a:2:{s:5:\"title\";s:12:\"帐号停用\";s:15:\"permission_name\";s:19:\"account_manage_stop\";}}}s:22:\"account_manage_recycle\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"回收站\";s:3:\"url\";s:32:\"./index.php?c=account&a=recycle&\";s:15:\"permission_name\";s:22:\"account_manage_recycle\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:12:\"帐号删除\";s:15:\"permission_name\";s:21:\"account_manage_delete\";}i:1;a:2:{s:5:\"title\";s:12:\"帐号恢复\";s:15:\"permission_name\";s:22:\"account_manage_recover\";}}}s:30:\"account_manage_system_platform\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:19:\" 微信开放平台\";s:3:\"url\";s:32:\"./index.php?c=system&a=platform&\";s:15:\"permission_name\";s:30:\"account_manage_system_platform\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:30:\"account_manage_expired_message\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:22:\" 自定义到期提示\";s:3:\"url\";s:40:\"./index.php?c=account&a=expired-message&\";s:15:\"permission_name\";s:30:\"account_manage_expired_message\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:5;}s:13:\"module_manage\";a:8:{s:5:\"title\";s:12:\"应用管理\";s:4:\"icon\";s:19:\"wi wi-module-manage\";s:9:\"dimension\";i:2;s:3:\"url\";s:50:\"./index.php?c=module&a=manage-system&do=installed&\";s:7:\"section\";a:1:{s:13:\"module_manage\";a:2:{s:5:\"title\";s:12:\"应用管理\";s:4:\"menu\";a:5:{s:23:\"module_manage_installed\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"已安装列表\";s:3:\"url\";s:50:\"./index.php?c=module&a=manage-system&do=installed&\";s:15:\"permission_name\";s:23:\"module_manage_installed\";s:4:\"icon\";N;s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:20:\"module_manage_stoped\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"已停用列表\";s:3:\"url\";s:54:\"./index.php?c=module&a=manage-system&do=recycle&type=1\";s:15:\"permission_name\";s:20:\"module_manage_stoped\";s:4:\"icon\";N;s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:27:\"module_manage_not_installed\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"未安装列表\";s:3:\"url\";s:54:\"./index.php?c=module&a=manage-system&do=not_installed&\";s:15:\"permission_name\";s:27:\"module_manage_not_installed\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:21:\"module_manage_recycle\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"回收站\";s:3:\"url\";s:54:\"./index.php?c=module&a=manage-system&do=recycle&type=2\";s:15:\"permission_name\";s:21:\"module_manage_recycle\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:23:\"module_manage_subscribe\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"订阅管理\";s:3:\"url\";s:50:\"./index.php?c=module&a=manage-system&do=subscribe&\";s:15:\"permission_name\";s:23:\"module_manage_subscribe\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:6;}s:11:\"user_manage\";a:8:{s:5:\"title\";s:12:\"用户管理\";s:4:\"icon\";s:16:\"wi wi-user-group\";s:9:\"dimension\";i:2;s:3:\"url\";s:29:\"./index.php?c=user&a=display&\";s:7:\"section\";a:1:{s:11:\"user_manage\";a:2:{s:5:\"title\";s:12:\"用户管理\";s:4:\"menu\";a:7:{s:19:\"user_manage_display\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"普通用户\";s:3:\"url\";s:29:\"./index.php?c=user&a=display&\";s:15:\"permission_name\";s:19:\"user_manage_display\";s:4:\"icon\";N;s:12:\"displayorder\";i:7;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:19:\"user_manage_founder\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"副站长\";s:3:\"url\";s:32:\"./index.php?c=founder&a=display&\";s:15:\"permission_name\";s:19:\"user_manage_founder\";s:4:\"icon\";N;s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:17:\"user_manage_clerk\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"店员管理\";s:3:\"url\";s:39:\"./index.php?c=user&a=display&type=clerk\";s:15:\"permission_name\";s:17:\"user_manage_clerk\";s:4:\"icon\";N;s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:17:\"user_manage_check\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"审核用户\";s:3:\"url\";s:39:\"./index.php?c=user&a=display&type=check\";s:15:\"permission_name\";s:17:\"user_manage_check\";s:4:\"icon\";N;s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:19:\"user_manage_recycle\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"回收站\";s:3:\"url\";s:41:\"./index.php?c=user&a=display&type=recycle\";s:15:\"permission_name\";s:19:\"user_manage_recycle\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:18:\"user_manage_fields\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"用户属性设置\";s:3:\"url\";s:39:\"./index.php?c=user&a=fields&do=display&\";s:15:\"permission_name\";s:18:\"user_manage_fields\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:18:\"user_manage_expire\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"用户过期设置\";s:3:\"url\";s:28:\"./index.php?c=user&a=expire&\";s:15:\"permission_name\";s:18:\"user_manage_expire\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:7;}s:10:\"permission\";a:8:{s:5:\"title\";s:9:\"权限组\";s:4:\"icon\";s:22:\"wi wi-userjurisdiction\";s:9:\"dimension\";i:2;s:3:\"url\";s:29:\"./index.php?c=module&a=group&\";s:7:\"section\";a:1:{s:10:\"permission\";a:2:{s:5:\"title\";s:9:\"权限组\";s:4:\"menu\";a:4:{s:23:\"permission_module_group\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"应用权限组\";s:3:\"url\";s:29:\"./index.php?c=module&a=group&\";s:15:\"permission_name\";s:23:\"permission_module_group\";s:4:\"icon\";N;s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:31:\"permission_create_account_group\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"账号权限组\";s:3:\"url\";s:34:\"./index.php?c=user&a=create-group&\";s:15:\"permission_name\";s:31:\"permission_create_account_group\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:21:\"permission_user_group\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"用户权限组合\";s:3:\"url\";s:27:\"./index.php?c=user&a=group&\";s:15:\"permission_name\";s:21:\"permission_user_group\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:24:\"permission_founder_group\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:21:\"副站长权限组合\";s:3:\"url\";s:30:\"./index.php?c=founder&a=group&\";s:15:\"permission_name\";s:24:\"permission_founder_group\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:8;}s:6:\"system\";a:8:{s:5:\"title\";s:12:\"系统功能\";s:4:\"icon\";s:13:\"wi wi-setting\";s:9:\"dimension\";i:3;s:3:\"url\";s:31:\"./index.php?c=article&a=notice&\";s:7:\"section\";a:5:{s:7:\"article\";a:3:{s:5:\"title\";s:12:\"站内公告\";s:4:\"menu\";a:1:{s:14:\"system_article\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"站内公告\";s:3:\"url\";s:31:\"./index.php?c=article&a=notice&\";s:15:\"permission_name\";s:14:\"system_article\";s:4:\"icon\";s:13:\"wi wi-article\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:12:\"公告列表\";s:15:\"permission_name\";s:26:\"system_article_notice_list\";}i:1;a:2:{s:5:\"title\";s:12:\"公告分类\";s:15:\"permission_name\";s:30:\"system_article_notice_category\";}}}}s:7:\"founder\";b:1;}s:15:\"system_template\";a:3:{s:5:\"title\";s:6:\"模板\";s:4:\"menu\";a:1:{s:15:\"system_template\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"微官网模板\";s:3:\"url\";s:32:\"./index.php?c=system&a=template&\";s:15:\"permission_name\";s:15:\"system_template\";s:4:\"icon\";s:17:\"wi wi-wx-template\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:7:\"founder\";b:1;}s:14:\"system_welcome\";a:3:{s:5:\"title\";s:12:\"系统首页\";s:4:\"menu\";a:2:{s:14:\"system_welcome\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"系统首页应用\";s:3:\"url\";s:60:\"./index.php?c=module&a=manage-system&support=welcome_support\";s:15:\"permission_name\";s:14:\"system_welcome\";s:4:\"icon\";s:20:\"wi wi-system-welcome\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:11:\"system_news\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"系统新闻\";s:3:\"url\";s:29:\"./index.php?c=article&a=news&\";s:15:\"permission_name\";s:11:\"system_news\";s:4:\"icon\";s:13:\"wi wi-article\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:13:\"新闻列表 \";s:15:\"permission_name\";s:24:\"system_article_news_list\";}i:1;a:2:{s:5:\"title\";s:13:\"新闻分类 \";s:15:\"permission_name\";s:28:\"system_article_news_category\";}}}}s:7:\"founder\";b:1;}s:17:\"system_statistics\";a:3:{s:5:\"title\";s:6:\"统计\";s:4:\"menu\";a:1:{s:23:\"system_account_analysis\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"访问统计\";s:3:\"url\";s:35:\"./index.php?c=statistics&a=account&\";s:15:\"permission_name\";s:23:\"system_account_analysis\";s:4:\"icon\";s:17:\"wi wi-statistical\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:7:\"founder\";b:1;}s:5:\"cache\";a:2:{s:5:\"title\";s:6:\"缓存\";s:4:\"menu\";a:1:{s:26:\"system_setting_updatecache\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"更新缓存\";s:3:\"url\";s:35:\"./index.php?c=system&a=updatecache&\";s:15:\"permission_name\";s:26:\"system_setting_updatecache\";s:4:\"icon\";s:12:\"wi wi-update\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:9;}s:4:\"site\";a:9:{s:5:\"title\";s:12:\"站点设置\";s:4:\"icon\";s:17:\"wi wi-system-site\";s:9:\"dimension\";i:3;s:3:\"url\";s:28:\"./index.php?c=system&a=site&\";s:7:\"section\";a:4:{s:5:\"cloud\";a:2:{s:5:\"title\";s:9:\"云服务\";s:4:\"menu\";a:3:{s:14:\"system_profile\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"系统升级\";s:3:\"url\";s:30:\"./index.php?c=cloud&a=upgrade&\";s:15:\"permission_name\";s:20:\"system_cloud_upgrade\";s:4:\"icon\";s:11:\"wi wi-cache\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:21:\"system_cloud_register\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"注册站点\";s:3:\"url\";s:30:\"./index.php?c=cloud&a=profile&\";s:15:\"permission_name\";s:21:\"system_cloud_register\";s:4:\"icon\";s:18:\"wi wi-registersite\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:21:\"system_cloud_diagnose\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"云服务诊断\";s:3:\"url\";s:31:\"./index.php?c=cloud&a=diagnose&\";s:15:\"permission_name\";s:21:\"system_cloud_diagnose\";s:4:\"icon\";s:14:\"wi wi-diagnose\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"setting\";a:2:{s:5:\"title\";s:6:\"设置\";s:4:\"menu\";a:9:{s:19:\"system_setting_site\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"站点设置\";s:3:\"url\";s:28:\"./index.php?c=system&a=site&\";s:15:\"permission_name\";s:19:\"system_setting_site\";s:4:\"icon\";s:18:\"wi wi-site-setting\";s:12:\"displayorder\";i:9;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_setting_menu\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"菜单设置\";s:3:\"url\";s:28:\"./index.php?c=system&a=menu&\";s:15:\"permission_name\";s:19:\"system_setting_menu\";s:4:\"icon\";s:18:\"wi wi-menu-setting\";s:12:\"displayorder\";i:8;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_attachment\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"附件设置\";s:3:\"url\";s:34:\"./index.php?c=system&a=attachment&\";s:15:\"permission_name\";s:25:\"system_setting_attachment\";s:4:\"icon\";s:16:\"wi wi-attachment\";s:12:\"displayorder\";i:7;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_systeminfo\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"系统信息\";s:3:\"url\";s:34:\"./index.php?c=system&a=systeminfo&\";s:15:\"permission_name\";s:25:\"system_setting_systeminfo\";s:4:\"icon\";s:17:\"wi wi-system-info\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_setting_logs\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"查看日志\";s:3:\"url\";s:28:\"./index.php?c=system&a=logs&\";s:15:\"permission_name\";s:19:\"system_setting_logs\";s:4:\"icon\";s:9:\"wi wi-log\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:26:\"system_setting_ipwhitelist\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:11:\"IP白名单\";s:3:\"url\";s:35:\"./index.php?c=system&a=ipwhitelist&\";s:15:\"permission_name\";s:26:\"system_setting_ipwhitelist\";s:4:\"icon\";s:8:\"wi wi-ip\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:28:\"system_setting_sensitiveword\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"过滤敏感词\";s:3:\"url\";s:37:\"./index.php?c=system&a=sensitiveword&\";s:15:\"permission_name\";s:28:\"system_setting_sensitiveword\";s:4:\"icon\";s:15:\"wi wi-sensitive\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_thirdlogin\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:25:\"用户登录/注册设置\";s:3:\"url\";s:33:\"./index.php?c=user&a=registerset&\";s:15:\"permission_name\";s:25:\"system_setting_thirdlogin\";s:4:\"icon\";s:10:\"wi wi-user\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:20:\"system_setting_oauth\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"全局借用权限\";s:3:\"url\";s:29:\"./index.php?c=system&a=oauth&\";s:15:\"permission_name\";s:20:\"system_setting_oauth\";s:4:\"icon\";s:11:\"wi wi-oauth\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"utility\";a:2:{s:5:\"title\";s:12:\"常用工具\";s:4:\"menu\";a:6:{s:24:\"system_utility_filecheck\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"系统文件校验\";s:3:\"url\";s:33:\"./index.php?c=system&a=filecheck&\";s:15:\"permission_name\";s:24:\"system_utility_filecheck\";s:4:\"icon\";s:10:\"wi wi-file\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:23:\"system_utility_optimize\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"性能优化\";s:3:\"url\";s:32:\"./index.php?c=system&a=optimize&\";s:15:\"permission_name\";s:23:\"system_utility_optimize\";s:4:\"icon\";s:14:\"wi wi-optimize\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:23:\"system_utility_database\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"数据库\";s:3:\"url\";s:32:\"./index.php?c=system&a=database&\";s:15:\"permission_name\";s:23:\"system_utility_database\";s:4:\"icon\";s:9:\"wi wi-sql\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_utility_scan\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"木马查杀\";s:3:\"url\";s:28:\"./index.php?c=system&a=scan&\";s:15:\"permission_name\";s:19:\"system_utility_scan\";s:4:\"icon\";s:12:\"wi wi-safety\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:18:\"system_utility_bom\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"检测文件BOM\";s:3:\"url\";s:27:\"./index.php?c=system&a=bom&\";s:15:\"permission_name\";s:18:\"system_utility_bom\";s:4:\"icon\";s:9:\"wi wi-bom\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:20:\"system_utility_check\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"系统常规检测\";s:3:\"url\";s:29:\"./index.php?c=system&a=check&\";s:15:\"permission_name\";s:20:\"system_utility_check\";s:4:\"icon\";s:9:\"wi wi-bom\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"backjob\";a:2:{s:5:\"title\";s:12:\"后台任务\";s:4:\"menu\";a:1:{s:10:\"system_job\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"后台任务\";s:3:\"url\";s:38:\"./index.php?c=system&a=job&do=display&\";s:15:\"permission_name\";s:10:\"system_job\";s:4:\"icon\";s:9:\"wi wi-job\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:7:\"founder\";b:1;s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:10;}s:6:\"myself\";a:8:{s:5:\"title\";s:12:\"我的账户\";s:4:\"icon\";s:10:\"wi wi-bell\";s:9:\"dimension\";i:2;s:3:\"url\";s:29:\"./index.php?c=user&a=profile&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:11;}s:7:\"message\";a:8:{s:5:\"title\";s:12:\"消息管理\";s:4:\"icon\";s:10:\"wi wi-bell\";s:9:\"dimension\";i:2;s:3:\"url\";s:31:\"./index.php?c=message&a=notice&\";s:7:\"section\";a:1:{s:7:\"message\";a:2:{s:5:\"title\";s:12:\"消息管理\";s:4:\"menu\";a:3:{s:14:\"message_notice\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"消息提醒\";s:3:\"url\";s:31:\"./index.php?c=message&a=notice&\";s:15:\"permission_name\";s:14:\"message_notice\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:15:\"message_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"消息设置\";s:3:\"url\";s:42:\"./index.php?c=message&a=notice&do=setting&\";s:15:\"permission_name\";s:15:\"message_setting\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:22:\"message_wechat_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"微信提醒设置\";s:3:\"url\";s:49:\"./index.php?c=message&a=notice&do=wechat_setting&\";s:15:\"permission_name\";s:22:\"message_wechat_setting\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:12;}s:7:\"account\";a:8:{s:5:\"title\";s:9:\"公众号\";s:4:\"icon\";s:18:\"wi wi-white-collar\";s:9:\"dimension\";i:3;s:3:\"url\";s:41:\"./index.php?c=home&a=welcome&do=platform&\";s:7:\"section\";a:5:{s:8:\"platform\";a:3:{s:5:\"title\";s:12:\"增强功能\";s:4:\"menu\";a:6:{s:14:\"platform_reply\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"自动回复\";s:3:\"url\";s:31:\"./index.php?c=platform&a=reply&\";s:15:\"permission_name\";s:14:\"platform_reply\";s:4:\"icon\";s:11:\"wi wi-reply\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";a:7:{s:22:\"platform_reply_keyword\";a:4:{s:5:\"title\";s:21:\"关键字自动回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=keyword\";s:15:\"permission_name\";s:22:\"platform_reply_keyword\";s:6:\"active\";s:7:\"keyword\";}s:22:\"platform_reply_special\";a:4:{s:5:\"title\";s:24:\"非关键字自动回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=special\";s:15:\"permission_name\";s:22:\"platform_reply_special\";s:6:\"active\";s:7:\"special\";}s:22:\"platform_reply_welcome\";a:4:{s:5:\"title\";s:24:\"首次访问自动回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=welcome\";s:15:\"permission_name\";s:22:\"platform_reply_welcome\";s:6:\"active\";s:7:\"welcome\";}s:22:\"platform_reply_default\";a:4:{s:5:\"title\";s:12:\"默认回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=default\";s:15:\"permission_name\";s:22:\"platform_reply_default\";s:6:\"active\";s:7:\"default\";}s:22:\"platform_reply_service\";a:4:{s:5:\"title\";s:12:\"常用服务\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=service\";s:15:\"permission_name\";s:22:\"platform_reply_service\";s:6:\"active\";s:7:\"service\";}s:22:\"platform_reply_userapi\";a:5:{s:5:\"title\";s:21:\"自定义接口回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=userapi\";s:15:\"permission_name\";s:22:\"platform_reply_userapi\";s:6:\"active\";s:7:\"userapi\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:22:\"platform_reply_setting\";a:4:{s:5:\"title\";s:12:\"回复设置\";s:3:\"url\";s:38:\"./index.php?c=profile&a=reply-setting&\";s:15:\"permission_name\";s:22:\"platform_reply_setting\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}}}s:13:\"platform_menu\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"自定义菜单\";s:3:\"url\";s:38:\"./index.php?c=platform&a=menu&do=post&\";s:15:\"permission_name\";s:13:\"platform_menu\";s:4:\"icon\";s:16:\"wi wi-custommenu\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:21:\"platform_menu_default\";a:4:{s:5:\"title\";s:12:\"默认菜单\";s:3:\"url\";s:38:\"./index.php?c=platform&a=menu&do=post&\";s:15:\"permission_name\";s:21:\"platform_menu_default\";s:6:\"active\";s:4:\"post\";}s:25:\"platform_menu_conditional\";a:5:{s:5:\"title\";s:15:\"个性化菜单\";s:3:\"url\";s:47:\"./index.php?c=platform&a=menu&do=display&type=3\";s:15:\"permission_name\";s:25:\"platform_menu_conditional\";s:6:\"active\";s:7:\"display\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}}}s:11:\"platform_qr\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:2:{i:0;i:1;i:1;i:3;}s:10:\"is_display\";i:1;s:5:\"title\";s:22:\"二维码/转化链接\";s:3:\"url\";s:28:\"./index.php?c=platform&a=qr&\";s:15:\"permission_name\";s:11:\"platform_qr\";s:4:\"icon\";s:12:\"wi wi-qrcode\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:14:\"platform_qr_qr\";a:4:{s:5:\"title\";s:9:\"二维码\";s:3:\"url\";s:36:\"./index.php?c=platform&a=qr&do=list&\";s:15:\"permission_name\";s:14:\"platform_qr_qr\";s:6:\"active\";s:4:\"list\";}s:22:\"platform_qr_statistics\";a:4:{s:5:\"title\";s:21:\"二维码扫描统计\";s:3:\"url\";s:39:\"./index.php?c=platform&a=qr&do=display&\";s:15:\"permission_name\";s:22:\"platform_qr_statistics\";s:6:\"active\";s:7:\"display\";}}}s:17:\"platform_masstask\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"定时群发\";s:3:\"url\";s:30:\"./index.php?c=platform&a=mass&\";s:15:\"permission_name\";s:17:\"platform_masstask\";s:4:\"icon\";s:13:\"wi wi-crontab\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:22:\"platform_masstask_post\";a:4:{s:5:\"title\";s:12:\"定时群发\";s:3:\"url\";s:38:\"./index.php?c=platform&a=mass&do=post&\";s:15:\"permission_name\";s:22:\"platform_masstask_post\";s:6:\"active\";s:4:\"post\";}s:22:\"platform_masstask_send\";a:4:{s:5:\"title\";s:12:\"群发记录\";s:3:\"url\";s:38:\"./index.php?c=platform&a=mass&do=send&\";s:15:\"permission_name\";s:22:\"platform_masstask_send\";s:6:\"active\";s:4:\"send\";}}}s:17:\"platform_material\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:16:\"素材/编辑器\";s:3:\"url\";s:34:\"./index.php?c=platform&a=material&\";s:15:\"permission_name\";s:17:\"platform_material\";s:4:\"icon\";s:12:\"wi wi-redact\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:5:{s:22:\"platform_material_news\";a:4:{s:5:\"title\";s:6:\"图文\";s:3:\"url\";s:43:\"./index.php?c=platform&a=material&type=news\";s:15:\"permission_name\";s:22:\"platform_material_news\";s:6:\"active\";s:4:\"news\";}s:23:\"platform_material_image\";a:4:{s:5:\"title\";s:6:\"图片\";s:3:\"url\";s:44:\"./index.php?c=platform&a=material&type=image\";s:15:\"permission_name\";s:23:\"platform_material_image\";s:6:\"active\";s:5:\"image\";}s:23:\"platform_material_voice\";a:4:{s:5:\"title\";s:6:\"语音\";s:3:\"url\";s:44:\"./index.php?c=platform&a=material&type=voice\";s:15:\"permission_name\";s:23:\"platform_material_voice\";s:6:\"active\";s:5:\"voice\";}s:23:\"platform_material_video\";a:5:{s:5:\"title\";s:6:\"视频\";s:3:\"url\";s:44:\"./index.php?c=platform&a=material&type=video\";s:15:\"permission_name\";s:23:\"platform_material_video\";s:6:\"active\";s:5:\"video\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:24:\"platform_material_delete\";a:3:{s:5:\"title\";s:6:\"删除\";s:15:\"permission_name\";s:24:\"platform_material_delete\";s:10:\"is_display\";b:0;}}}s:13:\"platform_site\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:2:{i:0;i:1;i:1;i:3;}s:10:\"is_display\";i:1;s:5:\"title\";s:16:\"微官网-文章\";s:3:\"url\";s:27:\"./index.php?c=site&a=multi&\";s:15:\"permission_name\";s:13:\"platform_site\";s:4:\"icon\";s:10:\"wi wi-home\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:4:{s:19:\"platform_site_multi\";a:4:{s:5:\"title\";s:9:\"微官网\";s:3:\"url\";s:38:\"./index.php?c=site&a=multi&do=display&\";s:15:\"permission_name\";s:19:\"platform_site_multi\";s:6:\"active\";s:5:\"multi\";}s:19:\"platform_site_style\";a:4:{s:5:\"title\";s:15:\"微官网模板\";s:3:\"url\";s:39:\"./index.php?c=site&a=style&do=template&\";s:15:\"permission_name\";s:19:\"platform_site_style\";s:6:\"active\";s:5:\"style\";}s:21:\"platform_site_article\";a:4:{s:5:\"title\";s:12:\"文章管理\";s:3:\"url\";s:40:\"./index.php?c=site&a=article&do=display&\";s:15:\"permission_name\";s:21:\"platform_site_article\";s:6:\"active\";s:7:\"article\";}s:22:\"platform_site_category\";a:4:{s:5:\"title\";s:18:\"文章分类管理\";s:3:\"url\";s:41:\"./index.php?c=site&a=category&do=display&\";s:15:\"permission_name\";s:22:\"platform_site_category\";s:6:\"active\";s:8:\"category\";}}}}s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}}s:15:\"platform_module\";a:3:{s:5:\"title\";s:12:\"应用模块\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:2:\"mc\";a:3:{s:5:\"title\";s:6:\"粉丝\";s:4:\"menu\";a:3:{s:7:\"mc_fans\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"粉丝管理\";s:3:\"url\";s:24:\"./index.php?c=mc&a=fans&\";s:15:\"permission_name\";s:7:\"mc_fans\";s:4:\"icon\";s:16:\"wi wi-fansmanage\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:15:\"mc_fans_display\";a:4:{s:5:\"title\";s:12:\"全部粉丝\";s:3:\"url\";s:35:\"./index.php?c=mc&a=fans&do=display&\";s:15:\"permission_name\";s:15:\"mc_fans_display\";s:6:\"active\";s:7:\"display\";}s:21:\"mc_fans_fans_sync_set\";a:4:{s:5:\"title\";s:18:\"粉丝同步设置\";s:3:\"url\";s:41:\"./index.php?c=mc&a=fans&do=fans_sync_set&\";s:15:\"permission_name\";s:21:\"mc_fans_fans_sync_set\";s:6:\"active\";s:13:\"fans_sync_set\";}}}s:9:\"mc_member\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"会员管理\";s:3:\"url\";s:26:\"./index.php?c=mc&a=member&\";s:15:\"permission_name\";s:9:\"mc_member\";s:4:\"icon\";s:10:\"wi wi-fans\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:7:{s:17:\"mc_member_diaplsy\";a:4:{s:5:\"title\";s:12:\"会员管理\";s:3:\"url\";s:37:\"./index.php?c=mc&a=member&do=display&\";s:15:\"permission_name\";s:17:\"mc_member_diaplsy\";s:6:\"active\";s:7:\"display\";}s:15:\"mc_member_group\";a:4:{s:5:\"title\";s:9:\"会员组\";s:3:\"url\";s:36:\"./index.php?c=mc&a=group&do=display&\";s:15:\"permission_name\";s:15:\"mc_member_group\";s:6:\"active\";s:7:\"display\";}s:12:\"mc_member_uc\";a:5:{s:5:\"title\";s:12:\"会员中心\";s:3:\"url\";s:34:\"./index.php?c=site&a=editor&do=uc&\";s:15:\"permission_name\";s:12:\"mc_member_uc\";s:6:\"active\";s:2:\"uc\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:19:\"mc_member_quickmenu\";a:5:{s:5:\"title\";s:12:\"快捷菜单\";s:3:\"url\";s:41:\"./index.php?c=site&a=editor&do=quickmenu&\";s:15:\"permission_name\";s:19:\"mc_member_quickmenu\";s:6:\"active\";s:9:\"quickmenu\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:25:\"mc_member_register_seting\";a:5:{s:5:\"title\";s:12:\"注册设置\";s:3:\"url\";s:46:\"./index.php?c=mc&a=member&do=register_setting&\";s:15:\"permission_name\";s:25:\"mc_member_register_seting\";s:6:\"active\";s:16:\"register_setting\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:24:\"mc_member_credit_setting\";a:4:{s:5:\"title\";s:12:\"积分设置\";s:3:\"url\";s:44:\"./index.php?c=mc&a=member&do=credit_setting&\";s:15:\"permission_name\";s:24:\"mc_member_credit_setting\";s:6:\"active\";s:14:\"credit_setting\";}s:16:\"mc_member_fields\";a:4:{s:5:\"title\";s:18:\"会员字段管理\";s:3:\"url\";s:34:\"./index.php?c=mc&a=fields&do=list&\";s:15:\"permission_name\";s:16:\"mc_member_fields\";s:6:\"active\";s:4:\"list\";}}}s:10:\"mc_message\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"留言管理\";s:3:\"url\";s:27:\"./index.php?c=mc&a=message&\";s:15:\"permission_name\";s:10:\"mc_message\";s:4:\"icon\";s:13:\"wi wi-message\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}}s:7:\"profile\";a:3:{s:5:\"title\";s:6:\"配置\";s:4:\"menu\";a:7:{s:15:\"profile_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"参数配置\";s:3:\"url\";s:31:\"./index.php?c=profile&a=remote&\";s:15:\"permission_name\";s:15:\"profile_setting\";s:4:\"icon\";s:23:\"wi wi-parameter-setting\";s:12:\"displayorder\";i:7;s:2:\"id\";N;s:14:\"sub_permission\";a:6:{s:22:\"profile_setting_remote\";a:4:{s:5:\"title\";s:12:\"远程附件\";s:3:\"url\";s:42:\"./index.php?c=profile&a=remote&do=display&\";s:15:\"permission_name\";s:22:\"profile_setting_remote\";s:6:\"active\";s:7:\"display\";}s:24:\"profile_setting_passport\";a:5:{s:5:\"title\";s:12:\"借用权限\";s:3:\"url\";s:42:\"./index.php?c=profile&a=passport&do=oauth&\";s:15:\"permission_name\";s:24:\"profile_setting_passport\";s:6:\"active\";s:5:\"oauth\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:25:\"profile_setting_tplnotice\";a:5:{s:5:\"title\";s:18:\"微信通知设置\";s:3:\"url\";s:42:\"./index.php?c=profile&a=tplnotice&do=list&\";s:15:\"permission_name\";s:25:\"profile_setting_tplnotice\";s:6:\"active\";s:4:\"list\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:22:\"profile_setting_notify\";a:5:{s:5:\"title\";s:18:\"邮件通知参数\";s:3:\"url\";s:39:\"./index.php?c=profile&a=notify&do=mail&\";s:15:\"permission_name\";s:22:\"profile_setting_notify\";s:6:\"active\";s:4:\"mail\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:26:\"profile_setting_uc_setting\";a:5:{s:5:\"title\";s:14:\"UC站点整合\";s:3:\"url\";s:45:\"./index.php?c=profile&a=common&do=uc_setting&\";s:15:\"permission_name\";s:26:\"profile_setting_uc_setting\";s:6:\"active\";s:10:\"uc_setting\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:27:\"profile_setting_upload_file\";a:5:{s:5:\"title\";s:20:\"上传JS接口文件\";s:3:\"url\";s:46:\"./index.php?c=profile&a=common&do=upload_file&\";s:15:\"permission_name\";s:27:\"profile_setting_upload_file\";s:6:\"active\";s:11:\"upload_file\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}}}s:15:\"profile_payment\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:2:{i:0;i:1;i:1;i:3;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"支付参数\";s:3:\"url\";s:32:\"./index.php?c=profile&a=payment&\";s:15:\"permission_name\";s:15:\"profile_payment\";s:4:\"icon\";s:17:\"wi wi-pay-setting\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:19:\"profile_payment_pay\";a:4:{s:5:\"title\";s:12:\"支付配置\";s:3:\"url\";s:32:\"./index.php?c=profile&a=payment&\";s:15:\"permission_name\";s:19:\"profile_payment_pay\";s:6:\"active\";s:7:\"payment\";}s:22:\"profile_payment_refund\";a:4:{s:5:\"title\";s:12:\"退款配置\";s:3:\"url\";s:42:\"./index.php?c=profile&a=refund&do=display&\";s:15:\"permission_name\";s:22:\"profile_payment_refund\";s:6:\"active\";s:6:\"refund\";}}}s:23:\"profile_app_module_link\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"数据同步\";s:3:\"url\";s:44:\"./index.php?c=profile&a=module-link-uniacid&\";s:15:\"permission_name\";s:31:\"profile_app_module_link_uniacid\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"profile_bind_domain\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"域名绑定\";s:3:\"url\";s:36:\"./index.php?c=profile&a=bind-domain&\";s:15:\"permission_name\";s:19:\"profile_bind_domain\";s:4:\"icon\";s:17:\"wi wi-bind-domain\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:18:\"webapp_module_link\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:1:{i:0;i:5;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"数据同步\";s:3:\"url\";s:44:\"./index.php?c=profile&a=module-link-uniacid&\";s:15:\"permission_name\";s:18:\"webapp_module_link\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:14:\"webapp_rewrite\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:1:{i:0;i:5;}s:10:\"is_display\";i:0;s:5:\"title\";s:9:\"伪静态\";s:3:\"url\";s:31:\"./index.php?c=webapp&a=rewrite&\";s:15:\"permission_name\";s:14:\"webapp_rewrite\";s:4:\"icon\";s:13:\"wi wi-rewrite\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:18:\"webapp_bind_domain\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:1:{i:0;i:5;}s:10:\"is_display\";i:0;s:5:\"title\";s:18:\"域名访问设置\";s:3:\"url\";s:35:\"./index.php?c=webapp&a=bind-domain&\";s:15:\"permission_name\";s:18:\"webapp_bind_domain\";s:4:\"icon\";s:17:\"wi wi-bind-domain\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}}s:10:\"statistics\";a:3:{s:5:\"title\";s:6:\"统计\";s:4:\"menu\";a:2:{s:16:\"statistics_visit\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"访问统计\";s:3:\"url\";s:31:\"./index.php?c=statistics&a=app&\";s:15:\"permission_name\";s:16:\"statistics_visit\";s:4:\"icon\";s:17:\"wi wi-statistical\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:3:{s:20:\"statistics_visit_app\";a:4:{s:5:\"title\";s:24:\"app端访问统计信息\";s:3:\"url\";s:42:\"./index.php?c=statistics&a=app&do=display&\";s:15:\"permission_name\";s:20:\"statistics_visit_app\";s:6:\"active\";s:3:\"app\";}s:21:\"statistics_visit_site\";a:4:{s:5:\"title\";s:24:\"所有用户访问统计\";s:3:\"url\";s:51:\"./index.php?c=statistics&a=site&do=current_account&\";s:15:\"permission_name\";s:21:\"statistics_visit_site\";s:6:\"active\";s:4:\"site\";}s:24:\"statistics_visit_setting\";a:4:{s:5:\"title\";s:18:\"访问统计设置\";s:3:\"url\";s:46:\"./index.php?c=statistics&a=setting&do=display&\";s:15:\"permission_name\";s:24:\"statistics_visit_setting\";s:6:\"active\";s:7:\"setting\";}}}s:15:\"statistics_fans\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"用户统计\";s:3:\"url\";s:32:\"./index.php?c=statistics&a=fans&\";s:15:\"permission_name\";s:15:\"statistics_fans\";s:4:\"icon\";s:17:\"wi wi-statistical\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:13;}s:5:\"wxapp\";a:8:{s:5:\"title\";s:15:\"微信小程序\";s:4:\"icon\";s:19:\"wi wi-small-routine\";s:9:\"dimension\";i:3;s:3:\"url\";s:38:\"./index.php?c=wxapp&a=display&do=home&\";s:7:\"section\";a:5:{s:14:\"wxapp_entrance\";a:4:{s:5:\"title\";s:15:\"小程序入口\";s:4:\"menu\";a:1:{s:20:\"module_entrance_link\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"入口页面\";s:3:\"url\";s:36:\"./index.php?c=wxapp&a=entrance-link&\";s:15:\"permission_name\";s:19:\"wxapp_entrance_link\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;}s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:2:\"mc\";a:4:{s:5:\"title\";s:6:\"粉丝\";s:4:\"menu\";a:1:{s:9:\"mc_member\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:6:\"会员\";s:3:\"url\";s:26:\"./index.php?c=mc&a=member&\";s:15:\"permission_name\";s:15:\"mc_wxapp_member\";s:4:\"icon\";s:10:\"wi wi-fans\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:4:{s:17:\"mc_member_diaplsy\";a:4:{s:5:\"title\";s:12:\"会员管理\";s:3:\"url\";s:37:\"./index.php?c=mc&a=member&do=display&\";s:15:\"permission_name\";s:17:\"mc_member_diaplsy\";s:6:\"active\";s:7:\"display\";}s:15:\"mc_member_group\";a:4:{s:5:\"title\";s:9:\"会员组\";s:3:\"url\";s:36:\"./index.php?c=mc&a=group&do=display&\";s:15:\"permission_name\";s:15:\"mc_member_group\";s:6:\"active\";s:7:\"display\";}s:24:\"mc_member_credit_setting\";a:4:{s:5:\"title\";s:12:\"积分设置\";s:3:\"url\";s:44:\"./index.php?c=mc&a=member&do=credit_setting&\";s:15:\"permission_name\";s:24:\"mc_member_credit_setting\";s:6:\"active\";s:14:\"credit_setting\";}s:16:\"mc_member_fields\";a:4:{s:5:\"title\";s:18:\"会员字段管理\";s:3:\"url\";s:34:\"./index.php?c=mc&a=fields&do=list&\";s:15:\"permission_name\";s:16:\"mc_member_fields\";s:6:\"active\";s:4:\"list\";}}}}s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;}s:13:\"wxapp_profile\";a:3:{s:5:\"title\";s:6:\"配置\";s:4:\"menu\";a:5:{s:33:\"wxapp_profile_module_link_uniacid\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:7:{i:0;i:4;i:1;i:7;i:2;i:8;i:3;i:6;i:4;i:11;i:5;i:12;i:6;i:13;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"数据同步\";s:3:\"url\";s:42:\"./index.php?c=wxapp&a=module-link-uniacid&\";s:15:\"permission_name\";s:33:\"wxapp_profile_module_link_uniacid\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:21:\"wxapp_profile_payment\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"支付参数\";s:3:\"url\";s:30:\"./index.php?c=wxapp&a=payment&\";s:15:\"permission_name\";s:21:\"wxapp_profile_payment\";s:4:\"icon\";s:16:\"wi wi-appsetting\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:17:\"wxapp_payment_pay\";a:4:{s:5:\"title\";s:12:\"支付参数\";s:3:\"url\";s:41:\"./index.php?c=wxapp&a=payment&do=display&\";s:15:\"permission_name\";s:17:\"wxapp_payment_pay\";s:6:\"active\";s:7:\"payment\";}s:20:\"wxapp_payment_refund\";a:4:{s:5:\"title\";s:12:\"退款配置\";s:3:\"url\";s:40:\"./index.php?c=wxapp&a=refund&do=display&\";s:15:\"permission_name\";s:20:\"wxapp_payment_refund\";s:6:\"active\";s:6:\"refund\";}}}s:28:\"wxapp_profile_front_download\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"下载程序包\";s:3:\"url\";s:37:\"./index.php?c=wxapp&a=front-download&\";s:15:\"permission_name\";s:28:\"wxapp_profile_front_download\";s:4:\"icon\";s:13:\"wi wi-examine\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:23:\"wxapp_profile_domainset\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"域名设置\";s:3:\"url\";s:32:\"./index.php?c=wxapp&a=domainset&\";s:15:\"permission_name\";s:23:\"wxapp_profile_domainset\";s:4:\"icon\";s:13:\"wi wi-examine\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:22:\"profile_setting_remote\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"参数配置\";s:3:\"url\";s:31:\"./index.php?c=profile&a=remote&\";s:15:\"permission_name\";s:22:\"profile_setting_remote\";s:4:\"icon\";s:23:\"wi wi-parameter-setting\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:7:{i:0;i:4;i:1;i:7;i:2;i:8;i:3;i:6;i:4;i:11;i:5;i:12;i:6;i:13;}}s:10:\"statistics\";a:4:{s:5:\"title\";s:6:\"统计\";s:4:\"menu\";a:1:{s:16:\"statistics_visit\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:7:{i:0;i:4;i:1;i:7;i:2;i:8;i:3;i:6;i:4;i:11;i:5;i:12;i:6;i:13;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"访问统计\";s:3:\"url\";s:31:\"./index.php?c=statistics&a=app&\";s:15:\"permission_name\";s:22:\"statistics_visit_wxapp\";s:4:\"icon\";s:17:\"wi wi-statistical\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:3:{s:20:\"statistics_visit_app\";a:4:{s:5:\"title\";s:24:\"app端访问统计信息\";s:3:\"url\";s:42:\"./index.php?c=statistics&a=app&do=display&\";s:15:\"permission_name\";s:20:\"statistics_visit_app\";s:6:\"active\";s:3:\"app\";}s:21:\"statistics_visit_site\";a:4:{s:5:\"title\";s:24:\"所有用户访问统计\";s:3:\"url\";s:51:\"./index.php?c=statistics&a=site&do=current_account&\";s:15:\"permission_name\";s:21:\"statistics_visit_site\";s:6:\"active\";s:4:\"site\";}s:24:\"statistics_visit_setting\";a:4:{s:5:\"title\";s:18:\"访问统计设置\";s:3:\"url\";s:46:\"./index.php?c=statistics&a=setting&do=display&\";s:15:\"permission_name\";s:24:\"statistics_visit_setting\";s:6:\"active\";s:7:\"setting\";}}}}s:18:\"permission_display\";a:7:{i:0;i:4;i:1;i:7;i:2;i:8;i:3;i:6;i:4;i:11;i:5;i:12;i:6;i:13;}s:10:\"is_display\";i:0;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:14;}s:6:\"webapp\";a:7:{s:5:\"title\";s:2:\"PC\";s:4:\"icon\";s:8:\"wi wi-pc\";s:3:\"url\";s:39:\"./index.php?c=webapp&a=home&do=display&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:15;}s:5:\"xzapp\";a:7:{s:5:\"title\";s:9:\"熊掌号\";s:4:\"icon\";s:11:\"wi wi-xzapp\";s:3:\"url\";s:38:\"./index.php?c=xzapp&a=home&do=display&\";s:7:\"section\";a:1:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:12:\"应用模块\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:16;}s:6:\"aliapp\";a:7:{s:5:\"title\";s:18:\"支付宝小程序\";s:4:\"icon\";s:12:\"wi wi-aliapp\";s:3:\"url\";s:40:\"./index.php?c=miniapp&a=display&do=home&\";s:7:\"section\";a:1:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:17;}s:8:\"baiduapp\";a:7:{s:5:\"title\";s:15:\"百度小程序\";s:4:\"icon\";s:14:\"wi wi-baiduapp\";s:3:\"url\";s:40:\"./index.php?c=miniapp&a=display&do=home&\";s:7:\"section\";a:1:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:18;}s:10:\"toutiaoapp\";a:7:{s:5:\"title\";s:15:\"头条小程序\";s:4:\"icon\";s:16:\"wi wi-toutiaoapp\";s:3:\"url\";s:40:\"./index.php?c=miniapp&a=display&do=home&\";s:7:\"section\";a:1:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:19;}s:5:\"store\";a:7:{s:5:\"title\";s:6:\"商城\";s:4:\"icon\";s:11:\"wi wi-store\";s:3:\"url\";s:43:\"./index.php?c=home&a=welcome&do=ext&m=store\";s:7:\"section\";a:6:{s:11:\"store_goods\";a:2:{s:5:\"title\";s:12:\"商品分类\";s:4:\"menu\";a:6:{s:18:\"store_goods_module\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"应用模块\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=1\";s:15:\"permission_name\";s:18:\"store_goods_module\";s:4:\"icon\";s:11:\"wi wi-apply\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"store_goods_account\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"平台个数\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=2\";s:15:\"permission_name\";s:19:\"store_goods_account\";s:4:\"icon\";s:13:\"wi wi-account\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"store_goods_account_renew\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"平台续费\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=7\";s:15:\"permission_name\";s:25:\"store_goods_account_renew\";s:4:\"icon\";s:21:\"wi wi-appjurisdiction\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"store_goods_package\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"应用权限组\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=5\";s:15:\"permission_name\";s:19:\"store_goods_package\";s:4:\"icon\";s:21:\"wi wi-appjurisdiction\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"store_goods_users_package\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"用户权限组\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=9\";s:15:\"permission_name\";s:25:\"store_goods_users_package\";s:4:\"icon\";s:22:\"wi wi-userjurisdiction\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:15:\"store_goods_api\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:23:\"应用访问流量(API)\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=6\";s:15:\"permission_name\";s:15:\"store_goods_api\";s:4:\"icon\";s:9:\"wi wi-api\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:12:\"store_manage\";a:3:{s:5:\"title\";s:12:\"商城管理\";s:7:\"founder\";b:1;s:4:\"menu\";a:4:{s:18:\"store_manage_goods\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"添加商品\";s:3:\"url\";s:58:\"./index.php?c=site&a=entry&do=goodsSeller&m=store&direct=1\";s:15:\"permission_name\";s:18:\"store_manage_goods\";s:4:\"icon\";s:15:\"wi wi-goods-add\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:20:\"store_manage_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"商城设置\";s:3:\"url\";s:54:\"./index.php?c=site&a=entry&do=setting&m=store&direct=1\";s:15:\"permission_name\";s:20:\"store_manage_setting\";s:4:\"icon\";s:11:\"wi wi-store\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"store_manage_payset\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"支付设置\";s:3:\"url\";s:57:\"./index.php?c=site&a=entry&do=paySetting&m=store&direct=1\";s:15:\"permission_name\";s:19:\"store_manage_payset\";s:4:\"icon\";s:11:\"wi wi-money\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:23:\"store_manage_permission\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"商城访问权限\";s:3:\"url\";s:57:\"./index.php?c=site&a=entry&do=permission&m=store&direct=1\";s:15:\"permission_name\";s:23:\"store_manage_permission\";s:4:\"icon\";s:15:\"wi wi-blacklist\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:12:\"store_orders\";a:2:{s:5:\"title\";s:12:\"订单管理\";s:4:\"menu\";a:2:{s:15:\"store_orders_my\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"我的订单\";s:3:\"url\";s:53:\"./index.php?c=site&a=entry&do=orders&m=store&direct=1\";s:15:\"permission_name\";s:15:\"store_orders_my\";s:4:\"icon\";s:17:\"wi wi-sale-record\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:17:\"store_cash_orders\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"分销订单\";s:3:\"url\";s:71:\"./index.php?c=site&a=entry&do=cash&m=store&operate=cash_orders&direct=1\";s:15:\"permission_name\";s:17:\"store_cash_orders\";s:4:\"icon\";s:11:\"wi wi-order\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:14:\"store_payments\";a:2:{s:5:\"title\";s:12:\"收入明细\";s:4:\"menu\";a:1:{s:8:\"payments\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"收入明细\";s:3:\"url\";s:55:\"./index.php?c=site&a=entry&do=payments&m=store&direct=1\";s:15:\"permission_name\";s:8:\"payments\";s:4:\"icon\";s:17:\"wi wi-sale-record\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:17:\"store_cash_manage\";a:2:{s:5:\"title\";s:12:\"分销管理\";s:4:\"menu\";a:2:{s:25:\"store_manage_cash_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"分销设置\";s:3:\"url\";s:58:\"./index.php?c=site&a=entry&do=cashsetting&m=store&direct=1\";s:15:\"permission_name\";s:25:\"store_manage_cash_setting\";s:4:\"icon\";s:18:\"wi wi-site-setting\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:16:\"store_check_cash\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"提现审核\";s:3:\"url\";s:73:\"./index.php?c=site&a=entry&do=cash&m=store&operate=consume_order&direct=1\";s:15:\"permission_name\";s:16:\"store_check_cash\";s:4:\"icon\";s:18:\"wi wi-check-select\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:10:\"store_cash\";a:2:{s:5:\"title\";s:12:\"佣金管理\";s:4:\"menu\";a:1:{s:8:\"payments\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"我的佣金\";s:3:\"url\";s:66:\"./index.php?c=site&a=entry&do=cash&m=store&operate=mycash&direct=1\";s:15:\"permission_name\";s:8:\"payments\";s:4:\"icon\";s:10:\"wi wi-list\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:20;}s:11:\"custom_help\";a:7:{s:5:\"title\";s:12:\"本站帮助\";s:4:\"icon\";s:12:\"wi wi-market\";s:3:\"url\";s:39:\"./index.php?c=help&a=display&do=custom&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:21;}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:tuike_pdd:2', 'a:1:{s:6:\"module\";s:9:\"tuike_pdd\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:tuike_jd:2', 'a:1:{s:6:\"module\";s:8:\"tuike_jd\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:tiger_wxdaili', 'a:35:{s:3:\"mid\";s:2:\"14\";s:4:\"name\";s:13:\"tiger_wxdaili\";s:4:\"type\";s:8:\"activity\";s:5:\"title\";s:33:\"微信淘宝客【代理系统】\";s:7:\"version\";s:7:\"2.99.84\";s:7:\"ability\";s:33:\"微信淘宝客【代理系统】\";s:11:\"description\";s:33:\"微信淘宝客【代理系统】\";s:6:\"author\";s:12:\"创心团队\";s:3:\"url\";s:39:\"https://www.huzhan.com/ishop31919/code/\";s:8:\"settings\";s:1:\"1\";s:10:\"subscribes\";a:0:{}s:7:\"handles\";a:12:{i:0;s:5:\"image\";i:1;s:5:\"voice\";i:2;s:5:\"video\";i:3;s:10:\"shortvideo\";i:4;s:8:\"location\";i:5;s:4:\"link\";i:6;s:9:\"subscribe\";i:7;s:2:\"qr\";i:8;s:5:\"trace\";i:9;s:5:\"click\";i:10;s:14:\"merchant_order\";i:11;s:4:\"text\";}s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"0\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:6:\"a:0:{}\";s:13:\"title_initial\";s:1:\"W\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"0\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"1\";s:10:\"oauth_type\";s:1:\"1\";s:16:\"phoneapp_support\";s:1:\"1\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"1\";s:14:\"aliapp_support\";s:1:\"1\";s:4:\"logo\";s:49:\"http://tbk.5ikh.com/addons/tiger_wxdaili/icon.jpg\";s:16:\"baiduapp_support\";s:1:\"1\";s:18:\"toutiaoapp_support\";s:1:\"1\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:65:\"http://tbk.5ikh.com/addons/tiger_wxdaili/preview.jpg?v=1574857517\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:stat_todaylock:2', 'a:1:{s:6:\"expire\";i:1576674856;}');
INSERT INTO `ims_core_cache` VALUES ('we7:accesstoken:2', 'a:2:{s:5:\"token\";s:157:\"28_5jQ7IHpqJsASZAQiz2N3e9vXl_3ldbDThPnavr991bW3f0TpT_6hLwZr2Fi02wDSGHLwtxYsVz6DHUqssA0nNCbNFcul_93DO7kHlyHhRgSbbbWSO1yrhBMu0a-QFBHrXfLjf43vdLk_VWxrUCNbAAALTE\";s:6:\"expire\";i:1577535879;}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:basic', 'a:35:{s:3:\"mid\";s:1:\"1\";s:4:\"name\";s:5:\"basic\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"基本文字回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:24:\"和您进行简单对话\";s:11:\"description\";s:201:\"一问一答得简单对话. 当访客的对话语句中包含指定关键字, 或对话语句完全等于特定关键字, 或符合某些特定的格式时. 系统自动应答设定好的回复内容.\";s:6:\"author\";s:13:\"WeEngine Team\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"0\";s:10:\"oauth_type\";s:1:\"0\";s:16:\"phoneapp_support\";s:1:\"0\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"0\";s:14:\"aliapp_support\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:16:\"baiduapp_support\";s:1:\"0\";s:18:\"toutiaoapp_support\";s:1:\"0\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:57:\"http://tbk.5ikh.com/addons/basic/preview.jpg?v=1574841396\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:basic:2', 'a:1:{s:6:\"module\";s:5:\"basic\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:news', 'a:35:{s:3:\"mid\";s:1:\"2\";s:4:\"name\";s:4:\"news\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:24:\"基本混合图文回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:33:\"为你提供生动的图文资讯\";s:11:\"description\";s:272:\"一问一答得简单对话, 但是回复内容包括图片文字等更生动的媒体内容. 当访客的对话语句中包含指定关键字, 或对话语句完全等于特定关键字, 或符合某些特定的格式时. 系统自动应答设定好的图文回复内容.\";s:6:\"author\";s:13:\"WeEngine Team\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"0\";s:10:\"oauth_type\";s:1:\"0\";s:16:\"phoneapp_support\";s:1:\"0\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"0\";s:14:\"aliapp_support\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:16:\"baiduapp_support\";s:1:\"0\";s:18:\"toutiaoapp_support\";s:1:\"0\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:56:\"http://tbk.5ikh.com/addons/news/preview.jpg?v=1574841396\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:news:2', 'a:1:{s:6:\"module\";s:4:\"news\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:music', 'a:35:{s:3:\"mid\";s:1:\"3\";s:4:\"name\";s:5:\"music\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"基本音乐回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:39:\"提供语音、音乐等音频类回复\";s:11:\"description\";s:183:\"在回复规则中可选择具有语音、音乐等音频类的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝，实现一问一答得简单对话。\";s:6:\"author\";s:13:\"WeEngine Team\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"0\";s:10:\"oauth_type\";s:1:\"0\";s:16:\"phoneapp_support\";s:1:\"0\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"0\";s:14:\"aliapp_support\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:16:\"baiduapp_support\";s:1:\"0\";s:18:\"toutiaoapp_support\";s:1:\"0\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:57:\"http://tbk.5ikh.com/addons/music/preview.jpg?v=1574841396\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:music:2', 'a:1:{s:6:\"module\";s:5:\"music\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:userapi', 'a:35:{s:3:\"mid\";s:1:\"4\";s:4:\"name\";s:7:\"userapi\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:21:\"自定义接口回复\";s:7:\"version\";s:3:\"1.1\";s:7:\"ability\";s:33:\"更方便的第三方接口设置\";s:11:\"description\";s:141:\"自定义接口又称第三方接口，可以让开发者更方便的接入微擎系统，高效的与微信公众平台进行对接整合。\";s:6:\"author\";s:13:\"WeEngine Team\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"0\";s:10:\"oauth_type\";s:1:\"0\";s:16:\"phoneapp_support\";s:1:\"0\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"0\";s:14:\"aliapp_support\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:16:\"baiduapp_support\";s:1:\"0\";s:18:\"toutiaoapp_support\";s:1:\"0\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:59:\"http://tbk.5ikh.com/addons/userapi/preview.jpg?v=1574841396\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:userapi:2', 'a:1:{s:6:\"module\";s:7:\"userapi\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:recharge', 'a:35:{s:3:\"mid\";s:1:\"5\";s:4:\"name\";s:8:\"recharge\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:24:\"会员中心充值模块\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:24:\"提供会员充值功能\";s:11:\"description\";s:0:\"\";s:6:\"author\";s:13:\"WeEngine Team\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"0\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"0\";s:10:\"oauth_type\";s:1:\"0\";s:16:\"phoneapp_support\";s:1:\"0\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"0\";s:14:\"aliapp_support\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:16:\"baiduapp_support\";s:1:\"0\";s:18:\"toutiaoapp_support\";s:1:\"0\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:60:\"http://tbk.5ikh.com/addons/recharge/preview.jpg?v=1574841396\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:recharge:2', 'a:1:{s:6:\"module\";s:8:\"recharge\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:images', 'a:35:{s:3:\"mid\";s:1:\"7\";s:4:\"name\";s:6:\"images\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"基本图片回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:18:\"提供图片回复\";s:11:\"description\";s:132:\"在回复规则中可选择具有图片的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝图片。\";s:6:\"author\";s:13:\"WeEngine Team\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"0\";s:10:\"oauth_type\";s:1:\"0\";s:16:\"phoneapp_support\";s:1:\"0\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"0\";s:14:\"aliapp_support\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:16:\"baiduapp_support\";s:1:\"0\";s:18:\"toutiaoapp_support\";s:1:\"0\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:58:\"http://tbk.5ikh.com/addons/images/preview.jpg?v=1574841396\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:images:2', 'a:1:{s:6:\"module\";s:6:\"images\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:video', 'a:35:{s:3:\"mid\";s:1:\"8\";s:4:\"name\";s:5:\"video\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"基本视频回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:18:\"提供图片回复\";s:11:\"description\";s:132:\"在回复规则中可选择具有视频的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝视频。\";s:6:\"author\";s:13:\"WeEngine Team\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"0\";s:10:\"oauth_type\";s:1:\"0\";s:16:\"phoneapp_support\";s:1:\"0\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"0\";s:14:\"aliapp_support\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:16:\"baiduapp_support\";s:1:\"0\";s:18:\"toutiaoapp_support\";s:1:\"0\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:57:\"http://tbk.5ikh.com/addons/video/preview.jpg?v=1574841396\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:video:2', 'a:1:{s:6:\"module\";s:5:\"video\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:voice', 'a:35:{s:3:\"mid\";s:1:\"9\";s:4:\"name\";s:5:\"voice\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"基本语音回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:18:\"提供语音回复\";s:11:\"description\";s:132:\"在回复规则中可选择具有语音的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝语音。\";s:6:\"author\";s:13:\"WeEngine Team\";s:3:\"url\";s:18:\"http://www.we7.cc/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"0\";s:10:\"oauth_type\";s:1:\"0\";s:16:\"phoneapp_support\";s:1:\"0\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"0\";s:14:\"aliapp_support\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:16:\"baiduapp_support\";s:1:\"0\";s:18:\"toutiaoapp_support\";s:1:\"0\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:57:\"http://tbk.5ikh.com/addons/voice/preview.jpg?v=1574841396\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:voice:2', 'a:1:{s:6:\"module\";s:5:\"voice\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:wxcard', 'a:35:{s:3:\"mid\";s:2:\"11\";s:4:\"name\";s:6:\"wxcard\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"微信卡券回复\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:18:\"微信卡券回复\";s:11:\"description\";s:18:\"微信卡券回复\";s:6:\"author\";s:13:\"WeEngine Team\";s:3:\"url\";s:18:\"http://www.m213.cn\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"0\";s:10:\"oauth_type\";s:1:\"0\";s:16:\"phoneapp_support\";s:1:\"0\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"0\";s:14:\"aliapp_support\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:16:\"baiduapp_support\";s:1:\"0\";s:18:\"toutiaoapp_support\";s:1:\"0\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:58:\"http://tbk.5ikh.com/addons/wxcard/preview.jpg?v=1574841396\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:wxcard:2', 'a:1:{s:6:\"module\";s:6:\"wxcard\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:custom', 'a:35:{s:3:\"mid\";s:1:\"6\";s:4:\"name\";s:6:\"custom\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:15:\"多客服转接\";s:7:\"version\";s:5:\"1.0.0\";s:7:\"ability\";s:36:\"用来接入腾讯的多客服系统\";s:11:\"description\";s:0:\"\";s:6:\"author\";s:13:\"WeEngine Team\";s:3:\"url\";s:17:\"http://bbs.we7.cc\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";a:0:{}s:7:\"handles\";a:6:{i:0;s:5:\"image\";i:1;s:5:\"voice\";i:2;s:5:\"video\";i:3;s:8:\"location\";i:4;s:4:\"link\";i:5;s:4:\"text\";}s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"0\";s:10:\"oauth_type\";s:1:\"0\";s:16:\"phoneapp_support\";s:1:\"0\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"0\";s:14:\"aliapp_support\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:16:\"baiduapp_support\";s:1:\"0\";s:18:\"toutiaoapp_support\";s:1:\"0\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:58:\"http://tbk.5ikh.com/addons/custom/preview.jpg?v=1574841396\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:custom:2', 'a:1:{s:6:\"module\";s:6:\"custom\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:chats', 'a:35:{s:3:\"mid\";s:2:\"10\";s:4:\"name\";s:5:\"chats\";s:4:\"type\";s:6:\"system\";s:5:\"title\";s:18:\"发送客服消息\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:77:\"公众号可以在粉丝最后发送消息的48小时内无限制发送消息\";s:11:\"description\";s:0:\"\";s:6:\"author\";s:9:\"易福网\";s:3:\"url\";s:19:\"http://www.m213.cn/\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"0\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:0:\"\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"0\";s:10:\"oauth_type\";s:1:\"0\";s:16:\"phoneapp_support\";s:1:\"0\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"0\";s:14:\"aliapp_support\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:16:\"baiduapp_support\";s:1:\"0\";s:18:\"toutiaoapp_support\";s:1:\"0\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:57:\"http://tbk.5ikh.com/addons/chats/preview.jpg?v=1574841396\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:chats:2', 'a:1:{s:6:\"module\";s:5:\"chats\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:store', 'a:35:{s:3:\"mid\";s:2:\"12\";s:4:\"name\";s:5:\"store\";s:4:\"type\";s:8:\"business\";s:5:\"title\";s:12:\"站内商城\";s:7:\"version\";s:3:\"1.0\";s:7:\"ability\";s:12:\"站内商城\";s:11:\"description\";s:12:\"站内商城\";s:6:\"author\";s:3:\"we7\";s:3:\"url\";s:0:\"\";s:8:\"settings\";s:1:\"0\";s:10:\"subscribes\";s:0:\"\";s:7:\"handles\";s:0:\"\";s:12:\"isrulefields\";s:1:\"0\";s:8:\"issystem\";s:1:\"1\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:0:\"\";s:13:\"title_initial\";s:1:\"Z\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"2\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"0\";s:10:\"oauth_type\";s:1:\"0\";s:16:\"phoneapp_support\";s:1:\"0\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"0\";s:14:\"aliapp_support\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:16:\"baiduapp_support\";s:1:\"0\";s:18:\"toutiaoapp_support\";s:1:\"0\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:57:\"http://tbk.5ikh.com/addons/store/preview.jpg?v=1574841396\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:store:2', 'a:1:{s:6:\"module\";s:5:\"store\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:unimodules:2', 'a:4:{i:0;s:9:\"tuike_pdd\";i:1;s:8:\"tuike_jd\";i:2;s:13:\"tiger_wxdaili\";i:3;s:11:\"tiger_newhu\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:unicount:2', 's:1:\"1\";');
INSERT INTO `ims_core_cache` VALUES ('we7:jsticket:2', 'a:2:{s:6:\"ticket\";s:86:\"kgt8ON7yVITDhtdwci0qeb59LBviZxFXv0Wew5p8h5CE_dmZkpmFMlkan9-jKo-d4FdG4qjgjtp-CPSi4J8P1Q\";s:6:\"expire\";i:1577535879;}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:1', 'a:53:{s:3:\"uid\";s:1:\"1\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"21a4594e0238b2064885a62ee4022da8@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"Ph6SmlzK\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1574841672\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:12:\"YOUSEESEEYOU\";s:6:\"avatar\";s:137:\"https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWftBuxiac4kVlUZsCHsqQD7kIib2eeIXjOvZVaUh2kTvKCPoicCC9PExopM7ibKoueneUzpKRFrN74jibBmwh40hf9f2/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"河南省\";s:10:\"residecity\";s:12:\"三门峡市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:delete_visit_ip:20191126', 'b:1;');
INSERT INTO `ims_core_cache` VALUES ('upgrade', 'a:3:{s:7:\"upgrade\";b:0;s:4:\"data\";a:5:{s:5:\"errno\";N;s:7:\"message\";s:14:\"发生错误: \";s:5:\"files\";a:0:{}s:7:\"schemas\";a:0:{}s:7:\"upgrade\";b:0;}s:10:\"lastupdate\";i:1577534158;}');
INSERT INTO `ims_core_cache` VALUES ('cloud:transtoken', 's:39:\"b731MHZ97hSGgKvcXW8w51DQsOgid3eErmZWr3Q\";');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:2', 'a:53:{s:3:\"uid\";s:1:\"2\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"baed59514a0bbccbc378989edf99f413@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"f2BP323X\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1574843590\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"晴天\";s:6:\"avatar\";s:133:\"https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWdqYhLCO119OTs3uZeH8mYRGq5wrWeSpU2XQIDa8riatDqnrVpSU97f1EkX58XCSsb0eMW1Y4KxUVgcLebHouPtC/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"上海省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:tiger_newhu:1', 'a:7:{s:2:\"id\";s:1:\"2\";s:7:\"uniacid\";s:1:\"1\";s:6:\"module\";s:11:\"tiger_newhu\";s:7:\"enabled\";s:1:\"1\";s:8:\"settings\";s:5092:\"a:237:{s:6:\"ddcjxz\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:6:\"ddcjjl\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:5:\"fyrmb\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:4:\"zgfa\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:4:\"yjfa\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:4:\"ejfa\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:9:\"diyyjtype\";s:1:\"0\";s:10:\"dlgzsdtype\";s:1:\"0\";s:8:\"cjlxtype\";s:1:\"0\";s:8:\"dztypelx\";s:1:\"0\";s:19:\"tiger_newhu_fansnum\";N;s:15:\"tiger_newhu_usr\";s:0:\"\";s:14:\"nbfchangemoney\";N;s:13:\"nbfhelpgeturl\";N;s:12:\"nbfwxpaypath\";N;s:5:\"mchid\";s:0:\"\";s:6:\"apikey\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:6:\"secret\";s:0:\"\";s:6:\"txtype\";s:1:\"0\";s:10:\"jdppddtype\";s:1:\"0\";s:5:\"szurl\";N;s:9:\"client_ip\";s:0:\"\";s:7:\"szcolor\";N;s:7:\"rmb_num\";N;s:7:\"day_num\";N;s:6:\"tx_num\";N;s:7:\"tklleft\";s:0:\"\";s:8:\"tklright\";s:0:\"\";s:6:\"hztype\";s:0:\"\";s:6:\"qdcode\";N;s:8:\"regurlxy\";s:0:\"\";s:5:\"qdpid\";s:0:\"\";s:6:\"btjzcq\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:6:\"txinfo\";s:0:\"\";s:12:\"locationtype\";s:1:\"3\";s:7:\"jiequan\";s:1:\"0\";s:7:\"paihang\";s:1:\"0\";s:5:\"style\";s:6:\"style2\";s:4:\"head\";N;s:4:\"txon\";N;s:7:\"gztitle\";s:0:\"\";s:8:\"gzpicurl\";s:0:\"\";s:13:\"gzdescription\";s:0:\"\";s:5:\"gzurl\";s:0:\"\";s:6:\"towurl\";N;s:4:\"cjss\";N;s:9:\"serackkey\";s:0:\"\";s:9:\"logintype\";s:1:\"0\";s:8:\"hlAppKey\";s:0:\"\";s:6:\"cjddgz\";s:0:\"\";s:8:\"gdfxtype\";s:1:\"0\";s:13:\"choujiangtype\";s:1:\"0\";s:7:\"pddtjdd\";s:1:\"0\";s:8:\"pddwenan\";s:0:\"\";s:11:\"jdviewwenan\";s:0:\"\";s:12:\"pddviewwenan\";s:0:\"\";s:11:\"yqycjiangli\";s:0:\"\";s:11:\"kuaizhanurl\";s:0:\"\";s:5:\"tljfl\";s:0:\"\";s:6:\"qdtype\";s:1:\"0\";s:7:\"qdtgurl\";s:0:\"\";s:6:\"dxtype\";s:1:\"0\";s:7:\"smstype\";s:4:\"dayu\";s:6:\"juhesj\";N;s:8:\"cxsqtype\";i:2;s:8:\"dyAppKey\";s:0:\"\";s:11:\"dyAppSecret\";s:0:\"\";s:20:\"dysms_free_sign_name\";s:0:\"\";s:19:\"dysms_template_code\";s:0:\"\";s:8:\"jhappkey\";s:0:\"\";s:6:\"jhcode\";s:0:\"\";s:6:\"gzljcj\";s:1:\"0\";s:10:\"qiandaormb\";s:0:\"\";s:6:\"hmyxtp\";s:0:\"\";s:5:\"pddcq\";s:1:\"0\";s:4:\"jdcq\";s:1:\"0\";s:10:\"appfxtltle\";N;s:12:\"appfxcontent\";N;s:5:\"ygzhf\";s:0:\"\";s:11:\"tbviewwenan\";N;s:5:\"gzewm\";s:0:\"\";s:5:\"kfewm\";s:0:\"\";s:7:\"hdtitle\";N;s:9:\"hdcontent\";N;s:7:\"qtstyle\";s:7:\"style99\";s:9:\"dhcontent\";N;s:9:\"dtkAppKey\";s:0:\"\";s:5:\"ptpid\";s:0:\"\";s:5:\"qqpid\";s:0:\"\";s:8:\"tkAppKey\";s:0:\"\";s:11:\"tksecretKey\";s:0:\"\";s:10:\"jqtkAppKey\";s:0:\"\";s:13:\"jqtksecretKey\";s:0:\"\";s:6:\"sdjltx\";s:0:\"\";s:6:\"sjjltx\";s:0:\"\";s:5:\"miyao\";s:0:\"\";s:10:\"qiandaourl\";s:0:\"\";s:7:\"jfscurl\";s:0:\"\";s:6:\"fxtype\";s:1:\"0\";s:3:\"zgf\";s:0:\"\";s:3:\"yjf\";s:0:\"\";s:3:\"ejf\";s:0:\"\";s:4:\"fxkg\";s:1:\"0\";s:6:\"yjtype\";s:0:\"\";s:9:\"cjssclass\";N;s:7:\"fxtitle\";s:0:\"\";s:9:\"fxcontent\";s:0:\"\";s:8:\"fxpicurl\";s:0:\"\";s:4:\"lbtx\";s:1:\"0\";s:5:\"gzhfl\";s:1:\"0\";s:5:\"flmsg\";s:0:\"\";s:6:\"flmsg1\";s:0:\"\";s:5:\"jzcjq\";s:1:\"0\";s:8:\"newflmsg\";s:0:\"\";s:8:\"adzoneid\";s:0:\"\";s:6:\"siteid\";s:0:\"\";s:5:\"ermsg\";s:0:\"\";s:7:\"zgtxmsg\";s:0:\"\";s:7:\"yjtxmsg\";s:0:\"\";s:7:\"ejtxmsg\";s:0:\"\";s:4:\"jfbl\";s:0:\"\";s:6:\"tttype\";s:1:\"0\";s:7:\"tttitle\";s:0:\"\";s:8:\"ttpicurl\";s:0:\"\";s:5:\"tturl\";s:0:\"\";s:5:\"ttsum\";s:0:\"\";s:9:\"yongjinjs\";s:0:\"\";s:4:\"tkzs\";N;s:8:\"jqrflmsg\";s:0:\"\";s:4:\"wzcj\";s:1:\"0\";s:6:\"yetype\";s:0:\"\";s:7:\"phbtype\";s:1:\"0\";s:4:\"tbid\";s:0:\"\";s:10:\"huiyuanurl\";s:0:\"\";s:3:\"hpx\";s:1:\"0\";s:10:\"hongbaourl\";s:0:\"\";s:6:\"yhlist\";s:1:\"0\";s:8:\"cjpicurl\";s:0:\"\";s:6:\"rxyjxs\";s:1:\"0\";s:10:\"hongbaoykg\";s:1:\"0\";s:10:\"cjsstypesy\";s:1:\"0\";s:10:\"cjsswzxsgs\";s:0:\"\";s:9:\"glyopenid\";s:0:\"\";s:10:\"khgetorder\";s:1:\"0\";s:7:\"khgettx\";s:1:\"0\";s:5:\"ljcjk\";s:1:\"0\";s:6:\"sdtype\";N;s:7:\"fsjldsz\";N;s:7:\"llqtype\";s:1:\"0\";s:8:\"sdguangc\";s:1:\"0\";s:6:\"qfmbid\";s:1:\"0\";s:4:\"fcss\";s:1:\"1\";s:7:\"tkltype\";s:1:\"0\";s:4:\"cxrk\";s:1:\"0\";s:5:\"gzhtp\";s:1:\"0\";s:6:\"mmtype\";s:1:\"0\";s:13:\"dtkapp_secret\";s:0:\"\";s:10:\"dtkapp_key\";s:0:\"\";s:6:\"error1\";s:0:\"\";s:6:\"error2\";s:0:\"\";s:6:\"error3\";s:0:\"\";s:6:\"error4\";s:0:\"\";s:8:\"zbjgtime\";s:0:\"\";s:10:\"zbtouxiang\";s:0:\"\";s:5:\"wsurl\";s:0:\"\";s:6:\"zblive\";s:1:\"0\";s:6:\"yktype\";s:1:\"0\";s:5:\"tbuid\";s:0:\"\";s:7:\"sylmkey\";N;s:6:\"cjsszn\";s:1:\"0\";s:5:\"jqrss\";N;s:6:\"gyspsj\";s:0:\"\";s:11:\"newflmsgjqr\";s:0:\"\";s:10:\"lbratetype\";s:1:\"0\";s:7:\"ldgzurl\";s:0:\"\";s:9:\"gzhcjtype\";s:1:\"0\";s:4:\"kfqq\";s:0:\"\";s:6:\"kftime\";s:0:\"\";s:8:\"mspicurl\";s:0:\"\";s:6:\"mstime\";N;s:5:\"cqmsg\";s:0:\"\";s:8:\"topcolor\";s:0:\"\";s:4:\"sy99\";s:1:\"0\";s:5:\"syjhs\";s:1:\"0\";s:4:\"syms\";s:1:\"0\";s:6:\"sybmmk\";s:1:\"0\";s:5:\"syddq\";N;s:9:\"newsstyle\";N;s:5:\"tklmb\";s:0:\"\";s:6:\"sinkey\";s:0:\"\";s:5:\"dwzlj\";s:1:\"0\";s:8:\"zdgdtype\";s:1:\"0\";s:7:\"appname\";s:0:\"\";s:6:\"appico\";s:0:\"\";s:5:\"azurl\";s:0:\"\";s:6:\"iosurl\";s:0:\"\";s:6:\"apptxt\";s:0:\"\";s:8:\"qqtongji\";s:0:\"\";s:6:\"mftype\";s:1:\"0\";s:8:\"mfhhtype\";s:1:\"0\";s:11:\"unionidtype\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:7:\"tljtype\";s:1:\"0\";s:5:\"tljyj\";s:0:\"\";s:6:\"tljsum\";s:0:\"\";s:5:\"tljsx\";s:0:\"\";s:8:\"tljtitle\";s:0:\"\";s:10:\"tljendtime\";N;s:12:\"tljadzone_id\";N;s:9:\"smskgtype\";s:1:\"0\";s:7:\"xqdwzxs\";s:1:\"0\";s:9:\"jhspicurl\";s:0:\"\";s:9:\"tqgpicurl\";s:0:\"\";s:6:\"dlhead\";s:1:\"0\";s:5:\"rjqqq\";N;s:6:\"viewtk\";s:1:\"0\";s:8:\"zhaotype\";s:1:\"0\";s:6:\"dlddfx\";s:1:\"0\";s:7:\"itemewm\";s:1:\"0\";s:8:\"ljqtzapp\";s:1:\"0\";s:10:\"tklnewtype\";N;s:8:\"tknewurl\";s:0:\"\";s:5:\"zydwz\";s:0:\"\";s:6:\"zhaoxs\";s:1:\"0\";s:5:\"ewmlj\";N;s:12:\"hongbaoytype\";s:1:\"0\";s:4:\"mypy\";s:1:\"0\";s:8:\"cjsstype\";s:1:\"0\";s:8:\"hbsctime\";s:0:\"\";s:7:\"hbcsmsg\";s:0:\"\";s:5:\"rwurl\";N;s:6:\"AppKey\";s:0:\"\";s:9:\"appSecret\";s:0:\"\";s:6:\"jdtjdd\";s:1:\"0\";s:4:\"city\";s:0:\"\";}\";s:8:\"shortcut\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:uniaccount:2', 'a:21:{s:4:\"acid\";s:1:\"2\";s:7:\"uniacid\";s:1:\"2\";s:5:\"token\";s:32:\"Nlru68yh2jjJZ6FLsue7JDzsjjlRHI8u\";s:14:\"encodingaeskey\";s:43:\"DBUP17Z244WSqWS9s9299S2u2pzDbPU9272Ui7925P4\";s:5:\"level\";s:1:\"4\";s:4:\"name\";s:9:\"淘宝客\";s:7:\"account\";s:19:\"13310015380@163.com\";s:8:\"original\";s:15:\"gh_1d0bcc6ca900\";s:9:\"signature\";s:0:\"\";s:7:\"country\";s:0:\"\";s:8:\"province\";s:0:\"\";s:4:\"city\";s:0:\"\";s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:10:\"lastupdate\";s:1:\"0\";s:3:\"key\";s:18:\"wx4ce1248fee1b6d3d\";s:6:\"secret\";s:32:\"1e2f6a4a33d751e23f817065607a60eb\";s:7:\"styleid\";s:1:\"0\";s:12:\"subscribeurl\";s:0:\"\";s:18:\"auth_refresh_token\";s:0:\"\";s:11:\"encrypt_key\";s:18:\"wx4ce1248fee1b6d3d\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:site_store_buy:6:2', 'i:0;');
INSERT INTO `ims_core_cache` VALUES ('we7:system_frame:1', 'a:21:{s:8:\"phoneapp\";a:7:{s:5:\"title\";s:3:\"APP\";s:4:\"icon\";s:18:\"wi wi-white-collar\";s:3:\"url\";s:41:\"./index.php?c=phoneapp&a=display&do=home&\";s:7:\"section\";a:2:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:16:\"phoneapp_profile\";a:4:{s:5:\"title\";s:6:\"配置\";s:4:\"menu\";a:2:{s:28:\"profile_phoneapp_module_link\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:1:{i:0;i:6;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"数据同步\";s:3:\"url\";s:42:\"./index.php?c=wxapp&a=module-link-uniacid&\";s:15:\"permission_name\";s:28:\"profile_phoneapp_module_link\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:14:\"front_download\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";b:1;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"下载APP\";s:3:\"url\";s:40:\"./index.php?c=phoneapp&a=front-download&\";s:15:\"permission_name\";s:23:\"phoneapp_front_download\";s:4:\"icon\";s:13:\"wi wi-examine\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:10:\"is_display\";b:1;s:18:\"permission_display\";a:1:{i:0;i:6;}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:0;s:12:\"displayorder\";i:0;}s:7:\"welcome\";a:7:{s:5:\"title\";s:6:\"首页\";s:4:\"icon\";s:10:\"wi wi-home\";s:3:\"url\";s:48:\"./index.php?c=home&a=welcome&do=system&page=home\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:2;}s:8:\"platform\";a:8:{s:5:\"title\";s:12:\"平台入口\";s:4:\"icon\";s:14:\"wi wi-platform\";s:9:\"dimension\";i:2;s:3:\"url\";s:44:\"./index.php?c=account&a=display&do=platform&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:3;}s:6:\"module\";a:8:{s:5:\"title\";s:12:\"应用入口\";s:4:\"icon\";s:11:\"wi wi-apply\";s:9:\"dimension\";i:2;s:3:\"url\";s:53:\"./index.php?c=module&a=display&do=switch_last_module&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:4;}s:14:\"account_manage\";a:8:{s:5:\"title\";s:12:\"平台管理\";s:4:\"icon\";s:21:\"wi wi-platform-manage\";s:9:\"dimension\";i:2;s:3:\"url\";s:31:\"./index.php?c=account&a=manage&\";s:7:\"section\";a:1:{s:14:\"account_manage\";a:2:{s:5:\"title\";s:12:\"平台管理\";s:4:\"menu\";a:4:{s:22:\"account_manage_display\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"平台列表\";s:3:\"url\";s:31:\"./index.php?c=account&a=manage&\";s:15:\"permission_name\";s:22:\"account_manage_display\";s:4:\"icon\";N;s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:1:{i:0;a:2:{s:5:\"title\";s:12:\"帐号停用\";s:15:\"permission_name\";s:19:\"account_manage_stop\";}}}s:22:\"account_manage_recycle\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"回收站\";s:3:\"url\";s:32:\"./index.php?c=account&a=recycle&\";s:15:\"permission_name\";s:22:\"account_manage_recycle\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:12:\"帐号删除\";s:15:\"permission_name\";s:21:\"account_manage_delete\";}i:1;a:2:{s:5:\"title\";s:12:\"帐号恢复\";s:15:\"permission_name\";s:22:\"account_manage_recover\";}}}s:30:\"account_manage_system_platform\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:19:\" 微信开放平台\";s:3:\"url\";s:32:\"./index.php?c=system&a=platform&\";s:15:\"permission_name\";s:30:\"account_manage_system_platform\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:30:\"account_manage_expired_message\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:22:\" 自定义到期提示\";s:3:\"url\";s:40:\"./index.php?c=account&a=expired-message&\";s:15:\"permission_name\";s:30:\"account_manage_expired_message\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:5;}s:13:\"module_manage\";a:8:{s:5:\"title\";s:12:\"应用管理\";s:4:\"icon\";s:19:\"wi wi-module-manage\";s:9:\"dimension\";i:2;s:3:\"url\";s:50:\"./index.php?c=module&a=manage-system&do=installed&\";s:7:\"section\";a:1:{s:13:\"module_manage\";a:2:{s:5:\"title\";s:12:\"应用管理\";s:4:\"menu\";a:5:{s:23:\"module_manage_installed\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"已安装列表\";s:3:\"url\";s:50:\"./index.php?c=module&a=manage-system&do=installed&\";s:15:\"permission_name\";s:23:\"module_manage_installed\";s:4:\"icon\";N;s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:20:\"module_manage_stoped\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"已停用列表\";s:3:\"url\";s:54:\"./index.php?c=module&a=manage-system&do=recycle&type=1\";s:15:\"permission_name\";s:20:\"module_manage_stoped\";s:4:\"icon\";N;s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:27:\"module_manage_not_installed\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"未安装列表\";s:3:\"url\";s:54:\"./index.php?c=module&a=manage-system&do=not_installed&\";s:15:\"permission_name\";s:27:\"module_manage_not_installed\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:21:\"module_manage_recycle\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"回收站\";s:3:\"url\";s:54:\"./index.php?c=module&a=manage-system&do=recycle&type=2\";s:15:\"permission_name\";s:21:\"module_manage_recycle\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:23:\"module_manage_subscribe\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"订阅管理\";s:3:\"url\";s:50:\"./index.php?c=module&a=manage-system&do=subscribe&\";s:15:\"permission_name\";s:23:\"module_manage_subscribe\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:6;}s:11:\"user_manage\";a:8:{s:5:\"title\";s:12:\"用户管理\";s:4:\"icon\";s:16:\"wi wi-user-group\";s:9:\"dimension\";i:2;s:3:\"url\";s:29:\"./index.php?c=user&a=display&\";s:7:\"section\";a:1:{s:11:\"user_manage\";a:2:{s:5:\"title\";s:12:\"用户管理\";s:4:\"menu\";a:7:{s:19:\"user_manage_display\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"普通用户\";s:3:\"url\";s:29:\"./index.php?c=user&a=display&\";s:15:\"permission_name\";s:19:\"user_manage_display\";s:4:\"icon\";N;s:12:\"displayorder\";i:7;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:19:\"user_manage_founder\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"副站长\";s:3:\"url\";s:32:\"./index.php?c=founder&a=display&\";s:15:\"permission_name\";s:19:\"user_manage_founder\";s:4:\"icon\";N;s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:17:\"user_manage_clerk\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"店员管理\";s:3:\"url\";s:39:\"./index.php?c=user&a=display&type=clerk\";s:15:\"permission_name\";s:17:\"user_manage_clerk\";s:4:\"icon\";N;s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:17:\"user_manage_check\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"审核用户\";s:3:\"url\";s:39:\"./index.php?c=user&a=display&type=check\";s:15:\"permission_name\";s:17:\"user_manage_check\";s:4:\"icon\";N;s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:19:\"user_manage_recycle\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"回收站\";s:3:\"url\";s:41:\"./index.php?c=user&a=display&type=recycle\";s:15:\"permission_name\";s:19:\"user_manage_recycle\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:18:\"user_manage_fields\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"用户属性设置\";s:3:\"url\";s:39:\"./index.php?c=user&a=fields&do=display&\";s:15:\"permission_name\";s:18:\"user_manage_fields\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:18:\"user_manage_expire\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"用户过期设置\";s:3:\"url\";s:28:\"./index.php?c=user&a=expire&\";s:15:\"permission_name\";s:18:\"user_manage_expire\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:7;}s:10:\"permission\";a:8:{s:5:\"title\";s:9:\"权限组\";s:4:\"icon\";s:22:\"wi wi-userjurisdiction\";s:9:\"dimension\";i:2;s:3:\"url\";s:29:\"./index.php?c=module&a=group&\";s:7:\"section\";a:1:{s:10:\"permission\";a:2:{s:5:\"title\";s:9:\"权限组\";s:4:\"menu\";a:4:{s:23:\"permission_module_group\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"应用权限组\";s:3:\"url\";s:29:\"./index.php?c=module&a=group&\";s:15:\"permission_name\";s:23:\"permission_module_group\";s:4:\"icon\";N;s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:31:\"permission_create_account_group\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"账号权限组\";s:3:\"url\";s:34:\"./index.php?c=user&a=create-group&\";s:15:\"permission_name\";s:31:\"permission_create_account_group\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:21:\"permission_user_group\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"用户权限组合\";s:3:\"url\";s:27:\"./index.php?c=user&a=group&\";s:15:\"permission_name\";s:21:\"permission_user_group\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}s:24:\"permission_founder_group\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:21:\"副站长权限组合\";s:3:\"url\";s:30:\"./index.php?c=founder&a=group&\";s:15:\"permission_name\";s:24:\"permission_founder_group\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:0:{}}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:8;}s:6:\"system\";a:8:{s:5:\"title\";s:12:\"系统功能\";s:4:\"icon\";s:13:\"wi wi-setting\";s:9:\"dimension\";i:3;s:3:\"url\";s:31:\"./index.php?c=article&a=notice&\";s:7:\"section\";a:5:{s:7:\"article\";a:3:{s:5:\"title\";s:12:\"站内公告\";s:4:\"menu\";a:1:{s:14:\"system_article\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"站内公告\";s:3:\"url\";s:31:\"./index.php?c=article&a=notice&\";s:15:\"permission_name\";s:14:\"system_article\";s:4:\"icon\";s:13:\"wi wi-article\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:12:\"公告列表\";s:15:\"permission_name\";s:26:\"system_article_notice_list\";}i:1;a:2:{s:5:\"title\";s:12:\"公告分类\";s:15:\"permission_name\";s:30:\"system_article_notice_category\";}}}}s:7:\"founder\";b:1;}s:15:\"system_template\";a:3:{s:5:\"title\";s:6:\"模板\";s:4:\"menu\";a:1:{s:15:\"system_template\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"微官网模板\";s:3:\"url\";s:32:\"./index.php?c=system&a=template&\";s:15:\"permission_name\";s:15:\"system_template\";s:4:\"icon\";s:17:\"wi wi-wx-template\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:7:\"founder\";b:1;}s:14:\"system_welcome\";a:3:{s:5:\"title\";s:12:\"系统首页\";s:4:\"menu\";a:2:{s:14:\"system_welcome\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"系统首页应用\";s:3:\"url\";s:60:\"./index.php?c=module&a=manage-system&support=welcome_support\";s:15:\"permission_name\";s:14:\"system_welcome\";s:4:\"icon\";s:20:\"wi wi-system-welcome\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:11:\"system_news\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"系统新闻\";s:3:\"url\";s:29:\"./index.php?c=article&a=news&\";s:15:\"permission_name\";s:11:\"system_news\";s:4:\"icon\";s:13:\"wi wi-article\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{i:0;a:2:{s:5:\"title\";s:13:\"新闻列表 \";s:15:\"permission_name\";s:24:\"system_article_news_list\";}i:1;a:2:{s:5:\"title\";s:13:\"新闻分类 \";s:15:\"permission_name\";s:28:\"system_article_news_category\";}}}}s:7:\"founder\";b:1;}s:17:\"system_statistics\";a:3:{s:5:\"title\";s:6:\"统计\";s:4:\"menu\";a:1:{s:23:\"system_account_analysis\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"访问统计\";s:3:\"url\";s:35:\"./index.php?c=statistics&a=account&\";s:15:\"permission_name\";s:23:\"system_account_analysis\";s:4:\"icon\";s:17:\"wi wi-statistical\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:7:\"founder\";b:1;}s:5:\"cache\";a:2:{s:5:\"title\";s:6:\"缓存\";s:4:\"menu\";a:1:{s:26:\"system_setting_updatecache\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"更新缓存\";s:3:\"url\";s:35:\"./index.php?c=system&a=updatecache&\";s:15:\"permission_name\";s:26:\"system_setting_updatecache\";s:4:\"icon\";s:12:\"wi wi-update\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:9;}s:4:\"site\";a:9:{s:5:\"title\";s:12:\"站点设置\";s:4:\"icon\";s:17:\"wi wi-system-site\";s:9:\"dimension\";i:3;s:3:\"url\";s:28:\"./index.php?c=system&a=site&\";s:7:\"section\";a:4:{s:5:\"cloud\";a:2:{s:5:\"title\";s:9:\"云服务\";s:4:\"menu\";a:3:{s:14:\"system_profile\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"系统升级\";s:3:\"url\";s:30:\"./index.php?c=cloud&a=upgrade&\";s:15:\"permission_name\";s:20:\"system_cloud_upgrade\";s:4:\"icon\";s:11:\"wi wi-cache\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:21:\"system_cloud_register\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"注册站点\";s:3:\"url\";s:30:\"./index.php?c=cloud&a=profile&\";s:15:\"permission_name\";s:21:\"system_cloud_register\";s:4:\"icon\";s:18:\"wi wi-registersite\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:21:\"system_cloud_diagnose\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"云服务诊断\";s:3:\"url\";s:31:\"./index.php?c=cloud&a=diagnose&\";s:15:\"permission_name\";s:21:\"system_cloud_diagnose\";s:4:\"icon\";s:14:\"wi wi-diagnose\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"setting\";a:2:{s:5:\"title\";s:6:\"设置\";s:4:\"menu\";a:9:{s:19:\"system_setting_site\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"站点设置\";s:3:\"url\";s:28:\"./index.php?c=system&a=site&\";s:15:\"permission_name\";s:19:\"system_setting_site\";s:4:\"icon\";s:18:\"wi wi-site-setting\";s:12:\"displayorder\";i:9;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_setting_menu\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"菜单设置\";s:3:\"url\";s:28:\"./index.php?c=system&a=menu&\";s:15:\"permission_name\";s:19:\"system_setting_menu\";s:4:\"icon\";s:18:\"wi wi-menu-setting\";s:12:\"displayorder\";i:8;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_attachment\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"附件设置\";s:3:\"url\";s:34:\"./index.php?c=system&a=attachment&\";s:15:\"permission_name\";s:25:\"system_setting_attachment\";s:4:\"icon\";s:16:\"wi wi-attachment\";s:12:\"displayorder\";i:7;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_systeminfo\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"系统信息\";s:3:\"url\";s:34:\"./index.php?c=system&a=systeminfo&\";s:15:\"permission_name\";s:25:\"system_setting_systeminfo\";s:4:\"icon\";s:17:\"wi wi-system-info\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_setting_logs\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"查看日志\";s:3:\"url\";s:28:\"./index.php?c=system&a=logs&\";s:15:\"permission_name\";s:19:\"system_setting_logs\";s:4:\"icon\";s:9:\"wi wi-log\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:26:\"system_setting_ipwhitelist\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:11:\"IP白名单\";s:3:\"url\";s:35:\"./index.php?c=system&a=ipwhitelist&\";s:15:\"permission_name\";s:26:\"system_setting_ipwhitelist\";s:4:\"icon\";s:8:\"wi wi-ip\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:28:\"system_setting_sensitiveword\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"过滤敏感词\";s:3:\"url\";s:37:\"./index.php?c=system&a=sensitiveword&\";s:15:\"permission_name\";s:28:\"system_setting_sensitiveword\";s:4:\"icon\";s:15:\"wi wi-sensitive\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"system_setting_thirdlogin\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:25:\"用户登录/注册设置\";s:3:\"url\";s:33:\"./index.php?c=user&a=registerset&\";s:15:\"permission_name\";s:25:\"system_setting_thirdlogin\";s:4:\"icon\";s:10:\"wi wi-user\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:20:\"system_setting_oauth\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"全局借用权限\";s:3:\"url\";s:29:\"./index.php?c=system&a=oauth&\";s:15:\"permission_name\";s:20:\"system_setting_oauth\";s:4:\"icon\";s:11:\"wi wi-oauth\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"utility\";a:2:{s:5:\"title\";s:12:\"常用工具\";s:4:\"menu\";a:6:{s:24:\"system_utility_filecheck\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"系统文件校验\";s:3:\"url\";s:33:\"./index.php?c=system&a=filecheck&\";s:15:\"permission_name\";s:24:\"system_utility_filecheck\";s:4:\"icon\";s:10:\"wi wi-file\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:23:\"system_utility_optimize\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"性能优化\";s:3:\"url\";s:32:\"./index.php?c=system&a=optimize&\";s:15:\"permission_name\";s:23:\"system_utility_optimize\";s:4:\"icon\";s:14:\"wi wi-optimize\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:23:\"system_utility_database\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:9:\"数据库\";s:3:\"url\";s:32:\"./index.php?c=system&a=database&\";s:15:\"permission_name\";s:23:\"system_utility_database\";s:4:\"icon\";s:9:\"wi wi-sql\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"system_utility_scan\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"木马查杀\";s:3:\"url\";s:28:\"./index.php?c=system&a=scan&\";s:15:\"permission_name\";s:19:\"system_utility_scan\";s:4:\"icon\";s:12:\"wi wi-safety\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:18:\"system_utility_bom\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"检测文件BOM\";s:3:\"url\";s:27:\"./index.php?c=system&a=bom&\";s:15:\"permission_name\";s:18:\"system_utility_bom\";s:4:\"icon\";s:9:\"wi wi-bom\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:20:\"system_utility_check\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"系统常规检测\";s:3:\"url\";s:29:\"./index.php?c=system&a=check&\";s:15:\"permission_name\";s:20:\"system_utility_check\";s:4:\"icon\";s:9:\"wi wi-bom\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:7:\"backjob\";a:2:{s:5:\"title\";s:12:\"后台任务\";s:4:\"menu\";a:1:{s:10:\"system_job\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"后台任务\";s:3:\"url\";s:38:\"./index.php?c=system&a=job&do=display&\";s:15:\"permission_name\";s:10:\"system_job\";s:4:\"icon\";s:9:\"wi wi-job\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:7:\"founder\";b:1;s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:10;}s:6:\"myself\";a:8:{s:5:\"title\";s:12:\"我的账户\";s:4:\"icon\";s:10:\"wi wi-bell\";s:9:\"dimension\";i:2;s:3:\"url\";s:29:\"./index.php?c=user&a=profile&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:11;}s:7:\"message\";a:8:{s:5:\"title\";s:12:\"消息管理\";s:4:\"icon\";s:10:\"wi wi-bell\";s:9:\"dimension\";i:2;s:3:\"url\";s:31:\"./index.php?c=message&a=notice&\";s:7:\"section\";a:1:{s:7:\"message\";a:2:{s:5:\"title\";s:12:\"消息管理\";s:4:\"menu\";a:3:{s:14:\"message_notice\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"消息提醒\";s:3:\"url\";s:31:\"./index.php?c=message&a=notice&\";s:15:\"permission_name\";s:14:\"message_notice\";s:4:\"icon\";N;s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:15:\"message_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"消息设置\";s:3:\"url\";s:42:\"./index.php?c=message&a=notice&do=setting&\";s:15:\"permission_name\";s:15:\"message_setting\";s:4:\"icon\";N;s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:22:\"message_wechat_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"微信提醒设置\";s:3:\"url\";s:49:\"./index.php?c=message&a=notice&do=wechat_setting&\";s:15:\"permission_name\";s:22:\"message_wechat_setting\";s:4:\"icon\";N;s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:12;}s:7:\"account\";a:8:{s:5:\"title\";s:9:\"公众号\";s:4:\"icon\";s:18:\"wi wi-white-collar\";s:9:\"dimension\";i:3;s:3:\"url\";s:41:\"./index.php?c=home&a=welcome&do=platform&\";s:7:\"section\";a:5:{s:8:\"platform\";a:3:{s:5:\"title\";s:12:\"增强功能\";s:4:\"menu\";a:6:{s:14:\"platform_reply\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"自动回复\";s:3:\"url\";s:31:\"./index.php?c=platform&a=reply&\";s:15:\"permission_name\";s:14:\"platform_reply\";s:4:\"icon\";s:11:\"wi wi-reply\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";a:7:{s:22:\"platform_reply_keyword\";a:4:{s:5:\"title\";s:21:\"关键字自动回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=keyword\";s:15:\"permission_name\";s:22:\"platform_reply_keyword\";s:6:\"active\";s:7:\"keyword\";}s:22:\"platform_reply_special\";a:4:{s:5:\"title\";s:24:\"非关键字自动回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=special\";s:15:\"permission_name\";s:22:\"platform_reply_special\";s:6:\"active\";s:7:\"special\";}s:22:\"platform_reply_welcome\";a:4:{s:5:\"title\";s:24:\"首次访问自动回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=welcome\";s:15:\"permission_name\";s:22:\"platform_reply_welcome\";s:6:\"active\";s:7:\"welcome\";}s:22:\"platform_reply_default\";a:4:{s:5:\"title\";s:12:\"默认回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=default\";s:15:\"permission_name\";s:22:\"platform_reply_default\";s:6:\"active\";s:7:\"default\";}s:22:\"platform_reply_service\";a:4:{s:5:\"title\";s:12:\"常用服务\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=service\";s:15:\"permission_name\";s:22:\"platform_reply_service\";s:6:\"active\";s:7:\"service\";}s:22:\"platform_reply_userapi\";a:5:{s:5:\"title\";s:21:\"自定义接口回复\";s:3:\"url\";s:40:\"./index.php?c=platform&a=reply&m=userapi\";s:15:\"permission_name\";s:22:\"platform_reply_userapi\";s:6:\"active\";s:7:\"userapi\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:22:\"platform_reply_setting\";a:4:{s:5:\"title\";s:12:\"回复设置\";s:3:\"url\";s:38:\"./index.php?c=profile&a=reply-setting&\";s:15:\"permission_name\";s:22:\"platform_reply_setting\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}}}s:13:\"platform_menu\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"自定义菜单\";s:3:\"url\";s:38:\"./index.php?c=platform&a=menu&do=post&\";s:15:\"permission_name\";s:13:\"platform_menu\";s:4:\"icon\";s:16:\"wi wi-custommenu\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:21:\"platform_menu_default\";a:4:{s:5:\"title\";s:12:\"默认菜单\";s:3:\"url\";s:38:\"./index.php?c=platform&a=menu&do=post&\";s:15:\"permission_name\";s:21:\"platform_menu_default\";s:6:\"active\";s:4:\"post\";}s:25:\"platform_menu_conditional\";a:5:{s:5:\"title\";s:15:\"个性化菜单\";s:3:\"url\";s:47:\"./index.php?c=platform&a=menu&do=display&type=3\";s:15:\"permission_name\";s:25:\"platform_menu_conditional\";s:6:\"active\";s:7:\"display\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}}}s:11:\"platform_qr\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:2:{i:0;i:1;i:1;i:3;}s:10:\"is_display\";i:1;s:5:\"title\";s:22:\"二维码/转化链接\";s:3:\"url\";s:28:\"./index.php?c=platform&a=qr&\";s:15:\"permission_name\";s:11:\"platform_qr\";s:4:\"icon\";s:12:\"wi wi-qrcode\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:14:\"platform_qr_qr\";a:4:{s:5:\"title\";s:9:\"二维码\";s:3:\"url\";s:36:\"./index.php?c=platform&a=qr&do=list&\";s:15:\"permission_name\";s:14:\"platform_qr_qr\";s:6:\"active\";s:4:\"list\";}s:22:\"platform_qr_statistics\";a:4:{s:5:\"title\";s:21:\"二维码扫描统计\";s:3:\"url\";s:39:\"./index.php?c=platform&a=qr&do=display&\";s:15:\"permission_name\";s:22:\"platform_qr_statistics\";s:6:\"active\";s:7:\"display\";}}}s:17:\"platform_masstask\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"定时群发\";s:3:\"url\";s:30:\"./index.php?c=platform&a=mass&\";s:15:\"permission_name\";s:17:\"platform_masstask\";s:4:\"icon\";s:13:\"wi wi-crontab\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:22:\"platform_masstask_post\";a:4:{s:5:\"title\";s:12:\"定时群发\";s:3:\"url\";s:38:\"./index.php?c=platform&a=mass&do=post&\";s:15:\"permission_name\";s:22:\"platform_masstask_post\";s:6:\"active\";s:4:\"post\";}s:22:\"platform_masstask_send\";a:4:{s:5:\"title\";s:12:\"群发记录\";s:3:\"url\";s:38:\"./index.php?c=platform&a=mass&do=send&\";s:15:\"permission_name\";s:22:\"platform_masstask_send\";s:6:\"active\";s:4:\"send\";}}}s:17:\"platform_material\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:16:\"素材/编辑器\";s:3:\"url\";s:34:\"./index.php?c=platform&a=material&\";s:15:\"permission_name\";s:17:\"platform_material\";s:4:\"icon\";s:12:\"wi wi-redact\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:5:{s:22:\"platform_material_news\";a:4:{s:5:\"title\";s:6:\"图文\";s:3:\"url\";s:43:\"./index.php?c=platform&a=material&type=news\";s:15:\"permission_name\";s:22:\"platform_material_news\";s:6:\"active\";s:4:\"news\";}s:23:\"platform_material_image\";a:4:{s:5:\"title\";s:6:\"图片\";s:3:\"url\";s:44:\"./index.php?c=platform&a=material&type=image\";s:15:\"permission_name\";s:23:\"platform_material_image\";s:6:\"active\";s:5:\"image\";}s:23:\"platform_material_voice\";a:4:{s:5:\"title\";s:6:\"语音\";s:3:\"url\";s:44:\"./index.php?c=platform&a=material&type=voice\";s:15:\"permission_name\";s:23:\"platform_material_voice\";s:6:\"active\";s:5:\"voice\";}s:23:\"platform_material_video\";a:5:{s:5:\"title\";s:6:\"视频\";s:3:\"url\";s:44:\"./index.php?c=platform&a=material&type=video\";s:15:\"permission_name\";s:23:\"platform_material_video\";s:6:\"active\";s:5:\"video\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:24:\"platform_material_delete\";a:3:{s:5:\"title\";s:6:\"删除\";s:15:\"permission_name\";s:24:\"platform_material_delete\";s:10:\"is_display\";b:0;}}}s:13:\"platform_site\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:2:{i:0;i:1;i:1;i:3;}s:10:\"is_display\";i:1;s:5:\"title\";s:16:\"微官网-文章\";s:3:\"url\";s:27:\"./index.php?c=site&a=multi&\";s:15:\"permission_name\";s:13:\"platform_site\";s:4:\"icon\";s:10:\"wi wi-home\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:4:{s:19:\"platform_site_multi\";a:4:{s:5:\"title\";s:9:\"微官网\";s:3:\"url\";s:38:\"./index.php?c=site&a=multi&do=display&\";s:15:\"permission_name\";s:19:\"platform_site_multi\";s:6:\"active\";s:5:\"multi\";}s:19:\"platform_site_style\";a:4:{s:5:\"title\";s:15:\"微官网模板\";s:3:\"url\";s:39:\"./index.php?c=site&a=style&do=template&\";s:15:\"permission_name\";s:19:\"platform_site_style\";s:6:\"active\";s:5:\"style\";}s:21:\"platform_site_article\";a:4:{s:5:\"title\";s:12:\"文章管理\";s:3:\"url\";s:40:\"./index.php?c=site&a=article&do=display&\";s:15:\"permission_name\";s:21:\"platform_site_article\";s:6:\"active\";s:7:\"article\";}s:22:\"platform_site_category\";a:4:{s:5:\"title\";s:18:\"文章分类管理\";s:3:\"url\";s:41:\"./index.php?c=site&a=category&do=display&\";s:15:\"permission_name\";s:22:\"platform_site_category\";s:6:\"active\";s:8:\"category\";}}}}s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}}s:15:\"platform_module\";a:3:{s:5:\"title\";s:12:\"应用模块\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:2:\"mc\";a:3:{s:5:\"title\";s:6:\"粉丝\";s:4:\"menu\";a:3:{s:7:\"mc_fans\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"粉丝管理\";s:3:\"url\";s:24:\"./index.php?c=mc&a=fans&\";s:15:\"permission_name\";s:7:\"mc_fans\";s:4:\"icon\";s:16:\"wi wi-fansmanage\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:15:\"mc_fans_display\";a:4:{s:5:\"title\";s:12:\"全部粉丝\";s:3:\"url\";s:35:\"./index.php?c=mc&a=fans&do=display&\";s:15:\"permission_name\";s:15:\"mc_fans_display\";s:6:\"active\";s:7:\"display\";}s:21:\"mc_fans_fans_sync_set\";a:4:{s:5:\"title\";s:18:\"粉丝同步设置\";s:3:\"url\";s:41:\"./index.php?c=mc&a=fans&do=fans_sync_set&\";s:15:\"permission_name\";s:21:\"mc_fans_fans_sync_set\";s:6:\"active\";s:13:\"fans_sync_set\";}}}s:9:\"mc_member\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"会员管理\";s:3:\"url\";s:26:\"./index.php?c=mc&a=member&\";s:15:\"permission_name\";s:9:\"mc_member\";s:4:\"icon\";s:10:\"wi wi-fans\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:7:{s:17:\"mc_member_diaplsy\";a:4:{s:5:\"title\";s:12:\"会员管理\";s:3:\"url\";s:37:\"./index.php?c=mc&a=member&do=display&\";s:15:\"permission_name\";s:17:\"mc_member_diaplsy\";s:6:\"active\";s:7:\"display\";}s:15:\"mc_member_group\";a:4:{s:5:\"title\";s:9:\"会员组\";s:3:\"url\";s:36:\"./index.php?c=mc&a=group&do=display&\";s:15:\"permission_name\";s:15:\"mc_member_group\";s:6:\"active\";s:7:\"display\";}s:12:\"mc_member_uc\";a:5:{s:5:\"title\";s:12:\"会员中心\";s:3:\"url\";s:34:\"./index.php?c=site&a=editor&do=uc&\";s:15:\"permission_name\";s:12:\"mc_member_uc\";s:6:\"active\";s:2:\"uc\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:19:\"mc_member_quickmenu\";a:5:{s:5:\"title\";s:12:\"快捷菜单\";s:3:\"url\";s:41:\"./index.php?c=site&a=editor&do=quickmenu&\";s:15:\"permission_name\";s:19:\"mc_member_quickmenu\";s:6:\"active\";s:9:\"quickmenu\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:25:\"mc_member_register_seting\";a:5:{s:5:\"title\";s:12:\"注册设置\";s:3:\"url\";s:46:\"./index.php?c=mc&a=member&do=register_setting&\";s:15:\"permission_name\";s:25:\"mc_member_register_seting\";s:6:\"active\";s:16:\"register_setting\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:24:\"mc_member_credit_setting\";a:4:{s:5:\"title\";s:12:\"积分设置\";s:3:\"url\";s:44:\"./index.php?c=mc&a=member&do=credit_setting&\";s:15:\"permission_name\";s:24:\"mc_member_credit_setting\";s:6:\"active\";s:14:\"credit_setting\";}s:16:\"mc_member_fields\";a:4:{s:5:\"title\";s:18:\"会员字段管理\";s:3:\"url\";s:34:\"./index.php?c=mc&a=fields&do=list&\";s:15:\"permission_name\";s:16:\"mc_member_fields\";s:6:\"active\";s:4:\"list\";}}}s:10:\"mc_message\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"留言管理\";s:3:\"url\";s:27:\"./index.php?c=mc&a=message&\";s:15:\"permission_name\";s:10:\"mc_message\";s:4:\"icon\";s:13:\"wi wi-message\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}}s:7:\"profile\";a:3:{s:5:\"title\";s:6:\"配置\";s:4:\"menu\";a:7:{s:15:\"profile_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"参数配置\";s:3:\"url\";s:31:\"./index.php?c=profile&a=remote&\";s:15:\"permission_name\";s:15:\"profile_setting\";s:4:\"icon\";s:23:\"wi wi-parameter-setting\";s:12:\"displayorder\";i:7;s:2:\"id\";N;s:14:\"sub_permission\";a:6:{s:22:\"profile_setting_remote\";a:4:{s:5:\"title\";s:12:\"远程附件\";s:3:\"url\";s:42:\"./index.php?c=profile&a=remote&do=display&\";s:15:\"permission_name\";s:22:\"profile_setting_remote\";s:6:\"active\";s:7:\"display\";}s:24:\"profile_setting_passport\";a:5:{s:5:\"title\";s:12:\"借用权限\";s:3:\"url\";s:42:\"./index.php?c=profile&a=passport&do=oauth&\";s:15:\"permission_name\";s:24:\"profile_setting_passport\";s:6:\"active\";s:5:\"oauth\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:25:\"profile_setting_tplnotice\";a:5:{s:5:\"title\";s:18:\"微信通知设置\";s:3:\"url\";s:42:\"./index.php?c=profile&a=tplnotice&do=list&\";s:15:\"permission_name\";s:25:\"profile_setting_tplnotice\";s:6:\"active\";s:4:\"list\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:22:\"profile_setting_notify\";a:5:{s:5:\"title\";s:18:\"邮件通知参数\";s:3:\"url\";s:39:\"./index.php?c=profile&a=notify&do=mail&\";s:15:\"permission_name\";s:22:\"profile_setting_notify\";s:6:\"active\";s:4:\"mail\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:26:\"profile_setting_uc_setting\";a:5:{s:5:\"title\";s:14:\"UC站点整合\";s:3:\"url\";s:45:\"./index.php?c=profile&a=common&do=uc_setting&\";s:15:\"permission_name\";s:26:\"profile_setting_uc_setting\";s:6:\"active\";s:10:\"uc_setting\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}s:27:\"profile_setting_upload_file\";a:5:{s:5:\"title\";s:20:\"上传JS接口文件\";s:3:\"url\";s:46:\"./index.php?c=profile&a=common&do=upload_file&\";s:15:\"permission_name\";s:27:\"profile_setting_upload_file\";s:6:\"active\";s:11:\"upload_file\";s:10:\"is_display\";a:2:{i:0;i:1;i:1;i:3;}}}}s:15:\"profile_payment\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:2:{i:0;i:1;i:1;i:3;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"支付参数\";s:3:\"url\";s:32:\"./index.php?c=profile&a=payment&\";s:15:\"permission_name\";s:15:\"profile_payment\";s:4:\"icon\";s:17:\"wi wi-pay-setting\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:19:\"profile_payment_pay\";a:4:{s:5:\"title\";s:12:\"支付配置\";s:3:\"url\";s:32:\"./index.php?c=profile&a=payment&\";s:15:\"permission_name\";s:19:\"profile_payment_pay\";s:6:\"active\";s:7:\"payment\";}s:22:\"profile_payment_refund\";a:4:{s:5:\"title\";s:12:\"退款配置\";s:3:\"url\";s:42:\"./index.php?c=profile&a=refund&do=display&\";s:15:\"permission_name\";s:22:\"profile_payment_refund\";s:6:\"active\";s:6:\"refund\";}}}s:23:\"profile_app_module_link\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"数据同步\";s:3:\"url\";s:44:\"./index.php?c=profile&a=module-link-uniacid&\";s:15:\"permission_name\";s:31:\"profile_app_module_link_uniacid\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"profile_bind_domain\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"域名绑定\";s:3:\"url\";s:36:\"./index.php?c=profile&a=bind-domain&\";s:15:\"permission_name\";s:19:\"profile_bind_domain\";s:4:\"icon\";s:17:\"wi wi-bind-domain\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:18:\"webapp_module_link\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:1:{i:0;i:5;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"数据同步\";s:3:\"url\";s:44:\"./index.php?c=profile&a=module-link-uniacid&\";s:15:\"permission_name\";s:18:\"webapp_module_link\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:14:\"webapp_rewrite\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:1:{i:0;i:5;}s:10:\"is_display\";i:0;s:5:\"title\";s:9:\"伪静态\";s:3:\"url\";s:31:\"./index.php?c=webapp&a=rewrite&\";s:15:\"permission_name\";s:14:\"webapp_rewrite\";s:4:\"icon\";s:13:\"wi wi-rewrite\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:18:\"webapp_bind_domain\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:1:{i:0;i:5;}s:10:\"is_display\";i:0;s:5:\"title\";s:18:\"域名访问设置\";s:3:\"url\";s:35:\"./index.php?c=webapp&a=bind-domain&\";s:15:\"permission_name\";s:18:\"webapp_bind_domain\";s:4:\"icon\";s:17:\"wi wi-bind-domain\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}}s:10:\"statistics\";a:3:{s:5:\"title\";s:6:\"统计\";s:4:\"menu\";a:2:{s:16:\"statistics_visit\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"访问统计\";s:3:\"url\";s:31:\"./index.php?c=statistics&a=app&\";s:15:\"permission_name\";s:16:\"statistics_visit\";s:4:\"icon\";s:17:\"wi wi-statistical\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";a:3:{s:20:\"statistics_visit_app\";a:4:{s:5:\"title\";s:24:\"app端访问统计信息\";s:3:\"url\";s:42:\"./index.php?c=statistics&a=app&do=display&\";s:15:\"permission_name\";s:20:\"statistics_visit_app\";s:6:\"active\";s:3:\"app\";}s:21:\"statistics_visit_site\";a:4:{s:5:\"title\";s:24:\"所有用户访问统计\";s:3:\"url\";s:51:\"./index.php?c=statistics&a=site&do=current_account&\";s:15:\"permission_name\";s:21:\"statistics_visit_site\";s:6:\"active\";s:4:\"site\";}s:24:\"statistics_visit_setting\";a:4:{s:5:\"title\";s:18:\"访问统计设置\";s:3:\"url\";s:46:\"./index.php?c=statistics&a=setting&do=display&\";s:15:\"permission_name\";s:24:\"statistics_visit_setting\";s:6:\"active\";s:7:\"setting\";}}}s:15:\"statistics_fans\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:4:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;}s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"用户统计\";s:3:\"url\";s:32:\"./index.php?c=statistics&a=fans&\";s:15:\"permission_name\";s:15:\"statistics_fans\";s:4:\"icon\";s:17:\"wi wi-statistical\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:5:{i:0;i:1;i:1;i:3;i:2;i:9;i:3;i:10;i:4;i:5;}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:13;}s:5:\"wxapp\";a:8:{s:5:\"title\";s:15:\"微信小程序\";s:4:\"icon\";s:19:\"wi wi-small-routine\";s:9:\"dimension\";i:3;s:3:\"url\";s:38:\"./index.php?c=wxapp&a=display&do=home&\";s:7:\"section\";a:5:{s:14:\"wxapp_entrance\";a:4:{s:5:\"title\";s:15:\"小程序入口\";s:4:\"menu\";a:1:{s:20:\"module_entrance_link\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"入口页面\";s:3:\"url\";s:36:\"./index.php?c=wxapp&a=entrance-link&\";s:15:\"permission_name\";s:19:\"wxapp_entrance_link\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;}s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}s:2:\"mc\";a:4:{s:5:\"title\";s:6:\"粉丝\";s:4:\"menu\";a:1:{s:9:\"mc_member\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:6:\"会员\";s:3:\"url\";s:26:\"./index.php?c=mc&a=member&\";s:15:\"permission_name\";s:15:\"mc_wxapp_member\";s:4:\"icon\";s:10:\"wi wi-fans\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:4:{s:17:\"mc_member_diaplsy\";a:4:{s:5:\"title\";s:12:\"会员管理\";s:3:\"url\";s:37:\"./index.php?c=mc&a=member&do=display&\";s:15:\"permission_name\";s:17:\"mc_member_diaplsy\";s:6:\"active\";s:7:\"display\";}s:15:\"mc_member_group\";a:4:{s:5:\"title\";s:9:\"会员组\";s:3:\"url\";s:36:\"./index.php?c=mc&a=group&do=display&\";s:15:\"permission_name\";s:15:\"mc_member_group\";s:6:\"active\";s:7:\"display\";}s:24:\"mc_member_credit_setting\";a:4:{s:5:\"title\";s:12:\"积分设置\";s:3:\"url\";s:44:\"./index.php?c=mc&a=member&do=credit_setting&\";s:15:\"permission_name\";s:24:\"mc_member_credit_setting\";s:6:\"active\";s:14:\"credit_setting\";}s:16:\"mc_member_fields\";a:4:{s:5:\"title\";s:18:\"会员字段管理\";s:3:\"url\";s:34:\"./index.php?c=mc&a=fields&do=list&\";s:15:\"permission_name\";s:16:\"mc_member_fields\";s:6:\"active\";s:4:\"list\";}}}}s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;}s:13:\"wxapp_profile\";a:3:{s:5:\"title\";s:6:\"配置\";s:4:\"menu\";a:5:{s:33:\"wxapp_profile_module_link_uniacid\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:7:{i:0;i:4;i:1;i:7;i:2;i:8;i:3;i:6;i:4;i:11;i:5;i:12;i:6;i:13;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"数据同步\";s:3:\"url\";s:42:\"./index.php?c=wxapp&a=module-link-uniacid&\";s:15:\"permission_name\";s:33:\"wxapp_profile_module_link_uniacid\";s:4:\"icon\";s:18:\"wi wi-data-synchro\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:21:\"wxapp_profile_payment\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"支付参数\";s:3:\"url\";s:30:\"./index.php?c=wxapp&a=payment&\";s:15:\"permission_name\";s:21:\"wxapp_profile_payment\";s:4:\"icon\";s:16:\"wi wi-appsetting\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";a:2:{s:17:\"wxapp_payment_pay\";a:4:{s:5:\"title\";s:12:\"支付参数\";s:3:\"url\";s:41:\"./index.php?c=wxapp&a=payment&do=display&\";s:15:\"permission_name\";s:17:\"wxapp_payment_pay\";s:6:\"active\";s:7:\"payment\";}s:20:\"wxapp_payment_refund\";a:4:{s:5:\"title\";s:12:\"退款配置\";s:3:\"url\";s:40:\"./index.php?c=wxapp&a=refund&do=display&\";s:15:\"permission_name\";s:20:\"wxapp_payment_refund\";s:6:\"active\";s:6:\"refund\";}}}s:28:\"wxapp_profile_front_download\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";i:1;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"下载程序包\";s:3:\"url\";s:37:\"./index.php?c=wxapp&a=front-download&\";s:15:\"permission_name\";s:28:\"wxapp_profile_front_download\";s:4:\"icon\";s:13:\"wi wi-examine\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:23:\"wxapp_profile_domainset\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"域名设置\";s:3:\"url\";s:32:\"./index.php?c=wxapp&a=domainset&\";s:15:\"permission_name\";s:23:\"wxapp_profile_domainset\";s:4:\"icon\";s:13:\"wi wi-examine\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:22:\"profile_setting_remote\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:3:{i:0;i:4;i:1;i:7;i:2;i:8;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"参数配置\";s:3:\"url\";s:31:\"./index.php?c=profile&a=remote&\";s:15:\"permission_name\";s:22:\"profile_setting_remote\";s:4:\"icon\";s:23:\"wi wi-parameter-setting\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}}s:18:\"permission_display\";a:7:{i:0;i:4;i:1;i:7;i:2;i:8;i:3;i:6;i:4;i:11;i:5;i:12;i:6;i:13;}}s:10:\"statistics\";a:4:{s:5:\"title\";s:6:\"统计\";s:4:\"menu\";a:1:{s:16:\"statistics_visit\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";a:7:{i:0;i:4;i:1;i:7;i:2;i:8;i:3;i:6;i:4;i:11;i:5;i:12;i:6;i:13;}s:10:\"is_display\";i:0;s:5:\"title\";s:12:\"访问统计\";s:3:\"url\";s:31:\"./index.php?c=statistics&a=app&\";s:15:\"permission_name\";s:22:\"statistics_visit_wxapp\";s:4:\"icon\";s:17:\"wi wi-statistical\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";a:3:{s:20:\"statistics_visit_app\";a:4:{s:5:\"title\";s:24:\"app端访问统计信息\";s:3:\"url\";s:42:\"./index.php?c=statistics&a=app&do=display&\";s:15:\"permission_name\";s:20:\"statistics_visit_app\";s:6:\"active\";s:3:\"app\";}s:21:\"statistics_visit_site\";a:4:{s:5:\"title\";s:24:\"所有用户访问统计\";s:3:\"url\";s:51:\"./index.php?c=statistics&a=site&do=current_account&\";s:15:\"permission_name\";s:21:\"statistics_visit_site\";s:6:\"active\";s:4:\"site\";}s:24:\"statistics_visit_setting\";a:4:{s:5:\"title\";s:18:\"访问统计设置\";s:3:\"url\";s:46:\"./index.php?c=statistics&a=setting&do=display&\";s:15:\"permission_name\";s:24:\"statistics_visit_setting\";s:6:\"active\";s:7:\"setting\";}}}}s:18:\"permission_display\";a:7:{i:0;i:4;i:1;i:7;i:2;i:8;i:3;i:6;i:4;i:11;i:5;i:12;i:6;i:13;}s:10:\"is_display\";i:0;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:14;}s:6:\"webapp\";a:7:{s:5:\"title\";s:2:\"PC\";s:4:\"icon\";s:8:\"wi wi-pc\";s:3:\"url\";s:39:\"./index.php?c=webapp&a=home&do=display&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:15;}s:5:\"xzapp\";a:7:{s:5:\"title\";s:9:\"熊掌号\";s:4:\"icon\";s:11:\"wi wi-xzapp\";s:3:\"url\";s:38:\"./index.php?c=xzapp&a=home&do=display&\";s:7:\"section\";a:1:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:12:\"应用模块\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:16;}s:6:\"aliapp\";a:7:{s:5:\"title\";s:18:\"支付宝小程序\";s:4:\"icon\";s:12:\"wi wi-aliapp\";s:3:\"url\";s:40:\"./index.php?c=miniapp&a=display&do=home&\";s:7:\"section\";a:1:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:17;}s:8:\"baiduapp\";a:7:{s:5:\"title\";s:15:\"百度小程序\";s:4:\"icon\";s:14:\"wi wi-baiduapp\";s:3:\"url\";s:40:\"./index.php?c=miniapp&a=display&do=home&\";s:7:\"section\";a:1:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:18;}s:10:\"toutiaoapp\";a:7:{s:5:\"title\";s:15:\"头条小程序\";s:4:\"icon\";s:16:\"wi wi-toutiaoapp\";s:3:\"url\";s:40:\"./index.php?c=miniapp&a=display&do=home&\";s:7:\"section\";a:1:{s:15:\"platform_module\";a:3:{s:5:\"title\";s:6:\"应用\";s:4:\"menu\";a:0:{}s:10:\"is_display\";b:1;}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:19;}s:5:\"store\";a:7:{s:5:\"title\";s:6:\"商城\";s:4:\"icon\";s:11:\"wi wi-store\";s:3:\"url\";s:43:\"./index.php?c=home&a=welcome&do=ext&m=store\";s:7:\"section\";a:6:{s:11:\"store_goods\";a:2:{s:5:\"title\";s:12:\"商品分类\";s:4:\"menu\";a:6:{s:18:\"store_goods_module\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"应用模块\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=1\";s:15:\"permission_name\";s:18:\"store_goods_module\";s:4:\"icon\";s:11:\"wi wi-apply\";s:12:\"displayorder\";i:6;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"store_goods_account\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"平台个数\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=2\";s:15:\"permission_name\";s:19:\"store_goods_account\";s:4:\"icon\";s:13:\"wi wi-account\";s:12:\"displayorder\";i:5;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"store_goods_account_renew\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"平台续费\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=7\";s:15:\"permission_name\";s:25:\"store_goods_account_renew\";s:4:\"icon\";s:21:\"wi wi-appjurisdiction\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"store_goods_package\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"应用权限组\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=5\";s:15:\"permission_name\";s:19:\"store_goods_package\";s:4:\"icon\";s:21:\"wi wi-appjurisdiction\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:25:\"store_goods_users_package\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:15:\"用户权限组\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=9\";s:15:\"permission_name\";s:25:\"store_goods_users_package\";s:4:\"icon\";s:22:\"wi wi-userjurisdiction\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:15:\"store_goods_api\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:23:\"应用访问流量(API)\";s:3:\"url\";s:64:\"./index.php?c=site&a=entry&do=goodsbuyer&m=store&direct=1&type=6\";s:15:\"permission_name\";s:15:\"store_goods_api\";s:4:\"icon\";s:9:\"wi wi-api\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:12:\"store_manage\";a:3:{s:5:\"title\";s:12:\"商城管理\";s:7:\"founder\";b:1;s:4:\"menu\";a:4:{s:18:\"store_manage_goods\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"添加商品\";s:3:\"url\";s:58:\"./index.php?c=site&a=entry&do=goodsSeller&m=store&direct=1\";s:15:\"permission_name\";s:18:\"store_manage_goods\";s:4:\"icon\";s:15:\"wi wi-goods-add\";s:12:\"displayorder\";i:4;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:20:\"store_manage_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"商城设置\";s:3:\"url\";s:54:\"./index.php?c=site&a=entry&do=setting&m=store&direct=1\";s:15:\"permission_name\";s:20:\"store_manage_setting\";s:4:\"icon\";s:11:\"wi wi-store\";s:12:\"displayorder\";i:3;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:19:\"store_manage_payset\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"支付设置\";s:3:\"url\";s:57:\"./index.php?c=site&a=entry&do=paySetting&m=store&direct=1\";s:15:\"permission_name\";s:19:\"store_manage_payset\";s:4:\"icon\";s:11:\"wi wi-money\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:23:\"store_manage_permission\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:18:\"商城访问权限\";s:3:\"url\";s:57:\"./index.php?c=site&a=entry&do=permission&m=store&direct=1\";s:15:\"permission_name\";s:23:\"store_manage_permission\";s:4:\"icon\";s:15:\"wi wi-blacklist\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:12:\"store_orders\";a:2:{s:5:\"title\";s:12:\"订单管理\";s:4:\"menu\";a:2:{s:15:\"store_orders_my\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"我的订单\";s:3:\"url\";s:53:\"./index.php?c=site&a=entry&do=orders&m=store&direct=1\";s:15:\"permission_name\";s:15:\"store_orders_my\";s:4:\"icon\";s:17:\"wi wi-sale-record\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:17:\"store_cash_orders\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"分销订单\";s:3:\"url\";s:71:\"./index.php?c=site&a=entry&do=cash&m=store&operate=cash_orders&direct=1\";s:15:\"permission_name\";s:17:\"store_cash_orders\";s:4:\"icon\";s:11:\"wi wi-order\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:14:\"store_payments\";a:2:{s:5:\"title\";s:12:\"收入明细\";s:4:\"menu\";a:1:{s:8:\"payments\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"收入明细\";s:3:\"url\";s:55:\"./index.php?c=site&a=entry&do=payments&m=store&direct=1\";s:15:\"permission_name\";s:8:\"payments\";s:4:\"icon\";s:17:\"wi wi-sale-record\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:17:\"store_cash_manage\";a:2:{s:5:\"title\";s:12:\"分销管理\";s:4:\"menu\";a:2:{s:25:\"store_manage_cash_setting\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"分销设置\";s:3:\"url\";s:58:\"./index.php?c=site&a=entry&do=cashsetting&m=store&direct=1\";s:15:\"permission_name\";s:25:\"store_manage_cash_setting\";s:4:\"icon\";s:18:\"wi wi-site-setting\";s:12:\"displayorder\";i:2;s:2:\"id\";N;s:14:\"sub_permission\";N;}s:16:\"store_check_cash\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"提现审核\";s:3:\"url\";s:73:\"./index.php?c=site&a=entry&do=cash&m=store&operate=consume_order&direct=1\";s:15:\"permission_name\";s:16:\"store_check_cash\";s:4:\"icon\";s:18:\"wi wi-check-select\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}s:10:\"store_cash\";a:2:{s:5:\"title\";s:12:\"佣金管理\";s:4:\"menu\";a:1:{s:8:\"payments\";a:10:{s:9:\"is_system\";i:1;s:18:\"permission_display\";N;s:10:\"is_display\";i:1;s:5:\"title\";s:12:\"我的佣金\";s:3:\"url\";s:66:\"./index.php?c=site&a=entry&do=cash&m=store&operate=mycash&direct=1\";s:15:\"permission_name\";s:8:\"payments\";s:4:\"icon\";s:10:\"wi wi-list\";s:12:\"displayorder\";i:1;s:2:\"id\";N;s:14:\"sub_permission\";N;}}}}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:20;}s:11:\"custom_help\";a:7:{s:5:\"title\";s:12:\"本站帮助\";s:4:\"icon\";s:12:\"wi wi-market\";s:3:\"url\";s:39:\"./index.php?c=help&a=display&do=custom&\";s:7:\"section\";a:0:{}s:9:\"is_system\";b:1;s:10:\"is_display\";b:1;s:12:\"displayorder\";i:21;}}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:tuike_pdd:1', 'a:1:{s:6:\"module\";s:9:\"tuike_pdd\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:tuike_jd:1', 'a:1:{s:6:\"module\";s:8:\"tuike_jd\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:tiger_wxdaili:1', 'a:1:{s:6:\"module\";s:13:\"tiger_wxdaili\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:stat_todaylock:1', 'a:1:{s:6:\"expire\";i:1576148001;}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:basic:1', 'a:1:{s:6:\"module\";s:5:\"basic\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:news:1', 'a:1:{s:6:\"module\";s:4:\"news\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:music:1', 'a:1:{s:6:\"module\";s:5:\"music\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:userapi:1', 'a:1:{s:6:\"module\";s:7:\"userapi\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:recharge:1', 'a:1:{s:6:\"module\";s:8:\"recharge\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:images:1', 'a:1:{s:6:\"module\";s:6:\"images\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:video:1', 'a:1:{s:6:\"module\";s:5:\"video\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:voice:1', 'a:1:{s:6:\"module\";s:5:\"voice\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:wxcard:1', 'a:1:{s:6:\"module\";s:6:\"wxcard\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:custom:1', 'a:1:{s:6:\"module\";s:6:\"custom\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:chats:1', 'a:1:{s:6:\"module\";s:5:\"chats\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_setting:store:1', 'a:1:{s:6:\"module\";s:5:\"store\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:24', 'a:53:{s:3:\"uid\";s:2:\"24\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"280674f32294d0b9840c4dc5f5e24c58@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"vf2y1I3O\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576312528\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:15:\"孟蓝蓝蓝蓝\";s:6:\"avatar\";s:132:\"http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKvJiaNbED0ibpWicrpibToUFHId5Cfh7ATatloyWhzoxZiaBV5CaHjt732s995NGJdoURZqgM2I9z86YQ/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"辽宁省\";s:10:\"residecity\";s:9:\"大连市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:unicount:1', 's:1:\"1\";');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:15', 'a:53:{s:3:\"uid\";s:2:\"15\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"df1367b1ed73095d918c5eeba8caf8cd@we7.cc\";s:8:\"password\";s:32:\"8498d41abcdae39ae6b199acc3b98cc7\";s:4:\"salt\";s:8:\"saAUKlKa\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1575013970\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:9:\"李豌豆\";s:6:\"avatar\";s:126:\"https://thirdwx.qlogo.cn/mmopen/ajNVdqHZLLDq99UqtQM4k1Od01teWpvVaqfziax9ia8xmxicC1NEicT70PJ4O8HGCTn9AIR2uA0dlfNZ6JMqwuHBdQ/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"0\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:9:\"百慕大\";s:14:\"resideprovince\";s:3:\"省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:7', 'a:53:{s:3:\"uid\";s:1:\"7\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"fe488dd422720e3266867d76d5eb7260@we7.cc\";s:8:\"password\";s:32:\"59e8f3b15e608f1ca1d75f328d33495b\";s:4:\"salt\";s:8:\"xi2nfmmW\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1574907871\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:10:\"张大欢i\";s:6:\"avatar\";s:129:\"https://thirdwx.qlogo.cn/mmopen/ajNVdqHZLLDl2pIoicZhWHjFqsEQic5T59Rh1DGEpxibZtI8oaOhia8MRK97SRMDGoEnb6ic5eYTibARyWU27jlNUTiaQ/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"上海省\";s:10:\"residecity\";s:15:\"浦东新区市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:delete_visit_ip:20191127', 'b:1;');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:31', 'a:53:{s:3:\"uid\";s:2:\"31\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"b4b7e0d3821bc3aa0acb644cdf96002e@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"fMb5QavI\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576718013\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"鱼儿\";s:6:\"avatar\";s:133:\"https://thirdwx.qlogo.cn/mmopen/5tkFZyjZoYJU0l3G0r1cCaf3TWIeG3Xxpz2OchTSEsNNSnJDiaGXZeNdjOJ4sJqfhc2jfsUjMj3Pl0KBYnjOw7cH5xWJ1GAd7/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"湖北省\";s:10:\"residecity\";s:9:\"宜昌市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:6', 'a:53:{s:3:\"uid\";s:1:\"6\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"706b59ad00def72acf29c5021bb1579b@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"xglFhF0z\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1574866465\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"甜甜\";s:6:\"avatar\";s:136:\"https://thirdwx.qlogo.cn/mmopen/g9nTv4YbEkXxqIqSu495ApZ2PtFV0xM5uliaxAqca6dic3T8avwk0uiaqsRujgqtMrARF2bV9abATDlCwVzJmCUwrj0oiacFuhsE/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"河北省\";s:10:\"residecity\";s:12:\"张家口市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:8', 'a:53:{s:3:\"uid\";s:1:\"8\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"ce011704c6b07c2703c6f239e2870cd5@we7.cc\";s:8:\"password\";s:32:\"593d97616659bea96aac09b1f0f7bc75\";s:4:\"salt\";s:8:\"N9Qyz9el\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1574910082\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"周游\";s:6:\"avatar\";s:128:\"https://thirdwx.qlogo.cn/mmopen/Q3auHgzwzM6qmL6KUA6g1S50icC8yOSZANhGPtXfbetDgVjpeibictGialUdoOm1QOVfIkTKeibpj20bwUEjPmAFAicA/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"瑞士\";s:14:\"resideprovince\";s:12:\"日内瓦省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:delete_visit_ip:20191201', 'b:1;');
INSERT INTO `ims_core_cache` VALUES ('we7:delete_visit_ip:20191207', 'b:1;');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:34', 'a:53:{s:3:\"uid\";s:2:\"34\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"cb935d5ee10b229e4dc6bb4f1cf67fc0@we7.cc\";s:8:\"password\";s:32:\"580c938a8b6c869618d9f3470bee710b\";s:4:\"salt\";s:8:\"Ha5llX7S\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576998569\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:9:\"韩宝音\";s:6:\"avatar\";s:137:\"https://thirdwx.qlogo.cn/mmopen/oibkjzpUkPNwYvk2RNxLBM2uX8s2NrvhVOImAcbn7V7D1KAiaX3jibSicwsxCcJWLAbWvbAYaUPH5Q8fYqeyEJ7XiaRQ1aBvIwpEc/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"北京省\";s:10:\"residecity\";s:9:\"朝阳市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:42', 'a:53:{s:3:\"uid\";s:2:\"42\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"f7e1c81c9d02f5b8b44b8c7116aa24f0@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"M1jSSjJH\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1577248321\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:9:\"菲宝宝\";s:6:\"avatar\";s:136:\"https://thirdwx.qlogo.cn/mmopen/g9nTv4YbEkW02OJB48RRqia73cIeDdRwlHdlhoDibAHbDvFU8fhOsKnfycqSRkibagalLRV9PJ6mw5pueDLaWOhfZak14Re6ibRD/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"北京省\";s:10:\"residecity\";s:9:\"丰台市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:11', 'a:53:{s:3:\"uid\";s:2:\"11\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"f0da89e16ded48f85ac7bbc7098b2474@we7.cc\";s:8:\"password\";s:32:\"eadcbe8bc990be656c4acde9b16c7571\";s:4:\"salt\";s:8:\"uYix22F1\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1574912960\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"iyoung\";s:6:\"avatar\";s:136:\"https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWdqYhLCO119Oa2WxIHBPxTbmWTSlTTlicuFhV7hfcFIbAvib73u84V2FHiciblxL0XfCq0ngqQ83d33Pk51IlzVmGHz/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"上海省\";s:10:\"residecity\";s:9:\"静安市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:12', 'a:53:{s:3:\"uid\";s:2:\"12\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"e5099cea5e335f5b3021aae89cc572bd@we7.cc\";s:8:\"password\";s:32:\"fe4c2cf68f9f8404c121b3d11668c992\";s:4:\"salt\";s:8:\"q288V8jU\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1574947676\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:36:\"德望物流夏国亮（工作用）\";s:6:\"avatar\";s:135:\"https://thirdwx.qlogo.cn/mmopen/FrdAUicrPIibd2sFIwU7Dvu3OXJ0nIDfKyor5B3pkE1VcyLBAVFYWa9LXLsMrtbVWey4Yess3KibtboS6v0B0a9VHUM1Y3xyAuk/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"上海省\";s:10:\"residecity\";s:9:\"闵行市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:13', 'a:53:{s:3:\"uid\";s:2:\"13\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"cb3a556b4b116d341f350e89475b9e8f@we7.cc\";s:8:\"password\";s:32:\"fce1839886b2623824d362daca978522\";s:4:\"salt\";s:8:\"CogTSTg3\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1574948591\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:3:\"鹄\";s:6:\"avatar\";s:133:\"https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWe52UHnTkoZzHwQgavZl1TMOKfPB0kGf9gEIkRkH3Hl9TB3NyvICuibwm0nuZECKNyvaN8EPuPDlZGdkbKKEeVpg/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"0\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:0:\"\";s:14:\"resideprovince\";s:3:\"省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:delete_visit_ip:20191128', 'b:1;');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:14', 'a:53:{s:3:\"uid\";s:2:\"14\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"0422cbf5ceffc3e707edc5ea0f1cefde@we7.cc\";s:8:\"password\";s:32:\"d953b7a153ea8800db780e88d446a074\";s:4:\"salt\";s:8:\"PLue5cDI\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1575013716\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"张靓\";s:6:\"avatar\";s:139:\"https://thirdwx.qlogo.cn/mmopen/5tkFZyjZoYJU0l3G0r1cCSqzUCFeibTbOib0Z2NOpJnASZE09nzWZQicYricnriasUBr6UlgYAdYibtHcz2zwtHKibkDZLjz0Idhak9/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"浙江省\";s:10:\"residecity\";s:9:\"杭州市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:delete_visit_ip:20191203', 'b:1;');
INSERT INTO `ims_core_cache` VALUES ('we7:delete_visit_ip:20191204', 'b:1;');
INSERT INTO `ims_core_cache` VALUES ('we7:delete_visit_ip:20191206', 'b:1;');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:4', 'a:53:{s:3:\"uid\";s:1:\"4\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"1bbbe34a68cd980a436cdd939ff55120@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"Zf9O4KFI\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1574859117\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"橙子\";s:6:\"avatar\";s:135:\"https://thirdwx.qlogo.cn/mmopen/g9nTv4YbEkXEYycwspc5iae2HfRBxYrLAoN7C1DP0GWWTI2z2bC4S77l4MOibYEILbfkH90dyFckIHwJUmkW6icIfvWIUdJoWqK/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"河南省\";s:10:\"residecity\";s:9:\"开封市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:delete_visit_ip:20191129', 'b:1;');
INSERT INTO `ims_core_cache` VALUES ('we7:delete_visit_ip:20191205', 'b:1;');
INSERT INTO `ims_core_cache` VALUES ('we7:delete_visit_ip:20191130', 'b:1;');
INSERT INTO `ims_core_cache` VALUES ('we7:delete_visit_ip:20191202', 'b:1;');
INSERT INTO `ims_core_cache` VALUES ('we7:defaultgroupid:2', 's:1:\"2\";');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:17', 'a:53:{s:3:\"uid\";s:2:\"17\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"c4b2becfc842f033beec2f6a38d70584@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"A7b3HOQq\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1575810435\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:9:\"张文延\";s:6:\"avatar\";s:130:\"http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKyEBiaMIJN3zpmvwrwsPOxVbsbJDFoEKbZyowk1YO0qUOQjbia0XkcFZwib9IJm2Iv8EVmky51nw2fQ/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"上海省\";s:10:\"residecity\";s:15:\"浦东新区市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:module_info:tiger_newhu', 'a:35:{s:3:\"mid\";s:2:\"13\";s:4:\"name\";s:11:\"tiger_newhu\";s:4:\"type\";s:8:\"activity\";s:5:\"title\";s:19:\"新-微信淘宝客\";s:7:\"version\";s:6:\"6.0.35\";s:7:\"ability\";s:19:\"新-微信淘宝客\";s:11:\"description\";s:19:\"新-微信淘宝客\";s:6:\"author\";s:25:\"博雅科技QQ:1661316352\";s:3:\"url\";s:39:\"https://www.huzhan.com/ishop27106/code/\";s:8:\"settings\";s:1:\"1\";s:10:\"subscribes\";a:2:{i:0;s:9:\"subscribe\";i:1;s:11:\"unsubscribe\";}s:7:\"handles\";a:12:{i:0;s:5:\"image\";i:1;s:5:\"voice\";i:2;s:5:\"video\";i:3;s:10:\"shortvideo\";i:4;s:8:\"location\";i:5;s:4:\"link\";i:6;s:9:\"subscribe\";i:7;s:2:\"qr\";i:8;s:5:\"trace\";i:9;s:5:\"click\";i:10;s:14:\"merchant_order\";i:11;s:4:\"text\";}s:12:\"isrulefields\";s:1:\"1\";s:8:\"issystem\";s:1:\"0\";s:6:\"target\";s:1:\"0\";s:6:\"iscard\";s:1:\"0\";s:11:\"permissions\";s:6:\"a:0:{}\";s:13:\"title_initial\";s:1:\"X\";s:13:\"wxapp_support\";s:1:\"1\";s:11:\"app_support\";s:1:\"0\";s:14:\"webapp_support\";s:1:\"1\";s:15:\"welcome_support\";s:1:\"1\";s:10:\"oauth_type\";s:1:\"1\";s:16:\"phoneapp_support\";s:1:\"1\";s:15:\"account_support\";s:1:\"2\";s:13:\"xzapp_support\";s:1:\"1\";s:14:\"aliapp_support\";s:1:\"1\";s:4:\"logo\";s:51:\"http://hztbk.wjlnfs.com/addons/tiger_newhu/icon.jpg\";s:16:\"baiduapp_support\";s:1:\"1\";s:18:\"toutiaoapp_support\";s:1:\"1\";s:9:\"isdisplay\";i:1;s:7:\"preview\";s:67:\"http://hztbk.wjlnfs.com/addons/tiger_newhu/preview.jpg?v=1575862118\";s:11:\"main_module\";b:0;s:11:\"plugin_list\";a:0:{}s:12:\"recycle_info\";a:0:{}}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:18', 'a:53:{s:3:\"uid\";s:2:\"18\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"cb5a9b8316185c73991f88b3b8e86579@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"sSbGsBsB\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1575862377\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:28:\"维健乐商城客服~小维\";s:6:\"avatar\";s:131:\"http://thirdwx.qlogo.cn/mmopen/vi_32/E2E08icS1c1OUKafIoy76EFqBDymF5MibstQjn4F2bXOTnbOPZPbLFtEiaAPI59kH9Vp6GXxGJHbGGaMiaQ1f9St3Q/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:3:\"省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:19', 'a:53:{s:3:\"uid\";s:2:\"19\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"23dabb9a8ad0c67f17a3b7d1a919a9f0@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"G8PI8A8e\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1575877980\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:15:\"火星糖葫芦\";s:6:\"avatar\";s:127:\"http://thirdwx.qlogo.cn/mmopen/vi_32/6OlFfArInlmYpyW4B0jX07xC9ZLYSWTevtnMNtKopkv5EoL45kpMsnzKHHxwzeZubd6aW30cBkPGNJYUA1XNrg/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"上海省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:20', 'a:53:{s:3:\"uid\";s:2:\"20\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"3270cc7b018bd3da9b52dd8dc1fd3490@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"zyGzpzG7\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1575878143\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:9:\"唐某人\";s:6:\"avatar\";s:134:\"http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKKbnW4CtREqR2Bic5a0Ksiczc1ib3RWgTIYQNBicL7rhO7egibHGdOxnNKQ9KibdCuCTzLHO7pJcPHOibDw/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"上海省\";s:10:\"residecity\";s:9:\"长宁市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:21', 'a:53:{s:3:\"uid\";s:2:\"21\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"cc9ddbd3b435cef8b56a371773e11993@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"liNNZbp1\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1575935051\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:23:\"师董会 客服 刘婷\";s:6:\"avatar\";s:129:\"http://thirdwx.qlogo.cn/mmopen/vi_32/rkPlX6T4KDmE2CfFXdcvjpuU4J8CviabONtSO1bia4QKnIhJOXRFmtJ6BANFe2P7XNyguMNh5Mh9toBLCD59wbWA/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"0\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:3:\"省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:33', 'a:53:{s:3:\"uid\";s:2:\"33\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"6fad9c07a515e2da82793d61a30f2a95@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"QmpT572X\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576840553\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:18:\"世纪保理客服\";s:6:\"avatar\";s:130:\"http://thirdwx.qlogo.cn/mmopen/vi_32/8yH6SyTIx6Emkndaf6LRbbFgyyNxvh2DH7iakhn0aZJNNCCCVFGOGCYqzzbvrIkFrqmz2WuoZlKqyibOxfibMKaFA/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"吉林省\";s:10:\"residecity\";s:9:\"长春市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:22', 'a:53:{s:3:\"uid\";s:2:\"22\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"d3ba463b4591da25dc8d91ce86427a3b@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"BB666DiB\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576027280\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:0:\"\";s:6:\"avatar\";s:128:\"http://thirdwx.qlogo.cn/mmopen/vi_32/EOYsicTeX861ItLyd1fd2ueTzCJ7LesnmpA4jFCHpGDpeTW3dsyDdCgaOeloMtW2vl9De67IxwufTH3sDX7abAQ/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"北京省\";s:10:\"residecity\";s:9:\"昌平市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:23', 'a:53:{s:3:\"uid\";s:2:\"23\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"e7bee1b3ad34f551f7852a99ef35a337@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"wmCs8PNK\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576119155\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:9:\"周月璞\";s:6:\"avatar\";s:130:\"http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTL2T1fVJQYlslkYzKrEM4cuvNly2A7wSMtVvjgHknoAiaqKQxWpgKQILxa1RiaW1vgC46rs4icsamXIQ/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"上海省\";s:10:\"residecity\";s:9:\"普陀市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:25', 'a:53:{s:3:\"uid\";s:2:\"25\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"7a7853a92a06dcfba8f9334643bd90f7@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"EHUfw3Uh\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576467154\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:12:\"东方郁华\";s:6:\"avatar\";s:136:\"http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTL4iaNicCaM9zgoj4QicPqKgjJTicL3HGibA23aqYE1AhKibT9OHGR2TIUBFicX9H8XEibnvDfVmLVchTibxJQ/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"河南省\";s:10:\"residecity\";s:9:\"郑州市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:26', 'a:53:{s:3:\"uid\";s:2:\"26\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"de6f9aee74a019fd3494d3ef4aa36b54@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"KeU67dUJ\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576479976\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:4:\"rose\";s:6:\"avatar\";s:133:\"http://thirdwx.qlogo.cn/mmopen/vi_32/DYAIOgq83epNVjeMoibVTGaBw26pvMawzxmDrdnHsFfVogKiaX2cHiah8CxJnyYzYXcuRp4icSic3EqyIRfufebic5wg/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"上海省\";s:10:\"residecity\";s:9:\"徐汇市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:27', 'a:53:{s:3:\"uid\";s:2:\"27\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"97b1473a5210dc0bab3f8385df9436d3@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"k2lE3tYW\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576487471\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"九哥\";s:6:\"avatar\";s:130:\"http://thirdwx.qlogo.cn/mmopen/vi_32/RNHBL7vpkzpiaLDPib1TZlgmxL2Uttic9uvFYRe09UYd81pxvk0psP8nezoXhm21252mV1WMm8FD8G0BxB4v4xZ6g/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"河南省\";s:10:\"residecity\";s:9:\"焦作市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:28', 'a:53:{s:3:\"uid\";s:2:\"28\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"5f137865d6d19ab4f9e2350a9541b839@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"P76xRuhd\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576488501\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:5:\"Panda\";s:6:\"avatar\";s:130:\"http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJrCta0BxlH8qfLZoXx8dsQZPVClKqwpvu5LnaK29MqGtqxbFiaVSjYBmibaibatCHToZY4aPM3pvZRA/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:9:\"百慕大\";s:14:\"resideprovince\";s:3:\"省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:29', 'a:53:{s:3:\"uid\";s:2:\"29\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"f2e721a12e8b817f1526c1ac591804c5@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"aTdJVId3\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576549617\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"大白\";s:6:\"avatar\";s:134:\"http://thirdwx.qlogo.cn/mmopen/vi_32/IsQwBDluGH5bsVJibDr5eIicicW3bXY2X3zIykoFqxPIRJgA4iajxmLnWazicFiaF6MF7ARgZhZ6VRsGwfNCibhxxDY0Q/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"四川省\";s:10:\"residecity\";s:9:\"成都市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:44', 'a:53:{s:3:\"uid\";s:2:\"44\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"be57c8df115cb02e2a0c71e31fd31864@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"uaG9VQQU\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1577421517\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"菲菲\";s:6:\"avatar\";s:130:\"http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLlbJWvrFONK9P9s9ib3fiattmA29muBGJcree0CZZqAmjrRx4BnFpHtjt7ic56HEdlCuES3D1SUKKbA/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"0\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"吉林省\";s:10:\"residecity\";s:9:\"长春市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:5', 'a:53:{s:3:\"uid\";s:1:\"5\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"c3ade0649517c1e99fac3ae20f3d2185@we7.cc\";s:8:\"password\";s:32:\"ff001935f00a87f9a48f10f1f15da787\";s:4:\"salt\";s:8:\"h0PX8yEx\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1574865944\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"李续\";s:6:\"avatar\";s:136:\"https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWcgXic78daA8BhJxcvqEq9u1F4WBwNESwBrr2cfwialzzrMwD4GVdicxo0XFvJbSHxa9fmcjw0fBgzRFiambbqFH1Vg/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"河南省\";s:10:\"residecity\";s:9:\"南阳市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:32', 'a:53:{s:3:\"uid\";s:2:\"32\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"a0681a88a907b8ab4660e417abd8fe77@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"esr2bPIl\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576743953\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:12:\"生活就是\";s:6:\"avatar\";s:133:\"http://thirdwx.qlogo.cn/mmopen/vi_32/0icg5wTP8ljMO47djhJapYaxunJepdAVDo5ZDia4ia7ZdbE4xUvBMvq0DibNuosibvYHrKHPAbLYGZ4vHJXficNUkhpg/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"湖北省\";s:10:\"residecity\";s:9:\"武汉市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:43', 'a:53:{s:3:\"uid\";s:2:\"43\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"b21c68e795ea13ebae57bfcc39223c8b@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"lA24m4EF\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1577349667\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:18:\"捍卫梦想程捷\";s:6:\"avatar\";s:135:\"http://thirdwx.qlogo.cn/mmopen/vi_32/IibiaJKWOs1Jmqd8zvotOuaicYickSjiajFMxjDpnN9JwQu7ibUKENPwokvtk8s4licgXSHgpjdB88iboQank7AyEhsOzQ/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"山东省\";s:10:\"residecity\";s:9:\"莱芜市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:36', 'a:53:{s:3:\"uid\";s:2:\"36\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"d5159b2a6ed416c5909c61d212bd0483@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"Vt8kDzPh\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1577059786\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"悦悦\";s:6:\"avatar\";s:135:\"https://thirdwx.qlogo.cn/mmopen/g9nTv4YbEkW02OJB48RRqrj4zLWLERbFy0N5fTkvWibbgaYQ4hP53DsIC28J1qiczhgymnTuFLTmQuh6Y4uWInBIDoDiaqjEEXR/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"河北省\";s:10:\"residecity\";s:12:\"石家庄市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:35', 'a:53:{s:3:\"uid\";s:2:\"35\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"f3b8a829c1eb8f5ebed123099742eb2b@we7.cc\";s:8:\"password\";s:32:\"04dbf10b0a15e8bb94beb220d45aefd5\";s:4:\"salt\";s:8:\"w2Gvj0h3\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1576998742\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"宋襄\";s:6:\"avatar\";s:133:\"https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWdqYhLCO119Oft9E7q6wrpefyjVjmPSN05pbrapdHgHyzTE8ncCQX4uklzuNOmcHDdiaR2ElYQX2SuI6fmhkA6SE/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"北京省\";s:10:\"residecity\";s:9:\"朝阳市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:37', 'a:53:{s:3:\"uid\";s:2:\"37\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"bcf050ba3b6e14da1835b2ab6b385b12@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"kPHdbbQ1\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1577060230\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:22:\"中苋农业-杨聚辉\";s:6:\"avatar\";s:138:\"https://thirdwx.qlogo.cn/mmopen/oibkjzpUkPNxt9BSDAUhQ6XcgicMSQBpVqWdpDaS8p9hmiaxls7ia0Zy6ekgVUoM4OwVxTWkPPacstRtlmgibnq1EftAic480cdrH6/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"河北省\";s:10:\"residecity\";s:12:\"石家庄市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:38', 'a:53:{s:3:\"uid\";s:2:\"38\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"9dad6cbd46acd221d2b9df6ef9564662@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"vc8WNpP1\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1577070596\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:12:\"入目三分\";s:6:\"avatar\";s:134:\"http://thirdwx.qlogo.cn/mmopen/vi_32/ftmhxOPbc2YAEcLUs5S98luHxN3oXElnhZCib79U7BhxfbIIjibkHickgdkG8SrictyqWogsDianicEDicCUBNIUqLjgw/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"冰岛\";s:14:\"resideprovince\";s:3:\"省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:39', 'a:53:{s:3:\"uid\";s:2:\"39\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"933de318180694b0a81154e9952c6994@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"kqR5331Z\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1577175118\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"赵胖\";s:6:\"avatar\";s:130:\"http://thirdwx.qlogo.cn/mmopen/vi_32/DYAIOgq83eoq8X8jVJtZSKylYR2Lz5wnDrQx0DKPUKQGvDohNCnnUR3eeSibO4LR7ZCFTPm3BRicNlbtO2ibXSdKQ/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"北京省\";s:10:\"residecity\";s:9:\"朝阳市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:40', 'a:53:{s:3:\"uid\";s:2:\"40\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"658c70c3f4e92bf18d6e7eea06ef8f28@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"QKqE2Z0b\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1577175687\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:6:\"张霞\";s:6:\"avatar\";s:130:\"http://thirdwx.qlogo.cn/mmopen/vi_32/DYAIOgq83ep6D3wRxMv0McSyeOo1A3d7odp4zuSkgc3uMicJMibfyN8Qyd2ynpO9JGK8l3H4Y9EshkHiagy7mxI7Q/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:0:\"\";s:14:\"resideprovince\";s:27:\"华夏钰霖万人团队省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:41', 'a:53:{s:3:\"uid\";s:2:\"41\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"7ba42c9db2602f1436b597438ffa35d8@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"RhUz37Ri\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1577189543\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:11:\"Kevin王浩\";s:6:\"avatar\";s:128:\"http://thirdwx.qlogo.cn/mmopen/vi_32/01DZVjQC43mdeMfqRtt7SzHDQdhoTAWMuqHJsoDY3miaJmMADnoIQ5hCckscZELI94zCEj7JnjYdIPYSUESLJOg/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"1\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:3:\"省\";s:10:\"residecity\";s:3:\"市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:10', 'a:53:{s:3:\"uid\";s:2:\"10\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"5be66b102800880aa6568e39e05dadb2@we7.cc\";s:8:\"password\";s:32:\"8dc931bb126998d527bf2584248de622\";s:4:\"salt\";s:8:\"f09V1d61\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1574912467\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:18:\"月牙上的猫咪\";s:6:\"avatar\";s:126:\"https://thirdwx.qlogo.cn/mmopen/PiajxSqBRaEK9wXnNXcDz0k1Q2ibibt0RStUnlRA61HBl2To3VQuN5gdIvsCkJ4DjibflODy7QNN5e32XwLB6kZyGg/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"北京省\";s:10:\"residecity\";s:9:\"朝阳市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
INSERT INTO `ims_core_cache` VALUES ('we7:memberinfo:45', 'a:53:{s:3:\"uid\";s:2:\"45\";s:7:\"uniacid\";s:1:\"2\";s:6:\"mobile\";s:0:\"\";s:5:\"email\";s:39:\"36be1e440db9af7ab12c74e320c8a31c@we7.cc\";s:8:\"password\";s:32:\"5c8a1326c4aff37929f38a36a511e65e\";s:4:\"salt\";s:8:\"iRQl77Zq\";s:7:\"groupid\";s:1:\"2\";s:7:\"credit1\";d:0;s:7:\"credit2\";d:0;s:7:\"credit3\";d:0;s:7:\"credit4\";d:0;s:7:\"credit5\";d:0;s:7:\"credit6\";d:0;s:10:\"createtime\";s:10:\"1577442090\";s:8:\"realname\";s:0:\"\";s:8:\"nickname\";s:8:\"鑫  玥\";s:6:\"avatar\";s:130:\"http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLRrAYSDgCqw4OsaqwuefQKvoTicgg1yDHtPA1Pm4iaVzb3eOYtBZCwUTpwq0gYhKla1ic7NLYhgeNew/132\";s:2:\"qq\";s:0:\"\";s:3:\"vip\";s:1:\"0\";s:6:\"gender\";s:1:\"2\";s:9:\"birthyear\";s:1:\"0\";s:10:\"birthmonth\";s:1:\"0\";s:8:\"birthday\";s:1:\"0\";s:13:\"constellation\";s:0:\"\";s:6:\"zodiac\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:6:\"idcard\";s:0:\"\";s:9:\"studentid\";s:0:\"\";s:5:\"grade\";s:0:\"\";s:7:\"address\";s:0:\"\";s:7:\"zipcode\";s:0:\"\";s:11:\"nationality\";s:6:\"中国\";s:14:\"resideprovince\";s:9:\"山东省\";s:10:\"residecity\";s:9:\"济南市\";s:10:\"residedist\";s:0:\"\";s:14:\"graduateschool\";s:0:\"\";s:7:\"company\";s:0:\"\";s:9:\"education\";s:0:\"\";s:10:\"occupation\";s:0:\"\";s:8:\"position\";s:0:\"\";s:7:\"revenue\";s:0:\"\";s:15:\"affectivestatus\";s:0:\"\";s:10:\"lookingfor\";s:0:\"\";s:9:\"bloodtype\";s:0:\"\";s:6:\"height\";s:0:\"\";s:6:\"weight\";s:0:\"\";s:6:\"alipay\";s:0:\"\";s:3:\"msn\";s:0:\"\";s:6:\"taobao\";s:0:\"\";s:4:\"site\";s:0:\"\";s:3:\"bio\";s:0:\"\";s:8:\"interest\";s:0:\"\";s:12:\"pay_password\";s:0:\"\";}');
COMMIT;

-- ----------------------------
-- Table structure for ims_core_cron
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_cron`;
CREATE TABLE `ims_core_cron` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cloudid` int(10) unsigned NOT NULL,
  `module` varchar(50) NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `filename` varchar(50) NOT NULL,
  `lastruntime` int(10) unsigned NOT NULL,
  `nextruntime` int(10) unsigned NOT NULL,
  `weekday` tinyint(3) NOT NULL,
  `day` tinyint(3) NOT NULL,
  `hour` tinyint(3) NOT NULL,
  `minute` varchar(255) NOT NULL,
  `extra` varchar(5000) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `createtime` (`createtime`),
  KEY `nextruntime` (`nextruntime`),
  KEY `uniacid` (`uniacid`),
  KEY `cloudid` (`cloudid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_core_cron_record
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_cron_record`;
CREATE TABLE `ims_core_cron_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `module` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `tid` int(10) unsigned NOT NULL,
  `note` varchar(500) NOT NULL,
  `tag` varchar(5000) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `tid` (`tid`),
  KEY `module` (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_core_job
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_job`;
CREATE TABLE `ims_core_job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `payload` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `title` varchar(22) NOT NULL,
  `handled` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `endtime` int(11) NOT NULL,
  `isdeleted` tinyint(1) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_core_menu
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_menu`;
CREATE TABLE `ims_core_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL,
  `title` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `url` varchar(255) NOT NULL,
  `append_title` varchar(30) NOT NULL,
  `append_url` varchar(255) NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `type` varchar(15) NOT NULL,
  `is_display` tinyint(3) unsigned NOT NULL,
  `is_system` tinyint(3) unsigned NOT NULL,
  `permission_name` varchar(50) NOT NULL,
  `group_name` varchar(30) NOT NULL,
  `icon` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_core_menu
-- ----------------------------
BEGIN;
INSERT INTO `ims_core_menu` VALUES (1, 0, '', '', '', '', '', 0, '', 0, 1, 'phoneapp', 'frame', '');
COMMIT;

-- ----------------------------
-- Table structure for ims_core_menu_shortcut
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_menu_shortcut`;
CREATE TABLE `ims_core_menu_shortcut` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `uniacid` int(10) NOT NULL,
  `modulename` varchar(100) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `position` varchar(100) NOT NULL,
  `updatetime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_core_paylog
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_paylog`;
CREATE TABLE `ims_core_paylog` (
  `plid` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `acid` int(10) NOT NULL,
  `openid` varchar(40) NOT NULL,
  `uniontid` varchar(64) NOT NULL,
  `tid` varchar(128) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tag` varchar(2000) NOT NULL,
  `is_usecard` tinyint(3) unsigned NOT NULL,
  `card_type` tinyint(3) unsigned NOT NULL,
  `card_id` varchar(50) NOT NULL,
  `card_fee` decimal(10,2) unsigned NOT NULL,
  `encrypt_code` varchar(100) NOT NULL,
  PRIMARY KEY (`plid`),
  KEY `idx_openid` (`openid`),
  KEY `idx_tid` (`tid`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `uniontid` (`uniontid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_core_performance
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_performance`;
CREATE TABLE `ims_core_performance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL,
  `runtime` varchar(10) NOT NULL,
  `runurl` varchar(512) NOT NULL,
  `runsql` varchar(512) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_core_queue
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_queue`;
CREATE TABLE `ims_core_queue` (
  `qid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `message` varchar(2000) NOT NULL,
  `params` varchar(1000) NOT NULL,
  `keyword` varchar(1000) NOT NULL,
  `response` varchar(2000) NOT NULL,
  `module` varchar(50) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  PRIMARY KEY (`qid`),
  KEY `uniacid` (`uniacid`,`acid`),
  KEY `module` (`module`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_core_refundlog
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_refundlog`;
CREATE TABLE `ims_core_refundlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `refund_uniontid` varchar(64) NOT NULL,
  `reason` varchar(80) NOT NULL,
  `uniontid` varchar(64) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `refund_uniontid` (`refund_uniontid`),
  KEY `uniontid` (`uniontid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_core_resource
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_resource`;
CREATE TABLE `ims_core_resource` (
  `mid` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `media_id` varchar(100) NOT NULL,
  `trunk` int(10) unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  PRIMARY KEY (`mid`),
  KEY `acid` (`uniacid`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_core_sendsms_log
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_sendsms_log`;
CREATE TABLE `ims_core_sendsms_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `content` varchar(255) NOT NULL,
  `result` varchar(255) NOT NULL,
  `createtime` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_core_sessions
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_sessions`;
CREATE TABLE `ims_core_sessions` (
  `sid` char(32) NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  `data` varchar(5000) NOT NULL,
  `expiretime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_core_sessions
-- ----------------------------
BEGIN;
INSERT INTO `ims_core_sessions` VALUES ('aa81db020f71c8f42722db8cd697ad3e', 2, 'oyIJkxC8MH55oRiEazaSsk6BejwM', 'openid|s:28:\"oyIJkxC8MH55oRiEazaSsk6BejwM\";__reply_times|a:3:{s:7:\"content\";s:58:\"https://health.pingan.com/m/index.shtml?from=singlemessage\";s:4:\"date\";s:10:\"2019-12-28\";s:5:\"times\";i:1;}', 1577532840);
INSERT INTO `ims_core_sessions` VALUES ('2be20a070c55de451ec36acdae8aa94e', 2, '101.244.147.47', 'acid|s:1:\"2\";uniacid|i:2;token|a:2:{s:4:\"B6Ig\";i:1577535905;s:4:\"wZW7\";i:1577535907;}', 1577539507);
INSERT INTO `ims_core_sessions` VALUES ('7b73ff1c2f8a8bbf14b35f4cb5a36e19', 2, '61.170.201.254', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"f91Z\";i:1577529102;s:4:\"a781\";i:1577529234;s:4:\"C9ue\";i:1577529237;s:4:\"hGyQ\";i:1577529274;s:4:\"a9uu\";i:1577529276;s:4:\"TQuM\";i:1577529283;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxC8MH55oRiEazaSsk6BejwM\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxC8MH55oRiEazaSsk6BejwM\";uid|s:2:\"23\";userinfo|s:824:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4QzhNSDU1b1JpRWF6YVNzazZCZWp3TSI7czo4OiJuaWNrbmFtZSI7czo5OiLlkajmnIjnkp4iO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuaZrumZgCI7czo4OiJwcm92aW5jZSI7czo2OiLkuIrmtbciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMyOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdkcVloTENPMTE5T1RaT2szSmVzWVE0Yk56MEtENXUwb3VwbmtOemRzZ3NyT0c3VlBhNFF0STY2YUJTVW9YdmpBT1M5UFg2VkVMb3VyMkdTbnRjU09aZi8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzYxMTkxODI7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTMyOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdkcVloTENPMTE5T1RaT2szSmVzWVE0Yk56MEtENXUwb3VwbmtOemRzZ3NyT0c3VlBhNFF0STY2YUJTVW9YdmpBT1M5UFg2VkVMb3VyMkdTbnRjU09aZi8xMzIiO30=\";', 1577532883);
INSERT INTO `ims_core_sessions` VALUES ('0f38f6dc55418512ccc5b4eb2365eaad', 2, '223.104.213.14', 'acid|s:1:\"2\";uniacid|i:2;token|a:4:{s:4:\"NoO8\";i:1577520819;s:4:\"Z11r\";i:1577520820;s:4:\"w77z\";i:1577520821;s:4:\"fxHC\";i:1577520824;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxKRA-1SNFQ7eGhk4vbNYs1I\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxKRA-1SNFQ7eGhk4vbNYs1I\";uid|s:1:\"3\";userinfo|s:832:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4S1JBLTFTTkZRN2VHaGs0dmJOWXMxSSI7czo4OiJuaWNrbmFtZSI7czo1OiJhbGxlbiI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi5oKJ5bC8IjtzOjg6InByb3ZpbmNlIjtzOjE1OiLmlrDljZflqIHlsJTlo6siO3M6NzoiY291bnRyeSI7czoxMjoi5r6z5aSn5Yip5LqaIjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyODoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9QaWFqeFNxQlJhRUpBdHVxR2FGcTVpY0p0Tm9zdDZKMEJUNHJBYzFKWXRmWlBxcGliTUtpYU9nWEtaSXNQVXVOS1Z6MDhsYjVndWlheTJaR0R3emlhT2NtZlJ0Zy8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ4NTIxODA7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI4OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL1BpYWp4U3FCUmFFSkF0dXFHYUZxNWljSnROb3N0NkowQlQ0ckFjMUpZdGZaUHFwaWJNS2lhT2dYS1pJc1BVdU5LVnowOGxiNWd1aWF5MlpHRHd6aWFPY21mUnRnLzEzMiI7fQ==\";', 1577524424);
INSERT INTO `ims_core_sessions` VALUES ('504467add032b1aa8940dfbfeec66699', 2, '101.89.19.149', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"sal6\";i:1577421672;}dest_url|s:118:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26pid%3D%26dluid%3D\";', 1577425272);
INSERT INTO `ims_core_sessions` VALUES ('75d867feebde8db77e8b2cd511be0fc0', 2, '112.224.21.223', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"NuYi\";i:1577442107;s:4:\"tHph\";i:1577442108;s:4:\"Dw9R\";i:1577442113;s:4:\"Led5\";i:1577442115;s:4:\"Wm7l\";i:1577442119;s:4:\"kM9p\";i:1577442120;}dest_url|s:148:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dsinglemessage%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxCYqR-imehqQonoWatXQI4A\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxCYqR-imehqQonoWatXQI4A\";userinfo|s:716:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreENZcVItaW1laHFRb25vV2F0WFFJNEEiO3M6ODoibmlja25hbWUiO3M6ODoi6ZGrICDnjqUiO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6Iua1juWNlyI7czo4OiJwcm92aW5jZSI7czo2OiLlsbHkuJwiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMwOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvUTBqNFR3R1RmVExSckFZU0RnQ3F3NE9zYXF3dWVmUUt2b1RpY2dnMXlESHRQQTFQbTRpYVZ6YjNlT1l0QlpDd1VUcHdxMGdZaEtsYTFpYzdOTFloZ2VOZXcvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTMwOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvUTBqNFR3R1RmVExSckFZU0RnQ3F3NE9zYXF3dWVmUUt2b1RpY2dnMXlESHRQQTFQbTRpYVZ6YjNlT1l0QlpDd1VUcHdxMGdZaEtsYTFpYzdOTFloZ2VOZXcvMTMyIjt9\";uid|s:2:\"45\";', 1577445720);
INSERT INTO `ims_core_sessions` VALUES ('f75064edf3558bc6434a847e6d155ea8', 2, '36.49.187.78', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"fiBP\";i:1577426547;s:4:\"smpg\";i:1577426547;s:4:\"Z1yX\";i:1577426576;s:4:\"RI22\";i:1577426580;s:4:\"tzuP\";i:1577426581;s:4:\"ysHS\";i:1577426596;}dest_url|s:148:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dsinglemessage%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxM2PN8YIYddNJYV26VD-9bU\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxM2PN8YIYddNJYV26VD-9bU\";uid|s:2:\"44\";userinfo|s:716:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreE0yUE44WUlZZGROSllWMjZWRC05YlUiO3M6ODoibmlja25hbWUiO3M6Njoi6I+y6I+yIjtzOjM6InNleCI7aTowO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLplb/mmKUiO3M6ODoicHJvdmluY2UiO3M6Njoi5ZCJ5p6XIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRMbGJKV3ZyRk9OSzlQOXM5aWIzZmlhdHRtQTI5bXVCR0pjcmVlMENaWnFBbWpyUng0Qm5GcEh0anQ3aWM1NkhFZGxDdUVTM0QxU1VLS2JBLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRMbGJKV3ZyRk9OSzlQOXM5aWIzZmlhdHRtQTI5bXVCR0pjcmVlMENaWnFBbWpyUng0Qm5GcEh0anQ3aWM1NkhFZGxDdUVTM0QxU1VLS2JBLzEzMiI7fQ==\";', 1577430196);
INSERT INTO `ims_core_sessions` VALUES ('117bc366addf2c461c499cf8169516d3', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"oQqh\";i:1577418310;}dest_url|s:876:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D577124967334%26org_price%3D63%26price%3D58%26coupons_price%3D5%26goods_sale%3D105%26title%3D%25E5%258A%25A0%25E7%2583%25AD%25E5%259D%2590%25E5%259E%25AB%25E5%258A%259E%25E5%2585%25AC%25E5%25AE%25A4%25E7%2594%25B5%25E7%2583%25AD%25E5%259D%2590%25E5%259E%25AB%25E5%258A%25A0%25E7%2583%25AD%25E6%25A4%2585%25E5%259E%25AB%25E6%259A%2596%25E8%2585%25B0%25E5%259E%25AB%25E5%258F%2591%25E7%2583%25AD%25E9%259D%25A0%25E8%2583%258C%25E5%25A4%259A%25E5%258A%259F%25E8%2583%25BD%25E5%25AE%25B6%25E7%2594%25A8%25E7%2594%25B5%25E6%259A%2596%25E5%259E%25AB%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi3%252F1089124079%252FO1CN01Mro6Fg1g0E1oHK6en_%2521%25211089124079.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577421910);
INSERT INTO `ims_core_sessions` VALUES ('815fca22efa3e5a0a13b3acab4a6dcca', 2, '61.129.6.159', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"sEN2\";i:1577380800;}dest_url|s:233:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26dluid%3D%26pid%3Dmm_711720113_1065450073_109733950492%26m%3Dtiger_newhu%26do%3Dcqlist%26zn%3D0%26key%3D%25E6%2597%25A0%25E7%25BA%25BF%25E8%2580%25B3%25E6%259C%25BA\";', 1577384400);
INSERT INTO `ims_core_sessions` VALUES ('aab3da81e4551124efbf7ce0d8cc0e68', 2, '101.89.19.149', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"vFxd\";i:1577380788;}dest_url|s:168:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26id%3D2%26do%3Dwnqtzgoods%26m%3Dtiger_newhu%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1577384388);
INSERT INTO `ims_core_sessions` VALUES ('cd97f855e9455e9287be776214553a15', 2, '61.151.206.126', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"BBql\";i:1577380799;}dest_url|s:1075:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D600475477956%26org_price%3D68%26price%3D48%26coupons_price%3D20%26goods_sale%3D16327%26title%3D%25E5%25B0%2591%25E5%25A5%25B3%25E5%25BF%2583%25E6%2597%25A0%25E7%25BA%25BF%25E8%2593%259D%25E7%2589%2599%25E8%2580%25B3%25E6%259C%25BA%25E5%25A5%25B3%25E7%2594%259F%25E6%25AC%25BE%25E5%258F%25AF%25E7%2588%25B1%25E5%258F%258C%25E8%2580%25B3%25E5%2585%25A5%25E8%2580%25B3%25E5%25BC%258F%25E9%25A9%25AC%25E5%258D%25A1%25E9%25BE%2599%25E7%25B2%2589%25E8%2589%25B2inpods12%25E8%25BF%2590%25E5%258A%25A8%25E8%258B%25B9%25E6%259E%259Cvivo%25E5%258D%258E%25E4%25B8%25BA%25E5%25B0%258F%25E7%25B1%25B3oppo%25E5%25AE%2589%25E5%258D%2593%25E9%2580%259A%25E7%2594%25A8%25E9%259A%2590%25E5%25BD%25A2%25E8%25BF%25B7%25E4%25BD%25A0%25E7%25A3%25A8%25E7%25A0%2582%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi2%252F2204669442%252FO1CN01tFdydQ2JcUEFYY5Aq_%2521%25210-item_pic.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577384399);
INSERT INTO `ims_core_sessions` VALUES ('1bbd4c23633d9ad2e23764cef6770b29', 2, '61.151.178.236', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"ls62\";i:1577375167;}dest_url|s:877:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D606317173508%26org_price%3D55%26price%3D45%26coupons_price%3D10%26goods_sale%3D215%26title%3D%25E5%258D%2597%25E6%259E%2581%25E4%25BA%25BA%25E6%259A%2596%25E6%25A1%258C%25E5%259E%25AB%25E5%258A%25A0%25E7%2583%25AD%25E9%25BC%25A0%25E6%25A0%2587%25E5%259E%25AB%25E5%25A4%25A7%25E6%25A1%258C%25E9%259D%25A2%25E5%258F%2591%25E7%2583%25AD%25E6%25A1%258C%25E5%259E%25AB%25E4%25B9%25A6%25E6%25A1%258C%25E4%25B9%25A6%25E5%2586%2599%25E7%2594%25B5%25E8%2584%2591%25E5%258A%259E%25E5%2585%25AC%25E5%25AE%25A4%25E6%25A1%258C%25E6%259A%2596%25E5%259E%25AB%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi1%252F2364456160%252FO1CN01fUHNFw1vNKKWCMmhw_%2521%25210-item_pic.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577378767);
INSERT INTO `ims_core_sessions` VALUES ('6ee1b13a205e8397d1895407f59164de', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"QcK5\";i:1577375114;}dest_url|s:877:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D606317173508%26org_price%3D55%26price%3D45%26coupons_price%3D10%26goods_sale%3D215%26title%3D%25E5%258D%2597%25E6%259E%2581%25E4%25BA%25BA%25E6%259A%2596%25E6%25A1%258C%25E5%259E%25AB%25E5%258A%25A0%25E7%2583%25AD%25E9%25BC%25A0%25E6%25A0%2587%25E5%259E%25AB%25E5%25A4%25A7%25E6%25A1%258C%25E9%259D%25A2%25E5%258F%2591%25E7%2583%25AD%25E6%25A1%258C%25E5%259E%25AB%25E4%25B9%25A6%25E6%25A1%258C%25E4%25B9%25A6%25E5%2586%2599%25E7%2594%25B5%25E8%2584%2591%25E5%258A%259E%25E5%2585%25AC%25E5%25AE%25A4%25E6%25A1%258C%25E6%259A%2596%25E5%259E%25AB%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi1%252F2364456160%252FO1CN01fUHNFw1vNKKWCMmhw_%2521%25210-item_pic.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577378714);
INSERT INTO `ims_core_sessions` VALUES ('58eb2b592e165674f00ab0ab7b68393c', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"PdfZ\";i:1577374206;}dest_url|s:1154:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D604163125578%26org_price%3D39.5%26price%3D39.5%26coupons_price%3D0%26goods_sale%3D21470%26title%3D%25E5%258D%25A1%25E5%258F%25A4%25E9%25A9%25B0%25E7%25AC%2594%25E8%25AE%25B0%25E6%259C%25AC%25E7%2594%25B5%25E8%2584%2591%25E6%2594%25AF%25E6%259E%25B6%25E6%2589%2598%25E6%259E%25B6%25E6%25A1%258C%25E9%259D%25A2%25E5%25A2%259E%25E9%25AB%2598%25E4%25BE%25BF%25E6%258D%25B7%25E5%25BC%258F%25E6%2595%25A3%25E7%2583%25AD%25E5%2599%25A8%25E6%259E%25B6%25E5%25AD%2590%25E6%258A%2598%25E5%258F%25A0%25E6%25A1%258C%25E4%25B8%258A%25E5%258D%2587%25E9%2599%258Dmac%25E6%258A%25AC%25E9%25AB%2598%25E5%259E%25AB%25E9%25AB%2598%25E8%2584%259A%25E5%259E%25AB%25E6%2594%25AF%25E6%2592%2591%25E5%25BA%2595%25E5%25BA%25A7%25E9%25A2%2588%25E6%25A4%258E%25E6%2587%2592%25E4%25BA%25BA%25E8%258B%25B9%25E6%259E%259C%25E6%2589%258B%25E6%258F%2590%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi4%252F898146183%252FO1CN01c0Iw3t1vXrRrRbK2g_%2521%25210-item_pic.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577377806);
INSERT INTO `ims_core_sessions` VALUES ('8cdffe7f364cd2fc0ff79c8584162c6f', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"voh2\";i:1577375060;}dest_url|s:1154:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D604163125578%26org_price%3D39.5%26price%3D39.5%26coupons_price%3D0%26goods_sale%3D21470%26title%3D%25E5%258D%25A1%25E5%258F%25A4%25E9%25A9%25B0%25E7%25AC%2594%25E8%25AE%25B0%25E6%259C%25AC%25E7%2594%25B5%25E8%2584%2591%25E6%2594%25AF%25E6%259E%25B6%25E6%2589%2598%25E6%259E%25B6%25E6%25A1%258C%25E9%259D%25A2%25E5%25A2%259E%25E9%25AB%2598%25E4%25BE%25BF%25E6%258D%25B7%25E5%25BC%258F%25E6%2595%25A3%25E7%2583%25AD%25E5%2599%25A8%25E6%259E%25B6%25E5%25AD%2590%25E6%258A%2598%25E5%258F%25A0%25E6%25A1%258C%25E4%25B8%258A%25E5%258D%2587%25E9%2599%258Dmac%25E6%258A%25AC%25E9%25AB%2598%25E5%259E%25AB%25E9%25AB%2598%25E8%2584%259A%25E5%259E%25AB%25E6%2594%25AF%25E6%2592%2591%25E5%25BA%2595%25E5%25BA%25A7%25E9%25A2%2588%25E6%25A4%258E%25E6%2587%2592%25E4%25BA%25BA%25E8%258B%25B9%25E6%259E%259C%25E6%2589%258B%25E6%258F%2590%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi4%252F898146183%252FO1CN01c0Iw3t1vXrRrRbK2g_%2521%25210-item_pic.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577378660);
INSERT INTO `ims_core_sessions` VALUES ('55ca3a2c8753fca89722ad789c38f463', 2, '61.151.206.126', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"wMQx\";i:1577363415;}dest_url|s:1088:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D584755203302%26org_price%3D42.9%26price%3D37.9%26coupons_price%3D5%26goods_sale%3D702%26title%3D%25E7%25AC%25AC%25E4%25B8%2580%25E5%258D%25AB%25E6%2595%25B0%25E6%258D%25AE%25E7%25BA%25BF%25E4%25B8%2589%25E5%2590%2588%25E4%25B8%2580%25E5%2585%2585%25E7%2594%25B5%25E7%25BA%25BF%25E5%2599%25A8%25E4%25B8%2580%25E6%258B%2596%25E4%25B8%2589%25E4%25BC%25B8%25E7%25BC%25A9%25E7%25BA%25BFtype%2Bc%25E5%258D%258E%25E4%25B8%25BAP20%25E5%25BF%25AB%25E5%2585%2585%25E8%258B%25B9%25E6%259E%259C5%25E5%25A4%259A%25E5%258A%259F%25E8%2583%25BD%25E5%25B0%258F%25E7%25B1%25B3%25E4%25B9%259D%25E8%25BD%25A6%25E8%25BD%25BD%25E5%25A4%259A%25E7%2594%25A83%25E5%258F%25AF%25E6%2594%25B6%25E7%25BC%25A9%25E6%2589%258B%25E6%259C%25BA%25E5%25BF%25AB%25E5%2586%25B2%25E5%25A4%25B4%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi1%252F2455420587%252FO1CN01cK1Obp1GCt3vbTrZ7_%2521%25210-item_pic.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577367015);
INSERT INTO `ims_core_sessions` VALUES ('138bdba99251b7fa326974d7d4c40164', 2, '61.136.222.65', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"TqPZ\";i:1576726637;s:4:\"O3wh\";i:1576726648;s:4:\"Bq5H\";i:1576726648;s:4:\"LjC5\";i:1576726655;s:4:\"NYy2\";i:1576726661;s:4:\"N1VT\";i:1576726695;}dest_url|s:137:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26scene%3D126%26clicktime%3D1576726630\";oauth_openid|s:28:\"oyIJkxGhmim2MJe060lBsmnRcByc\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxGhmim2MJe060lBsmnRcByc\";uid|s:2:\"31\";userinfo|s:840:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4R2htaW0yTUplMDYwbEJzbW5SY0J5YyI7czo4OiJuaWNrbmFtZSI7czoxODoi8J+QoPCfkKDwn5Cg6bG85YS/IjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLlrpzmmIwiO3M6ODoicHJvdmluY2UiO3M6Njoi5rmW5YyXIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzMzoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi81dGtGWnlqWm9ZSlUwbDNHMHIxY0NhZjNUV0llRzNYeHB6Mk9jaFRTRXNOTlNuSkRpYUdYWmVOZGpPSjRzSnFmaGMyamZzVWpNajNQbDBLQlluak93N2NINXhXSjFHQWQ3LzEzMiI7czoxNDoic3Vic2NyaWJlX3RpbWUiO2k6MTU3NjcxODA3NTtzOjc6Imdyb3VwaWQiO2k6MDtzOjEwOiJ0YWdpZF9saXN0IjthOjA6e31zOjY6ImF2YXRhciI7czoxMzM6Imh0dHBzOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vNXRrRlp5alpvWUpVMGwzRzByMWNDYWYzVFdJZUczWHhwejJPY2hUU0VzTk5TbkpEaWFHWFplTmRqT0o0c0pxZmhjMmpmc1VqTWozUGwwS0JZbmpPdzdjSDV4V0oxR0FkNy8xMzIiO30=\";', 1576730295);
INSERT INTO `ims_core_sessions` VALUES ('d01e67fdc71c578720228b891f2aba5a', 2, '114.95.224.34', 'acid|s:1:\"2\";uniacid|i:2;token|a:4:{s:4:\"pGKL\";i:1576752094;s:4:\"ozSp\";i:1576752094;s:4:\"XVpP\";i:1576752095;s:4:\"s62L\";i:1576752096;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxKRA-1SNFQ7eGhk4vbNYs1I\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxKRA-1SNFQ7eGhk4vbNYs1I\";uid|s:1:\"3\";userinfo|s:832:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4S1JBLTFTTkZRN2VHaGs0dmJOWXMxSSI7czo4OiJuaWNrbmFtZSI7czo1OiJhbGxlbiI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi5oKJ5bC8IjtzOjg6InByb3ZpbmNlIjtzOjE1OiLmlrDljZflqIHlsJTlo6siO3M6NzoiY291bnRyeSI7czoxMjoi5r6z5aSn5Yip5LqaIjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyODoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9QaWFqeFNxQlJhRUpBdHVxR2FGcTVpY0p0Tm9zdDZKMEJUNHJBYzFKWXRmWlBxcGliTUtpYU9nWEtaSXNQVXVOS1Z6MDhsYjVndWlheTJaR0R3emlhT2NtZlJ0Zy8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ4NTIxODA7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI4OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL1BpYWp4U3FCUmFFSkF0dXFHYUZxNWljSnROb3N0NkowQlQ0ckFjMUpZdGZaUHFwaWJNS2lhT2dYS1pJc1BVdU5LVnowOGxiNWd1aWF5MlpHRHd6aWFPY21mUnRnLzEzMiI7fQ==\";', 1576755696);
INSERT INTO `ims_core_sessions` VALUES ('b64ed1883b760b6ca73822ad16ca5196', 2, 'oyIJkxLX68JtAeeGt6lnFmFj8tgY', 'openid|s:28:\"oyIJkxLX68JtAeeGt6lnFmFj8tgY\";__reply_times|a:3:{s:7:\"content\";N;s:4:\"date\";s:10:\"2019-12-19\";s:5:\"times\";i:1;}', 1576737237);
INSERT INTO `ims_core_sessions` VALUES ('b7dfa80457c27af7d4e90e594f0687c1', 2, '61.151.207.141', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"F59M\";i:1577014263;}', 1577017863);
INSERT INTO `ims_core_sessions` VALUES ('c6ad8e4b9c7a675d531e8fa9f7080e5a', 2, '58.247.206.156', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"yy01\";i:1577014263;}', 1577017863);
INSERT INTO `ims_core_sessions` VALUES ('4f644176406e21c26dfdcefccb7f49c7', 2, 'oyIJkxD2zxZZd1Yi3nNOV51mPGws', 'openid|s:28:\"oyIJkxD2zxZZd1Yi3nNOV51mPGws\";__reply_times|a:3:{s:7:\"content\";s:72:\"http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu\";s:4:\"date\";s:10:\"2019-12-23\";s:5:\"times\";i:1;}', 1577063427);
INSERT INTO `ims_core_sessions` VALUES ('01347bb61d18a9717a60a9bbfd797bb8', 2, '101.24.121.106', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"g1eq\";i:1577060245;s:4:\"thfp\";i:1577060246;s:4:\"ZrDO\";i:1577060341;s:4:\"BIp7\";i:1577060343;s:4:\"kd5V\";i:1577060348;s:4:\"hKZm\";i:1577060349;}dest_url|s:125:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxG093gnjRE-9oYqgc61qYbs\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxG093gnjRE-9oYqgc61qYbs\";userinfo|s:736:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEcwOTNnbmpSRS05b1lxZ2M2MXFZYnMiO3M6ODoibmlja25hbWUiO3M6MjI6IuS4reiLi+WGnOS4mi3mnajogZrovokiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjk6Iuefs+WutuW6hCI7czo4OiJwcm92aW5jZSI7czo2OiLmsrPljJciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI4OiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvUTBqNFR3R1RmVEpLaGI5aWFVdWo2Q05hN2h3dzZDNXdjWjRyVDc5SDJlYXhTRGp6QUw3eG1WYWNhbnpwR0Z2SmJ1WDRsOFlwNkFhMDRlRXgxMmtMWEZBLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEyODoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRKS2hiOWlhVXVqNkNOYTdod3c2QzV3Y1o0clQ3OUgyZWF4U0RqekFMN3htVmFjYW56cEdGdkpidVg0bDhZcDZBYTA0ZUV4MTJrTFhGQS8xMzIiO30=\";uid|s:2:\"37\";', 1577063949);
INSERT INTO `ims_core_sessions` VALUES ('45b17865fb0384bffad9a83c88ffc918', 2, 'oyIJkxG093gnjRE-9oYqgc61qYbs', 'openid|s:28:\"oyIJkxG093gnjRE-9oYqgc61qYbs\";__reply_times|a:3:{s:7:\"content\";s:72:\"http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu\";s:4:\"date\";s:10:\"2019-12-23\";s:5:\"times\";i:1;}', 1577063941);
INSERT INTO `ims_core_sessions` VALUES ('ebedec94e6b96b6fcafad40458869fcc', 2, '180.156.152.30', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"wgPk\";i:1577505136;s:4:\"Cv5U\";i:1577505137;s:4:\"e14P\";i:1577505138;s:4:\"o88u\";i:1577505143;s:4:\"Y8BK\";i:1577505165;s:4:\"ASi7\";i:1577505167;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxN12B-UAC92kuWMsCPUNpnk\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxN12B-UAC92kuWMsCPUNpnk\";uid|s:1:\"2\";userinfo|s:816:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4TjEyQi1VQUM5Mmt1V01zQ1BVTnBuayI7czo4OiJuaWNrbmFtZSI7czo2OiLmmbTlpKkiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjA6IiI7czo4OiJwcm92aW5jZSI7czo2OiLkuIrmtbciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMzOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdkcVloTENPMTE5T1RzM3VaZUg4bVlSR3E1d3JXZVNwVTJYUUlEYThyaWF0RHFuclZwU1U5N2YxRWtYNThYQ1NzYjBlTVcxWTRLeFVWZ2NMZWJIb3VQdEMvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc0ODUxOTAyO3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMzoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi93UXBBY0F0UkVXZHFZaExDTzExOU9UczN1WmVIOG1ZUkdxNXdyV2VTcFUyWFFJRGE4cmlhdERxbnJWcFNVOTdmMUVrWDU4WENTc2IwZU1XMVk0S3hVVmdjTGViSG91UHRDLzEzMiI7fQ==\";', 1577508767);
INSERT INTO `ims_core_sessions` VALUES ('ccdb90e6d2a23243ddbc77132fca5f2f', 2, '120.242.29.162', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"tX9x\";i:1577070593;s:4:\"I244\";i:1577070594;s:4:\"o5rF\";i:1577070596;s:4:\"YYvl\";i:1577070597;s:4:\"Und9\";i:1577070604;s:4:\"Ln29\";i:1577070612;}dest_url|s:125:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxMWAkO2VRTkAYRWZUtXGA1s\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxMWAkO2VRTkAYRWZUtXGA1s\";userinfo|s:720:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreE1XQWtPMlZSVGtBWVJXWlV0WEdBMXMiO3M6ODoibmlja25hbWUiO3M6MTI6IuWFpeebruS4ieWIhiI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6MDoiIjtzOjg6InByb3ZpbmNlIjtzOjA6IiI7czo3OiJjb3VudHJ5IjtzOjY6IuWGsOWymyI7czoxMDoiaGVhZGltZ3VybCI7czoxMzQ6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9mdG1oeE9QYmMyWUFFY0xVczVTOThsdUh4TjNvWEVsbmhaQ2liNzlVN0JoeGZiSUlqaWJrSGlja2dka0c4U3JpY3R5cVdvZ3NEaWFuaWNFRGljQ1VCTklVcUxqZ3cvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTM0OiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvZnRtaHhPUGJjMllBRWNMVXM1Uzk4bHVIeE4zb1hFbG5oWkNpYjc5VTdCaHhmYklJamlia0hpY2tnZGtHOFNyaWN0eXFXb2dzRGlhbmljRURpY0NVQk5JVXFMamd3LzEzMiI7fQ==\";uid|s:2:\"38\";', 1577074212);
INSERT INTO `ims_core_sessions` VALUES ('dbfc729c657a9c0770d45af85e6838f7', 2, '223.104.253.10', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"CEN3\";i:1577258602;s:4:\"t31M\";i:1577258603;s:4:\"T3d4\";i:1577258604;s:4:\"w80H\";i:1577258608;s:4:\"f2Zh\";i:1577258612;s:4:\"iy3k\";i:1577258618;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxKRA-1SNFQ7eGhk4vbNYs1I\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxKRA-1SNFQ7eGhk4vbNYs1I\";uid|s:1:\"3\";userinfo|s:832:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4S1JBLTFTTkZRN2VHaGs0dmJOWXMxSSI7czo4OiJuaWNrbmFtZSI7czo1OiJhbGxlbiI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi5oKJ5bC8IjtzOjg6InByb3ZpbmNlIjtzOjE1OiLmlrDljZflqIHlsJTlo6siO3M6NzoiY291bnRyeSI7czoxMjoi5r6z5aSn5Yip5LqaIjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyODoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9QaWFqeFNxQlJhRUpBdHVxR2FGcTVpY0p0Tm9zdDZKMEJUNHJBYzFKWXRmWlBxcGliTUtpYU9nWEtaSXNQVXVOS1Z6MDhsYjVndWlheTJaR0R3emlhT2NtZlJ0Zy8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ4NTIxODA7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI4OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL1BpYWp4U3FCUmFFSkF0dXFHYUZxNWljSnROb3N0NkowQlQ0ckFjMUpZdGZaUHFwaWJNS2lhT2dYS1pJc1BVdU5LVnowOGxiNWd1aWF5MlpHRHd6aWFPY21mUnRnLzEzMiI7fQ==\";', 1577262218);
INSERT INTO `ims_core_sessions` VALUES ('a87d6170881877a2671e40f4751381f4', 2, 'oyIJkxN12B-UAC92kuWMsCPUNpnk', 'openid|s:28:\"oyIJkxN12B-UAC92kuWMsCPUNpnk\";__reply_times|a:3:{s:7:\"content\";s:72:\"http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu\";s:4:\"date\";s:10:\"2019-12-28\";s:5:\"times\";i:1;}', 1577508735);
INSERT INTO `ims_core_sessions` VALUES ('5863d6f9d4c5a41409badc7cd30d91d4', 2, '223.104.212.93', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"Nk2i\";i:1577269689;s:4:\"HWKu\";i:1577269699;s:4:\"NYo2\";i:1577269700;s:4:\"y8Hb\";i:1577269702;s:4:\"e77L\";i:1577269706;s:4:\"PJZJ\";i:1577269706;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxCB9hYjLKccpLfH8JHuLGQY\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxCB9hYjLKccpLfH8JHuLGQY\";uid|s:1:\"1\";userinfo|s:856:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4Q0I5aFlqTEtjY3BMZkg4Skh1TEdRWSI7czo4OiJuaWNrbmFtZSI7czoxODoiVGhlIFJvZ3VlIEFzc2Fzc2luIjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo5OiLkuInpl6jls6EiO3M6ODoicHJvdmluY2UiO3M6Njoi5rKz5Y2XIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzNzoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi93UXBBY0F0UkVXZnRCdXhpYWM0a1ZsVVpzQ0hzcVFEN2tJaWIyZWVJWGpPdlpWYVVoMmtUdktDUG9pY0NDOVBFeG9wTTdpYktvdWVuZVV6cEtSRnJONzRqaWJCbXdoNDBoZjlmMi8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ4NDM5OTM7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTM3OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdmdEJ1eGlhYzRrVmxVWnNDSHNxUUQ3a0lpYjJlZUlYak92WlZhVWgya1R2S0NQb2ljQ0M5UEV4b3BNN2liS291ZW5lVXpwS1JGck43NGppYkJtd2g0MGhmOWYyLzEzMiI7fQ==\";', 1577273306);
INSERT INTO `ims_core_sessions` VALUES ('69f29355f131a6b7e36b9d530fff2ad6', 2, '183.40.222.225', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"zBEh\";i:1577175113;s:4:\"Os94\";i:1577175114;s:4:\"i3dL\";i:1577175115;s:4:\"g5kn\";i:1577175118;s:4:\"I45w\";i:1577175120;s:4:\"z4ox\";i:1577175122;}dest_url|s:148:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dsinglemessage%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxHhDeYdI7MKL7Oc41WKS56Y\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxHhDeYdI7MKL7Oc41WKS56Y\";userinfo|s:716:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEhoRGVZZEk3TUtMN09jNDFXS1M1NlkiO3M6ODoibmlja25hbWUiO3M6Njoi6LW16IOWIjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLmnJ3pmLMiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0RZQUlPZ3E4M2VvcThYOGpWSnRaU0t5bFlSMkx6NXduRHJReDBES1BVS1FHdkRvaE5Dbm5VUjNlZVNpYk80TFI3WkNGVFBtM0JSaWNObGJ0TzJpYlhTZEtRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0RZQUlPZ3E4M2VvcThYOGpWSnRaU0t5bFlSMkx6NXduRHJReDBES1BVS1FHdkRvaE5Dbm5VUjNlZVNpYk80TFI3WkNGVFBtM0JSaWNObGJ0TzJpYlhTZEtRLzEzMiI7fQ==\";uid|s:2:\"39\";', 1577178722);
INSERT INTO `ims_core_sessions` VALUES ('375008803aa5eb6449e13c8bb9483367', 2, '117.136.104.141', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"f88c\";i:1577175685;s:4:\"jGHl\";i:1577175686;s:4:\"l8tU\";i:1577175687;s:4:\"TbPf\";i:1577175688;s:4:\"Yr7x\";i:1577175691;s:4:\"XGQP\";i:1577175702;}dest_url|s:168:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dgroupmessage%26isappinstalled%3D0%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxKyPk9vbyPHIdZMLoi4BzaI\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxKyPk9vbyPHIdZMLoi4BzaI\";userinfo|s:732:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEt5UGs5dmJ5UEhJZFpNTG9pNEJ6YUkiO3M6ODoibmlja25hbWUiO3M6MTA6IuW8oOmcnvCfjpciO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjA6IiI7czo4OiJwcm92aW5jZSI7czoyNDoi5Y2O5aSP6ZKw6ZyW5LiH5Lq65Zui6ZifIjtzOjc6ImNvdW50cnkiO3M6MDoiIjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0RZQUlPZ3E4M2VwNkQzd1J4TXYwTWNTeWVPbzFBM2Q3b2RwNHp1U2tnYzN1TWljSk1pYmZ5TjhReWQyeW5wTzlKR0s4bDNINFk5RXNoa0hpYWd5N214STdRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0RZQUlPZ3E4M2VwNkQzd1J4TXYwTWNTeWVPbzFBM2Q3b2RwNHp1U2tnYzN1TWljSk1pYmZ5TjhReWQyeW5wTzlKR0s4bDNINFk5RXNoa0hpYWd5N214STdRLzEzMiI7fQ==\";uid|s:2:\"40\";', 1577179302);
INSERT INTO `ims_core_sessions` VALUES ('a4d01d0710a15b2ea2f06c351bbfc0ba', 2, '113.120.42.235', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"CjW2\";i:1577442049;s:4:\"uA1v\";i:1577442050;s:4:\"HSpd\";i:1577442051;s:4:\"Micc\";i:1577442052;s:4:\"m8T4\";i:1577442053;s:4:\"Ix13\";i:1577442056;}dest_url|s:148:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dsinglemessage%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxCf1Kj9cjsqi54xaSKuwais\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxCf1Kj9cjsqi54xaSKuwais\";uid|s:2:\"43\";userinfo|s:744:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreENmMUtqOWNqc3FpNTR4YVNLdXdhaXMiO3M6ODoibmlja25hbWUiO3M6MTg6IuaNjeWNq+aipuaDs+eoi+aNtyI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi6I6x6IqcIjtzOjg6InByb3ZpbmNlIjtzOjY6IuWxseS4nCI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzU6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9JaWJpYUpLV09zMUptcWQ4enZvdE91YWljWWlja1NqaWFqRk14akRwbk45SndRdTdpYlVLRU5Qd29rdnRrOHM0bGljZ1hTSGdwamRCODhpYm9RYW5rN0F5RWhzT3pRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzNToiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0lpYmlhSktXT3MxSm1xZDh6dm90T3VhaWNZaWNrU2ppYWpGTXhqRHBuTjlKd1F1N2liVUtFTlB3b2t2dGs4czRsaWNnWFNIZ3BqZEI4OGlib1Fhbms3QXlFaHNPelEvMTMyIjt9\";', 1577445656);
INSERT INTO `ims_core_sessions` VALUES ('8fab4be166be7f3c339cb7810825cb0c', 2, '124.64.18.193', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"q1Ay\";i:1577189539;s:4:\"W7BB\";i:1577189540;s:4:\"L964\";i:1577189541;s:4:\"M5j4\";i:1577189543;s:4:\"SJdn\";i:1577189545;s:4:\"J4TO\";i:1577189548;}dest_url|s:168:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dgroupmessage%26isappinstalled%3D0%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxHAGFVDcPiTZolus03y9nt4\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxHAGFVDcPiTZolus03y9nt4\";userinfo|s:700:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEhBR0ZWRGNQaVRab2x1czAzeTludDQiO3M6ODoibmlja25hbWUiO3M6MTE6Iktldmlu546L5rWpIjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6MDoiIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyODoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyLzAxRFpWalFDNDNtZGVNZnFSdHQ3U3pIRFFkaG9UQVdNdXFISnNvRFkzbWlhSm1NQURub0lRNWhDY2tzY1pFTEk5NHpDRWo3Sm5qWWRJUFlTVUVTTEpPZy8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMjg6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi8wMURaVmpRQzQzbWRlTWZxUnR0N1N6SERRZGhvVEFXTXVxSEpzb0RZM21pYUptTUFEbm9JUTVoQ2Nrc2NaRUxJOTR6Q0VqN0puallkSVBZU1VFU0xKT2cvMTMyIjt9\";uid|s:2:\"41\";', 1577193148);
INSERT INTO `ims_core_sessions` VALUES ('f595e746815036fbb5f47fa13ccb44a9', 2, '180.97.118.219', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"v651\";i:1577189601;}dest_url|s:141:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dgroupmessage%26isappinstalled%3D0\";', 1577193201);
INSERT INTO `ims_core_sessions` VALUES ('f895d6aef4d239a7978a62e3fbccafef', 2, '101.89.239.232', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"a5w8\";i:1577189603;}dest_url|s:168:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dgroupmessage%26isappinstalled%3D0%26wxref%3Dmp.weixin.qq.com\";', 1577193203);
INSERT INTO `ims_core_sessions` VALUES ('2cc1dba7a11b06827c71957ba17a20d2', 2, '61.148.244.54', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"VuF6\";i:1577248279;s:4:\"Soeq\";i:1577248284;s:4:\"HZko\";i:1577248324;s:4:\"Uvim\";i:1577248332;s:4:\"v1QL\";i:1577248336;s:4:\"qiA9\";i:1577248339;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxESZBGbNb1VyCREQvnt0O9A\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxESZBGbNb1VyCREQvnt0O9A\";uid|s:2:\"10\";userinfo|s:820:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RVNaQkdiTmIxVnlDUkVRdm50ME85QSI7czo4OiJuaWNrbmFtZSI7czoxODoi5pyI54mZ5LiK55qE54yr5ZKqIjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLmnJ3pmLMiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyNToiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9hak5WZHFIWkxMQU5URmRVbUE5TDlXTkVXRlF2bzRTRHZNQTVsNlR0M2pwbHl3dE0zZVVEQURpYmp1ZThwRXpZMTlLaWJWYXFlaWNISVhjUHBJTDdZc21qdy8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ5MTI0Njc7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI1OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2FqTlZkcUhaTExBTlRGZFVtQTlMOVdORVdGUXZvNFNEdk1BNWw2VHQzanBseXd0TTNlVURBRGlianVlOHBFelkxOUtpYlZhcWVpY0hJWGNQcElMN1lzbWp3LzEzMiI7fQ==\";', 1577251939);
INSERT INTO `ims_core_sessions` VALUES ('a44e7559464c4ffbcb078366c21086d4', 2, '117.136.0.145', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"BZCk\";i:1577248548;s:4:\"qUag\";i:1577248717;s:4:\"JzUp\";i:1577248720;s:4:\"u0dG\";i:1577248725;s:4:\"hQsf\";i:1577248725;s:4:\"GwhD\";i:1577248792;}dest_url|s:229:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dsinglemessage%26isappinstalled%3D0%26scene%3D1%26clicktime%3D1577248315%26enterid%3D1577248315%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxJGBPe7ctUhDlBrd6WBj3CE\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxJGBPe7ctUhDlBrd6WBj3CE\";userinfo|s:720:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEpHQlBlN2N0VWhEbEJyZDZXQmozQ0UiO3M6ODoibmlja25hbWUiO3M6MTU6IuKYgOiPsuWuneWuneKYgCI7czozOiJzZXgiO2k6MjtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi5Liw5Y+wIjtzOjg6InByb3ZpbmNlIjtzOjY6IuWMl+S6rCI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMjc6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUSmFxNnlLSk5oY05CZjlnS3dTR01HdVhtTG1ra1laSG1IS3ZkQzlnQ3pla25hSHNES0d3b1llNmVJNUh2T3FLQnFtUGNoU0R6VEhJQS8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMjc6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUSmFxNnlLSk5oY05CZjlnS3dTR01HdVhtTG1ra1laSG1IS3ZkQzlnQ3pla25hSHNES0d3b1llNmVJNUh2T3FLQnFtUGNoU0R6VEhJQS8xMzIiO30=\";uid|s:2:\"42\";', 1577252392);
INSERT INTO `ims_core_sessions` VALUES ('3a7bb231aee4282e67beb89dd1512855', 2, 'oyIJkxJGBPe7ctUhDlBrd6WBj3CE', 'openid|s:28:\"oyIJkxJGBPe7ctUhDlBrd6WBj3CE\";__reply_times|a:3:{s:7:\"content\";s:72:\"http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu\";s:4:\"date\";s:10:\"2019-12-25\";s:5:\"times\";i:4;}', 1577252317);
INSERT INTO `ims_core_sessions` VALUES ('dcc36ce99cd3efa123c07f0cf872676d', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"GLxU\";i:1577248439;}dest_url|s:1091:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D574119176912%26org_price%3D37.9%26price%3D27.9%26coupons_price%3D10%26goods_sale%3D16542%26title%3D%25E8%258B%25B1%25E8%258F%25B2%25E5%2585%258BPM9%25E9%2593%259D%25E5%2590%2588%25E9%2587%2591%25E6%2597%25A0%25E7%25BA%25BF%25E9%25BC%25A0%25E6%25A0%2587%25E5%258F%25AF%25E5%2585%2585%25E7%2594%25B5%25E5%25BC%258F%25E8%2593%259D%25E7%2589%25995.0%25E6%2597%25A0%25E9%2599%2590%25E9%259D%2599%25E9%259F%25B3%25E6%2597%25A0%25E5%25A3%25B0%25E7%2594%25B5%25E8%2584%2591%25E5%258A%259E%25E5%2585%25AC%25E6%25B8%25B8%25E6%2588%258F%25E5%25A5%25B3%25E7%2594%259F%25E5%258F%25AF%25E7%2588%25B1%25E8%258B%25B9%25E6%259E%259CMac%25E5%258D%258E%25E7%25A1%2595%25E8%2581%2594%25E6%2583%25B3%25E7%25AC%2594%25E8%25AE%25B0%25E6%259C%25ACipad%25E9%2580%259A%25E7%2594%25A8%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi1%252F1589613703%252FO1CN01QDJSfC1dE1CjSrtrA_%2521%25210-item_pic.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577252039);
INSERT INTO `ims_core_sessions` VALUES ('1359b0e8569e85c510c6d32bd03a3e40', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"Ju4l\";i:1577248444;}dest_url|s:1091:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D574119176912%26org_price%3D37.9%26price%3D27.9%26coupons_price%3D10%26goods_sale%3D16542%26title%3D%25E8%258B%25B1%25E8%258F%25B2%25E5%2585%258BPM9%25E9%2593%259D%25E5%2590%2588%25E9%2587%2591%25E6%2597%25A0%25E7%25BA%25BF%25E9%25BC%25A0%25E6%25A0%2587%25E5%258F%25AF%25E5%2585%2585%25E7%2594%25B5%25E5%25BC%258F%25E8%2593%259D%25E7%2589%25995.0%25E6%2597%25A0%25E9%2599%2590%25E9%259D%2599%25E9%259F%25B3%25E6%2597%25A0%25E5%25A3%25B0%25E7%2594%25B5%25E8%2584%2591%25E5%258A%259E%25E5%2585%25AC%25E6%25B8%25B8%25E6%2588%258F%25E5%25A5%25B3%25E7%2594%259F%25E5%258F%25AF%25E7%2588%25B1%25E8%258B%25B9%25E6%259E%259CMac%25E5%258D%258E%25E7%25A1%2595%25E8%2581%2594%25E6%2583%25B3%25E7%25AC%2594%25E8%25AE%25B0%25E6%259C%25ACipad%25E9%2580%259A%25E7%2594%25A8%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi1%252F1589613703%252FO1CN01QDJSfC1dE1CjSrtrA_%2521%25210-item_pic.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577252044);
INSERT INTO `ims_core_sessions` VALUES ('a61a6bed04748bebdf84901f4d5c4dac', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"HqiO\";i:1577248567;}dest_url|s:646:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D577247156040%26org_price%3D99%26price%3D99%26coupons_price%3D0%26goods_sale%3D4%26title%3D%25E5%258D%258E%25E4%25B8%25BAMateDock2%25E5%258E%259F%25E8%25A3%2585%25E6%2589%25A9%25E5%25B1%2595%25E5%259D%259EMatebookE%25E7%25AC%2594%25E8%25AE%25B0%25E6%259C%25AC13%252F14%2BD%2BXpro%25E6%258B%2593%25E5%25B1%2595Mate30%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi1%252F4149492803%252FO1CN011WZodEN40IlGQQA_%2521%25214149492803.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577252167);
INSERT INTO `ims_core_sessions` VALUES ('db325de85d0bb59b14a3ae3a4706c37f', 2, '61.151.206.126', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"WSxX\";i:1577248798;}dest_url|s:646:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D577247156040%26org_price%3D99%26price%3D99%26coupons_price%3D0%26goods_sale%3D4%26title%3D%25E5%258D%258E%25E4%25B8%25BAMateDock2%25E5%258E%259F%25E8%25A3%2585%25E6%2589%25A9%25E5%25B1%2595%25E5%259D%259EMatebookE%25E7%25AC%2594%25E8%25AE%25B0%25E6%259C%25AC13%252F14%2BD%2BXpro%25E6%258B%2593%25E5%25B1%2595Mate30%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi1%252F4149492803%252FO1CN011WZodEN40IlGQQA_%2521%25214149492803.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577252398);
INSERT INTO `ims_core_sessions` VALUES ('eed6c5166398fd0d7c855e56c8ee78cf', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"s06F\";i:1577248802;}dest_url|s:646:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D577247156040%26org_price%3D99%26price%3D99%26coupons_price%3D0%26goods_sale%3D4%26title%3D%25E5%258D%258E%25E4%25B8%25BAMateDock2%25E5%258E%259F%25E8%25A3%2585%25E6%2589%25A9%25E5%25B1%2595%25E5%259D%259EMatebookE%25E7%25AC%2594%25E8%25AE%25B0%25E6%259C%25AC13%252F14%2BD%2BXpro%25E6%258B%2593%25E5%25B1%2595Mate30%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi1%252F4149492803%252FO1CN011WZodEN40IlGQQA_%2521%25214149492803.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577252402);
INSERT INTO `ims_core_sessions` VALUES ('757ffb85bef0cf3e5c8d00134842da80', 2, 'oyIJkxCB9hYjLKccpLfH8JHuLGQY', 'openid|s:28:\"oyIJkxCB9hYjLKccpLfH8JHuLGQY\";__reply_times|a:3:{s:7:\"content\";s:72:\"http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu\";s:4:\"date\";s:10:\"2019-12-25\";s:5:\"times\";i:2;}', 1577273261);
INSERT INTO `ims_core_sessions` VALUES ('a68a9255eaab7e258330a0f3726bd001', 2, 'oyIJkxK5tBGzqZSKzxCF0AEBTUzQ', 'openid|s:28:\"oyIJkxK5tBGzqZSKzxCF0AEBTUzQ\";__reply_times|a:3:{s:7:\"content\";s:72:\"http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu\";s:4:\"date\";s:10:\"2019-12-22\";s:5:\"times\";i:1;}', 1576981809);
INSERT INTO `ims_core_sessions` VALUES ('4fcc7d0ce7d9160ca1833f29c03f75d6', 2, '114.95.224.34', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"wLH7\";i:1576978216;s:4:\"wMKJ\";i:1576978254;s:4:\"wy6t\";i:1576978258;s:4:\"K7qu\";i:1576978299;s:4:\"DJ8K\";i:1576978304;s:4:\"nw5D\";i:1576978437;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxK5tBGzqZSKzxCF0AEBTUzQ\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxK5tBGzqZSKzxCF0AEBTUzQ\";uid|s:2:\"19\";userinfo|s:832:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4SzV0Qkd6cVpTS3p4Q0YwQUVCVFV6USI7czo4OiJuaWNrbmFtZSI7czoxNToi54Gr5pif57OW6JGr6IqmIjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6Njoi5LiK5rW3IjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzNToiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9NV25sd1RDYWpJRTI4WG5qVDdLUFpsdHVFR1ZCVW9ZMldqWVZOYm9zekRUcUZyRmVIQWlhNWJVZzRyYWljWDYwMjhuRnhyRXNaOVdEbmZJcHpmSmlibFlLZzNnanV1NUg3ZWYvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc1OTc0NTMzO3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzNToiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9NV25sd1RDYWpJRTI4WG5qVDdLUFpsdHVFR1ZCVW9ZMldqWVZOYm9zekRUcUZyRmVIQWlhNWJVZzRyYWljWDYwMjhuRnhyRXNaOVdEbmZJcHpmSmlibFlLZzNnanV1NUg3ZWYvMTMyIjt9\";', 1576982037);
INSERT INTO `ims_core_sessions` VALUES ('6fbf0ca856879fa31fe8b8295d678310', 2, 'oyIJkxOydYgbafLdBlHRc6RBLPB8', 'openid|s:28:\"oyIJkxOydYgbafLdBlHRc6RBLPB8\";__reply_times|a:3:{s:7:\"content\";s:72:\"http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu\";s:4:\"date\";s:10:\"2019-12-19\";s:5:\"times\";i:1;}', 1576755839);
INSERT INTO `ims_core_sessions` VALUES ('a5cee6ce001a47ffcc5945dc1de9ab29', 2, '27.18.20.229', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"l4cH\";i:1576743954;s:4:\"c99e\";i:1576743958;s:4:\"x9q3\";i:1576743963;s:4:\"mJHd\";i:1576743963;s:4:\"au70\";i:1576743981;s:4:\"bNl3\";i:1576743982;}dest_url|s:169:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dsinglemessage%26isappinstalled%3D0%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxFqe8qlSJ32tVCxWTJm7b_Q\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxFqe8qlSJ32tVCxWTJm7b_Q\";userinfo|s:748:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEZxZThxbFNKMzJ0VkN4V1RKbTdiX1EiO3M6ODoibmlja25hbWUiO3M6MjU6IueUn+a0u+WwseaYr/CfkLflkozov5zmlrkiO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuatpuaxiSI7czo4OiJwcm92aW5jZSI7czo2OiLmuZbljJciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMzOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvMGljZzV3VFA4bGpNTzQ3ZGpoSmFwWWF4dW5KZXBkQVZEbzVaRGlhNGlhN1pkYkU0eFV2Qk12cTBEaWJOdW9zaWJ2WUhyS0hQQWJMWUdaNHZISlhmaWNOVWtocGcvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTMzOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvMGljZzV3VFA4bGpNTzQ3ZGpoSmFwWWF4dW5KZXBkQVZEbzVaRGlhNGlhN1pkYkU0eFV2Qk12cTBEaWJOdW9zaWJ2WUhyS0hQQWJMWUdaNHZISlhmaWNOVWtocGcvMTMyIjt9\";uid|s:2:\"32\";', 1576747582);
INSERT INTO `ims_core_sessions` VALUES ('e47d27196abcec1fdb833cd73655c2e1', 2, '101.91.60.107', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"t8Z2\";i:1576744011;}dest_url|s:169:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dsinglemessage%26isappinstalled%3D0%26wxref%3Dmp.weixin.qq.com\";', 1576747611);
INSERT INTO `ims_core_sessions` VALUES ('f0eb57255718982cb8ad04aa7d802541', 2, '101.91.60.107', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"uT7T\";i:1576744023;}dest_url|s:153:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Djdindex%26m%3Dtuike_jd%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1576747623);
INSERT INTO `ims_core_sessions` VALUES ('03920830602cbd54e544f76af039f587', 2, '114.85.131.151', 'acid|s:1:\"2\";uniacid|i:2;token|a:4:{s:4:\"WNK2\";i:1576752857;s:4:\"WGPR\";i:1576752858;s:4:\"IYc7\";i:1576752864;s:4:\"Hk2E\";i:1576752866;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxOydYgbafLdBlHRc6RBLPB8\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxOydYgbafLdBlHRc6RBLPB8\";uid|s:2:\"13\";userinfo|s:796:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4T3lkWWdiYWZMZEJsSFJjNlJCTFBCOCI7czo4OiJuaWNrbmFtZSI7czozOiLpuYQiO3M6Mzoic2V4IjtpOjA7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjA6IiI7czo4OiJwcm92aW5jZSI7czowOiIiO3M6NzoiY291bnRyeSI7czowOiIiO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMzOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdlNTJVSG5Ua29aekh3UWdhdlpsMVRNT0tmUEIwa0dmOWdFSWtSa0gzSGw5VEIzTnl2SUN1aWJ3bTBudVpFQ0tOeXZhTjhFUHVQRGxaR2RrYktLRWVWcGcvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc0OTQ4NTkxO3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMzoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi93UXBBY0F0UkVXZTUyVUhuVGtvWnpId1FnYXZabDFUTU9LZlBCMGtHZjlnRUlrUmtIM0hsOVRCM055dklDdWlid20wbnVaRUNLTnl2YU44RVB1UERsWkdka2JLS0VlVnBnLzEzMiI7fQ==\";', 1576756466);
INSERT INTO `ims_core_sessions` VALUES ('7a932ce1bffaf0aee7f821b5db713b73', 2, '61.151.207.141', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"Pq8Q\";i:1576752921;}dest_url|s:164:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26hd%3D1%26do%3Dnewcat%26m%3Dtiger_newhu%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1576756521);
INSERT INTO `ims_core_sessions` VALUES ('e4b31a1bcdbcdc51545135d2639cf99c', 2, 'oyIJkxHbS8h882yHJX3HKPBiNxAM', 'openid|s:28:\"oyIJkxHbS8h882yHJX3HKPBiNxAM\";__reply_times|a:3:{s:7:\"content\";s:72:\"http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu\";s:4:\"date\";s:10:\"2019-12-19\";s:5:\"times\";i:1;}', 1576762118);
INSERT INTO `ims_core_sessions` VALUES ('57883f2099732619efb6e8fa64099679', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"iD8q\";i:1576754188;}dest_url|s:186:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26lm%3D2%26itemid%3D601396424185%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1576757788);
INSERT INTO `ims_core_sessions` VALUES ('76c6551c91fcac13022af3dab7e2ed44', 2, '39.155.185.14', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"eQmP\";i:1577337115;}', 1577340715);
INSERT INTO `ims_core_sessions` VALUES ('639a90b9b25151a094141852b770197e', 2, '223.104.9.190', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"NE4Z\";i:1576754456;s:4:\"M6N7\";i:1576754461;s:4:\"QO24\";i:1576754476;s:4:\"D2mN\";i:1576754476;s:4:\"Jb09\";i:1576754479;s:4:\"kOmn\";i:1576754487;}dest_url|s:125:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxOTYfOs8PQAHVhYe99g-DsM\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxOTYfOs8PQAHVhYe99g-DsM\";uid|s:2:\"24\";userinfo|s:732:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreE9UWWZPczhQUUFIVmhZZTk5Zy1Ec00iO3M6ODoibmlja25hbWUiO3M6MTU6IuWtn+iTneiTneiTneiTnSI7czozOiJzZXgiO2k6MjtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi5aSn6L+eIjtzOjg6InByb3ZpbmNlIjtzOjY6Iui+veWugSI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzI6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUS3ZKaWFOYkVEMGlicFdpY3JwaWJUb1VGSElkNUNmaDdBVGF0bG95V2h6b3haaWFCVjVDYUhqdDczMnM5OTVOR0pkb1VSWnFnTTJJOXo4NllRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMjoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRLdkppYU5iRUQwaWJwV2ljcnBpYlRvVUZISWQ1Q2ZoN0FUYXRsb3lXaHpveFppYUJWNUNhSGp0NzMyczk5NU5HSmRvVVJacWdNMkk5ejg2WVEvMTMyIjt9\";', 1576758087);
INSERT INTO `ims_core_sessions` VALUES ('b788d09fedd84b5ff4313aec46b1c89c', 2, '223.104.9.190', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"DTlA\";i:1576755661;s:4:\"Jp11\";i:1576755661;s:4:\"nndU\";i:1576755662;s:4:\"K8q2\";i:1576755663;s:4:\"PrsO\";i:1576755663;s:4:\"a6Pg\";i:1576755666;}dest_url|s:125:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxOTYfOs8PQAHVhYe99g-DsM\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxOTYfOs8PQAHVhYe99g-DsM\";uid|s:2:\"24\";userinfo|s:732:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreE9UWWZPczhQUUFIVmhZZTk5Zy1Ec00iO3M6ODoibmlja25hbWUiO3M6MTU6IuWtn+iTneiTneiTneiTnSI7czozOiJzZXgiO2k6MjtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi5aSn6L+eIjtzOjg6InByb3ZpbmNlIjtzOjY6Iui+veWugSI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzI6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUS3ZKaWFOYkVEMGlicFdpY3JwaWJUb1VGSElkNUNmaDdBVGF0bG95V2h6b3haaWFCVjVDYUhqdDczMnM5OTVOR0pkb1VSWnFnTTJJOXo4NllRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMjoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRLdkppYU5iRUQwaWJwV2ljcnBpYlRvVUZISWQ1Q2ZoN0FUYXRsb3lXaHpveFppYUJWNUNhSGp0NzMyczk5NU5HSmRvVVJacWdNMkk5ejg2WVEvMTMyIjt9\";', 1576759266);
INSERT INTO `ims_core_sessions` VALUES ('ddd2fa89f6d756dcfe57ef8d978945ce', 2, '61.151.206.126', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"Tu88\";i:1576756328;}dest_url|s:186:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26lm%3D2%26itemid%3D561380323357%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1576759928);
INSERT INTO `ims_core_sessions` VALUES ('a96a115af31af52a07db70aec45a2354', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"AX8g\";i:1576756691;}dest_url|s:186:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26lm%3D2%26itemid%3D525075604618%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1576760291);
INSERT INTO `ims_core_sessions` VALUES ('80188271561625574314dc284f6d6e4d', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"QVCt\";i:1576756722;}dest_url|s:186:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26lm%3D2%26itemid%3D525075604618%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1576760322);
INSERT INTO `ims_core_sessions` VALUES ('95d5cca8eda4ea8cd7822d0967fc4848', 2, '221.217.244.207', 'acid|s:1:\"2\";uniacid|i:2;token|a:4:{s:4:\"jvJk\";i:1576758519;s:4:\"wNwx\";i:1576758520;s:4:\"M9MA\";i:1576758521;s:4:\"k7gr\";i:1576758524;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxHbS8h882yHJX3HKPBiNxAM\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxHbS8h882yHJX3HKPBiNxAM\";uid|s:2:\"30\";userinfo|s:820:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4SGJTOGg4ODJ5SEpYM0hLUEJpTnhBTSI7czo4OiJuaWNrbmFtZSI7czo5OiLnjovlvabmmJUiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuS4nOWfjiI7czo4OiJwcm92aW5jZSI7czo2OiLljJfkuqwiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMwOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL1EzYXVIZ3p3ek00cFJVcVRwOEdneWo3aWJkS1RjSmxpYWliZ2ljaWM0Ykx0aWJLSVNiVHlwQkp3amZSTkNMbThzRmo1OEgycVR2MUR6RlRLeTVVaWFOS2tJSmlhSlEvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc2NzU4MjY2O3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMDoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9RM2F1SGd6d3pNNHBSVXFUcDhHZ3lqN2liZEtUY0psaWFpYmdpY2ljNGJMdGliS0lTYlR5cEJKd2pmUk5DTG04c0ZqNThIMnFUdjFEekZUS3k1VWlhTktrSUppYUpRLzEzMiI7fQ==\";', 1576762124);
INSERT INTO `ims_core_sessions` VALUES ('68e5ecc577802485e14ec60a7ebf0c31', 2, '114.95.224.34', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"MMoE\";i:1576978150;s:4:\"i6y5\";i:1576978151;s:4:\"w3kf\";i:1576978159;s:4:\"OE65\";i:1576978160;s:4:\"tbzg\";i:1576978164;s:4:\"y7aN\";i:1576978164;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxKRA-1SNFQ7eGhk4vbNYs1I\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxKRA-1SNFQ7eGhk4vbNYs1I\";uid|s:1:\"3\";userinfo|s:832:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4S1JBLTFTTkZRN2VHaGs0dmJOWXMxSSI7czo4OiJuaWNrbmFtZSI7czo1OiJhbGxlbiI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi5oKJ5bC8IjtzOjg6InByb3ZpbmNlIjtzOjE1OiLmlrDljZflqIHlsJTlo6siO3M6NzoiY291bnRyeSI7czoxMjoi5r6z5aSn5Yip5LqaIjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyODoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9QaWFqeFNxQlJhRUpBdHVxR2FGcTVpY0p0Tm9zdDZKMEJUNHJBYzFKWXRmWlBxcGliTUtpYU9nWEtaSXNQVXVOS1Z6MDhsYjVndWlheTJaR0R3emlhT2NtZlJ0Zy8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ4NTIxODA7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI4OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL1BpYWp4U3FCUmFFSkF0dXFHYUZxNWljSnROb3N0NkowQlQ0ckFjMUpZdGZaUHFwaWJNS2lhT2dYS1pJc1BVdU5LVnowOGxiNWd1aWF5MlpHRHd6aWFPY21mUnRnLzEzMiI7fQ==\";', 1576981764);
INSERT INTO `ims_core_sessions` VALUES ('da6718feab15defbb0421384dbafa4b7', 2, '27.18.20.229', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"CBw5\";i:1576813956;s:4:\"NyLo\";i:1576813958;s:4:\"Zzh8\";i:1576813962;s:4:\"hTTy\";i:1576813962;s:4:\"ok4b\";i:1576813966;s:4:\"SJnH\";i:1576813967;}dest_url|s:169:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dsinglemessage%26isappinstalled%3D0%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxFqe8qlSJ32tVCxWTJm7b_Q\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxFqe8qlSJ32tVCxWTJm7b_Q\";uid|s:2:\"32\";userinfo|s:748:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEZxZThxbFNKMzJ0VkN4V1RKbTdiX1EiO3M6ODoibmlja25hbWUiO3M6MjU6IueUn+a0u+WwseaYr/CfkLflkozov5zmlrkiO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuatpuaxiSI7czo4OiJwcm92aW5jZSI7czo2OiLmuZbljJciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMzOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvMGljZzV3VFA4bGpNTzQ3ZGpoSmFwWWF4dW5KZXBkQVZEbzVaRGlhNGlhN1pkYkU0eFV2Qk12cTBEaWJOdW9zaWJ2WUhyS0hQQWJMWUdaNHZISlhmaWNOVWtocGcvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTMzOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvMGljZzV3VFA4bGpNTzQ3ZGpoSmFwWWF4dW5KZXBkQVZEbzVaRGlhNGlhN1pkYkU0eFV2Qk12cTBEaWJOdW9zaWJ2WUhyS0hQQWJMWUdaNHZISlhmaWNOVWtocGcvMTMyIjt9\";', 1576817567);
INSERT INTO `ims_core_sessions` VALUES ('e8c06c8ba8af2ccd8d3448c9d15cd0de', 2, '101.89.239.216', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"p7U2\";i:1576814013;}dest_url|s:142:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dsinglemessage%26isappinstalled%3D0\";', 1576817613);
INSERT INTO `ims_core_sessions` VALUES ('522f20ccd614d0963bcfb4a484d1f03c', 2, '101.89.19.197', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"uAWy\";i:1576814016;}dest_url|s:169:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dsinglemessage%26isappinstalled%3D0%26wxref%3Dmp.weixin.qq.com\";', 1576817616);
INSERT INTO `ims_core_sessions` VALUES ('5ee0c6cab146d3ab33b7df3316808773', 2, '101.91.60.104', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"esUv\";i:1576814022;}dest_url|s:153:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Djdindex%26m%3Dtuike_jd%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1576817622);
INSERT INTO `ims_core_sessions` VALUES ('c22dfcbf74144c9eeafaf32e8ca0b321', 2, '101.91.60.106', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"GChH\";i:1577266348;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";', 1577269948);
INSERT INTO `ims_core_sessions` VALUES ('262b3d1ee2127a7d5b245e24e8e96ab1', 2, '61.151.207.205', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"D8h5\";i:1577266349;}dest_url|s:125:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com\";', 1577269949);
INSERT INTO `ims_core_sessions` VALUES ('0bc6aed9866a6c22d26ceaeb2179a770', 2, '61.129.6.151', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"ffLj\";i:1577266354;}dest_url|s:153:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Djdindex%26m%3Dtuike_jd%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1577269954);
INSERT INTO `ims_core_sessions` VALUES ('06ea1de5b329dfe1537bebeb6d5c2bfd', 2, '101.89.239.216', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"aGuC\";i:1577266357;}dest_url|s:130:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26jdlm%3D1%26do%3Djdview%26m%3Dtuike_jd%26itemid%3D52219513711\";', 1577269957);
INSERT INTO `ims_core_sessions` VALUES ('73aa46821b1ae8dcc01d0f7ad8963bc9', 2, '106.113.14.167', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"P77v\";i:1577060164;s:4:\"xiH6\";i:1577060188;s:4:\"dNnN\";i:1577060199;s:4:\"s3Hl\";i:1577060199;s:4:\"IcK5\";i:1577060204;s:4:\"foxo\";i:1577060204;}dest_url|s:125:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxD2zxZZd1Yi3nNOV51mPGws\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxD2zxZZd1Yi3nNOV51mPGws\";userinfo|s:712:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEQyenhaWmQxWWkzbk5PVjUxbVBHd3MiO3M6ODoibmlja25hbWUiO3M6Njoi5oKm5oKmIjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo5OiLnn7PlrrbluoQiO3M6ODoicHJvdmluY2UiO3M6Njoi5rKz5YyXIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyNzoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRJclpnM3pJNjVMVTVPMUQ4NzV3YUlGd2VRcmI1c0VlZDBIWXhIQldFS1VkUmFBSVZPYThzQ2F2d1VqRnJxdllmT1E4cUZXUDNESVVnLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEyNzoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRJclpnM3pJNjVMVTVPMUQ4NzV3YUlGd2VRcmI1c0VlZDBIWXhIQldFS1VkUmFBSVZPYThzQ2F2d1VqRnJxdllmT1E4cUZXUDNESVVnLzEzMiI7fQ==\";uid|s:2:\"36\";', 1577063804);
INSERT INTO `ims_core_sessions` VALUES ('258e93c6b7041ef86a50a309fe1b7af8', 2, '27.18.20.229', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"m4e3\";i:1576825834;s:4:\"buCZ\";i:1576825834;s:4:\"hRzd\";i:1576825835;s:4:\"wBVb\";i:1576825836;s:4:\"FP10\";i:1576825837;s:4:\"TIjc\";i:1576825839;}dest_url|s:169:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dsinglemessage%26isappinstalled%3D0%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxFqe8qlSJ32tVCxWTJm7b_Q\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxFqe8qlSJ32tVCxWTJm7b_Q\";uid|s:2:\"32\";userinfo|s:748:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEZxZThxbFNKMzJ0VkN4V1RKbTdiX1EiO3M6ODoibmlja25hbWUiO3M6MjU6IueUn+a0u+WwseaYr/CfkLflkozov5zmlrkiO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuatpuaxiSI7czo4OiJwcm92aW5jZSI7czo2OiLmuZbljJciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMzOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvMGljZzV3VFA4bGpNTzQ3ZGpoSmFwWWF4dW5KZXBkQVZEbzVaRGlhNGlhN1pkYkU0eFV2Qk12cTBEaWJOdW9zaWJ2WUhyS0hQQWJMWUdaNHZISlhmaWNOVWtocGcvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTMzOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvMGljZzV3VFA4bGpNTzQ3ZGpoSmFwWWF4dW5KZXBkQVZEbzVaRGlhNGlhN1pkYkU0eFV2Qk12cTBEaWJOdW9zaWJ2WUhyS0hQQWJMWUdaNHZISlhmaWNOVWtocGcvMTMyIjt9\";', 1576829439);
INSERT INTO `ims_core_sessions` VALUES ('d40210403b7d279f10b3b649d822e0e2', 2, 'oyIJkxESZBGbNb1VyCREQvnt0O9A', 'openid|s:28:\"oyIJkxESZBGbNb1VyCREQvnt0O9A\";__reply_times|a:3:{s:7:\"content\";s:72:\"http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu\";s:4:\"date\";s:10:\"2019-12-28\";s:5:\"times\";i:1;}', 1577468971);
INSERT INTO `ims_core_sessions` VALUES ('759d5411764a403f2a75905520c47df7', 2, '124.64.17.217', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"rf8t\";i:1576845036;s:4:\"j9Hy\";i:1576845052;s:4:\"zOFJ\";i:1576845055;s:4:\"Bc3Y\";i:1576845055;s:4:\"hi10\";i:1576845057;s:4:\"ILy6\";i:1576845059;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxESZBGbNb1VyCREQvnt0O9A\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxESZBGbNb1VyCREQvnt0O9A\";uid|s:2:\"10\";userinfo|s:820:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RVNaQkdiTmIxVnlDUkVRdm50ME85QSI7czo4OiJuaWNrbmFtZSI7czoxODoi5pyI54mZ5LiK55qE54yr5ZKqIjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLmnJ3pmLMiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyNjoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9QaWFqeFNxQlJhRUs5d1huTlhjRHowazFRMmliaWJ0MFJTdFVubFJBNjFIQmwyVG8zVlF1TjVnZEl2c0NrSjREamliZmxPRHk3UU5ONWUzMlh3TEI2a1p5R2cvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc0OTEyNDY3O3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEyNjoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9QaWFqeFNxQlJhRUs5d1huTlhjRHowazFRMmliaWJ0MFJTdFVubFJBNjFIQmwyVG8zVlF1TjVnZEl2c0NrSjREamliZmxPRHk3UU5ONWUzMlh3TEI2a1p5R2cvMTMyIjt9\";', 1576848659);
INSERT INTO `ims_core_sessions` VALUES ('bd719a0c0c99730ed1663c3fff1f87d5', 2, '221.216.72.121', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"sRjb\";i:1576840547;s:4:\"PksD\";i:1576840548;s:4:\"P9ss\";i:1576840548;s:4:\"VZpP\";i:1576840553;s:4:\"SnKb\";i:1576840554;s:4:\"G7R9\";i:1576840563;}dest_url|s:125:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxPTRQQQzbxQqN92ie9obzxM\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxPTRQQQzbxQqN92ie9obzxM\";userinfo|s:732:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreFBUUlFRUXpieFFxTjkyaWU5b2J6eE0iO3M6ODoibmlja25hbWUiO3M6MTg6IuS4lue6quS/neeQhuWuouacjSI7czozOiJzZXgiO2k6MjtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi6ZW/5pilIjtzOjg6InByb3ZpbmNlIjtzOjY6IuWQieaelyI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzA6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi84eUg2U3lUSXg2RW1rbmRhZjZMUmJiRmd5eU54dmgyREg3aWFraG4wYVpKTk5DQ0NWRkdPR0NZcXp6YnZySWtGcnFtejJXdW9abEtxeWliT3hmaWJNS2FGQS8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMzA6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi84eUg2U3lUSXg2RW1rbmRhZjZMUmJiRmd5eU54dmgyREg3aWFraG4wYVpKTk5DQ0NWRkdPR0NZcXp6YnZySWtGcnFtejJXdW9abEtxeWliT3hmaWJNS2FGQS8xMzIiO30=\";uid|s:2:\"33\";', 1576844163);
INSERT INTO `ims_core_sessions` VALUES ('6a890613b909bbc533b63b8b62b3d233', 2, '106.61.11.126', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"tzH9\";i:1577173340;s:4:\"ARmZ\";i:1577173341;s:4:\"Tv0d\";i:1577173342;s:4:\"GMag\";i:1577173342;s:4:\"tc0T\";i:1577173345;s:4:\"VJ7S\";i:1577173352;}dest_url|s:147:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26from%3Dgroupmessage%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxPQUDLj2dj8NZeX58Hsxryk\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxPQUDLj2dj8NZeX58Hsxryk\";uid|s:2:\"25\";userinfo|s:740:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreFBRVURMajJkajhOWmVYNThIc3hyeWsiO3M6ODoibmlja25hbWUiO3M6MTI6IuS4nOaWuemDgeWNjiI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi6YOR5beeIjtzOjg6InByb3ZpbmNlIjtzOjY6Iuays+WNlyI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzY6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUTDRpYU5pY0NhTTl6Z29qNFFpY1BxS2dqSlRpY0wzSEdpYkEyM2FxWUUxQWhLaWJUOU9IR1IyVElVQkZpY1g5SDhYRWlibnZEZlZtTFZjaFRpYnhKUS8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMzY6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUTDRpYU5pY0NhTTl6Z29qNFFpY1BxS2dqSlRpY0wzSEdpYkEyM2FxWUUxQWhLaWJUOU9IR1IyVElVQkZpY1g5SDhYRWlibnZEZlZtTFZjaFRpYnhKUS8xMzIiO30=\";', 1577176952);
INSERT INTO `ims_core_sessions` VALUES ('f70f0fe76f849582f8b10e3065ea5b21', 2, '39.155.185.14', 'acid|s:1:\"2\";uniacid|i:2;token|a:4:{s:4:\"GSg8\";i:1577421492;s:4:\"PuxS\";i:1577421493;s:4:\"q86y\";i:1577421493;s:4:\"ImFd\";i:1577421496;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxD8muNpYh6c4TrVYK2YtcLs\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxD8muNpYh6c4TrVYK2YtcLs\";uid|s:1:\"9\";userinfo|s:840:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RDhtdU5wWWg2YzRUclZZSzJZdGNMcyI7czo4OiJuaWNrbmFtZSI7czo5OiLkuZTpuY/ovr4iO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuWQieaelyI7czo4OiJwcm92aW5jZSI7czo2OiLlkInmnpciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTM4OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuLzV0a0ZaeWpab1lKVTBsM0cwcjFjQ1c2N0k4ckdpYXd6aWJIblZVQ0RJTXhRMmczaWJpY3NNdjZvUGZqZjlranNMYmRpY2FMM3FuZ3MxY2liNGpKcEV2ZGpyVDZxTFdBYUxRRVFrVy8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ5MTAwOTA7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTM4OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuLzV0a0ZaeWpab1lKVTBsM0cwcjFjQ1c2N0k4ckdpYXd6aWJIblZVQ0RJTXhRMmczaWJpY3NNdjZvUGZqZjlranNMYmRpY2FMM3FuZ3MxY2liNGpKcEV2ZGpyVDZxTFdBYUxRRVFrVy8xMzIiO30=\";', 1577425096);
INSERT INTO `ims_core_sessions` VALUES ('37377a2a5dcc585ccbf9f0a5ea0d37de', 2, 'oyIJkxD8muNpYh6c4TrVYK2YtcLs', 'openid|s:28:\"oyIJkxD8muNpYh6c4TrVYK2YtcLs\";__reply_times|a:3:{s:7:\"content\";s:72:\"http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu\";s:4:\"date\";s:10:\"2019-12-27\";s:5:\"times\";i:1;}', 1577425092);
INSERT INTO `ims_core_sessions` VALUES ('e8a20444d65a096ced2c0a8c755bc5c3', 2, '101.89.239.238', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"l9R9\";i:1576978271;}dest_url|s:125:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com\";', 1576981871);
INSERT INTO `ims_core_sessions` VALUES ('a5f9d86aa41d398e7d30a6adda571b1f', 2, '61.151.178.197', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"hAI4\";i:1576978272;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";', 1576981872);
INSERT INTO `ims_core_sessions` VALUES ('a6b20b195c42e4a318aa81bbf447261f', 2, '61.151.207.186', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"EKFf\";i:1576978314;}dest_url|s:175:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26itemid%3D610104449485%26lm%3D2%26pid%3Dmm_711720113_1065450073_109733950492%26do%3Dview%26m%3Dtiger_newhu\";', 1576981914);
INSERT INTO `ims_core_sessions` VALUES ('7e617aa57433ffee3c3537119c9052e5', 2, 'oyIJkxEwZegHiYnx-6At2gzylBAQ', 'openid|s:28:\"oyIJkxEwZegHiYnx-6At2gzylBAQ\";__reply_times|a:3:{s:7:\"content\";s:72:\"http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu\";s:4:\"date\";s:10:\"2019-12-26\";s:5:\"times\";i:3;}', 1577340644);
INSERT INTO `ims_core_sessions` VALUES ('65bb7e17ed466e2cfc50d6150f83976e', 2, '39.155.185.14', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"e5Xz\";i:1577337028;s:4:\"u00X\";i:1577337044;s:4:\"WLEG\";i:1577337045;s:4:\"Xnff\";i:1577337078;s:4:\"qUbI\";i:1577337079;s:4:\"KP42\";i:1577337095;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxEwZegHiYnx-6At2gzylBAQ\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxEwZegHiYnx-6At2gzylBAQ\";uid|s:2:\"34\";userinfo|s:836:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RXdaZWdIaVlueC02QXQyZ3p5bEJBUSI7czo4OiJuaWNrbmFtZSI7czo5OiLpn6nlrp3pn7MiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuacnemYsyI7czo4OiJwcm92aW5jZSI7czo2OiLljJfkuqwiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTM3OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL29pYmtqenBVa1BOd1l2azJSTnhMQk0ydVg4czJOcnZoVk9JbUFjYm43VjdEMUtBaWFYM2ppYlNpY3dzeENjSldMQWJXdmJBWWFVUEg1UThmWXFleUVKN1hpYVJRMWFCdkl3cEVjLzEzMiI7czoxNDoic3Vic2NyaWJlX3RpbWUiO2k6MTU3Njk5ODU2ODtzOjc6Imdyb3VwaWQiO2k6MDtzOjEwOiJ0YWdpZF9saXN0IjthOjA6e31zOjY6ImF2YXRhciI7czoxMzc6Imh0dHBzOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vb2lia2p6cFVrUE53WXZrMlJOeExCTTJ1WDhzMk5ydmhWT0ltQWNibjdWN0QxS0FpYVgzamliU2ljd3N4Q2NKV0xBYld2YkFZYVVQSDVROGZZcWV5RUo3WGlhUlExYUJ2SXdwRWMvMTMyIjt9\";', 1577340695);
INSERT INTO `ims_core_sessions` VALUES ('b02f8617e39a5a520eea0bd6df2a4432', 2, '61.151.178.197', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"PmVZ\";i:1576998670;}dest_url|s:155:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dmember%26m%3Dtiger_newhu%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1577002270);
INSERT INTO `ims_core_sessions` VALUES ('c4c40bb765e98a338489110c5e6482b2', 2, '101.89.239.232', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"L16G\";i:1576998694;}dest_url|s:118:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26pid%3D%26dluid%3D\";', 1577002294);
INSERT INTO `ims_core_sessions` VALUES ('abbb314b0c7daddc5e5fa07d80a1d520', 2, 'oyIJkxJBo77bqleCI0cqpTVfUNPw', 'openid|s:28:\"oyIJkxJBo77bqleCI0cqpTVfUNPw\";__reply_times|a:3:{s:7:\"content\";N;s:4:\"date\";s:10:\"2019-12-22\";s:5:\"times\";i:1;}', 1577002342);
INSERT INTO `ims_core_sessions` VALUES ('1912cdcc7f30f2d38fc4b9c2eb8a9356', 2, '124.64.17.217', 'acid|s:1:\"2\";uniacid|i:2;token|a:6:{s:4:\"XKLl\";i:1577014201;s:4:\"JMau\";i:1577014201;s:4:\"Jg61\";i:1577014202;s:4:\"sDyg\";i:1577014207;s:4:\"qbf9\";i:1577014207;s:4:\"nUQq\";i:1577014216;}dest_url|s:125:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com\";oauth_openid|s:28:\"oyIJkxPTRQQQzbxQqN92ie9obzxM\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxPTRQQQzbxQqN92ie9obzxM\";uid|s:2:\"33\";userinfo|s:732:\"YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreFBUUlFRUXpieFFxTjkyaWU5b2J6eE0iO3M6ODoibmlja25hbWUiO3M6MTg6IuS4lue6quS/neeQhuWuouacjSI7czozOiJzZXgiO2k6MjtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi6ZW/5pilIjtzOjg6InByb3ZpbmNlIjtzOjY6IuWQieaelyI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzA6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi84eUg2U3lUSXg2RW1rbmRhZjZMUmJiRmd5eU54dmgyREg3aWFraG4wYVpKTk5DQ0NWRkdPR0NZcXp6YnZySWtGcnFtejJXdW9abEtxeWliT3hmaWJNS2FGQS8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMzA6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi84eUg2U3lUSXg2RW1rbmRhZjZMUmJiRmd5eU54dmgyREg3aWFraG4wYVpKTk5DQ0NWRkdPR0NZcXp6YnZySWtGcnFtejJXdW9abEtxeWliT3hmaWJNS2FGQS8xMzIiO30=\";', 1577017816);
INSERT INTO `ims_core_sessions` VALUES ('f2eb25c5f1ed595a402d2b0a3b2051d4', 2, 'oyIJkxKRA-1SNFQ7eGhk4vbNYs1I', 'openid|s:28:\"oyIJkxKRA-1SNFQ7eGhk4vbNYs1I\";__reply_times|a:3:{s:7:\"content\";s:72:\"http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu\";s:4:\"date\";s:10:\"2019-12-28\";s:5:\"times\";i:1;}', 1577524417);
INSERT INTO `ims_core_sessions` VALUES ('29bd3e81ab72b130809f9b157acbd809', 2, '223.104.9.220', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"saK4\";i:1577507391;}', 1577510991);
INSERT INTO `ims_core_sessions` VALUES ('5cf2de773f8138a18a4cc4024f0c6c5c', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"hT1m\";i:1577418292;}dest_url|s:125:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com\";', 1577421892);
INSERT INTO `ims_core_sessions` VALUES ('3b69e0cea7077c1c2f48014b6de88cc4', 2, '61.151.206.25', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"Sl21\";i:1577362902;}dest_url|s:876:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D577124967334%26org_price%3D63%26price%3D58%26coupons_price%3D5%26goods_sale%3D108%26title%3D%25E5%258A%25A0%25E7%2583%25AD%25E5%259D%2590%25E5%259E%25AB%25E5%258A%259E%25E5%2585%25AC%25E5%25AE%25A4%25E7%2594%25B5%25E7%2583%25AD%25E5%259D%2590%25E5%259E%25AB%25E5%258A%25A0%25E7%2583%25AD%25E6%25A4%2585%25E5%259E%25AB%25E6%259A%2596%25E8%2585%25B0%25E5%259E%25AB%25E5%258F%2591%25E7%2583%25AD%25E9%259D%25A0%25E8%2583%258C%25E5%25A4%259A%25E5%258A%259F%25E8%2583%25BD%25E5%25AE%25B6%25E7%2594%25A8%25E7%2594%25B5%25E6%259A%2596%25E5%259E%25AB%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi3%252F1089124079%252FO1CN01Mro6Fg1g0E1oHK6en_%2521%25211089124079.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577366502);
INSERT INTO `ims_core_sessions` VALUES ('2127f88e55343c55a7cd28bfa0b0c89c', 2, '221.219.231.113', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"Tsbd\";i:1577467111;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";oauth_openid|s:28:\"oyIJkxESZBGbNb1VyCREQvnt0O9A\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxESZBGbNb1VyCREQvnt0O9A\";uid|s:2:\"10\";userinfo|s:820:\"YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RVNaQkdiTmIxVnlDUkVRdm50ME85QSI7czo4OiJuaWNrbmFtZSI7czoxODoi5pyI54mZ5LiK55qE54yr5ZKqIjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLmnJ3pmLMiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyNToiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9hak5WZHFIWkxMQU5URmRVbUE5TDlXTkVXRlF2bzRTRHZNQTVsNlR0M2pwbHl3dE0zZVVEQURpYmp1ZThwRXpZMTlLaWJWYXFlaWNISVhjUHBJTDdZc21qdy8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ5MTI0Njc7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI1OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2FqTlZkcUhaTExBTlRGZFVtQTlMOVdORVdGUXZvNFNEdk1BNWw2VHQzanBseXd0TTNlVURBRGlianVlOHBFelkxOUtpYlZhcWVpY0hJWGNQcElMN1lzbWp3LzEzMiI7fQ==\";', 1577470711);
INSERT INTO `ims_core_sessions` VALUES ('7fb886f3df89bad338ef669b82c80f7f', 2, '61.151.178.175', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"Yx4a\";i:1577349721;}dest_url|s:148:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com%26from%3Dsinglemessage\";', 1577353321);
INSERT INTO `ims_core_sessions` VALUES ('1de721ee493dbced8d401135992dae70', 2, '59.37.97.56', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"hgqv\";i:1577337476;}dest_url|s:878:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D603187367136%26org_price%3D329%26price%3D299%26coupons_price%3D30%26goods_sale%3D28%26title%3D%25E7%2594%259F%25E6%25B4%25BB%25E5%2585%2583%25E7%25B4%25A0%25E6%2597%2585%25E8%25A1%258C%25E6%258A%2598%25E5%258F%25A0%25E6%25B0%25B4%25E5%25A3%25B6%25E5%25AE%25B6%25E7%2594%25A8%25E4%25BE%25BF%25E6%2590%25BA%25E5%25BC%258F%25E7%2583%25A7%25E6%25B0%25B4%25E5%25A3%25B6%25E6%2597%2585%25E6%25B8%25B8%25E7%2594%25B5%25E7%2583%25AD%25E5%25B0%258F%25E5%259E%258B%25E4%25BF%259D%25E6%25B8%25A9%25E4%25B8%2580%25E4%25BD%2593%25E6%25B0%25B4%25E6%259D%25AF%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi1%252F4222563050%252FO1CN01QLyy2T1YOwZrWPdXX_%2521%25210-item_pic.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577341076);
INSERT INTO `ims_core_sessions` VALUES ('e05038817fd6dfd7064a6aa278d5da4f', 2, '61.151.178.166', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"MT67\";i:1577337155;}dest_url|s:878:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D603187367136%26org_price%3D329%26price%3D299%26coupons_price%3D30%26goods_sale%3D28%26title%3D%25E7%2594%259F%25E6%25B4%25BB%25E5%2585%2583%25E7%25B4%25A0%25E6%2597%2585%25E8%25A1%258C%25E6%258A%2598%25E5%258F%25A0%25E6%25B0%25B4%25E5%25A3%25B6%25E5%25AE%25B6%25E7%2594%25A8%25E4%25BE%25BF%25E6%2590%25BA%25E5%25BC%258F%25E7%2583%25A7%25E6%25B0%25B4%25E5%25A3%25B6%25E6%2597%2585%25E6%25B8%25B8%25E7%2594%25B5%25E7%2583%25AD%25E5%25B0%258F%25E5%259E%258B%25E4%25BF%259D%25E6%25B8%25A9%25E4%25B8%2580%25E4%25BD%2593%25E6%25B0%25B4%25E6%259D%25AF%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi1%252F4222563050%252FO1CN01QLyy2T1YOwZrWPdXX_%2521%25210-item_pic.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577340755);
INSERT INTO `ims_core_sessions` VALUES ('5d31b4e6d403b92028374d4bebc113f1', 2, '59.36.121.178', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"SANP\";i:1577337151;}dest_url|s:878:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dview%26m%3Dtiger_newhu%26id%3Dundefined%26dluid%3D%26lm%3D1%26itemid%3D603187367136%26org_price%3D329%26price%3D299%26coupons_price%3D30%26goods_sale%3D28%26title%3D%25E7%2594%259F%25E6%25B4%25BB%25E5%2585%2583%25E7%25B4%25A0%25E6%2597%2585%25E8%25A1%258C%25E6%258A%2598%25E5%258F%25A0%25E6%25B0%25B4%25E5%25A3%25B6%25E5%25AE%25B6%25E7%2594%25A8%25E4%25BE%25BF%25E6%2590%25BA%25E5%25BC%258F%25E7%2583%25A7%25E6%25B0%25B4%25E5%25A3%25B6%25E6%2597%2585%25E6%25B8%25B8%25E7%2594%25B5%25E7%2583%25AD%25E5%25B0%258F%25E5%259E%258B%25E4%25BF%259D%25E6%25B8%25A9%25E4%25B8%2580%25E4%25BD%2593%25E6%25B0%25B4%25E6%259D%25AF%26pic_url%3Dhttps%253A%252F%252Fimg.alicdn.com%252Fbao%252Fuploaded%252Fi1%252F4222563050%252FO1CN01QLyy2T1YOwZrWPdXX_%2521%25210-item_pic.jpg%26pid%3Dmm_711720113_1065450073_109733950492\";', 1577340751);
INSERT INTO `ims_core_sessions` VALUES ('9dfd971a7289f28f904cac2152cd8b29', 2, '58.247.206.151', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"GkwM\";i:1577287646;}dest_url|s:147:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com%26from%3Dgroupmessage\";', 1577291246);
INSERT INTO `ims_core_sessions` VALUES ('52ebc870a14850a4c3cf47e940f8fd46', 2, '61.151.178.175', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"R45Q\";i:1577287665;}dest_url|s:1276:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26dluid%3D%26pid%3Dmm_711720113_1065450073_109733950492%26m%3Dtiger_newhu%26do%3Dcqlist%26zn%3D0%26key%3D%25E3%2580%2590%25E5%2585%2581%25E5%25AE%259D%25E6%259A%2596%25E9%25A2%2588%25E8%25B4%25B4%25E8%2595%25B2%25E8%2589%25BE%25E9%25A2%2588%25E6%25A4%258E%25E7%2583%25AD%25E6%2595%25B7%25E8%25B4%25B4%25E6%259A%2596%25E5%25AE%259D%25E5%25AE%259D%25E8%25B4%25B4%25E9%25A2%2588%25E9%2583%25A8%25E4%25BF%259D%25E6%259A%2596%25E8%2587%25AA%25E5%258F%2591%25E7%2583%25AD%25E9%25A2%2588%25E6%25A4%258E%25E8%25B4%25B4%25E8%2582%25A9%25E9%25A2%2588%25E8%25B4%25B4%25E3%2580%2591https%253A%252F%252Fm.tb.cn%252Fh.ezTImpl%253Fsm%253D2088d6%2B%25E9%25BB%259E%25EF%25BF%25A1%25E6%2593%258A%25E2%2598%2586%25E9%258F%2588%25E3%2584%25A3%25E6%258E%25A5%25EF%25BC%258C%25E5%2586%258D%25E9%2580%2589%25E6%258B%25A9%25E7%2580%258F%25E8%25A6%25BD%25E2%2586%2592%25E5%2599%2590%25E5%2592%2591%25E2%2584%2596%25E4%25BA%2593%25EF%25BC%259B%25E6%2588%2596%25E5%25BE%25A9%25E3%2581%259A%25E2%2596%25A0%25E6%25B7%259B%25E8%25BF%2599%25E5%258F%25A5%25E8%25AF%259D%25E2%2582%25A4LtgC10jrkXw%25E2%2582%25A4%25E5%2590%258E%25E6%2589%2593%25E5%25BC%2580%25F0%259F%2591%2589%25E6%25B7%2598%25E7%2581%25AC%25E5%25AF%25B3%25F0%259F%2591%2588\";', 1577291265);
INSERT INTO `ims_core_sessions` VALUES ('3a97493768797bb58c8ac05eeec3b86d', 2, '61.151.178.197', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"i3V4\";i:1577337138;}dest_url|s:623:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26dluid%3D%26pid%3Dmm_711720113_1065450073_109733950492%26m%3Dtiger_newhu%26do%3Dcqlist%26zn%3D0%26key%3D%25E7%2594%259F%25E6%25B4%25BB%25E5%2585%2583%25E7%25B4%25A0%25E6%2597%2585%25E8%25A1%258C%25E6%258A%2598%25E5%258F%25A0%25E6%25B0%25B4%25E5%25A3%25B6%25E5%25AE%25B6%25E7%2594%25A8%25E4%25BE%25BF%25E6%2590%25BA%25E5%25BC%258F%25E7%2583%25A7%25E6%25B0%25B4%25E5%25A3%25B6%25E6%2597%2585%25E6%25B8%25B8%25E7%2594%25B5%25E7%2583%25AD%25E5%25B0%258F%25E5%259E%258B%25E4%25BF%259D%25E6%25B8%25A9%25E4%25B8%2580%25E4%25BD%2593%25E6%25B0%25B4%25E6%259D%25AF\";', 1577340738);
INSERT INTO `ims_core_sessions` VALUES ('f6f803869e2159fdfe42e9c829d38362', 2, '101.227.139.172', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"BWH5\";i:1577273223;}dest_url|s:164:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26hd%3D1%26do%3Dnewcat%26m%3Dtiger_newhu%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1577276823);
INSERT INTO `ims_core_sessions` VALUES ('68e164fbdaa2c3fdbca634444b5b19f9', 2, '106.38.133.106', 'acid|s:1:\"2\";uniacid|i:2;token|a:4:{s:4:\"OEjr\";i:1577276843;s:4:\"yrgG\";i:1577276843;s:4:\"m7Bb\";i:1577276845;s:4:\"leYC\";i:1577276852;}dest_url|s:168:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com%26from%3Dgroupmessage%26isappinstalled%3D0\";oauth_openid|s:28:\"oyIJkxCjhq3z1CnqHCScGXIoEs08\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxCjhq3z1CnqHCScGXIoEs08\";', 1577280452);
INSERT INTO `ims_core_sessions` VALUES ('fc425875163d0e8941a7a93475b908ec', 2, '58.247.206.156', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"vOw1\";i:1577269766;}dest_url|s:130:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26jdlm%3D1%26do%3Djdview%26m%3Dtuike_jd%26itemid%3D10268879787\";', 1577273366);
INSERT INTO `ims_core_sessions` VALUES ('178bdef4a5da612601a3d019b41b7e6c', 2, '114.246.125.158', 'acid|s:1:\"2\";uniacid|i:2;token|a:2:{s:4:\"o1ZW\";i:1577315094;s:4:\"veP6\";i:1577315095;}dest_url|s:147:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com%26from%3Dgroupmessage\";oauth_openid|s:28:\"oyIJkxPTRQQQzbxQqN92ie9obzxM\";oauth_acid|s:1:\"2\";openid|s:28:\"oyIJkxPTRQQQzbxQqN92ie9obzxM\";uid|s:2:\"33\";', 1577318695);
INSERT INTO `ims_core_sessions` VALUES ('8db548d32f16ba044deb946a3f33805b', 2, '101.91.60.106', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"DiE7\";i:1577337043;}dest_url|s:125:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu%26wxref%3Dmp.weixin.qq.com\";', 1577340643);
INSERT INTO `ims_core_sessions` VALUES ('6f17c35cb088fc7be6ec3b79a435f0f8', 2, '59.36.121.178', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"zAgf\";i:1577337071;}dest_url|s:98:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dindex%26m%3Dtiger_newhu\";', 1577340671);
INSERT INTO `ims_core_sessions` VALUES ('b7c4629bb32074f5053ec8529e6d5c12', 2, '61.151.207.141', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"drM5\";i:1577269742;}dest_url|s:152:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dddq%26m%3Dtiger_newhu%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1577273342);
INSERT INTO `ims_core_sessions` VALUES ('9d1a42911a6ec3e4ebd9029a19078115', 2, '101.89.29.92', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"xmwS\";i:1577266368;}dest_url|s:120:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dpddview%26m%3Dtuike_pdd%26itemid%3D2607261135\";', 1577269968);
INSERT INTO `ims_core_sessions` VALUES ('df6fa54adcd30ef4e0726202413fe37a', 2, '101.91.60.107', 'acid|s:1:\"2\";uniacid|i:2;token|a:1:{s:4:\"LmLE\";i:1577266365;}dest_url|s:155:\"http%3A%2F%2Fhztbk.wjlnfs.com%2Fapp%2Findex.php%3Fi%3D2%26c%3Dentry%26do%3Dpddindex%26m%3Dtuike_pdd%26pid%3Dmm_711720113_1065450073_109733950492%26dluid%3D\";', 1577269965);
INSERT INTO `ims_core_sessions` VALUES ('qkbi8lb8nrof2vo9jft1gvk2al', 2, '127.0.0.1', 'acid|s:1:\"2\";uniacid|i:2;token|a:2:{s:4:\"ftg5\";i:1577540668;s:4:\"y2ur\";i:1577540671;}', 1577544271);
COMMIT;

-- ----------------------------
-- Table structure for ims_core_settings
-- ----------------------------
DROP TABLE IF EXISTS `ims_core_settings`;
CREATE TABLE `ims_core_settings` (
  `key` varchar(200) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_core_settings
-- ----------------------------
BEGIN;
INSERT INTO `ims_core_settings` VALUES ('copyright', 'a:1:{s:6:\"slides\";a:3:{i:0;s:58:\"https://img.alicdn.com/tps/TB1pfG4IFXXXXc6XXXXXXXXXXXX.jpg\";i:1;s:58:\"https://img.alicdn.com/tps/TB1sXGYIFXXXXc5XpXXXXXXXXXX.jpg\";i:2;s:58:\"https://img.alicdn.com/tps/TB1h9xxIFXXXXbKXXXXXXXXXXXX.jpg\";}}');
INSERT INTO `ims_core_settings` VALUES ('authmode', 'i:1;');
INSERT INTO `ims_core_settings` VALUES ('close', 'a:2:{s:6:\"status\";s:1:\"0\";s:6:\"reason\";s:0:\"\";}');
INSERT INTO `ims_core_settings` VALUES ('register', 'a:4:{s:4:\"open\";i:1;s:6:\"verify\";i:0;s:4:\"code\";i:1;s:7:\"groupid\";i:1;}');
INSERT INTO `ims_core_settings` VALUES ('thirdlogin', 'a:4:{s:6:\"system\";a:3:{s:5:\"appid\";s:0:\"\";s:9:\"appsecret\";s:0:\"\";s:9:\"authstate\";s:0:\"\";}s:2:\"qq\";a:3:{s:5:\"appid\";s:0:\"\";s:9:\"appsecret\";s:0:\"\";s:9:\"authstate\";i:0;}s:6:\"wechat\";a:3:{s:5:\"appid\";s:0:\"\";s:9:\"appsecret\";s:0:\"\";s:9:\"authstate\";s:0:\"\";}s:6:\"mobile\";a:3:{s:5:\"appid\";s:0:\"\";s:9:\"appsecret\";s:0:\"\";s:9:\"authstate\";s:0:\"\";}}');
INSERT INTO `ims_core_settings` VALUES ('cloudip', 'a:0:{}');
INSERT INTO `ims_core_settings` VALUES ('platform', 'a:5:{s:5:\"token\";s:32:\"SLZdvo61blXbhzYZXdsAaHsyY8z31HBV\";s:14:\"encodingaeskey\";s:43:\"vEyLkSIQqdDZslZyizCSLtZHSSpIIDjSeKdSZUlkkcS\";s:9:\"appsecret\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:9:\"authstate\";i:1;}');
INSERT INTO `ims_core_settings` VALUES ('module_receive_ban', 'a:0:{}');
COMMIT;

-- ----------------------------
-- Table structure for ims_coupon_location
-- ----------------------------
DROP TABLE IF EXISTS `ims_coupon_location`;
CREATE TABLE `ims_coupon_location` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `sid` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `business_name` varchar(50) NOT NULL,
  `branch_name` varchar(50) NOT NULL,
  `category` varchar(255) NOT NULL,
  `province` varchar(15) NOT NULL,
  `city` varchar(15) NOT NULL,
  `district` varchar(15) NOT NULL,
  `address` varchar(50) NOT NULL,
  `longitude` varchar(15) NOT NULL,
  `latitude` varchar(15) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `photo_list` varchar(10000) NOT NULL,
  `avg_price` int(10) unsigned NOT NULL,
  `open_time` varchar(50) NOT NULL,
  `recommend` varchar(255) NOT NULL,
  `special` varchar(255) NOT NULL,
  `introduction` varchar(255) NOT NULL,
  `offset_type` tinyint(3) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `message` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`,`acid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_cover_reply
-- ----------------------------
DROP TABLE IF EXISTS `ims_cover_reply`;
CREATE TABLE `ims_cover_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `multiid` int(10) unsigned NOT NULL,
  `rid` int(10) unsigned NOT NULL,
  `module` varchar(30) NOT NULL,
  `do` varchar(30) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_cover_reply
-- ----------------------------
BEGIN;
INSERT INTO `ims_cover_reply` VALUES (1, 1, 0, 7, 'mc', '', '进入个人中心', '', '', './index.php?c=mc&a=home&i=1');
INSERT INTO `ims_cover_reply` VALUES (2, 1, 1, 8, 'site', '', '进入首页', '', '', './index.php?c=home&i=1&t=1');
COMMIT;

-- ----------------------------
-- Table structure for ims_custom_reply
-- ----------------------------
DROP TABLE IF EXISTS `ims_custom_reply`;
CREATE TABLE `ims_custom_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `start1` int(10) NOT NULL,
  `end1` int(10) NOT NULL,
  `start2` int(10) NOT NULL,
  `end2` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_images_reply
-- ----------------------------
DROP TABLE IF EXISTS `ims_images_reply`;
CREATE TABLE `ims_images_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `mediaid` varchar(255) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_job
-- ----------------------------
DROP TABLE IF EXISTS `ims_job`;
CREATE TABLE `ims_job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `payload` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `title` varchar(22) NOT NULL,
  `handled` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `endtime` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `isdeleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_card
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_card`;
CREATE TABLE `ims_mc_card` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `color` varchar(255) NOT NULL,
  `background` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `format_type` tinyint(3) unsigned NOT NULL,
  `format` varchar(50) NOT NULL,
  `description` varchar(512) NOT NULL,
  `fields` varchar(1000) NOT NULL,
  `snpos` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `business` text NOT NULL,
  `discount_type` tinyint(3) unsigned NOT NULL,
  `discount` varchar(3000) NOT NULL,
  `grant` varchar(3000) NOT NULL,
  `grant_rate` varchar(20) NOT NULL,
  `offset_rate` int(10) unsigned NOT NULL,
  `offset_max` int(10) NOT NULL,
  `nums_status` tinyint(3) unsigned NOT NULL,
  `nums_text` varchar(15) NOT NULL,
  `nums` varchar(1000) NOT NULL,
  `times_status` tinyint(3) unsigned NOT NULL,
  `times_text` varchar(15) NOT NULL,
  `times` varchar(1000) NOT NULL,
  `params` longtext NOT NULL,
  `html` longtext NOT NULL,
  `recommend_status` tinyint(3) unsigned NOT NULL,
  `sign_status` tinyint(3) unsigned NOT NULL,
  `brand_name` varchar(128) NOT NULL,
  `quantity` int(10) NOT NULL,
  `notice` varchar(48) NOT NULL,
  `max_increase_bonus` int(10) NOT NULL,
  `least_money_to_use_bonus` int(10) NOT NULL,
  `source` int(1) NOT NULL,
  `card_id` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_card_care
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_card_care`;
CREATE TABLE `ims_mc_card_care` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `title` varchar(30) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `groupid` int(10) unsigned NOT NULL,
  `credit1` int(10) unsigned NOT NULL,
  `credit2` int(10) unsigned NOT NULL,
  `couponid` int(10) unsigned NOT NULL,
  `granttime` int(10) unsigned NOT NULL,
  `days` int(10) unsigned NOT NULL,
  `time` tinyint(3) unsigned NOT NULL,
  `show_in_card` tinyint(3) unsigned NOT NULL,
  `content` varchar(1000) NOT NULL,
  `sms_notice` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_card_credit_set
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_card_credit_set`;
CREATE TABLE `ims_mc_card_credit_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `sign` varchar(1000) NOT NULL,
  `share` varchar(500) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_card_members
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_card_members`;
CREATE TABLE `ims_mc_card_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) DEFAULT NULL,
  `openid` varchar(50) NOT NULL,
  `cid` int(10) NOT NULL,
  `cardsn` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `nums` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_card_notices
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_card_notices`;
CREATE TABLE `ims_mc_card_notices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `title` varchar(30) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `groupid` int(10) unsigned NOT NULL,
  `content` text NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_card_notices_unread
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_card_notices_unread`;
CREATE TABLE `ims_mc_card_notices_unread` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `notice_id` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `is_new` tinyint(3) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`),
  KEY `notice_id` (`notice_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_card_recommend
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_card_recommend`;
CREATE TABLE `ims_mc_card_recommend` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `title` varchar(30) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `url` varchar(100) NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_card_record
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_card_record`;
CREATE TABLE `ims_mc_card_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `type` varchar(15) NOT NULL,
  `model` tinyint(3) unsigned NOT NULL,
  `fee` decimal(10,2) unsigned NOT NULL,
  `tag` varchar(10) NOT NULL,
  `note` varchar(255) NOT NULL,
  `remark` varchar(200) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_card_sign_record
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_card_sign_record`;
CREATE TABLE `ims_mc_card_sign_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `credit` int(10) unsigned NOT NULL,
  `is_grant` tinyint(3) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_cash_record
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_cash_record`;
CREATE TABLE `ims_mc_cash_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `clerk_id` int(10) unsigned NOT NULL,
  `store_id` int(10) unsigned NOT NULL,
  `clerk_type` tinyint(3) unsigned NOT NULL,
  `fee` decimal(10,2) unsigned NOT NULL,
  `final_fee` decimal(10,2) unsigned NOT NULL,
  `credit1` int(10) unsigned NOT NULL,
  `credit1_fee` decimal(10,2) unsigned NOT NULL,
  `credit2` decimal(10,2) unsigned NOT NULL,
  `cash` decimal(10,2) unsigned NOT NULL,
  `return_cash` decimal(10,2) unsigned NOT NULL,
  `final_cash` decimal(10,2) unsigned NOT NULL,
  `remark` varchar(255) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `trade_type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_chats_record
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_chats_record`;
CREATE TABLE `ims_mc_chats_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `flag` tinyint(3) unsigned NOT NULL,
  `openid` varchar(32) NOT NULL,
  `msgtype` varchar(15) NOT NULL,
  `content` varchar(10000) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`,`acid`),
  KEY `openid` (`openid`),
  KEY `createtime` (`createtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_credits_recharge
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_credits_recharge`;
CREATE TABLE `ims_mc_credits_recharge` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  `tid` varchar(64) NOT NULL,
  `transid` varchar(30) NOT NULL,
  `fee` varchar(10) NOT NULL,
  `type` varchar(15) NOT NULL,
  `tag` varchar(10) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `backtype` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid_uid` (`uniacid`,`uid`),
  KEY `idx_tid` (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_credits_record
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_credits_record`;
CREATE TABLE `ims_mc_credits_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `uniacid` int(11) NOT NULL,
  `credittype` varchar(10) NOT NULL,
  `num` decimal(10,2) NOT NULL,
  `operator` int(10) unsigned NOT NULL,
  `module` varchar(30) NOT NULL,
  `clerk_id` int(10) unsigned NOT NULL,
  `store_id` int(10) unsigned NOT NULL,
  `clerk_type` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `remark` varchar(200) NOT NULL,
  `real_uniacid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_fans_groups
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_fans_groups`;
CREATE TABLE `ims_mc_fans_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `groups` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_mc_fans_groups
-- ----------------------------
BEGIN;
INSERT INTO `ims_mc_fans_groups` VALUES (1, 2, 2, 'a:1:{i:2;a:3:{s:2:\"id\";i:2;s:4:\"name\";s:9:\"星标组\";s:5:\"count\";i:0;}}');
COMMIT;

-- ----------------------------
-- Table structure for ims_mc_fans_tag
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_fans_tag`;
CREATE TABLE `ims_mc_fans_tag` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `fanid` int(11) NOT NULL DEFAULT '0',
  `openid` varchar(50) NOT NULL,
  `subscribe` int(11) DEFAULT '0',
  `nickname` varchar(100) DEFAULT NULL,
  `sex` int(11) DEFAULT '0',
  `language` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `headimgurl` varchar(150) DEFAULT NULL,
  `subscribe_time` int(11) NOT NULL DEFAULT '0',
  `unionid` varchar(100) DEFAULT NULL,
  `remark` varchar(250) DEFAULT NULL,
  `groupid` varchar(100) DEFAULT NULL,
  `tagid_list` varchar(250) DEFAULT NULL,
  `subscribe_scene` varchar(100) DEFAULT NULL,
  `qr_scene_str` varchar(250) DEFAULT NULL,
  `qr_scene` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fanid` (`fanid`),
  KEY `openid` (`openid`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_mc_fans_tag
-- ----------------------------
BEGIN;
INSERT INTO `ims_mc_fans_tag` VALUES (1, 0, 0, 'oyIJkxKRA-1SNFQ7eGhk4vbNYs1I', 1, 'allen', 1, 'zh_CN', '悉尼', '新南威尔士', '澳大利亚', 'https://thirdwx.qlogo.cn/mmopen/PiajxSqBRaEJAtuqGaFq5icJtNost6J0BT4rAc1JYtfZPqpibMKiaOgXKZIsPUuNKVz08lb5guiay2ZGDwziaOcmfRtg/132', 1574852180, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
INSERT INTO `ims_mc_fans_tag` VALUES (2, 0, 0, 'oyIJkxEEw16OoqSZSe9tnkOqo6KI', 1, '李续', 1, 'zh_CN', '南阳', '河南', '中国', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWcgXic78daA8BhJxcvqEq9u1F4WBwNESwBrr2cfwialzzrMwD4GVdicxo0XFvJbSHxa9fmcjw0fBgzRFiambbqFH1Vg/132', 1574865943, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
INSERT INTO `ims_mc_fans_tag` VALUES (3, 0, 0, 'oyIJkxH0qd8vy0htHJKTB3ul6e5s', 1, '张大欢i', 2, 'zh_CN', '浦东新区', '上海', '中国', 'https://thirdwx.qlogo.cn/mmopen/ajNVdqHZLLDl2pIoicZhWHjFqsEQic5T59Rh1DGEpxibZtI8oaOhia8MRK97SRMDGoEnb6ic5eYTibARyWU27jlNUTiaQ/132', 1574907871, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
INSERT INTO `ims_mc_fans_tag` VALUES (4, 0, 0, 'oyIJkxLX68JtAeeGt6lnFmFj8tgY', 1, '周游', 1, 'zh_CN', '', '日内瓦', '瑞士', 'https://thirdwx.qlogo.cn/mmopen/Q3auHgzwzM6qmL6KUA6g1S50icC8yOSZANhGPtXfbetDgVjpeibictGialUdoOm1QOVfIkTKeibpj20bwUEjPmAFAicA/132', 1574910082, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
INSERT INTO `ims_mc_fans_tag` VALUES (5, 0, 0, 'oyIJkxD8muNpYh6c4TrVYK2YtcLs', 1, '乔鹏达', 1, 'zh_CN', '吉林', '吉林', '中国', 'https://thirdwx.qlogo.cn/mmopen/5tkFZyjZoYJU0l3G0r1cCW67I8rGiawzibHnVUCDIMxQ2g3ibicsMv6oPSFEicDibUictZzFdjPwlygMNZ3iavO9FpOSZUgesB8dqljF/132', 1574910090, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
INSERT INTO `ims_mc_fans_tag` VALUES (6, 0, 0, 'oyIJkxESZBGbNb1VyCREQvnt0O9A', 1, '月牙上的猫咪', 2, 'zh_CN', '朝阳', '北京', '中国', 'https://thirdwx.qlogo.cn/mmopen/PiajxSqBRaEK9wXnNXcDz0k1Q2ibibt0RStUnlRA61HBl2To3VQuN5gdIvsCkJ4DjibflODy7QNN5e32XwLB6kZyGg/132', 1574912467, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
INSERT INTO `ims_mc_fans_tag` VALUES (7, 0, 0, 'oyIJkxJwyyIILPi1tJulp5SiXcLY', 1, 'iyoung', 1, 'zh_CN', '静安', '上海', '中国', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWdqYhLCO119Oa2WxIHBPxTbmWTSlTTlicuFhV7hfcFIbAvib73u84V2FHiciblxL0XfCq0ngqQ83d33Pk51IlzVmGHz/132', 1574912960, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
INSERT INTO `ims_mc_fans_tag` VALUES (8, 0, 0, 'oyIJkxF6rfE8bHaemNpVa31sHmbA', 1, '德望物流夏国亮（工作用）', 1, 'zh_CN', '闵行', '上海', '中国', 'https://thirdwx.qlogo.cn/mmopen/FrdAUicrPIibd2sFIwU7Dvu3OXJ0nIDfKyor5B3pkE1VcyLBAVFYWa9LXLsMrtbVWey4Yess3KibtboS6v0B0a9VHUM1Y3xyAuk/132', 1574947676, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
INSERT INTO `ims_mc_fans_tag` VALUES (9, 0, 0, 'oyIJkxOydYgbafLdBlHRc6RBLPB8', 1, '鹄', 0, 'zh_CN', '', '', '', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWe52UHnTkoZzHwQgavZl1TMOKfPB0kGf9gEIkRkH3Hl9TB3NyvICuibwm0nuZECKNyvaN8EPuPDlZGdkbKKEeVpg/132', 1574948591, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
INSERT INTO `ims_mc_fans_tag` VALUES (10, 0, 0, 'oyIJkxPEZVHjjV7TM23qkYfut480', 1, '张靓', 1, 'zh_CN', '杭州', '浙江', '中国', 'https://thirdwx.qlogo.cn/mmopen/5tkFZyjZoYJU0l3G0r1cCSqzUCFeibTbOib0Z2NOpJnASZE09nzWZQicYricnriasUBr6UlgYAdYibtHcz2zwtHKibkDZLjz0Idhak9/132', 1575013716, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
INSERT INTO `ims_mc_fans_tag` VALUES (11, 0, 0, 'oyIJkxJVAyv7qk5FMzZnFPTx9ruM', 1, '李豌豆', 0, 'zh_CN', '', '', '百慕大', 'https://thirdwx.qlogo.cn/mmopen/ajNVdqHZLLDq99UqtQM4k1Od01teWpvVaqfziax9ia8xmxicC1NEicT70PJ4O8HGCTn9AIR2uA0dlfNZ6JMqwuHBdQ/132', 1575013970, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
INSERT INTO `ims_mc_fans_tag` VALUES (12, 0, 0, 'oyIJkxEwZegHiYnx-6At2gzylBAQ', 1, '韩宝音', 1, 'zh_CN', '朝阳', '北京', '中国', 'https://thirdwx.qlogo.cn/mmopen/oibkjzpUkPNwYvk2RNxLBM2uX8s2NrvhVOImAcbn7V7D1KAiaX3jibSicwsxCcJWLAbWvbAYaUPH5Q8fYqeyEJ7XiaRQ1aBvIwpEc/132', 1576998568, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
INSERT INTO `ims_mc_fans_tag` VALUES (13, 0, 0, 'oyIJkxJBo77bqleCI0cqpTVfUNPw', 1, '宋襄', 1, 'zh_CN', '朝阳', '北京', '中国', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWdqYhLCO119Oft9E7q6wrpefyjVjmPSN05pbrapdHgHyzTE8ncCQX4uklzuNOmcHDdiaR2ElYQX2SuI6fmhkA6SE/132', 1576998742, NULL, NULL, '0', 'N;', NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for ims_mc_fans_tag_mapping
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_fans_tag_mapping`;
CREATE TABLE `ims_mc_fans_tag_mapping` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fanid` int(11) unsigned NOT NULL,
  `tagid` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mapping` (`fanid`,`tagid`),
  KEY `fanid_index` (`fanid`),
  KEY `tagid_index` (`tagid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_groups
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_groups`;
CREATE TABLE `ims_mc_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `title` varchar(20) NOT NULL,
  `credit` int(10) unsigned NOT NULL,
  `isdefault` tinyint(4) NOT NULL,
  PRIMARY KEY (`groupid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_mc_groups
-- ----------------------------
BEGIN;
INSERT INTO `ims_mc_groups` VALUES (1, 1, '默认会员组', 0, 1);
INSERT INTO `ims_mc_groups` VALUES (2, 2, '默认会员组', 0, 1);
COMMIT;

-- ----------------------------
-- Table structure for ims_mc_handsel
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_handsel`;
CREATE TABLE `ims_mc_handsel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `touid` int(10) unsigned NOT NULL,
  `fromuid` varchar(32) NOT NULL,
  `module` varchar(30) NOT NULL,
  `sign` varchar(100) NOT NULL,
  `action` varchar(20) NOT NULL,
  `credit_value` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`touid`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_mapping_fans
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_mapping_fans`;
CREATE TABLE `ims_mc_mapping_fans` (
  `fanid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `acid` int(10) unsigned NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `groupid` varchar(60) NOT NULL,
  `salt` char(8) NOT NULL,
  `follow` tinyint(1) unsigned NOT NULL,
  `followtime` int(10) unsigned NOT NULL,
  `unfollowtime` int(10) unsigned NOT NULL,
  `tag` varchar(1000) NOT NULL,
  `updatetime` int(10) unsigned DEFAULT NULL,
  `unionid` varchar(64) NOT NULL,
  PRIMARY KEY (`fanid`),
  UNIQUE KEY `openid_2` (`openid`),
  KEY `acid` (`acid`),
  KEY `uniacid` (`uniacid`),
  KEY `nickname` (`nickname`),
  KEY `updatetime` (`updatetime`),
  KEY `uid` (`uid`),
  KEY `openid` (`openid`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_mc_mapping_fans
-- ----------------------------
BEGIN;
INSERT INTO `ims_mc_mapping_fans` VALUES (1, 2, 2, 1, 'oyIJkxCB9hYjLKccpLfH8JHuLGQY', 'The Rogue Assassin', '', 'Vfs2sUmS', 0, 1574843993, 1577271816, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4Q0I5aFlqTEtjY3BMZkg4Skh1TEdRWSI7czo4OiJuaWNrbmFtZSI7czoxODoiVGhlIFJvZ3VlIEFzc2Fzc2luIjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo5OiLkuInpl6jls6EiO3M6ODoicHJvdmluY2UiO3M6Njoi5rKz5Y2XIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzNzoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi93UXBBY0F0UkVXZnRCdXhpYWM0a1ZsVVpzQ0hzcVFEN2tJaWIyZWVJWGpPdlpWYVVoMmtUdktDUG9pY0NDOVBFeG9wTTdpYktvdWVuZVV6cEtSRnJONzRqaWJCbXdoNDBoZjlmMi8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ4NDM5OTM7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTM3OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdmdEJ1eGlhYzRrVmxVWnNDSHNxUUQ3a0lpYjJlZUlYak92WlZhVWgya1R2S0NQb2ljQ0M5UEV4b3BNN2liS291ZW5lVXpwS1JGck43NGppYkJtd2g0MGhmOWYyLzEzMiI7fQ==', 1577266289, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (2, 2, 2, 2, 'oyIJkxN12B-UAC92kuWMsCPUNpnk', '晴天', '', 'gJl6DFl9', 1, 1574851902, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4TjEyQi1VQUM5Mmt1V01zQ1BVTnBuayI7czo4OiJuaWNrbmFtZSI7czo2OiLmmbTlpKkiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjA6IiI7czo4OiJwcm92aW5jZSI7czo2OiLkuIrmtbciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMzOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdkcVloTENPMTE5T1RzM3VaZUg4bVlSR3E1d3JXZVNwVTJYUUlEYThyaWF0RHFuclZwU1U5N2YxRWtYNThYQ1NzYjBlTVcxWTRLeFVWZ2NMZWJIb3VQdEMvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc0ODUxOTAyO3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMzoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi93UXBBY0F0UkVXZHFZaExDTzExOU9UczN1WmVIOG1ZUkdxNXdyV2VTcFUyWFFJRGE4cmlhdERxbnJWcFNVOTdmMUVrWDU4WENTc2IwZU1XMVk0S3hVVmdjTGViSG91UHRDLzEzMiI7fQ==', 1577505138, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (17, 2, 2, 17, 'oyIJkxH01j6BKQ-ke9wR2OnsxyLc', '张文延', '', 'dp3y5La2', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEgwMWo2QktRLWtlOXdSMk9uc3h5TGMiO3M6ODoibmlja25hbWUiO3M6OToi5byg5paH5bu2IjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czoxMjoi5rWm5Lic5paw5Yy6IjtzOjg6InByb3ZpbmNlIjtzOjY6IuS4iua1tyI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzA6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUS3lFQmlhTUlKTjN6cG12d3J3c1BPeFZic2JKREZvRUtiWnlvd2sxWU8wcVVPUWpiaWEwWGtjRlp3aWI5SUptMkl2OEVWbWt5NTFudzJmUS8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMzA6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUS3lFQmlhTUlKTjN6cG12d3J3c1BPeFZic2JKREZvRUtiWnlvd2sxWU8wcVVPUWpiaWEwWGtjRlp3aWI5SUptMkl2OEVWbWt5NTFudzJmUS8xMzIiO30=', 1575810435, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (3, 2, 2, 3, 'oyIJkxKRA-1SNFQ7eGhk4vbNYs1I', 'allen', '', 'xEPrteV4', 1, 1574852180, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4S1JBLTFTTkZRN2VHaGs0dmJOWXMxSSI7czo4OiJuaWNrbmFtZSI7czo1OiJhbGxlbiI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi5oKJ5bC8IjtzOjg6InByb3ZpbmNlIjtzOjE1OiLmlrDljZflqIHlsJTlo6siO3M6NzoiY291bnRyeSI7czoxMjoi5r6z5aSn5Yip5LqaIjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyODoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9QaWFqeFNxQlJhRUpBdHVxR2FGcTVpY0p0Tm9zdDZKMEJUNHJBYzFKWXRmWlBxcGliTUtpYU9nWEtaSXNQVXVOS1Z6MDhsYjVndWlheTJaR0R3emlhT2NtZlJ0Zy8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ4NTIxODA7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI4OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL1BpYWp4U3FCUmFFSkF0dXFHYUZxNWljSnROb3N0NkowQlQ0ckFjMUpZdGZaUHFwaWJNS2lhT2dYS1pJc1BVdU5LVnowOGxiNWd1aWF5MlpHRHd6aWFPY21mUnRnLzEzMiI7fQ==', 1577520821, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (22, 2, 2, 22, 'oyIJkxDrUZlqAOTTwcSrNEuK5gb8', '', '', 'sDhedDz0', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreERyVVpscUFPVFR3Y1NyTkV1SzVnYjgiO3M6ODoibmlja25hbWUiO3M6MjI6IvCfjLDlpb3lkIPkuI3ov4fmoJflrZAiO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuaYjOW5syI7czo4OiJwcm92aW5jZSI7czo2OiLljJfkuqwiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI4OiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvRU9Zc2ljVGVYODYxSXRMeWQxZmQydWVUekNKN0xlc25tcEE0akZDSHBHRHBlVFczZHN5RGRDZ2FPZWxvTXRXMnZsOURlNjdJeHd1ZlRIM3NEWDdhYkFRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEyODoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0VPWXNpY1RlWDg2MUl0THlkMWZkMnVlVHpDSjdMZXNubXBBNGpGQ0hwR0RwZVRXM2RzeURkQ2dhT2Vsb010VzJ2bDlEZTY3SXh3dWZUSDNzRFg3YWJBUS8xMzIiO30=', 1576027280, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (4, 2, 2, 4, 'oyIJkxDMJqc166acwBef98LsxQTk', '橙子', '', 'AsnqNc11', 1, 1574864529, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RE1KcWMxNjZhY3dCZWY5OExzeFFUayI7czo4OiJuaWNrbmFtZSI7czo2OiLmqZnlrZAiO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuW8gOWwgSI7czo4OiJwcm92aW5jZSI7czo2OiLmsrPljZciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMzOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2c5blR2NFliRWtYRVl5Y3dzcGM1aWFlMkhmUkJ4WXJMQW9ON0MxRFAwR1dXVEkyejJiQzRTN3pidXFKcW9nQVRzeklLWjBqUmd2NElzSXFHckNmRjF3eVJoa20zMk1kUGwvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc0ODY0NTI5O3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMzoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9nOW5UdjRZYkVrWEVZeWN3c3BjNWlhZTJIZlJCeFlyTEFvTjdDMURQMEdXV1RJMnoyYkM0Uzd6YnVxSnFvZ0FUc3pJS1owalJndjRJc0lxR3JDZkYxd3lSaGttMzJNZFBsLzEzMiI7fQ==', 1575677198, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (5, 2, 2, 5, 'oyIJkxEEw16OoqSZSe9tnkOqo6KI', '李续', '', 'COJ6X7Uv', 1, 1574865943, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RUV3MTZPb3FTWlNlOXRua09xbzZLSSI7czo4OiJuaWNrbmFtZSI7czo2OiLmnY7nu60iO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuWNl+mYsyI7czo4OiJwcm92aW5jZSI7czo2OiLmsrPljZciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTM2OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdjZ1hpYzc4ZGFBOEJoSnhjdnFFcTl1MUY0V0J3TkVTd0JycjJjZndpYWx6enJNd0Q0R1ZkaWN4bzBYRnZKYlNIeGE5Zm1jancwZkJnelJGaWFtYmJxRkgxVmcvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc0ODY1OTQzO3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzNjoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi93UXBBY0F0UkVXY2dYaWM3OGRhQThCaEp4Y3ZxRXE5dTFGNFdCd05FU3dCcnIyY2Z3aWFsenpyTXdENEdWZGljeG8wWEZ2SmJTSHhhOWZtY2p3MGZCZ3pSRmlhbWJicUZIMVZnLzEzMiI7fQ==', 1576717983, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (6, 2, 2, 6, 'oyIJkxE4DfAf0heysu6Z_4xz4c4M', '甜甜', '', 'n9GsNgO3', 1, 1574867348, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RTREZkFmMGhleXN1NlpfNHh6NGM0TSI7czo4OiJuaWNrbmFtZSI7czo2OiLnlJznlJwiO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjk6IuW8oOWutuWPoyI7czo4OiJwcm92aW5jZSI7czo2OiLmsrPljJciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTM2OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2c5blR2NFliRWtYeHFJcVN1NDk1QXBaMlB0RlYweE01dWxpYXhBcWNhNmRpYzNUOGF2d2swdWlhcXNSdWpncXRNckFSRjJiVjlhYkFURGxDd1Z6Sm1DVXdyajBvaWFjRnVoc0UvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc0ODY3MzQ4O3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzNjoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9nOW5UdjRZYkVrWHhxSXFTdTQ5NUFwWjJQdEZWMHhNNXVsaWF4QXFjYTZkaWMzVDhhdndrMHVpYXFzUnVqZ3F0TXJBUkYyYlY5YWJBVERsQ3dWekptQ1V3cmowb2lhY0Z1aHNFLzEzMiI7fQ==', 1574866465, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (7, 2, 2, 7, 'oyIJkxH0qd8vy0htHJKTB3ul6e5s', '张大欢i', '', 'soTOP11O', 0, 1574907871, 1574907883, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4SDBxZDh2eTBodEhKS1RCM3VsNmU1cyI7czo4OiJuaWNrbmFtZSI7czoxMDoi5byg5aSn5qyiaSI7czozOiJzZXgiO2k6MjtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6MTI6Iua1puS4nOaWsOWMuiI7czo4OiJwcm92aW5jZSI7czo2OiLkuIrmtbciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI5OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2FqTlZkcUhaTExEbDJwSW9pY1poV0hqRnFzRVFpYzVUNTlSaDFER0VweGliWnRJOG9hT2hpYThNUks5N1NSTURHb0VuYjZpYzVlWVRpYkFSeVdVMjdqbE5VVGlhUS8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ5MDc4NzE7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI5OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2FqTlZkcUhaTExEbDJwSW9pY1poV0hqRnFzRVFpYzVUNTlSaDFER0VweGliWnRJOG9hT2hpYThNUks5N1NSTURHb0VuYjZpYzVlWVRpYkFSeVdVMjdqbE5VVGlhUS8xMzIiO30=', 1574907871, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (8, 2, 2, 8, 'oyIJkxLX68JtAeeGt6lnFmFj8tgY', '周游', '', 'zZmPM9A8', 1, 1576733637, 1576730277, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4TFg2OEp0QWVlR3Q2bG5GbUZqOHRnWSI7czo4OiJuaWNrbmFtZSI7czo2OiLlkajmuLgiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjA6IiI7czo4OiJwcm92aW5jZSI7czo5OiLml6XlhoXnk6YiO3M6NzoiY291bnRyeSI7czo2OiLnkZ7lo6siO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI4OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL1EzYXVIZ3p3ek02cW1MNktVQTZnMVM1MGljQzh5T1NaQU5oR1B0WGZiZXREZ1ZqcGVpYmljdEdpYWxVZG9PbTFRT1ZmSWtUS2VpYnBqMjBid1VFalBtQUZBaWNBLzEzMiI7czoxNDoic3Vic2NyaWJlX3RpbWUiO2k6MTU3NjczMzYzNztzOjc6Imdyb3VwaWQiO2k6MDtzOjEwOiJ0YWdpZF9saXN0IjthOjA6e31zOjY6ImF2YXRhciI7czoxMjg6Imh0dHBzOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vUTNhdUhnend6TTZxbUw2S1VBNmcxUzUwaWNDOHlPU1pBTmhHUHRYZmJldERnVmpwZWliaWN0R2lhbFVkb09tMVFPVmZJa1RLZWlicGoyMGJ3VUVqUG1BRkFpY0EvMTMyIjt9', 1574910087, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (9, 2, 2, 9, 'oyIJkxD8muNpYh6c4TrVYK2YtcLs', '乔鹏达', '', 'i2I2SHY9', 1, 1574910090, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RDhtdU5wWWg2YzRUclZZSzJZdGNMcyI7czo4OiJuaWNrbmFtZSI7czo5OiLkuZTpuY/ovr4iO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuWQieaelyI7czo4OiJwcm92aW5jZSI7czo2OiLlkInmnpciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTM4OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuLzV0a0ZaeWpab1lKVTBsM0cwcjFjQ1c2N0k4ckdpYXd6aWJIblZVQ0RJTXhRMmczaWJpY3NNdjZvUGZqZjlranNMYmRpY2FMM3FuZ3MxY2liNGpKcEV2ZGpyVDZxTFdBYUxRRVFrVy8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ5MTAwOTA7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTM4OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuLzV0a0ZaeWpab1lKVTBsM0cwcjFjQ1c2N0k4ckdpYXd6aWJIblZVQ0RJTXhRMmczaWJpY3NNdjZvUGZqZjlranNMYmRpY2FMM3FuZ3MxY2liNGpKcEV2ZGpyVDZxTFdBYUxRRVFrVy8xMzIiO30=', 1577421493, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (23, 2, 2, 23, 'oyIJkxC8MH55oRiEazaSsk6BejwM', '周月璞', '', 'zf9tpDsE', 1, 1576119182, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4QzhNSDU1b1JpRWF6YVNzazZCZWp3TSI7czo4OiJuaWNrbmFtZSI7czo5OiLlkajmnIjnkp4iO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuaZrumZgCI7czo4OiJwcm92aW5jZSI7czo2OiLkuIrmtbciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMyOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdkcVloTENPMTE5T1RaT2szSmVzWVE0Yk56MEtENXUwb3VwbmtOemRzZ3NyT0c3VlBhNFF0STY2YUJTVW9YdmpBT1M5UFg2VkVMb3VyMkdTbnRjU09aZi8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzYxMTkxODI7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTMyOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdkcVloTENPMTE5T1RaT2szSmVzWVE0Yk56MEtENXUwb3VwbmtOemRzZ3NyT0c3VlBhNFF0STY2YUJTVW9YdmpBT1M5UFg2VkVMb3VyMkdTbnRjU09aZi8xMzIiO30=', 1577528880, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (10, 2, 2, 10, 'oyIJkxESZBGbNb1VyCREQvnt0O9A', '月牙上的猫咪', '', 'ib1B3Pja', 1, 1574912467, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RVNaQkdiTmIxVnlDUkVRdm50ME85QSI7czo4OiJuaWNrbmFtZSI7czoxODoi5pyI54mZ5LiK55qE54yr5ZKqIjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLmnJ3pmLMiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyNToiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9hak5WZHFIWkxMQU5URmRVbUE5TDlXTkVXRlF2bzRTRHZNQTVsNlR0M2pwbHl3dE0zZVVEQURpYmp1ZThwRXpZMTlLaWJWYXFlaWNISVhjUHBJTDdZc21qdy8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzQ5MTI0Njc7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI1OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2FqTlZkcUhaTExBTlRGZFVtQTlMOVdORVdGUXZvNFNEdk1BNWw2VHQzanBseXd0TTNlVURBRGlianVlOHBFelkxOUtpYlZhcWVpY0hJWGNQcElMN1lzbWp3LzEzMiI7fQ==', 1577465376, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (11, 2, 2, 11, 'oyIJkxJwyyIILPi1tJulp5SiXcLY', 'iyoung', '', 'uzvmV5iI', 1, 1574912960, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4Snd5eUlJTFBpMXRKdWxwNVNpWGNMWSI7czo4OiJuaWNrbmFtZSI7czo2OiJpeW91bmciO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IumdmeWuiSI7czo4OiJwcm92aW5jZSI7czo2OiLkuIrmtbciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTM2OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdkcVloTENPMTE5T2EyV3hJSEJQeFRibVdUU2xUVGxpY3VGaFY3aGZjRkliQXZpYjczdTg0VjJGSGljaWJseEwwWGZDcTBuZ3FRODNkMzNQazUxSWx6Vm1HSHovMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc0OTEyOTYwO3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzNjoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi93UXBBY0F0UkVXZHFZaExDTzExOU9hMld4SUhCUHhUYm1XVFNsVFRsaWN1RmhWN2hmY0ZJYkF2aWI3M3U4NFYyRkhpY2libHhMMFhmQ3EwbmdxUTgzZDMzUGs1MUlselZtR0h6LzEzMiI7fQ==', 1575300290, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (12, 2, 2, 12, 'oyIJkxF6rfE8bHaemNpVa31sHmbA', '德望物流夏国亮（工作用）', '', 'F5xx051p', 1, 1574947676, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RjZyZkU4YkhhZW1OcFZhMzFzSG1iQSI7czo4OiJuaWNrbmFtZSI7czozNjoi5b635pyb54mp5rWB5aSP5Zu95Lqu77yI5bel5L2c55So77yJIjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLpl7XooYwiO3M6ODoicHJvdmluY2UiO3M6Njoi5LiK5rW3IjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzNToiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9GcmRBVWljclBJaWJkMnNGSXdVN0R2dTNPWEowbklEZkt5b3I1QjNwa0UxVmN5TEJBVkZZV2E5TFhMc01ydGJWV2V5NFllc3MzS2lidGJvUzZ2MEIwYTlWSFVNMVkzeHlBdWsvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc0OTQ3Njc2O3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzNToiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9GcmRBVWljclBJaWJkMnNGSXdVN0R2dTNPWEowbklEZkt5b3I1QjNwa0UxVmN5TEJBVkZZV2E5TFhMc01ydGJWV2V5NFllc3MzS2lidGJvUzZ2MEIwYTlWSFVNMVkzeHlBdWsvMTMyIjt9', 1574947683, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (13, 2, 2, 13, 'oyIJkxOydYgbafLdBlHRc6RBLPB8', '鹄', '', 'trWw7pzL', 1, 1574948591, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4T3lkWWdiYWZMZEJsSFJjNlJCTFBCOCI7czo4OiJuaWNrbmFtZSI7czozOiLpuYQiO3M6Mzoic2V4IjtpOjA7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjA6IiI7czo4OiJwcm92aW5jZSI7czowOiIiO3M6NzoiY291bnRyeSI7czowOiIiO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMzOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdlNTJVSG5Ua29aekh3UWdhdlpsMVRNT0tmUEIwa0dmOWdFSWtSa0gzSGw5VEIzTnl2SUN1aWJ3bTBudVpFQ0tOeXZhTjhFUHVQRGxaR2RrYktLRWVWcGcvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc0OTQ4NTkxO3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMzoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi93UXBBY0F0UkVXZTUyVUhuVGtvWnpId1FnYXZabDFUTU9LZlBCMGtHZjlnRUlrUmtIM0hsOVRCM055dklDdWlid20wbnVaRUNLTnl2YU44RVB1UERsWkdka2JLS0VlVnBnLzEzMiI7fQ==', 1576752241, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (14, 2, 2, 14, 'oyIJkxPEZVHjjV7TM23qkYfut480', '张靓', '', 'V7FU6e8F', 1, 1575013716, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4UEVaVkhqalY3VE0yM3FrWWZ1dDQ4MCI7czo4OiJuaWNrbmFtZSI7czo2OiLlvKDpnZMiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuadreW3niI7czo4OiJwcm92aW5jZSI7czo2OiLmtZnmsZ8iO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTM5OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuLzV0a0ZaeWpab1lKVTBsM0cwcjFjQ1NxelVDRmVpYlRiT2liMFoyTk9wSm5BU1pFMDlueldaUWljWXJpY25yaWFzVUJyNlVsZ1lBZFlpYnRIY3oyend0SEtpYmtEWkxqejBJZGhhazkvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc1MDEzNzE2O3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzOToiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi81dGtGWnlqWm9ZSlUwbDNHMHIxY0NTcXpVQ0ZlaWJUYk9pYjBaMk5PcEpuQVNaRTA5bnpXWlFpY1lyaWNucmlhc1VCcjZVbGdZQWRZaWJ0SGN6Mnp3dEhLaWJrRFpManowSWRoYWs5LzEzMiI7fQ==', 1575013722, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (15, 2, 2, 15, 'oyIJkxJVAyv7qk5FMzZnFPTx9ruM', '李豌豆', '', 'qLsaAoaA', 1, 1575013970, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4SlZBeXY3cWs1Rk16Wm5GUFR4OXJ1TSI7czo4OiJuaWNrbmFtZSI7czo5OiLmnY7osYzosYYiO3M6Mzoic2V4IjtpOjA7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjA6IiI7czo4OiJwcm92aW5jZSI7czowOiIiO3M6NzoiY291bnRyeSI7czo5OiLnmb7mhZXlpKciO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTI2OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2FqTlZkcUhaTExEcTk5VXF0UU00azFPZDAxdGVXcHZWYXFmemlheDlpYTh4bXhpY0MxTkVpY1Q3MFBKNE84SEdDVG45QUlSMnVBMGRsZk5aNkpNcXd1SEJkUS8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzUwMTM5NzA7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI2OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2FqTlZkcUhaTExEcTk5VXF0UU00azFPZDAxdGVXcHZWYXFmemlheDlpYTh4bXhpY0MxTkVpY1Q3MFBKNE84SEdDVG45QUlSMnVBMGRsZk5aNkpNcXd1SEJkUS8xMzIiO30=', 1575013974, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (16, 2, 2, 16, 'oyIJkxI5sNKQFTf26x_HMNibia1k', '毛玮', '', 'WYnLH999', 1, 1575172137, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4STVzTktRRlRmMjZ4X0hNTmliaWExayI7czo4OiJuaWNrbmFtZSI7czo2OiLmr5vnjq4iO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuadqOa1piI7czo4OiJwcm92aW5jZSI7czo2OiLkuIrmtbciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTIzOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2c5blR2NFliRWtWOVp3NDhGYWpYajY1NnJYY3RVejZhRVIwZE1MT2RMUGhjSGtSRUlsTnhBZ1V5bVkxMXA1TWxmeHpmOXpSRzJ2WmVSaGljUW1XSXJXZy8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzUxNzIxMzc7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTIzOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2c5blR2NFliRWtWOVp3NDhGYWpYajY1NnJYY3RVejZhRVIwZE1MT2RMUGhjSGtSRUlsTnhBZ1V5bVkxMXA1TWxmeHpmOXpSRzJ2WmVSaGljUW1XSXJXZy8xMzIiO30=', 1575625140, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (18, 2, 2, 18, 'oyIJkxCgS5sIIOHLREugdOEuBSGY', '维健乐商城客服~小维', '', 'yQCpzXs1', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreENnUzVzSUlPSExSRXVnZE9FdUJTR1kiO3M6ODoibmlja25hbWUiO3M6Mjg6Iue7tOWBpeS5kOWVhuWfjuWuouacjX7lsI/nu7QiO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjA6IiI7czo4OiJwcm92aW5jZSI7czowOiIiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMxOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvRTJFMDhpY1MxYzFPVUthZklveTc2RUZxQkR5bUY1TWlic3RRam40RjJiWE9UbmJPUFpQYkxGdEVpYUFQSTU5a0g5VnA2R1h4R0pIYkdHYU1pYVExZjlTdDNRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMToiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0UyRTA4aWNTMWMxT1VLYWZJb3k3NkVGcUJEeW1GNU1pYnN0UWpuNEYyYlhPVG5iT1BaUGJMRnRFaWFBUEk1OWtIOVZwNkdYeEdKSGJHR2FNaWFRMWY5U3QzUS8xMzIiO30=', 1575862377, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (19, 2, 2, 19, 'oyIJkxK5tBGzqZSKzxCF0AEBTUzQ', '火星糖葫芦', '', 'KfR66c34', 1, 1575974533, 1575878089, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4SzV0Qkd6cVpTS3p4Q0YwQUVCVFV6USI7czo4OiJuaWNrbmFtZSI7czoxNToi54Gr5pif57OW6JGr6IqmIjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6Njoi5LiK5rW3IjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzNToiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9NV25sd1RDYWpJRTI4WG5qVDdLUFpsdHVFR1ZCVW9ZMldqWVZOYm9zekRUcUZyRmVIQWlhNWJVZzRyYWljWDYwMjhuRnhyRXNaOVdEbmZJcHpmSmlibFlLZzNnanV1NUg3ZWYvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc1OTc0NTMzO3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzNToiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9NV25sd1RDYWpJRTI4WG5qVDdLUFpsdHVFR1ZCVW9ZMldqWVZOYm9zekRUcUZyRmVIQWlhNWJVZzRyYWljWDYwMjhuRnhyRXNaOVdEbmZJcHpmSmlibFlLZzNnanV1NUg3ZWYvMTMyIjt9', 1576978211, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (20, 2, 2, 20, 'oyIJkxGeZKWm9t1g0uYe3Dk_nY6A', '唐某人', '', 'aUVbv3mi', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEdlWktXbTl0MWcwdVllM0RrX25ZNkEiO3M6ODoibmlja25hbWUiO3M6OToi5ZSQ5p+Q5Lq6IjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLplb/lroEiO3M6ODoicHJvdmluY2UiO3M6Njoi5LiK5rW3IjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzNDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRLS2JuVzRDdFJFcVIyQmljNWEwS3NpY3pjMWliM1JXZ1RJWVFOQmljTDdyaE83ZWdpYkhHZE94bk5LUTlLaWJkQ3VDVHpMSE83cEpjUEhPaWJEdy8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMzQ6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUS0tiblc0Q3RSRXFSMkJpYzVhMEtzaWN6YzFpYjNSV2dUSVlRTkJpY0w3cmhPN2VnaWJIR2RPeG5OS1E5S2liZEN1Q1R6TEhPN3BKY1BIT2liRHcvMTMyIjt9', 1575878143, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (21, 2, 2, 21, 'oyIJkxI6uICnC7A9EgzH2kaR4CM8', '师董会 客服 刘婷', '', 'qzQ0sC2v', 1, 1575941086, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEk2dUlDbkM3QTlFZ3pIMmthUjRDTTgiO3M6ODoibmlja25hbWUiO3M6MjM6IuW4iOiRo+S8miDlrqLmnI0g5YiY5am3IjtzOjM6InNleCI7aTowO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6MDoiIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyOToiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL3JrUGxYNlQ0S0RtRTJDZkZYZGN2anB1VTRKOEN2aWFiT050U08xYmlhNFFLbkloSk9YUkZtdEo2QkFORmUyUDdYTnlndU1OaDVNaDl0b0JMQ0Q1OXdiV0EvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI5OiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvcmtQbFg2VDRLRG1FMkNmRlhkY3ZqcHVVNEo4Q3ZpYWJPTnRTTzFiaWE0UUtuSWhKT1hSRm10SjZCQU5GZTJQN1hOeWd1TU5oNU1oOXRvQkxDRDU5d2JXQS8xMzIiO30=', 1575941101, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (24, 2, 2, 24, 'oyIJkxOTYfOs8PQAHVhYe99g-DsM', '孟蓝蓝蓝蓝', '', 'ziQkhIr7', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreE9UWWZPczhQUUFIVmhZZTk5Zy1Ec00iO3M6ODoibmlja25hbWUiO3M6MTU6IuWtn+iTneiTneiTneiTnSI7czozOiJzZXgiO2k6MjtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi5aSn6L+eIjtzOjg6InByb3ZpbmNlIjtzOjY6Iui+veWugSI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzI6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUS3ZKaWFOYkVEMGlicFdpY3JwaWJUb1VGSElkNUNmaDdBVGF0bG95V2h6b3haaWFCVjVDYUhqdDczMnM5OTVOR0pkb1VSWnFnTTJJOXo4NllRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMjoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRLdkppYU5iRUQwaWJwV2ljcnBpYlRvVUZISWQ1Q2ZoN0FUYXRsb3lXaHpveFppYUJWNUNhSGp0NzMyczk5NU5HSmRvVVJacWdNMkk5ejg2WVEvMTMyIjt9', 1576755663, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (25, 2, 2, 25, 'oyIJkxPQUDLj2dj8NZeX58Hsxryk', '东方郁华', '', 'cDh8hY9P', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreFBRVURMajJkajhOWmVYNThIc3hyeWsiO3M6ODoibmlja25hbWUiO3M6MTI6IuS4nOaWuemDgeWNjiI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi6YOR5beeIjtzOjg6InByb3ZpbmNlIjtzOjY6Iuays+WNlyI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzY6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUTDRpYU5pY0NhTTl6Z29qNFFpY1BxS2dqSlRpY0wzSEdpYkEyM2FxWUUxQWhLaWJUOU9IR1IyVElVQkZpY1g5SDhYRWlibnZEZlZtTFZjaFRpYnhKUS8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMzY6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9RMGo0VHdHVGZUTDRpYU5pY0NhTTl6Z29qNFFpY1BxS2dqSlRpY0wzSEdpYkEyM2FxWUUxQWhLaWJUOU9IR1IyVElVQkZpY1g5SDhYRWlibnZEZlZtTFZjaFRpYnhKUS8xMzIiO30=', 1577173342, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (26, 2, 2, 26, 'oyIJkxN9wUEc84s7BEvYxK5EtXxw', 'rose', '', 'Ou2F33cJ', 1, 1576479983, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreE45d1VFYzg0czdCRXZZeEs1RXRYeHciO3M6ODoibmlja25hbWUiO3M6NDoicm9zZSI7czozOiJzZXgiO2k6MjtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi5b6Q5rGHIjtzOjg6InByb3ZpbmNlIjtzOjY6IuS4iua1tyI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzM6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9EWUFJT2dxODNlcE5WamVNb2liVlRHYUJ3MjZwdk1hd3p4bURyZG5Ic0ZmVm9nS2lhWDJjSGlhaDhDeEpueVl6WVhjdVJwNGljU2ljM0VxeUlSZnVmZWJpYzV3Zy8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMzM6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9EWUFJT2dxODNlcE5WamVNb2liVlRHYUJ3MjZwdk1hd3p4bURyZG5Ic0ZmVm9nS2lhWDJjSGlhaDhDeEpueVl6WVhjdVJwNGljU2ljM0VxeUlSZnVmZWJpYzV3Zy8xMzIiO30=', 1576479976, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (27, 2, 2, 27, 'oyIJkxAmTJK25_EsBwtoNfeckFgQ', '九哥', '', 'JoUULlPO', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEFtVEpLMjVfRXNCd3RvTmZlY2tGZ1EiO3M6ODoibmlja25hbWUiO3M6Njoi5Lmd5ZOlIjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLnhKbkvZwiO3M6ODoicHJvdmluY2UiO3M6Njoi5rKz5Y2XIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1JOSEJMN3Zwa3pwaWFMRFBpYjFUWmxnbXhMMlV0dGljOXV2RllSZTA5VVlkODFweHZrMHBzUDhuZXpvWGhtMjEyNTJtVjFXTW04RkQ4RzBCeEI0djR4WjZnLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1JOSEJMN3Zwa3pwaWFMRFBpYjFUWmxnbXhMMlV0dGljOXV2RllSZTA5VVlkODFweHZrMHBzUDhuZXpvWGhtMjEyNTJtVjFXTW04RkQ4RzBCeEI0djR4WjZnLzEzMiI7fQ==', 1576487471, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (28, 2, 2, 28, 'oyIJkxGeSDWUKzg5EcxLrG_wbm-s', 'Panda', '', 'Sjc1C19C', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEdlU0RXVUt6ZzVFY3hMckdfd2JtLXMiO3M6ODoibmlja25hbWUiO3M6NToiUGFuZGEiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjA6IiI7czo4OiJwcm92aW5jZSI7czowOiIiO3M6NzoiY291bnRyeSI7czo5OiLnmb7mhZXlpKciO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMwOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvUTBqNFR3R1RmVEpyQ3RhMEJ4bEg4cWZMWm9YeDhkc1FaUFZDbEtxd3B2dTVMbmFLMjlNcUd0cXhiRmlhVlNqWUJtaWJhaWJhdENIVG9aWTRhUE0zcHZaUkEvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTMwOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvUTBqNFR3R1RmVEpyQ3RhMEJ4bEg4cWZMWm9YeDhkc1FaUFZDbEtxd3B2dTVMbmFLMjlNcUd0cXhiRmlhVlNqWUJtaWJhaWJhdENIVG9aWTRhUE0zcHZaUkEvMTMyIjt9', 1576576554, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (29, 2, 2, 29, 'oyIJkxGOGWL9WHRKkW5PeRZN4uhQ', '大白', '', 'j31u5u5z', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEdPR1dMOVdIUktrVzVQZVJaTjR1aFEiO3M6ODoibmlja25hbWUiO3M6Njoi5aSn55m9IjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLmiJDpg70iO3M6ODoicHJvdmluY2UiO3M6Njoi5Zub5bedIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzNDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0lzUXdCRGx1R0g1YnNWSmliRHI1ZUlpY2ljVzNiWFkyWDN6SXlrb0ZxeFBJUkpnQTRpYWp4bUxuV2F6aWNGaWFGNk1GN0FSZ1poWjZWUnNHd2ZOQ2liaHh4RFkwUS8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMzQ6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9Jc1F3QkRsdUdINWJzVkppYkRyNWVJaWNpY1czYlhZMlgzekl5a29GcXhQSVJKZ0E0aWFqeG1MbldhemljRmlhRjZNRjdBUmdaaFo2VlJzR3dmTkNpYmh4eERZMFEvMTMyIjt9', 1576549659, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (30, 2, 2, 30, 'oyIJkxHbS8h882yHJX3HKPBiNxAM', '王彦昕', '', 'lo09X6o0', 1, 1576758266, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4SGJTOGg4ODJ5SEpYM0hLUEJpTnhBTSI7czo4OiJuaWNrbmFtZSI7czo5OiLnjovlvabmmJUiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuS4nOWfjiI7czo4OiJwcm92aW5jZSI7czo2OiLljJfkuqwiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMwOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL1EzYXVIZ3p3ek00cFJVcVRwOEdneWo3aWJkS1RjSmxpYWliZ2ljaWM0Ykx0aWJLSVNiVHlwQkp3amZSTkNMbThzRmo1OEgycVR2MUR6RlRLeTVVaWFOS2tJSmlhSlEvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc2NzU4MjY2O3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMDoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9RM2F1SGd6d3pNNHBSVXFUcDhHZ3lqN2liZEtUY0psaWFpYmdpY2ljNGJMdGliS0lTYlR5cEJKd2pmUk5DTG04c0ZqNThIMnFUdjFEekZUS3k1VWlhTktrSUppYUpRLzEzMiI7fQ==', 1576758521, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (31, 2, 2, 31, 'oyIJkxGhmim2MJe060lBsmnRcByc', '', '', 'eqJBk7Il', 1, 1576718075, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4R2htaW0yTUplMDYwbEJzbW5SY0J5YyI7czo4OiJuaWNrbmFtZSI7czoxODoi8J+QoPCfkKDwn5Cg6bG85YS/IjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLlrpzmmIwiO3M6ODoicHJvdmluY2UiO3M6Njoi5rmW5YyXIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzMzoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi81dGtGWnlqWm9ZSlUwbDNHMHIxY0NhZjNUV0llRzNYeHB6Mk9jaFRTRXNOTlNuSkRpYUdYWmVOZGpPSjRzSnFmaGMyamZzVWpNajNQbDBLQlluak93N2NINXhXSjFHQWQ3LzEzMiI7czoxNDoic3Vic2NyaWJlX3RpbWUiO2k6MTU3NjcxODA3NTtzOjc6Imdyb3VwaWQiO2k6MDtzOjEwOiJ0YWdpZF9saXN0IjthOjA6e31zOjY6ImF2YXRhciI7czoxMzM6Imh0dHBzOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vNXRrRlp5alpvWUpVMGwzRzByMWNDYWYzVFdJZUczWHhwejJPY2hUU0VzTk5TbkpEaWFHWFplTmRqT0o0c0pxZmhjMmpmc1VqTWozUGwwS0JZbmpPdzdjSDV4V0oxR0FkNy8xMzIiO30=', 1576726634, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (32, 2, 2, 32, 'oyIJkxFqe8qlSJ32tVCxWTJm7b_Q', '生活就是', '', 'Oy681Ax1', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEZxZThxbFNKMzJ0VkN4V1RKbTdiX1EiO3M6ODoibmlja25hbWUiO3M6MjU6IueUn+a0u+WwseaYr/CfkLflkozov5zmlrkiO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuatpuaxiSI7czo4OiJwcm92aW5jZSI7czo2OiLmuZbljJciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMzOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvMGljZzV3VFA4bGpNTzQ3ZGpoSmFwWWF4dW5KZXBkQVZEbzVaRGlhNGlhN1pkYkU0eFV2Qk12cTBEaWJOdW9zaWJ2WUhyS0hQQWJMWUdaNHZISlhmaWNOVWtocGcvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTMzOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvMGljZzV3VFA4bGpNTzQ3ZGpoSmFwWWF4dW5KZXBkQVZEbzVaRGlhNGlhN1pkYkU0eFV2Qk12cTBEaWJOdW9zaWJ2WUhyS0hQQWJMWUdaNHZISlhmaWNOVWtocGcvMTMyIjt9', 1576825836, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (33, 2, 2, 33, 'oyIJkxPTRQQQzbxQqN92ie9obzxM', '世纪保理客服', '', 'hSjy2rre', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreFBUUlFRUXpieFFxTjkyaWU5b2J6eE0iO3M6ODoibmlja25hbWUiO3M6MTg6IuS4lue6quS/neeQhuWuouacjSI7czozOiJzZXgiO2k6MjtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi6ZW/5pilIjtzOjg6InByb3ZpbmNlIjtzOjY6IuWQieaelyI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMjg6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi84eUg2U3lUSXg2RW1rbmRhZjZMUmJiRmd5eU54dmgyREg3aWFraG4wYVpKTk5DQ0NWRkdPR0NZcXp6YnZySWtGcjNzZk16YkV3M3htbDFNaE1ldW5aT2cvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTI4OiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvOHlINlN5VEl4NkVta25kYWY2TFJiYkZneXlOeHZoMkRIN2lha2huMGFaSk5OQ0NDVkZHT0dDWXF6emJ2cklrRnIzc2ZNemJFdzN4bWwxTWhNZXVuWk9nLzEzMiI7fQ==', 1577295623, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (34, 2, 2, 34, 'oyIJkxEwZegHiYnx-6At2gzylBAQ', '韩宝音', '', 't71PzMZ0', 1, 1576998568, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RXdaZWdIaVlueC02QXQyZ3p5bEJBUSI7czo4OiJuaWNrbmFtZSI7czo5OiLpn6nlrp3pn7MiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuacnemYsyI7czo4OiJwcm92aW5jZSI7czo2OiLljJfkuqwiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTM3OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL29pYmtqenBVa1BOd1l2azJSTnhMQk0ydVg4czJOcnZoVk9JbUFjYm43VjdEMUtBaWFYM2ppYlNpY3dzeENjSldMQWJXdmJBWWFVUEg1UThmWXFleUVKN1hpYVJRMWFCdkl3cEVjLzEzMiI7czoxNDoic3Vic2NyaWJlX3RpbWUiO2k6MTU3Njk5ODU2ODtzOjc6Imdyb3VwaWQiO2k6MDtzOjEwOiJ0YWdpZF9saXN0IjthOjA6e31zOjY6ImF2YXRhciI7czoxMzc6Imh0dHBzOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vb2lia2p6cFVrUE53WXZrMlJOeExCTTJ1WDhzMk5ydmhWT0ltQWNibjdWN0QxS0FpYVgzamliU2ljd3N4Q2NKV0xBYld2YkFZYVVQSDVROGZZcWV5RUo3WGlhUlExYUJ2SXdwRWMvMTMyIjt9', 1577336984, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (35, 2, 2, 35, 'oyIJkxJBo77bqleCI0cqpTVfUNPw', '宋襄', '', 'lX9SCJx1', 1, 1576998742, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4SkJvNzdicWxlQ0kwY3FwVFZmVU5QdyI7czo4OiJuaWNrbmFtZSI7czo2OiLlrovopYQiO3M6Mzoic2V4IjtpOjE7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6IuacnemYsyI7czo4OiJwcm92aW5jZSI7czo2OiLljJfkuqwiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMzOiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3dRcEFjQXRSRVdkcVloTENPMTE5T2Z0OUU3cTZ3cnBlZnlqVmptUFNOMDVwYnJhcGRIZ0h5elRFOG5jQ1FYNHVrbHp1Tk9tY0hEZGlhUjJFbFlRWDJTdUk2Zm1oa0E2U0UvMTMyIjtzOjE0OiJzdWJzY3JpYmVfdGltZSI7aToxNTc2OTk4NzQyO3M6NzoiZ3JvdXBpZCI7aTowO3M6MTA6InRhZ2lkX2xpc3QiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMzoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi93UXBBY0F0UkVXZHFZaExDTzExOU9mdDlFN3E2d3JwZWZ5alZqbVBTTjA1cGJyYXBkSGdIeXpURThuY0NRWDR1a2x6dU5PbWNIRGRpYVIyRWxZUVgyU3VJNmZtaGtBNlNFLzEzMiI7fQ==', 1576998742, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (36, 2, 2, 36, 'oyIJkxD2zxZZd1Yi3nNOV51mPGws', '悦悦', '', 'nV2qHEU3', 1, 1577059818, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RDJ6eFpaZDFZaTNuTk9WNTFtUEd3cyI7czo4OiJuaWNrbmFtZSI7czo2OiLmgqbmgqYiO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjk6Iuefs+WutuW6hCI7czo4OiJwcm92aW5jZSI7czo2OiLmsrPljJciO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTM1OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2c5blR2NFliRWtXMDJPSkI0OFJScXJqNHpMV0xFUmJGeTBONWZUa3ZXaWJiZ2FZUTRoUDUzRHNJQzI4SjFxaWN6aGd5bW5UdUZMVG1RdWg2WTR1V0luQklEb0RpYXFqRUVYUi8xMzIiO3M6MTQ6InN1YnNjcmliZV90aW1lIjtpOjE1NzcwNTk4MTg7czo3OiJncm91cGlkIjtpOjA7czoxMDoidGFnaWRfbGlzdCI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTM1OiJodHRwczovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL2c5blR2NFliRWtXMDJPSkI0OFJScXJqNHpMV0xFUmJGeTBONWZUa3ZXaWJiZ2FZUTRoUDUzRHNJQzI4SjFxaWN6aGd5bW5UdUZMVG1RdWg2WTR1V0luQklEb0RpYXFqRUVYUi8xMzIiO30=', 1577059786, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (37, 2, 2, 37, 'oyIJkxG093gnjRE-9oYqgc61qYbs', '中苋农业-杨聚辉', '', 'OFF7MFzM', 1, 1577060311, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4RzA5M2dualJFLTlvWXFnYzYxcVlicyI7czo4OiJuaWNrbmFtZSI7czoyMjoi5Lit6IuL5Yac5LiaLeadqOiBmui+iSI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6OToi55+z5a625bqEIjtzOjg6InByb3ZpbmNlIjtzOjY6Iuays+WMlyI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzg6Imh0dHBzOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vb2lia2p6cFVrUE54dDlCU0RBVWhRNlhjZ2ljTVNRQnBWcVdkcERhUzhwOWhtaWF4bHM3aWEwWnk2ZWtnVlVvTTRPd1Z4VFdrUFBhY3N0UnRsbWdpYm5xMUVmdEFpYzQ4MGNkckg2LzEzMiI7czoxNDoic3Vic2NyaWJlX3RpbWUiO2k6MTU3NzA2MDMxMTtzOjc6Imdyb3VwaWQiO2k6MDtzOjEwOiJ0YWdpZF9saXN0IjthOjA6e31zOjY6ImF2YXRhciI7czoxMzg6Imh0dHBzOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vb2lia2p6cFVrUE54dDlCU0RBVWhRNlhjZ2ljTVNRQnBWcVdkcERhUzhwOWhtaWF4bHM3aWEwWnk2ZWtnVlVvTTRPd1Z4VFdrUFBhY3N0UnRsbWdpYm5xMUVmdEFpYzQ4MGNkckg2LzEzMiI7fQ==', 1577060230, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (38, 2, 2, 38, 'oyIJkxMWAkO2VRTkAYRWZUtXGA1s', '入目三分', '', 'Kayje6uy', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreE1XQWtPMlZSVGtBWVJXWlV0WEdBMXMiO3M6ODoibmlja25hbWUiO3M6MTI6IuWFpeebruS4ieWIhiI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6MDoiIjtzOjg6InByb3ZpbmNlIjtzOjA6IiI7czo3OiJjb3VudHJ5IjtzOjY6IuWGsOWymyI7czoxMDoiaGVhZGltZ3VybCI7czoxMzQ6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9mdG1oeE9QYmMyWUFFY0xVczVTOThsdUh4TjNvWEVsbmhaQ2liNzlVN0JoeGZiSUlqaWJrSGlja2dka0c4U3JpY3R5cVdvZ3NEaWFuaWNFRGljQ1VCTklVcUxqZ3cvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTM0OiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvZnRtaHhPUGJjMllBRWNMVXM1Uzk4bHVIeE4zb1hFbG5oWkNpYjc5VTdCaHhmYklJamlia0hpY2tnZGtHOFNyaWN0eXFXb2dzRGlhbmljRURpY0NVQk5JVXFMamd3LzEzMiI7fQ==', 1577070596, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (39, 2, 2, 39, 'oyIJkxHhDeYdI7MKL7Oc41WKS56Y', '赵胖', '', 'eGPQQl0h', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEhoRGVZZEk3TUtMN09jNDFXS1M1NlkiO3M6ODoibmlja25hbWUiO3M6Njoi6LW16IOWIjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLmnJ3pmLMiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0RZQUlPZ3E4M2VvcThYOGpWSnRaU0t5bFlSMkx6NXduRHJReDBES1BVS1FHdkRvaE5Dbm5VUjNlZVNpYk80TFI3WkNGVFBtM0JSaWNObGJ0TzJpYlhTZEtRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0RZQUlPZ3E4M2VvcThYOGpWSnRaU0t5bFlSMkx6NXduRHJReDBES1BVS1FHdkRvaE5Dbm5VUjNlZVNpYk80TFI3WkNGVFBtM0JSaWNObGJ0TzJpYlhTZEtRLzEzMiI7fQ==', 1577175118, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (40, 2, 2, 40, 'oyIJkxKyPk9vbyPHIdZMLoi4BzaI', '张霞', '', 'x05hZEb5', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEt5UGs5dmJ5UEhJZFpNTG9pNEJ6YUkiO3M6ODoibmlja25hbWUiO3M6MTA6IuW8oOmcnvCfjpciO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjA6IiI7czo4OiJwcm92aW5jZSI7czoyNDoi5Y2O5aSP6ZKw6ZyW5LiH5Lq65Zui6ZifIjtzOjc6ImNvdW50cnkiO3M6MDoiIjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0RZQUlPZ3E4M2VwNkQzd1J4TXYwTWNTeWVPbzFBM2Q3b2RwNHp1U2tnYzN1TWljSk1pYmZ5TjhReWQyeW5wTzlKR0s4bDNINFk5RXNoa0hpYWd5N214STdRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0RZQUlPZ3E4M2VwNkQzd1J4TXYwTWNTeWVPbzFBM2Q3b2RwNHp1U2tnYzN1TWljSk1pYmZ5TjhReWQyeW5wTzlKR0s4bDNINFk5RXNoa0hpYWd5N214STdRLzEzMiI7fQ==', 1577175687, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (41, 2, 2, 41, 'oyIJkxHAGFVDcPiTZolus03y9nt4', 'Kevin王浩', '', 'kuU6at7X', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreEhBR0ZWRGNQaVRab2x1czAzeTludDQiO3M6ODoibmlja25hbWUiO3M6MTE6Iktldmlu546L5rWpIjtzOjM6InNleCI7aToxO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czowOiIiO3M6ODoicHJvdmluY2UiO3M6MDoiIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEyODoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyLzAxRFpWalFDNDNtZGVNZnFSdHQ3U3pIRFFkaG9UQVdNdXFISnNvRFkzbWlhSm1NQURub0lRNWhDY2tzY1pFTEk5NHpDRWo3Sm5qWWRJUFlTVUVTTEpPZy8xMzIiO3M6OToicHJpdmlsZWdlIjthOjA6e31zOjY6ImF2YXRhciI7czoxMjg6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi8wMURaVmpRQzQzbWRlTWZxUnR0N1N6SERRZGhvVEFXTXVxSEpzb0RZM21pYUptTUFEbm9JUTVoQ2Nrc2NaRUxJOTR6Q0VqN0puallkSVBZU1VFU0xKT2cvMTMyIjt9', 1577189543, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (42, 2, 2, 42, 'oyIJkxJGBPe7ctUhDlBrd6WBj3CE', '菲宝宝', '', 'yPv9MQOV', 1, 1577248376, 0, 'YToxMzp7czo5OiJzdWJzY3JpYmUiO2k6MTtzOjY6Im9wZW5pZCI7czoyODoib3lJSmt4SkdCUGU3Y3RVaERsQnJkNldCajNDRSI7czo4OiJuaWNrbmFtZSI7czoxNToi4piA6I+y5a6d5a6d4piAIjtzOjM6InNleCI7aToyO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLkuLDlj7AiO3M6ODoicHJvdmluY2UiO3M6Njoi5YyX5LqsIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzNjoiaHR0cHM6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi9nOW5UdjRZYkVrVzAyT0pCNDhSUnFpYTczY0llRGRSd2xIZGxob0RpYkFIYkR2RlU4ZmhPc0tuZnljcVNSa2liYWdhbExSVjlQSjZtdzVwdWVETGFXT2hmWmFrMTRSZTZpYlJELzEzMiI7czoxNDoic3Vic2NyaWJlX3RpbWUiO2k6MTU3NzI0ODM3NjtzOjc6Imdyb3VwaWQiO2k6MDtzOjEwOiJ0YWdpZF9saXN0IjthOjA6e31zOjY6ImF2YXRhciI7czoxMzY6Imh0dHBzOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vZzluVHY0WWJFa1cwMk9KQjQ4UlJxaWE3M2NJZURkUndsSGRsaG9EaWJBSGJEdkZVOGZoT3NLbmZ5Y3FTUmtpYmFnYWxMUlY5UEo2bXc1cHVlRExhV09oZlphazE0UmU2aWJSRC8xMzIiO30=', 1577248321, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (43, 2, 2, 43, 'oyIJkxCf1Kj9cjsqi54xaSKuwais', '捍卫梦想程捷', '', 'NRX8R98M', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreENmMUtqOWNqc3FpNTR4YVNLdXdhaXMiO3M6ODoibmlja25hbWUiO3M6MTg6IuaNjeWNq+aipuaDs+eoi+aNtyI7czozOiJzZXgiO2k6MTtzOjg6Imxhbmd1YWdlIjtzOjU6InpoX0NOIjtzOjQ6ImNpdHkiO3M6Njoi6I6x6IqcIjtzOjg6InByb3ZpbmNlIjtzOjY6IuWxseS4nCI7czo3OiJjb3VudHJ5IjtzOjY6IuS4reWbvSI7czoxMDoiaGVhZGltZ3VybCI7czoxMzU6Imh0dHA6Ly90aGlyZHd4LnFsb2dvLmNuL21tb3Blbi92aV8zMi9JaWJpYUpLV09zMUptcWQ4enZvdE91YWljWWlja1NqaWFqRk14akRwbk45SndRdTdpYlVLRU5Qd29rdnRrOHM0bGljZ1hTSGdwamRCODhpYm9RYW5rN0F5RWhzT3pRLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzNToiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL0lpYmlhSktXT3MxSm1xZDh6dm90T3VhaWNZaWNrU2ppYWpGTXhqRHBuTjlKd1F1N2liVUtFTlB3b2t2dGs4czRsaWNnWFNIZ3BqZEI4OGlib1Fhbms3QXlFaHNPelEvMTMyIjt9', 1577442052, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (44, 2, 2, 44, 'oyIJkxM2PN8YIYddNJYV26VD-9bU', '菲菲', '', 'cdz4dFNN', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreE0yUE44WUlZZGROSllWMjZWRC05YlUiO3M6ODoibmlja25hbWUiO3M6Njoi6I+y6I+yIjtzOjM6InNleCI7aTowO3M6ODoibGFuZ3VhZ2UiO3M6NToiemhfQ04iO3M6NDoiY2l0eSI7czo2OiLplb/mmKUiO3M6ODoicHJvdmluY2UiO3M6Njoi5ZCJ5p6XIjtzOjc6ImNvdW50cnkiO3M6Njoi5Lit5Zu9IjtzOjEwOiJoZWFkaW1ndXJsIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRMbGJKV3ZyRk9OSzlQOXM5aWIzZmlhdHRtQTI5bXVCR0pjcmVlMENaWnFBbWpyUng0Qm5GcEh0anQ3aWM1NkhFZGxDdUVTM0QxU1VLS2JBLzEzMiI7czo5OiJwcml2aWxlZ2UiO2E6MDp7fXM6NjoiYXZhdGFyIjtzOjEzMDoiaHR0cDovL3RoaXJkd3gucWxvZ28uY24vbW1vcGVuL3ZpXzMyL1EwajRUd0dUZlRMbGJKV3ZyRk9OSzlQOXM5aWIzZmlhdHRtQTI5bXVCR0pjcmVlMENaWnFBbWpyUng0Qm5GcEh0anQ3aWM1NkhFZGxDdUVTM0QxU1VLS2JBLzEzMiI7fQ==', 1577426341, '');
INSERT INTO `ims_mc_mapping_fans` VALUES (45, 2, 2, 45, 'oyIJkxCYqR-imehqQonoWatXQI4A', '鑫  玥', '', 'A4878M64', 0, 0, 0, 'YToxMDp7czo2OiJvcGVuaWQiO3M6Mjg6Im95SUpreENZcVItaW1laHFRb25vV2F0WFFJNEEiO3M6ODoibmlja25hbWUiO3M6ODoi6ZGrICDnjqUiO3M6Mzoic2V4IjtpOjI7czo4OiJsYW5ndWFnZSI7czo1OiJ6aF9DTiI7czo0OiJjaXR5IjtzOjY6Iua1juWNlyI7czo4OiJwcm92aW5jZSI7czo2OiLlsbHkuJwiO3M6NzoiY291bnRyeSI7czo2OiLkuK3lm70iO3M6MTA6ImhlYWRpbWd1cmwiO3M6MTMwOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvUTBqNFR3R1RmVExSckFZU0RnQ3F3NE9zYXF3dWVmUUt2b1RpY2dnMXlESHRQQTFQbTRpYVZ6YjNlT1l0QlpDd1VUcHdxMGdZaEtsYTFpYzdOTFloZ2VOZXcvMTMyIjtzOjk6InByaXZpbGVnZSI7YTowOnt9czo2OiJhdmF0YXIiO3M6MTMwOiJodHRwOi8vdGhpcmR3eC5xbG9nby5jbi9tbW9wZW4vdmlfMzIvUTBqNFR3R1RmVExSckFZU0RnQ3F3NE9zYXF3dWVmUUt2b1RpY2dnMXlESHRQQTFQbTRpYVZ6YjNlT1l0QlpDd1VUcHdxMGdZaEtsYTFpYzdOTFloZ2VOZXcvMTMyIjt9', 1577442090, '');
COMMIT;

-- ----------------------------
-- Table structure for ims_mc_mapping_ucenter
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_mapping_ucenter`;
CREATE TABLE `ims_mc_mapping_ucenter` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `centeruid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_mass_record
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_mass_record`;
CREATE TABLE `ims_mc_mass_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `groupname` varchar(50) NOT NULL,
  `fansnum` int(10) unsigned NOT NULL,
  `msgtype` varchar(10) NOT NULL,
  `content` varchar(10000) NOT NULL,
  `group` int(10) NOT NULL,
  `attach_id` int(10) unsigned NOT NULL,
  `media_id` varchar(100) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `cron_id` int(10) unsigned NOT NULL,
  `sendtime` int(10) unsigned NOT NULL,
  `finalsendtime` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `msg_id` varchar(50) NOT NULL,
  `msg_data_id` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`,`acid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_member_address
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_member_address`;
CREATE TABLE `ims_mc_member_address` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(50) unsigned NOT NULL,
  `username` varchar(20) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `zipcode` varchar(6) NOT NULL,
  `province` varchar(32) NOT NULL,
  `city` varchar(32) NOT NULL,
  `district` varchar(32) NOT NULL,
  `address` varchar(512) NOT NULL,
  `isdefault` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uinacid` (`uniacid`),
  KEY `idx_uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_member_fields
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_member_fields`;
CREATE TABLE `ims_mc_member_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `fieldid` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `available` tinyint(1) NOT NULL,
  `displayorder` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uniacid` (`uniacid`),
  KEY `idx_fieldid` (`fieldid`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_mc_member_fields
-- ----------------------------
BEGIN;
INSERT INTO `ims_mc_member_fields` VALUES (1, 2, 1, '真实姓名', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (2, 2, 2, '昵称', 1, 1);
INSERT INTO `ims_mc_member_fields` VALUES (3, 2, 3, '头像', 1, 1);
INSERT INTO `ims_mc_member_fields` VALUES (4, 2, 4, 'QQ号', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (5, 2, 5, '手机号码', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (6, 2, 6, 'VIP级别', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (7, 2, 7, '性别', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (8, 2, 8, '出生生日', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (9, 2, 9, '星座', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (10, 2, 10, '生肖', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (11, 2, 11, '固定电话', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (12, 2, 12, '证件号码', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (13, 2, 13, '学号', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (14, 2, 14, '班级', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (15, 2, 15, '邮寄地址', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (16, 2, 16, '邮编', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (17, 2, 17, '国籍', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (18, 2, 18, '居住地址', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (19, 2, 19, '毕业学校', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (20, 2, 20, '公司', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (21, 2, 21, '学历', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (22, 2, 22, '职业', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (23, 2, 23, '职位', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (24, 2, 24, '年收入', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (25, 2, 25, '情感状态', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (26, 2, 26, ' 交友目的', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (27, 2, 27, '血型', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (28, 2, 28, '身高', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (29, 2, 29, '体重', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (30, 2, 30, '支付宝帐号', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (31, 2, 31, 'MSN', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (32, 2, 32, '电子邮箱', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (33, 2, 33, '阿里旺旺', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (34, 2, 34, '主页', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (35, 2, 35, '自我介绍', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (36, 2, 36, '兴趣爱好', 1, 0);
INSERT INTO `ims_mc_member_fields` VALUES (37, 2, 37, '出生月份', 0, 0);
INSERT INTO `ims_mc_member_fields` VALUES (38, 2, 38, '出生日期', 0, 0);
INSERT INTO `ims_mc_member_fields` VALUES (39, 2, 39, '积分', 0, 0);
INSERT INTO `ims_mc_member_fields` VALUES (40, 2, 40, '余额', 0, 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_mc_member_property
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_member_property`;
CREATE TABLE `ims_mc_member_property` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `property` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mc_members
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_members`;
CREATE TABLE `ims_mc_members` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `mobile` varchar(18) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `salt` varchar(8) NOT NULL,
  `groupid` int(11) NOT NULL,
  `credit1` decimal(10,2) unsigned NOT NULL,
  `credit2` decimal(10,2) unsigned NOT NULL,
  `credit3` decimal(10,2) unsigned NOT NULL,
  `credit4` decimal(10,2) unsigned NOT NULL,
  `credit5` decimal(10,2) unsigned NOT NULL,
  `credit6` decimal(10,2) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `realname` varchar(10) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `vip` tinyint(3) unsigned NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `birthyear` smallint(6) unsigned NOT NULL,
  `birthmonth` tinyint(3) unsigned NOT NULL,
  `birthday` tinyint(3) unsigned NOT NULL,
  `constellation` varchar(10) NOT NULL,
  `zodiac` varchar(5) NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `idcard` varchar(30) NOT NULL,
  `studentid` varchar(50) NOT NULL,
  `grade` varchar(10) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `nationality` varchar(30) NOT NULL,
  `resideprovince` varchar(30) NOT NULL,
  `residecity` varchar(30) NOT NULL,
  `residedist` varchar(30) NOT NULL,
  `graduateschool` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `education` varchar(10) NOT NULL,
  `occupation` varchar(30) NOT NULL,
  `position` varchar(30) NOT NULL,
  `revenue` varchar(10) NOT NULL,
  `affectivestatus` varchar(30) NOT NULL,
  `lookingfor` varchar(255) NOT NULL,
  `bloodtype` varchar(5) NOT NULL,
  `height` varchar(5) NOT NULL,
  `weight` varchar(5) NOT NULL,
  `alipay` varchar(30) NOT NULL,
  `msn` varchar(30) NOT NULL,
  `taobao` varchar(30) NOT NULL,
  `site` varchar(30) NOT NULL,
  `bio` text NOT NULL,
  `interest` text NOT NULL,
  `pay_password` varchar(30) NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `groupid` (`groupid`),
  KEY `uniacid` (`uniacid`),
  KEY `email` (`email`),
  KEY `mobile` (`mobile`),
  KEY `createtime` (`createtime`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_mc_members
-- ----------------------------
BEGIN;
INSERT INTO `ims_mc_members` VALUES (1, 2, '', '21a4594e0238b2064885a62ee4022da8@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'Ph6SmlzK', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574841672, '', 'YOUSEESEEYOU', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWftBuxiac4kVlUZsCHsqQD7kIib2eeIXjOvZVaUh2kTvKCPoicCC9PExopM7ibKoueneUzpKRFrN74jibBmwh40hf9f2/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '河南省', '三门峡市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (2, 2, '', 'baed59514a0bbccbc378989edf99f413@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'f2BP323X', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574843590, '', '晴天', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWdqYhLCO119OTs3uZeH8mYRGq5wrWeSpU2XQIDa8riatDqnrVpSU97f1EkX58XCSsb0eMW1Y4KxUVgcLebHouPtC/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '上海省', '市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (3, 2, '', '559e9fcebd457af8a81c7542f775b11c@we7.cc', 'c292f0cd6454776170b410ec74948024', 'l2bzLnn9', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574852181, '', 'allen', 'https://thirdwx.qlogo.cn/mmopen/PiajxSqBRaEJAtuqGaFq5icJtNost6J0BT4rAc1JYtfZPqpibMKiaOgXKZIsPUuNKVz08lb5guiay2ZGDwziaOcmfRtg/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '澳大利亚', '新南威尔士省', '悉尼市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (4, 2, '', '1bbbe34a68cd980a436cdd939ff55120@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'Zf9O4KFI', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574859117, '', '橙子', 'https://thirdwx.qlogo.cn/mmopen/g9nTv4YbEkXEYycwspc5iae2HfRBxYrLAoN7C1DP0GWWTI2z2bC4S77l4MOibYEILbfkH90dyFckIHwJUmkW6icIfvWIUdJoWqK/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '河南省', '开封市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (5, 2, '', 'c3ade0649517c1e99fac3ae20f3d2185@we7.cc', 'ff001935f00a87f9a48f10f1f15da787', 'h0PX8yEx', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574865944, '', '李续', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWcgXic78daA8BhJxcvqEq9u1F4WBwNESwBrr2cfwialzzrMwD4GVdicxo0XFvJbSHxa9fmcjw0fBgzRFiambbqFH1Vg/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '河南省', '南阳市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (6, 2, '', '706b59ad00def72acf29c5021bb1579b@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'xglFhF0z', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574866465, '', '甜甜', 'https://thirdwx.qlogo.cn/mmopen/g9nTv4YbEkXxqIqSu495ApZ2PtFV0xM5uliaxAqca6dic3T8avwk0uiaqsRujgqtMrARF2bV9abATDlCwVzJmCUwrj0oiacFuhsE/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '河北省', '张家口市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (7, 2, '', 'fe488dd422720e3266867d76d5eb7260@we7.cc', '59e8f3b15e608f1ca1d75f328d33495b', 'xi2nfmmW', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574907871, '', '张大欢i', 'https://thirdwx.qlogo.cn/mmopen/ajNVdqHZLLDl2pIoicZhWHjFqsEQic5T59Rh1DGEpxibZtI8oaOhia8MRK97SRMDGoEnb6ic5eYTibARyWU27jlNUTiaQ/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '上海省', '浦东新区市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (8, 2, '', 'ce011704c6b07c2703c6f239e2870cd5@we7.cc', '593d97616659bea96aac09b1f0f7bc75', 'N9Qyz9el', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574910082, '', '周游', 'https://thirdwx.qlogo.cn/mmopen/Q3auHgzwzM6qmL6KUA6g1S50icC8yOSZANhGPtXfbetDgVjpeibictGialUdoOm1QOVfIkTKeibpj20bwUEjPmAFAicA/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '瑞士', '日内瓦省', '市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (9, 2, '', 'ad7af6b38f1bdda29363781d2eafcb64@we7.cc', '9c5036e0d00dd64c2f69144a4f55f46c', 'Z11VQH7q', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574910090, '', '乔鹏达', 'https://thirdwx.qlogo.cn/mmopen/5tkFZyjZoYJU0l3G0r1cCW67I8rGiawzibHnVUCDIMxQ2g3ibicsMv6oPSFEicDibUictZzFdjPwlygMNZ3iavO9FpOSZUgesB8dqljF/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '吉林省', '吉林市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (10, 2, '', '5be66b102800880aa6568e39e05dadb2@we7.cc', '8dc931bb126998d527bf2584248de622', 'f09V1d61', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574912467, '', '月牙上的猫咪', 'https://thirdwx.qlogo.cn/mmopen/PiajxSqBRaEK9wXnNXcDz0k1Q2ibibt0RStUnlRA61HBl2To3VQuN5gdIvsCkJ4DjibflODy7QNN5e32XwLB6kZyGg/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '北京省', '朝阳市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (11, 2, '', 'f0da89e16ded48f85ac7bbc7098b2474@we7.cc', 'eadcbe8bc990be656c4acde9b16c7571', 'uYix22F1', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574912960, '', 'iyoung', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWdqYhLCO119Oa2WxIHBPxTbmWTSlTTlicuFhV7hfcFIbAvib73u84V2FHiciblxL0XfCq0ngqQ83d33Pk51IlzVmGHz/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '上海省', '静安市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (12, 2, '', 'e5099cea5e335f5b3021aae89cc572bd@we7.cc', 'fe4c2cf68f9f8404c121b3d11668c992', 'q288V8jU', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574947676, '', '德望物流夏国亮（工作用）', 'https://thirdwx.qlogo.cn/mmopen/FrdAUicrPIibd2sFIwU7Dvu3OXJ0nIDfKyor5B3pkE1VcyLBAVFYWa9LXLsMrtbVWey4Yess3KibtboS6v0B0a9VHUM1Y3xyAuk/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '上海省', '闵行市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (13, 2, '', 'cb3a556b4b116d341f350e89475b9e8f@we7.cc', 'fce1839886b2623824d362daca978522', 'CogTSTg3', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1574948591, '', '鹄', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWe52UHnTkoZzHwQgavZl1TMOKfPB0kGf9gEIkRkH3Hl9TB3NyvICuibwm0nuZECKNyvaN8EPuPDlZGdkbKKEeVpg/132', '', 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '省', '市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (14, 2, '', '0422cbf5ceffc3e707edc5ea0f1cefde@we7.cc', 'd953b7a153ea8800db780e88d446a074', 'PLue5cDI', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1575013716, '', '张靓', 'https://thirdwx.qlogo.cn/mmopen/5tkFZyjZoYJU0l3G0r1cCSqzUCFeibTbOib0Z2NOpJnASZE09nzWZQicYricnriasUBr6UlgYAdYibtHcz2zwtHKibkDZLjz0Idhak9/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '浙江省', '杭州市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (15, 2, '', 'df1367b1ed73095d918c5eeba8caf8cd@we7.cc', '8498d41abcdae39ae6b199acc3b98cc7', 'saAUKlKa', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1575013970, '', '李豌豆', 'https://thirdwx.qlogo.cn/mmopen/ajNVdqHZLLDq99UqtQM4k1Od01teWpvVaqfziax9ia8xmxicC1NEicT70PJ4O8HGCTn9AIR2uA0dlfNZ6JMqwuHBdQ/132', '', 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '百慕大', '省', '市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (16, 2, '', 'e0c3fe85fa21be3019c9f626ab238b70@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'kYmms9A7', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1575172055, '', '毛玮', 'https://thirdwx.qlogo.cn/mmopen/g9nTv4YbEkV9Zw48FajXj656rXctUz6aER0dMLOdLPhcHkREIlNxAgUymY11p5Mlfxzf9zRG2vZeRhicQmWIrWg/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '上海省', '杨浦市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (17, 2, '', 'c4b2becfc842f033beec2f6a38d70584@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'A7b3HOQq', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1575810435, '', '张文延', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKyEBiaMIJN3zpmvwrwsPOxVbsbJDFoEKbZyowk1YO0qUOQjbia0XkcFZwib9IJm2Iv8EVmky51nw2fQ/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '上海省', '浦东新区市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (18, 2, '', 'cb5a9b8316185c73991f88b3b8e86579@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'sSbGsBsB', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1575862377, '', '维健乐商城客服~小维', 'http://thirdwx.qlogo.cn/mmopen/vi_32/E2E08icS1c1OUKafIoy76EFqBDymF5MibstQjn4F2bXOTnbOPZPbLFtEiaAPI59kH9Vp6GXxGJHbGGaMiaQ1f9St3Q/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '省', '市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (19, 2, '', '23dabb9a8ad0c67f17a3b7d1a919a9f0@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'G8PI8A8e', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1575877980, '', '火星糖葫芦', 'http://thirdwx.qlogo.cn/mmopen/vi_32/6OlFfArInlmYpyW4B0jX07xC9ZLYSWTevtnMNtKopkv5EoL45kpMsnzKHHxwzeZubd6aW30cBkPGNJYUA1XNrg/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '上海省', '市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (20, 2, '', '3270cc7b018bd3da9b52dd8dc1fd3490@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'zyGzpzG7', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1575878143, '', '唐某人', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKKbnW4CtREqR2Bic5a0Ksiczc1ib3RWgTIYQNBicL7rhO7egibHGdOxnNKQ9KibdCuCTzLHO7pJcPHOibDw/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '上海省', '长宁市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (21, 2, '', 'cc9ddbd3b435cef8b56a371773e11993@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'liNNZbp1', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1575935051, '', '师董会 客服 刘婷', 'http://thirdwx.qlogo.cn/mmopen/vi_32/rkPlX6T4KDmE2CfFXdcvjpuU4J8CviabONtSO1bia4QKnIhJOXRFmtJ6BANFe2P7XNyguMNh5Mh9toBLCD59wbWA/132', '', 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '省', '市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (22, 2, '', 'd3ba463b4591da25dc8d91ce86427a3b@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'BB666DiB', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576027280, '', '', 'http://thirdwx.qlogo.cn/mmopen/vi_32/EOYsicTeX861ItLyd1fd2ueTzCJ7LesnmpA4jFCHpGDpeTW3dsyDdCgaOeloMtW2vl9De67IxwufTH3sDX7abAQ/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '北京省', '昌平市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (23, 2, '', 'e7bee1b3ad34f551f7852a99ef35a337@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'wmCs8PNK', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576119155, '', '周月璞', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTL2T1fVJQYlslkYzKrEM4cuvNly2A7wSMtVvjgHknoAiaqKQxWpgKQILxa1RiaW1vgC46rs4icsamXIQ/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '上海省', '普陀市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (24, 2, '', '280674f32294d0b9840c4dc5f5e24c58@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'vf2y1I3O', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576312528, '', '孟蓝蓝蓝蓝', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKvJiaNbED0ibpWicrpibToUFHId5Cfh7ATatloyWhzoxZiaBV5CaHjt732s995NGJdoURZqgM2I9z86YQ/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '辽宁省', '大连市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (25, 2, '', '7a7853a92a06dcfba8f9334643bd90f7@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'EHUfw3Uh', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576467154, '', '东方郁华', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTL4iaNicCaM9zgoj4QicPqKgjJTicL3HGibA23aqYE1AhKibT9OHGR2TIUBFicX9H8XEibnvDfVmLVchTibxJQ/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '河南省', '郑州市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (26, 2, '', 'de6f9aee74a019fd3494d3ef4aa36b54@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'KeU67dUJ', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576479976, '', 'rose', 'http://thirdwx.qlogo.cn/mmopen/vi_32/DYAIOgq83epNVjeMoibVTGaBw26pvMawzxmDrdnHsFfVogKiaX2cHiah8CxJnyYzYXcuRp4icSic3EqyIRfufebic5wg/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '上海省', '徐汇市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (27, 2, '', '97b1473a5210dc0bab3f8385df9436d3@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'k2lE3tYW', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576487471, '', '九哥', 'http://thirdwx.qlogo.cn/mmopen/vi_32/RNHBL7vpkzpiaLDPib1TZlgmxL2Uttic9uvFYRe09UYd81pxvk0psP8nezoXhm21252mV1WMm8FD8G0BxB4v4xZ6g/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '河南省', '焦作市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (28, 2, '', '5f137865d6d19ab4f9e2350a9541b839@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'P76xRuhd', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576488501, '', 'Panda', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJrCta0BxlH8qfLZoXx8dsQZPVClKqwpvu5LnaK29MqGtqxbFiaVSjYBmibaibatCHToZY4aPM3pvZRA/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '百慕大', '省', '市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (29, 2, '', 'f2e721a12e8b817f1526c1ac591804c5@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'aTdJVId3', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576549617, '', '大白', 'http://thirdwx.qlogo.cn/mmopen/vi_32/IsQwBDluGH5bsVJibDr5eIicicW3bXY2X3zIykoFqxPIRJgA4iajxmLnWazicFiaF6MF7ARgZhZ6VRsGwfNCibhxxDY0Q/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '四川省', '成都市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (30, 2, '', 'a5c021282b0b8d3c5baa19e29157a603@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'ic54QpcC', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576647059, '', '王彦昕', 'https://thirdwx.qlogo.cn/mmopen/Q3auHgzwzM4pRUqTp8Ggyj7ibdKTcJliaibgicic4bLtibKISbTypBJwjfRNCLm8sFj58H2qTv1DzFTKy5UiaNKkIJiaJQ/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '北京省', '东城市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (31, 2, '', 'b4b7e0d3821bc3aa0acb644cdf96002e@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'fMb5QavI', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576718013, '', '鱼儿', 'https://thirdwx.qlogo.cn/mmopen/5tkFZyjZoYJU0l3G0r1cCaf3TWIeG3Xxpz2OchTSEsNNSnJDiaGXZeNdjOJ4sJqfhc2jfsUjMj3Pl0KBYnjOw7cH5xWJ1GAd7/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '湖北省', '宜昌市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (32, 2, '', 'a0681a88a907b8ab4660e417abd8fe77@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'esr2bPIl', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576743953, '', '生活就是', 'http://thirdwx.qlogo.cn/mmopen/vi_32/0icg5wTP8ljMO47djhJapYaxunJepdAVDo5ZDia4ia7ZdbE4xUvBMvq0DibNuosibvYHrKHPAbLYGZ4vHJXficNUkhpg/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '湖北省', '武汉市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (33, 2, '', '6fad9c07a515e2da82793d61a30f2a95@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'QmpT572X', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576840553, '', '世纪保理客服', 'http://thirdwx.qlogo.cn/mmopen/vi_32/8yH6SyTIx6Emkndaf6LRbbFgyyNxvh2DH7iakhn0aZJNNCCCVFGOGCYqzzbvrIkFrqmz2WuoZlKqyibOxfibMKaFA/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '吉林省', '长春市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (34, 2, '', 'cb935d5ee10b229e4dc6bb4f1cf67fc0@we7.cc', '580c938a8b6c869618d9f3470bee710b', 'Ha5llX7S', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576998569, '', '韩宝音', 'https://thirdwx.qlogo.cn/mmopen/oibkjzpUkPNwYvk2RNxLBM2uX8s2NrvhVOImAcbn7V7D1KAiaX3jibSicwsxCcJWLAbWvbAYaUPH5Q8fYqeyEJ7XiaRQ1aBvIwpEc/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '北京省', '朝阳市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (35, 2, '', 'f3b8a829c1eb8f5ebed123099742eb2b@we7.cc', '04dbf10b0a15e8bb94beb220d45aefd5', 'w2Gvj0h3', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1576998742, '', '宋襄', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWdqYhLCO119Oft9E7q6wrpefyjVjmPSN05pbrapdHgHyzTE8ncCQX4uklzuNOmcHDdiaR2ElYQX2SuI6fmhkA6SE/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '北京省', '朝阳市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (36, 2, '', 'd5159b2a6ed416c5909c61d212bd0483@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'Vt8kDzPh', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1577059786, '', '悦悦', 'https://thirdwx.qlogo.cn/mmopen/g9nTv4YbEkW02OJB48RRqrj4zLWLERbFy0N5fTkvWibbgaYQ4hP53DsIC28J1qiczhgymnTuFLTmQuh6Y4uWInBIDoDiaqjEEXR/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '河北省', '石家庄市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (37, 2, '', 'bcf050ba3b6e14da1835b2ab6b385b12@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'kPHdbbQ1', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1577060230, '', '中苋农业-杨聚辉', 'https://thirdwx.qlogo.cn/mmopen/oibkjzpUkPNxt9BSDAUhQ6XcgicMSQBpVqWdpDaS8p9hmiaxls7ia0Zy6ekgVUoM4OwVxTWkPPacstRtlmgibnq1EftAic480cdrH6/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '河北省', '石家庄市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (38, 2, '', '9dad6cbd46acd221d2b9df6ef9564662@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'vc8WNpP1', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1577070596, '', '入目三分', 'http://thirdwx.qlogo.cn/mmopen/vi_32/ftmhxOPbc2YAEcLUs5S98luHxN3oXElnhZCib79U7BhxfbIIjibkHickgdkG8SrictyqWogsDianicEDicCUBNIUqLjgw/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '冰岛', '省', '市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (39, 2, '', '933de318180694b0a81154e9952c6994@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'kqR5331Z', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1577175118, '', '赵胖', 'http://thirdwx.qlogo.cn/mmopen/vi_32/DYAIOgq83eoq8X8jVJtZSKylYR2Lz5wnDrQx0DKPUKQGvDohNCnnUR3eeSibO4LR7ZCFTPm3BRicNlbtO2ibXSdKQ/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '北京省', '朝阳市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (40, 2, '', '658c70c3f4e92bf18d6e7eea06ef8f28@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'QKqE2Z0b', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1577175687, '', '张霞', 'http://thirdwx.qlogo.cn/mmopen/vi_32/DYAIOgq83ep6D3wRxMv0McSyeOo1A3d7odp4zuSkgc3uMicJMibfyN8Qyd2ynpO9JGK8l3H4Y9EshkHiagy7mxI7Q/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '', '华夏钰霖万人团队省', '市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (41, 2, '', '7ba42c9db2602f1436b597438ffa35d8@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'RhUz37Ri', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1577189543, '', 'Kevin王浩', 'http://thirdwx.qlogo.cn/mmopen/vi_32/01DZVjQC43mdeMfqRtt7SzHDQdhoTAWMuqHJsoDY3miaJmMADnoIQ5hCckscZELI94zCEj7JnjYdIPYSUESLJOg/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '省', '市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (42, 2, '', 'f7e1c81c9d02f5b8b44b8c7116aa24f0@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'M1jSSjJH', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1577248321, '', '菲宝宝', 'https://thirdwx.qlogo.cn/mmopen/g9nTv4YbEkW02OJB48RRqia73cIeDdRwlHdlhoDibAHbDvFU8fhOsKnfycqSRkibagalLRV9PJ6mw5pueDLaWOhfZak14Re6ibRD/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '北京省', '丰台市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (43, 2, '', 'b21c68e795ea13ebae57bfcc39223c8b@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'lA24m4EF', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1577349667, '', '捍卫梦想程捷', 'http://thirdwx.qlogo.cn/mmopen/vi_32/IibiaJKWOs1Jmqd8zvotOuaicYickSjiajFMxjDpnN9JwQu7ibUKENPwokvtk8s4licgXSHgpjdB88iboQank7AyEhsOzQ/132', '', 0, 1, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '山东省', '莱芜市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (44, 2, '', 'be57c8df115cb02e2a0c71e31fd31864@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'uaG9VQQU', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1577421517, '', '菲菲', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLlbJWvrFONK9P9s9ib3fiattmA29muBGJcree0CZZqAmjrRx4BnFpHtjt7ic56HEdlCuES3D1SUKKbA/132', '', 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '吉林省', '长春市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `ims_mc_members` VALUES (45, 2, '', '36be1e440db9af7ab12c74e320c8a31c@we7.cc', '5c8a1326c4aff37929f38a36a511e65e', 'iRQl77Zq', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1577442090, '', '鑫  玥', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLRrAYSDgCqw4OsaqwuefQKvoTicgg1yDHtPA1Pm4iaVzb3eOYtBZCwUTpwq0gYhKla1ic7NLYhgeNew/132', '', 0, 2, 0, 0, 0, '', '', '', '', '', '', '', '', '中国', '山东省', '济南市', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
COMMIT;

-- ----------------------------
-- Table structure for ims_mc_oauth_fans
-- ----------------------------
DROP TABLE IF EXISTS `ims_mc_oauth_fans`;
CREATE TABLE `ims_mc_oauth_fans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `oauth_openid` varchar(50) NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_oauthopenid_acid` (`oauth_openid`,`acid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_menu_event
-- ----------------------------
DROP TABLE IF EXISTS `ims_menu_event`;
CREATE TABLE `ims_menu_event` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `keyword` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `picmd5` varchar(32) NOT NULL,
  `openid` varchar(128) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `picmd5` (`picmd5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_message_notice_log
-- ----------------------------
DROP TABLE IF EXISTS `ims_message_notice_log`;
CREATE TABLE `ims_message_notice_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` varchar(255) NOT NULL,
  `is_read` tinyint(3) NOT NULL,
  `uid` int(11) NOT NULL,
  `sign` varchar(22) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `status` tinyint(3) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_mobilenumber
-- ----------------------------
DROP TABLE IF EXISTS `ims_mobilenumber`;
CREATE TABLE `ims_mobilenumber` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(10) NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_modules
-- ----------------------------
DROP TABLE IF EXISTS `ims_modules`;
CREATE TABLE `ims_modules` (
  `mid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `version` varchar(15) NOT NULL,
  `ability` varchar(500) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `author` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `settings` tinyint(1) NOT NULL,
  `subscribes` varchar(500) NOT NULL,
  `handles` varchar(500) NOT NULL,
  `isrulefields` tinyint(1) NOT NULL,
  `issystem` tinyint(1) unsigned NOT NULL,
  `target` int(10) unsigned NOT NULL,
  `iscard` tinyint(3) unsigned NOT NULL,
  `permissions` varchar(5000) NOT NULL,
  `title_initial` varchar(1) NOT NULL,
  `wxapp_support` tinyint(1) NOT NULL,
  `app_support` tinyint(1) NOT NULL,
  `webapp_support` tinyint(1) NOT NULL DEFAULT '1',
  `welcome_support` int(2) NOT NULL,
  `oauth_type` tinyint(1) NOT NULL,
  `phoneapp_support` tinyint(1) NOT NULL,
  `account_support` tinyint(1) NOT NULL,
  `xzapp_support` tinyint(1) NOT NULL,
  `aliapp_support` tinyint(1) NOT NULL,
  `logo` varchar(250) NOT NULL,
  `baiduapp_support` tinyint(1) NOT NULL,
  `toutiaoapp_support` tinyint(1) NOT NULL,
  PRIMARY KEY (`mid`),
  KEY `idx_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_modules
-- ----------------------------
BEGIN;
INSERT INTO `ims_modules` VALUES (1, 'basic', 'system', '基本文字回复', '1.0', '和您进行简单对话', '一问一答得简单对话. 当访客的对话语句中包含指定关键字, 或对话语句完全等于特定关键字, 或符合某些特定的格式时. 系统自动应答设定好的回复内容.', 'WeEngine Team', 'http://www.we7.cc/', 0, '', '', 1, 1, 0, 0, '', '', 1, 2, 1, 0, 0, 0, 2, 0, 0, '', 0, 0);
INSERT INTO `ims_modules` VALUES (2, 'news', 'system', '基本混合图文回复', '1.0', '为你提供生动的图文资讯', '一问一答得简单对话, 但是回复内容包括图片文字等更生动的媒体内容. 当访客的对话语句中包含指定关键字, 或对话语句完全等于特定关键字, 或符合某些特定的格式时. 系统自动应答设定好的图文回复内容.', 'WeEngine Team', 'http://www.we7.cc/', 0, '', '', 1, 1, 0, 0, '', '', 1, 2, 1, 0, 0, 0, 2, 0, 0, '', 0, 0);
INSERT INTO `ims_modules` VALUES (3, 'music', 'system', '基本音乐回复', '1.0', '提供语音、音乐等音频类回复', '在回复规则中可选择具有语音、音乐等音频类的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝，实现一问一答得简单对话。', 'WeEngine Team', 'http://www.we7.cc/', 0, '', '', 1, 1, 0, 0, '', '', 1, 2, 1, 0, 0, 0, 2, 0, 0, '', 0, 0);
INSERT INTO `ims_modules` VALUES (4, 'userapi', 'system', '自定义接口回复', '1.1', '更方便的第三方接口设置', '自定义接口又称第三方接口，可以让开发者更方便的接入微擎系统，高效的与微信公众平台进行对接整合。', 'WeEngine Team', 'http://www.we7.cc/', 0, '', '', 1, 1, 0, 0, '', '', 1, 2, 1, 0, 0, 0, 2, 0, 0, '', 0, 0);
INSERT INTO `ims_modules` VALUES (5, 'recharge', 'system', '会员中心充值模块', '1.0', '提供会员充值功能', '', 'WeEngine Team', 'http://www.we7.cc/', 0, '', '', 0, 1, 0, 0, '', '', 1, 2, 1, 0, 0, 0, 2, 0, 0, '', 0, 0);
INSERT INTO `ims_modules` VALUES (6, 'custom', 'system', '多客服转接', '1.0.0', '用来接入腾讯的多客服系统', '', 'WeEngine Team', 'http://bbs.we7.cc', 0, 'a:0:{}', 'a:6:{i:0;s:5:\"image\";i:1;s:5:\"voice\";i:2;s:5:\"video\";i:3;s:8:\"location\";i:4;s:4:\"link\";i:5;s:4:\"text\";}', 1, 1, 0, 0, '', '', 1, 2, 1, 0, 0, 0, 2, 0, 0, '', 0, 0);
INSERT INTO `ims_modules` VALUES (7, 'images', 'system', '基本图片回复', '1.0', '提供图片回复', '在回复规则中可选择具有图片的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝图片。', 'WeEngine Team', 'http://www.we7.cc/', 0, '', '', 1, 1, 0, 0, '', '', 1, 2, 1, 0, 0, 0, 2, 0, 0, '', 0, 0);
INSERT INTO `ims_modules` VALUES (8, 'video', 'system', '基本视频回复', '1.0', '提供图片回复', '在回复规则中可选择具有视频的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝视频。', 'WeEngine Team', 'http://www.we7.cc/', 0, '', '', 1, 1, 0, 0, '', '', 1, 2, 1, 0, 0, 0, 2, 0, 0, '', 0, 0);
INSERT INTO `ims_modules` VALUES (9, 'voice', 'system', '基本语音回复', '1.0', '提供语音回复', '在回复规则中可选择具有语音的回复内容，并根据用户所设置的特定关键字精准的返回给粉丝语音。', 'WeEngine Team', 'http://www.we7.cc/', 0, '', '', 1, 1, 0, 0, '', '', 1, 2, 1, 0, 0, 0, 2, 0, 0, '', 0, 0);
INSERT INTO `ims_modules` VALUES (10, 'chats', 'system', '发送客服消息', '1.0', '公众号可以在粉丝最后发送消息的48小时内无限制发送消息', '', '易福网', 'http://www.m213.cn/', 0, '', '', 0, 1, 0, 0, '', '', 1, 2, 1, 0, 0, 0, 2, 0, 0, '', 0, 0);
INSERT INTO `ims_modules` VALUES (11, 'wxcard', 'system', '微信卡券回复', '1.0', '微信卡券回复', '微信卡券回复', 'WeEngine Team', 'http://www.m213.cn', 0, '', '', 1, 1, 0, 0, '', '', 1, 2, 1, 0, 0, 0, 2, 0, 0, '', 0, 0);
INSERT INTO `ims_modules` VALUES (12, 'store', 'business', '站内商城', '1.0', '站内商城', '站内商城', 'we7', '', 0, '', '', 0, 1, 0, 0, '', 'Z', 1, 2, 1, 0, 0, 0, 2, 0, 0, '', 0, 0);
INSERT INTO `ims_modules` VALUES (13, 'tiger_newhu', 'activity', '新-微信淘宝客', '6.0.35', '新-微信淘宝客', '新-微信淘宝客', '博雅科技QQ:1661316352', 'https://www.huzhan.com/ishop27106/code/', 1, 'a:2:{i:0;s:9:\"subscribe\";i:1;s:11:\"unsubscribe\";}', 'a:12:{i:0;s:5:\"image\";i:1;s:5:\"voice\";i:2;s:5:\"video\";i:3;s:10:\"shortvideo\";i:4;s:8:\"location\";i:5;s:4:\"link\";i:6;s:9:\"subscribe\";i:7;s:2:\"qr\";i:8;s:5:\"trace\";i:9;s:5:\"click\";i:10;s:14:\"merchant_order\";i:11;s:4:\"text\";}', 1, 0, 0, 0, 'a:0:{}', 'X', 1, 0, 1, 1, 1, 1, 2, 1, 1, 'addons/tiger_newhu/icon.jpg', 1, 1);
INSERT INTO `ims_modules` VALUES (14, 'tiger_wxdaili', 'activity', '微信淘宝客【代理系统】', '2.99.84', '微信淘宝客【代理系统】', '微信淘宝客【代理系统】', '创心团队', 'https://www.huzhan.com/ishop31919/code/', 1, 'a:0:{}', 'a:12:{i:0;s:5:\"image\";i:1;s:5:\"voice\";i:2;s:5:\"video\";i:3;s:10:\"shortvideo\";i:4;s:8:\"location\";i:5;s:4:\"link\";i:6;s:9:\"subscribe\";i:7;s:2:\"qr\";i:8;s:5:\"trace\";i:9;s:5:\"click\";i:10;s:14:\"merchant_order\";i:11;s:4:\"text\";}', 1, 0, 0, 0, 'a:0:{}', 'W', 1, 0, 1, 1, 1, 1, 2, 1, 1, 'addons/tiger_wxdaili/icon.jpg', 1, 1);
INSERT INTO `ims_modules` VALUES (15, 'tuike_jd', 'business', '推京客_京东优惠券', '1.1.19', '推京客_京东优惠券', '推京客_京东优惠券', '创心团队', 'http://https://www.huzhan.com/ishop31919/code/', 0, 'a:0:{}', 'a:12:{i:0;s:5:\"image\";i:1;s:5:\"voice\";i:2;s:5:\"video\";i:3;s:10:\"shortvideo\";i:4;s:8:\"location\";i:5;s:4:\"link\";i:6;s:9:\"subscribe\";i:7;s:2:\"qr\";i:8;s:5:\"trace\";i:9;s:5:\"click\";i:10;s:14:\"merchant_order\";i:11;s:4:\"text\";}', 0, 0, 0, 0, 'a:0:{}', 'T', 1, 0, 1, 1, 1, 1, 2, 1, 1, 'addons/tuike_jd/icon.jpg', 1, 1);
INSERT INTO `ims_modules` VALUES (16, 'tuike_pdd', 'business', '拼多多进宝', '1.2.91', '拼多多进宝', '拼多多进宝', '创心团队', 'https://www.huzhan.com/ishop31919/code/', 0, 'a:0:{}', 'a:12:{i:0;s:5:\"image\";i:1;s:5:\"voice\";i:2;s:5:\"video\";i:3;s:10:\"shortvideo\";i:4;s:8:\"location\";i:5;s:4:\"link\";i:6;s:9:\"subscribe\";i:7;s:2:\"qr\";i:8;s:5:\"trace\";i:9;s:5:\"click\";i:10;s:14:\"merchant_order\";i:11;s:4:\"text\";}', 0, 0, 0, 0, 'a:0:{}', 'P', 1, 0, 1, 1, 1, 1, 2, 1, 1, 'addons/tuike_pdd/icon.jpg', 1, 1);
COMMIT;

-- ----------------------------
-- Table structure for ims_modules_bindings
-- ----------------------------
DROP TABLE IF EXISTS `ims_modules_bindings`;
CREATE TABLE `ims_modules_bindings` (
  `eid` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(100) NOT NULL,
  `entry` varchar(30) NOT NULL,
  `call` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `do` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `direct` int(11) NOT NULL,
  `url` varchar(100) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `displayorder` tinyint(255) unsigned NOT NULL,
  `multilevel` tinyint(1) NOT NULL,
  `parent` varchar(50) NOT NULL,
  PRIMARY KEY (`eid`),
  KEY `idx_module` (`module`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_modules_bindings
-- ----------------------------
BEGIN;
INSERT INTO `ims_modules_bindings` VALUES (1, 'tiger_newhu', 'cover', '', '直播入口', 'live', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (2, 'tiger_newhu', 'cover', '', '积分排行榜', 'Ranking', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (3, 'tiger_newhu', 'cover', '', '我的积分', 'Records', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (4, 'tiger_newhu', 'cover', '', '积分商城', 'Goods', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (5, 'tiger_newhu', 'cover', '', '兑吧积分商城', 'Duibagoods', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (6, 'tiger_newhu', 'cover', '', '淘客商城', 'index', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (7, 'tiger_newhu', 'cover', '', '会员中心', 'member', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (8, 'tiger_newhu', 'cover', '', '晒单广场', 'sdindex', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (9, 'tiger_newhu', 'menu', '', '后台入口', 'index', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (10, 'tiger_wxdaili', 'cover', '', '搜索入口', 'search', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (11, 'tiger_wxdaili', 'cover', '', '代理选品库', 'xpk', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (12, 'tiger_wxdaili', 'cover', '', '代理申请入口', 'dlreg', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (13, 'tiger_wxdaili', 'cover', '', '新代理入口', 'user', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (14, 'tiger_wxdaili', 'menu', '', '提现审核', 'dltxsh', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (15, 'tiger_wxdaili', 'menu', '', '代理支付管理', 'order', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (16, 'tiger_wxdaili', 'menu', '', '代理管理', 'dlmember', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (17, 'tiger_wxdaili', 'menu', '', '加群管理', 'qungl', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (18, 'tiger_wxdaili', 'menu', '', '基础设置', 'dlset', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (19, 'tiger_wxdaili', 'menu', '', 'PC网站广告', 'ad', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (20, 'tiger_wxdaili', 'menu', '', '佣金结算记录', 'yjlog', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (21, 'tiger_wxdaili', 'menu', '', '手动结算', 'searchyj', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (22, 'tiger_wxdaili', 'menu', '', '拼多多PID管理', 'pddpidlist', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (23, 'tiger_wxdaili', 'menu', '', '京东推广位管理', 'jdpidlist', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (24, 'tiger_wxdaili', 'menu', '', '淘宝PID管理', 'tbpidlist', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (25, 'tiger_wxdaili', 'menu', '', '批量佣金管理', 'plyjlist', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (26, 'tiger_wxdaili', 'menu', '', '渠道ID管理', 'qudaoidlist', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (27, 'tiger_wxdaili', 'menu', '', '团长佣金管理', 'tzyjlist', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (28, 'tuike_jd', 'menu', '', '后台入口', 'set', '', 0, '', '', 0, 0, '');
INSERT INTO `ims_modules_bindings` VALUES (29, 'tuike_pdd', 'menu', '', '后台入口', 'set', '', 0, '', '', 0, 0, '');
COMMIT;

-- ----------------------------
-- Table structure for ims_modules_cloud
-- ----------------------------
DROP TABLE IF EXISTS `ims_modules_cloud`;
CREATE TABLE `ims_modules_cloud` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `title_initial` varchar(1) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `version` varchar(10) NOT NULL,
  `install_status` tinyint(4) NOT NULL,
  `account_support` tinyint(4) NOT NULL,
  `wxapp_support` tinyint(4) NOT NULL,
  `webapp_support` tinyint(4) NOT NULL,
  `phoneapp_support` tinyint(4) NOT NULL,
  `welcome_support` tinyint(4) NOT NULL,
  `main_module_name` varchar(50) NOT NULL,
  `main_module_logo` varchar(100) NOT NULL,
  `has_new_version` tinyint(1) NOT NULL,
  `has_new_branch` tinyint(1) NOT NULL,
  `is_ban` tinyint(4) NOT NULL,
  `lastupdatetime` int(11) NOT NULL,
  `xzapp_support` tinyint(1) NOT NULL,
  `cloud_id` int(11) NOT NULL,
  `aliapp_support` tinyint(1) NOT NULL,
  `baiduapp_support` tinyint(1) NOT NULL,
  `toutiaoapp_support` tinyint(1) NOT NULL,
  `buytime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `lastupdatetime` (`lastupdatetime`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_modules_ignore
-- ----------------------------
DROP TABLE IF EXISTS `ims_modules_ignore`;
CREATE TABLE `ims_modules_ignore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `version` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_modules_plugin
-- ----------------------------
DROP TABLE IF EXISTS `ims_modules_plugin`;
CREATE TABLE `ims_modules_plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `main_module` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `main_module` (`main_module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_modules_plugin_rank
-- ----------------------------
DROP TABLE IF EXISTS `ims_modules_plugin_rank`;
CREATE TABLE `ims_modules_plugin_rank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `plugin_name` varchar(200) NOT NULL,
  `main_module_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_modules_rank
-- ----------------------------
DROP TABLE IF EXISTS `ims_modules_rank`;
CREATE TABLE `ims_modules_rank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_name` varchar(100) NOT NULL,
  `uid` int(10) NOT NULL,
  `rank` int(10) NOT NULL,
  `uniacid` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module_name` (`module_name`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=241 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_modules_rank
-- ----------------------------
BEGIN;
INSERT INTO `ims_modules_rank` VALUES (1, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (2, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (3, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (4, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (5, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (6, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (7, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (8, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (9, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (10, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (11, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (12, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (13, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (14, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (15, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (16, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (17, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (18, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (19, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (20, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (21, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (22, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (23, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (24, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (25, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (26, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (27, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (28, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (29, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (30, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (31, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (32, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (33, 'tiger_newhu', 0, 3, 1);
INSERT INTO `ims_modules_rank` VALUES (34, 'tiger_wxdaili', 0, 2, 1);
INSERT INTO `ims_modules_rank` VALUES (35, 'tuike_jd', 0, 1, 1);
INSERT INTO `ims_modules_rank` VALUES (36, 'tuike_pdd', 0, 0, 1);
INSERT INTO `ims_modules_rank` VALUES (37, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (38, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (39, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (40, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (41, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (42, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (43, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (44, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (45, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (46, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (47, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (48, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (49, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (50, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (51, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (52, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (53, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (54, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (55, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (56, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (57, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (58, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (59, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (60, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (61, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (62, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (63, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (64, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (65, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (66, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (67, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (68, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (69, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (70, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (71, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (72, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (73, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (74, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (75, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (76, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (77, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (78, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (79, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (80, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (81, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (82, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (83, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (84, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (85, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (86, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (87, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (88, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (89, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (90, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (91, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (92, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (93, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (94, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (95, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (96, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (97, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (98, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (99, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (100, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (101, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (102, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (103, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (104, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (105, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (106, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (107, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (108, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (109, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (110, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (111, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (112, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (113, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (114, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (115, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (116, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (117, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (118, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (119, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (120, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (121, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (122, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (123, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (124, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (125, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (126, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (127, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (128, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (129, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (130, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (131, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (132, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (133, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (134, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (135, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (136, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (137, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (138, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (139, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (140, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (141, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (142, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (143, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (144, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (145, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (146, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (147, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (148, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (149, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (150, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (151, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (152, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (153, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (154, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (155, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (156, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (157, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (158, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (159, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (160, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (161, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (162, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (163, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (164, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (165, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (166, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (167, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (168, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (169, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (170, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (171, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (172, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (173, 'tiger_newhu', 0, 3, 1);
INSERT INTO `ims_modules_rank` VALUES (174, 'tiger_wxdaili', 0, 2, 1);
INSERT INTO `ims_modules_rank` VALUES (175, 'tuike_jd', 0, 1, 1);
INSERT INTO `ims_modules_rank` VALUES (176, 'tuike_pdd', 0, 0, 1);
INSERT INTO `ims_modules_rank` VALUES (177, 'tiger_newhu', 0, 3, 1);
INSERT INTO `ims_modules_rank` VALUES (178, 'tiger_wxdaili', 0, 2, 1);
INSERT INTO `ims_modules_rank` VALUES (179, 'tuike_jd', 0, 1, 1);
INSERT INTO `ims_modules_rank` VALUES (180, 'tuike_pdd', 0, 0, 1);
INSERT INTO `ims_modules_rank` VALUES (181, 'tiger_newhu', 0, 3, 1);
INSERT INTO `ims_modules_rank` VALUES (182, 'tiger_wxdaili', 0, 2, 1);
INSERT INTO `ims_modules_rank` VALUES (183, 'tuike_jd', 0, 1, 1);
INSERT INTO `ims_modules_rank` VALUES (184, 'tuike_pdd', 0, 0, 1);
INSERT INTO `ims_modules_rank` VALUES (185, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (186, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (187, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (188, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (189, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (190, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (191, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (192, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (193, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (194, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (195, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (196, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (197, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (198, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (199, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (200, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (201, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (202, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (203, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (204, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (205, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (206, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (207, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (208, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (209, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (210, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (211, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (212, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (213, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (214, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (215, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (216, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (217, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (218, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (219, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (220, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (221, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (222, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (223, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (224, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (225, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (226, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (227, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (228, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (229, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (230, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (231, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (232, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (233, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (234, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (235, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (236, 'tuike_pdd', 0, 0, 2);
INSERT INTO `ims_modules_rank` VALUES (237, 'tiger_newhu', 0, 3, 2);
INSERT INTO `ims_modules_rank` VALUES (238, 'tiger_wxdaili', 0, 2, 2);
INSERT INTO `ims_modules_rank` VALUES (239, 'tuike_jd', 0, 1, 2);
INSERT INTO `ims_modules_rank` VALUES (240, 'tuike_pdd', 0, 0, 2);
COMMIT;

-- ----------------------------
-- Table structure for ims_modules_recycle
-- ----------------------------
DROP TABLE IF EXISTS `ims_modules_recycle`;
CREATE TABLE `ims_modules_recycle` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `modulename` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `account_support` tinyint(1) NOT NULL,
  `wxapp_support` tinyint(1) NOT NULL,
  `welcome_support` tinyint(1) NOT NULL,
  `webapp_support` tinyint(1) NOT NULL,
  `phoneapp_support` tinyint(1) NOT NULL,
  `xzapp_support` tinyint(1) NOT NULL,
  `aliapp_support` tinyint(1) NOT NULL,
  `baiduapp_support` tinyint(1) NOT NULL,
  `toutiaoapp_support` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `modulename` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_music_reply
-- ----------------------------
DROP TABLE IF EXISTS `ims_music_reply`;
CREATE TABLE `ims_music_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `url` varchar(300) NOT NULL,
  `hqurl` varchar(300) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_news_reply
-- ----------------------------
DROP TABLE IF EXISTS `ims_news_reply`;
CREATE TABLE `ims_news_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `parent_id` int(10) NOT NULL,
  `title` varchar(50) NOT NULL,
  `author` varchar(64) NOT NULL,
  `description` varchar(255) NOT NULL,
  `thumb` varchar(500) NOT NULL,
  `content` mediumtext NOT NULL,
  `url` varchar(255) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `incontent` tinyint(1) NOT NULL,
  `createtime` int(10) NOT NULL,
  `media_id` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_phoneapp_versions
-- ----------------------------
DROP TABLE IF EXISTS `ims_phoneapp_versions`;
CREATE TABLE `ims_phoneapp_versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `version` varchar(20) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `modules` text,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `version` (`version`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_profile_fields
-- ----------------------------
DROP TABLE IF EXISTS `ims_profile_fields`;
CREATE TABLE `ims_profile_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field` varchar(255) NOT NULL,
  `available` tinyint(1) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `displayorder` smallint(6) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `unchangeable` tinyint(1) NOT NULL,
  `showinregister` tinyint(1) NOT NULL,
  `field_length` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_profile_fields
-- ----------------------------
BEGIN;
INSERT INTO `ims_profile_fields` VALUES (1, 'realname', 1, '真实姓名', '', 0, 1, 1, 1, 0);
INSERT INTO `ims_profile_fields` VALUES (2, 'nickname', 1, '昵称', '', 1, 1, 0, 1, 0);
INSERT INTO `ims_profile_fields` VALUES (3, 'avatar', 1, '头像', '', 1, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (4, 'qq', 1, 'QQ号', '', 0, 0, 0, 1, 0);
INSERT INTO `ims_profile_fields` VALUES (5, 'mobile', 1, '手机号码', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (6, 'vip', 1, 'VIP级别', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (7, 'gender', 1, '性别', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (8, 'birthyear', 1, '出生生日', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (9, 'constellation', 1, '星座', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (10, 'zodiac', 1, '生肖', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (11, 'telephone', 1, '固定电话', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (12, 'idcard', 1, '证件号码', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (13, 'studentid', 1, '学号', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (14, 'grade', 1, '班级', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (15, 'address', 1, '邮寄地址', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (16, 'zipcode', 1, '邮编', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (17, 'nationality', 1, '国籍', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (18, 'resideprovince', 1, '居住地址', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (19, 'graduateschool', 1, '毕业学校', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (20, 'company', 1, '公司', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (21, 'education', 1, '学历', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (22, 'occupation', 1, '职业', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (23, 'position', 1, '职位', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (24, 'revenue', 1, '年收入', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (25, 'affectivestatus', 1, '情感状态', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (26, 'lookingfor', 1, ' 交友目的', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (27, 'bloodtype', 1, '血型', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (28, 'height', 1, '身高', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (29, 'weight', 1, '体重', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (30, 'alipay', 1, '支付宝帐号', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (31, 'msn', 1, 'MSN', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (32, 'email', 1, '电子邮箱', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (33, 'taobao', 1, '阿里旺旺', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (34, 'site', 1, '主页', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (35, 'bio', 1, '自我介绍', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (36, 'interest', 1, '兴趣爱好', '', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (37, 'birthmonth', 0, '出生月份', '出生月份', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (38, 'birthday', 0, '出生日期', '出生日期', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (39, 'credit1', 0, '积分', '积分', 0, 0, 0, 0, 0);
INSERT INTO `ims_profile_fields` VALUES (40, 'credit2', 0, '余额', '余额', 0, 0, 0, 0, 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_qrcode
-- ----------------------------
DROP TABLE IF EXISTS `ims_qrcode`;
CREATE TABLE `ims_qrcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  `extra` int(10) unsigned NOT NULL,
  `qrcid` bigint(20) NOT NULL,
  `scene_str` varchar(64) NOT NULL,
  `name` varchar(50) NOT NULL,
  `keyword` varchar(100) NOT NULL,
  `model` tinyint(1) unsigned NOT NULL,
  `ticket` varchar(250) NOT NULL,
  `url` varchar(256) NOT NULL,
  `expire` int(10) unsigned NOT NULL,
  `subnum` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qrcid` (`qrcid`),
  KEY `uniacid` (`uniacid`),
  KEY `ticket` (`ticket`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_qrcode_stat
-- ----------------------------
DROP TABLE IF EXISTS `ims_qrcode_stat`;
CREATE TABLE `ims_qrcode_stat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `qid` int(10) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `qrcid` bigint(20) unsigned NOT NULL,
  `scene_str` varchar(64) NOT NULL,
  `name` varchar(50) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_rule
-- ----------------------------
DROP TABLE IF EXISTS `ims_rule`;
CREATE TABLE `ims_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `displayorder` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  `containtype` varchar(100) NOT NULL,
  `reply_type` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_rule
-- ----------------------------
BEGIN;
INSERT INTO `ims_rule` VALUES (1, 0, '城市天气', 'userapi', 255, 1, '', 0);
INSERT INTO `ims_rule` VALUES (2, 0, '百度百科', 'userapi', 255, 1, '', 0);
INSERT INTO `ims_rule` VALUES (3, 0, '即时翻译', 'userapi', 255, 1, '', 0);
INSERT INTO `ims_rule` VALUES (4, 0, '今日老黄历', 'userapi', 255, 1, '', 0);
INSERT INTO `ims_rule` VALUES (5, 0, '看新闻', 'userapi', 255, 1, '', 0);
INSERT INTO `ims_rule` VALUES (6, 0, '快递查询', 'userapi', 255, 1, '', 0);
INSERT INTO `ims_rule` VALUES (7, 1, '个人中心入口设置', 'cover', 0, 1, '', 0);
INSERT INTO `ims_rule` VALUES (8, 1, '微擎团队入口设置', 'cover', 0, 1, '', 0);
INSERT INTO `ims_rule` VALUES (9, 2, '老虎淘客规则说明', 'tiger_newhu', 0, 1, '', 0);
INSERT INTO `ims_rule` VALUES (10, 2, '老虎淘客口令说明', 'tiger_newhu', 0, 1, '', 0);
INSERT INTO `ims_rule` VALUES (11, 2, '老虎淘客口令说明2', 'tiger_newhu', 0, 1, '', 0);
INSERT INTO `ims_rule` VALUES (12, 2, '推客拼多多规则', 'tiger_newhu', 0, 1, '', 0);
INSERT INTO `ims_rule` VALUES (13, 2, '推客京东规则', 'tiger_newhu', 0, 1, '', 0);
INSERT INTO `ims_rule` VALUES (14, 2, '老虎公众号找产品', 'tiger_newhu', 0, 1, '', 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_rule_keyword
-- ----------------------------
DROP TABLE IF EXISTS `ims_rule_keyword`;
CREATE TABLE `ims_rule_keyword` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `module` varchar(50) NOT NULL,
  `content` varchar(255) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_content` (`content`),
  KEY `rid` (`rid`),
  KEY `idx_rid` (`rid`),
  KEY `idx_uniacid_type_content` (`uniacid`,`type`,`content`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_rule_keyword
-- ----------------------------
BEGIN;
INSERT INTO `ims_rule_keyword` VALUES (1, 1, 0, 'userapi', '^.+天气$', 3, 255, 1);
INSERT INTO `ims_rule_keyword` VALUES (2, 2, 0, 'userapi', '^百科.+$', 3, 255, 1);
INSERT INTO `ims_rule_keyword` VALUES (3, 2, 0, 'userapi', '^定义.+$', 3, 255, 1);
INSERT INTO `ims_rule_keyword` VALUES (4, 3, 0, 'userapi', '^@.+$', 3, 255, 1);
INSERT INTO `ims_rule_keyword` VALUES (5, 4, 0, 'userapi', '日历', 1, 255, 1);
INSERT INTO `ims_rule_keyword` VALUES (6, 4, 0, 'userapi', '万年历', 1, 255, 1);
INSERT INTO `ims_rule_keyword` VALUES (7, 4, 0, 'userapi', '黄历', 1, 255, 1);
INSERT INTO `ims_rule_keyword` VALUES (8, 4, 0, 'userapi', '几号', 1, 255, 1);
INSERT INTO `ims_rule_keyword` VALUES (9, 5, 0, 'userapi', '新闻', 1, 255, 1);
INSERT INTO `ims_rule_keyword` VALUES (10, 6, 0, 'userapi', '^(申通|圆通|中通|汇通|韵达|顺丰|EMS) *[a-z0-9]{1,}$', 3, 255, 1);
INSERT INTO `ims_rule_keyword` VALUES (11, 7, 1, 'cover', '个人中心', 1, 0, 1);
INSERT INTO `ims_rule_keyword` VALUES (12, 8, 1, 'cover', '首页', 1, 0, 1);
INSERT INTO `ims_rule_keyword` VALUES (13, 9, 2, 'tiger_newhu', 'http', 3, 0, 1);
INSERT INTO `ims_rule_keyword` VALUES (14, 10, 2, 'tiger_newhu', '￥', 3, 0, 1);
INSERT INTO `ims_rule_keyword` VALUES (15, 11, 2, 'tiger_newhu', '《', 3, 0, 1);
INSERT INTO `ims_rule_keyword` VALUES (16, 12, 2, 'tiger_newhu', 'yangkeduo.com', 3, 0, 1);
INSERT INTO `ims_rule_keyword` VALUES (17, 13, 2, 'tiger_newhu', 'jd.com', 3, 0, 1);
INSERT INTO `ims_rule_keyword` VALUES (18, 14, 2, 'tiger_newhu', '找', 3, 0, 1);
COMMIT;

-- ----------------------------
-- Table structure for ims_site_article
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_article`;
CREATE TABLE `ims_site_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `rid` int(10) unsigned NOT NULL,
  `kid` int(10) unsigned NOT NULL,
  `iscommend` tinyint(1) NOT NULL,
  `ishot` tinyint(1) unsigned NOT NULL,
  `pcate` int(10) unsigned NOT NULL,
  `ccate` int(10) unsigned NOT NULL,
  `template` varchar(300) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `incontent` tinyint(1) NOT NULL,
  `source` varchar(255) NOT NULL,
  `author` varchar(50) NOT NULL,
  `displayorder` int(10) unsigned NOT NULL,
  `linkurl` varchar(500) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `edittime` int(10) NOT NULL,
  `click` int(10) unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  `credit` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_iscommend` (`iscommend`),
  KEY `idx_ishot` (`ishot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_site_article_comment
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_article_comment`;
CREATE TABLE `ims_site_article_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `articleid` int(10) unsigned NOT NULL,
  `parentid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  `content` text,
  `is_read` tinyint(1) NOT NULL,
  `iscomment` tinyint(1) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `articleid` (`articleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_site_category
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_category`;
CREATE TABLE `ims_site_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `nid` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `parentid` int(10) unsigned NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL,
  `icon` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `styleid` int(10) unsigned NOT NULL,
  `linkurl` varchar(500) NOT NULL,
  `ishomepage` tinyint(1) NOT NULL,
  `icontype` tinyint(1) unsigned NOT NULL,
  `css` varchar(500) NOT NULL,
  `multiid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_site_multi
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_multi`;
CREATE TABLE `ims_site_multi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `title` varchar(30) NOT NULL,
  `styleid` int(10) unsigned NOT NULL,
  `site_info` text NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `bindhost` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `bindhost` (`bindhost`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_site_multi
-- ----------------------------
BEGIN;
INSERT INTO `ims_site_multi` VALUES (1, 1, '微擎团队', 1, '', 1, '');
INSERT INTO `ims_site_multi` VALUES (2, 2, '淘宝客', 2, '', 0, '');
COMMIT;

-- ----------------------------
-- Table structure for ims_site_nav
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_nav`;
CREATE TABLE `ims_site_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `multiid` int(10) unsigned NOT NULL,
  `section` tinyint(4) NOT NULL,
  `module` varchar(50) NOT NULL,
  `displayorder` smallint(5) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `position` tinyint(4) NOT NULL,
  `url` varchar(255) NOT NULL,
  `icon` varchar(500) NOT NULL,
  `css` varchar(1000) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  `categoryid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `multiid` (`multiid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_site_page
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_page`;
CREATE TABLE `ims_site_page` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `multiid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `params` longtext NOT NULL,
  `html` longtext NOT NULL,
  `multipage` longtext NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `goodnum` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `multiid` (`multiid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_site_slide
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_slide`;
CREATE TABLE `ims_site_slide` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `multiid` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `displayorder` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `multiid` (`multiid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_site_store_cash_log
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_store_cash_log`;
CREATE TABLE `ims_site_store_cash_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `founder_uid` int(10) NOT NULL,
  `number` char(30) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `create_time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `founder_uid` (`founder_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_site_store_cash_order
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_store_cash_order`;
CREATE TABLE `ims_site_store_cash_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `number` char(30) NOT NULL,
  `founder_uid` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `goods_id` int(10) NOT NULL,
  `order_amount` decimal(10,2) NOT NULL,
  `cash_log_id` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `create_time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `founder_uid` (`founder_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_site_store_create_account
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_store_create_account`;
CREATE TABLE `ims_site_store_create_account` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `uniacid` int(10) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `endtime` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_site_store_goods
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_store_goods`;
CREATE TABLE `ims_site_store_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL,
  `title` varchar(100) NOT NULL,
  `module` varchar(50) NOT NULL,
  `account_num` int(10) NOT NULL,
  `wxapp_num` int(10) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `unit` varchar(15) NOT NULL,
  `slide` varchar(1000) NOT NULL,
  `category_id` int(10) NOT NULL,
  `title_initial` varchar(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createtime` int(10) NOT NULL,
  `synopsis` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `module_group` int(10) NOT NULL,
  `api_num` int(10) NOT NULL,
  `user_group` int(10) NOT NULL,
  `user_group_price` varchar(1000) DEFAULT NULL,
  `account_group` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`module`),
  KEY `category_id` (`category_id`),
  KEY `price` (`price`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_site_store_order
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_store_order`;
CREATE TABLE `ims_site_store_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orderid` varchar(28) NOT NULL,
  `goodsid` int(10) NOT NULL,
  `duration` int(10) NOT NULL,
  `buyer` varchar(50) NOT NULL,
  `buyerid` int(10) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `changeprice` tinyint(1) NOT NULL,
  `createtime` int(10) NOT NULL,
  `uniacid` int(10) NOT NULL,
  `endtime` int(15) NOT NULL,
  `wxapp` int(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `goodid` (`goodsid`),
  KEY `buyerid` (`buyerid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_site_styles
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_styles`;
CREATE TABLE `ims_site_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `templateid` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_site_styles
-- ----------------------------
BEGIN;
INSERT INTO `ims_site_styles` VALUES (1, 1, 1, '微站默认模板_gC5C');
INSERT INTO `ims_site_styles` VALUES (2, 2, 1, '微站默认模板_lWbc');
COMMIT;

-- ----------------------------
-- Table structure for ims_site_styles_vars
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_styles_vars`;
CREATE TABLE `ims_site_styles_vars` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `templateid` int(10) unsigned NOT NULL,
  `styleid` int(10) unsigned NOT NULL,
  `variable` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `description` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_site_templates
-- ----------------------------
DROP TABLE IF EXISTS `ims_site_templates`;
CREATE TABLE `ims_site_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `title` varchar(30) NOT NULL,
  `version` varchar(64) NOT NULL,
  `description` varchar(500) NOT NULL,
  `author` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `sections` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_site_templates
-- ----------------------------
BEGIN;
INSERT INTO `ims_site_templates` VALUES (1, 'default', '微站默认模板', '', '由微擎提供默认微站模板套系', '易福团队', 'http://www.m213.cn', '1', 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_stat_fans
-- ----------------------------
DROP TABLE IF EXISTS `ims_stat_fans`;
CREATE TABLE `ims_stat_fans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `new` int(10) unsigned NOT NULL,
  `cancel` int(10) unsigned NOT NULL,
  `cumulate` int(10) NOT NULL,
  `date` varchar(8) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`,`date`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_stat_fans
-- ----------------------------
BEGIN;
INSERT INTO `ims_stat_fans` VALUES (1, 2, 0, 0, 0, '20191126');
INSERT INTO `ims_stat_fans` VALUES (2, 2, 0, 0, 0, '20191125');
INSERT INTO `ims_stat_fans` VALUES (3, 2, 0, 0, 0, '20191124');
INSERT INTO `ims_stat_fans` VALUES (4, 2, 0, 0, 0, '20191123');
INSERT INTO `ims_stat_fans` VALUES (5, 2, 0, 0, 0, '20191122');
INSERT INTO `ims_stat_fans` VALUES (6, 2, 0, 0, 0, '20191121');
INSERT INTO `ims_stat_fans` VALUES (7, 2, 0, 0, 0, '20191120');
INSERT INTO `ims_stat_fans` VALUES (8, 2, 6, 1, 0, '20191127');
INSERT INTO `ims_stat_fans` VALUES (9, 1, 0, 0, 0, '20191126');
INSERT INTO `ims_stat_fans` VALUES (10, 1, 0, 0, 0, '20191125');
INSERT INTO `ims_stat_fans` VALUES (11, 1, 0, 0, 0, '20191124');
INSERT INTO `ims_stat_fans` VALUES (12, 1, 0, 0, 0, '20191123');
INSERT INTO `ims_stat_fans` VALUES (13, 1, 0, 0, 0, '20191122');
INSERT INTO `ims_stat_fans` VALUES (14, 1, 0, 0, 0, '20191121');
INSERT INTO `ims_stat_fans` VALUES (15, 1, 0, 0, 0, '20191120');
INSERT INTO `ims_stat_fans` VALUES (16, 2, 7, 1, 0, '20191128');
INSERT INTO `ims_stat_fans` VALUES (17, 2, 2, 0, 0, '20191129');
INSERT INTO `ims_stat_fans` VALUES (18, 2, 1, 0, 0, '20191201');
INSERT INTO `ims_stat_fans` VALUES (19, 2, 0, 0, 0, '20191207');
INSERT INTO `ims_stat_fans` VALUES (20, 2, 0, 0, 0, '20191206');
INSERT INTO `ims_stat_fans` VALUES (21, 2, 0, 0, 0, '20191205');
INSERT INTO `ims_stat_fans` VALUES (22, 2, 0, 0, 0, '20191204');
INSERT INTO `ims_stat_fans` VALUES (23, 2, 0, 0, 0, '20191203');
INSERT INTO `ims_stat_fans` VALUES (24, 2, 0, 0, 0, '20191202');
INSERT INTO `ims_stat_fans` VALUES (25, 2, 1, 0, 0, '20191208');
INSERT INTO `ims_stat_fans` VALUES (26, 2, 1, 1, 0, '20191209');
INSERT INTO `ims_stat_fans` VALUES (27, 2, 2, 0, 0, '20191210');
INSERT INTO `ims_stat_fans` VALUES (28, 2, 0, 0, 0, '20191211');
INSERT INTO `ims_stat_fans` VALUES (29, 2, 1, 0, 0, '20191212');
INSERT INTO `ims_stat_fans` VALUES (30, 1, 0, 0, 0, '20191211');
INSERT INTO `ims_stat_fans` VALUES (31, 1, 0, 0, 0, '20191210');
INSERT INTO `ims_stat_fans` VALUES (32, 1, 0, 0, 0, '20191209');
INSERT INTO `ims_stat_fans` VALUES (33, 1, 0, 0, 0, '20191208');
INSERT INTO `ims_stat_fans` VALUES (34, 1, 0, 0, 0, '20191207');
INSERT INTO `ims_stat_fans` VALUES (35, 1, 0, 0, 0, '20191206');
INSERT INTO `ims_stat_fans` VALUES (36, 1, 0, 0, 0, '20191205');
INSERT INTO `ims_stat_fans` VALUES (37, 2, 1, 0, 0, '20191216');
INSERT INTO `ims_stat_fans` VALUES (38, 2, 0, 0, 0, '20191217');
INSERT INTO `ims_stat_fans` VALUES (39, 2, 0, 0, 0, '20191215');
INSERT INTO `ims_stat_fans` VALUES (40, 2, 0, 0, 0, '20191214');
INSERT INTO `ims_stat_fans` VALUES (41, 2, 0, 0, 0, '20191213');
INSERT INTO `ims_stat_fans` VALUES (42, 2, 3, 1, 0, '20191219');
INSERT INTO `ims_stat_fans` VALUES (43, 2, 2, 0, 0, '20191222');
INSERT INTO `ims_stat_fans` VALUES (44, 2, 2, 0, 0, '20191223');
INSERT INTO `ims_stat_fans` VALUES (45, 2, 1, 1, 0, '20191225');
COMMIT;

-- ----------------------------
-- Table structure for ims_stat_keyword
-- ----------------------------
DROP TABLE IF EXISTS `ims_stat_keyword`;
CREATE TABLE `ims_stat_keyword` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `rid` varchar(10) NOT NULL,
  `kid` int(10) unsigned NOT NULL,
  `hit` int(10) unsigned NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_stat_msg_history
-- ----------------------------
DROP TABLE IF EXISTS `ims_stat_msg_history`;
CREATE TABLE `ims_stat_msg_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `rid` int(10) unsigned NOT NULL,
  `kid` int(10) unsigned NOT NULL,
  `from_user` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `type` varchar(10) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_createtime` (`createtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_stat_rule
-- ----------------------------
DROP TABLE IF EXISTS `ims_stat_rule`;
CREATE TABLE `ims_stat_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `rid` int(10) unsigned NOT NULL,
  `hit` int(10) unsigned NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_createtime` (`createtime`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_stat_visit
-- ----------------------------
DROP TABLE IF EXISTS `ims_stat_visit`;
CREATE TABLE `ims_stat_visit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `module` varchar(100) NOT NULL,
  `count` int(10) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  `ip_count` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `module` (`module`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_stat_visit
-- ----------------------------
BEGIN;
INSERT INTO `ims_stat_visit` VALUES (1, 0, '', 110, 20191127, 'web', 2);
INSERT INTO `ims_stat_visit` VALUES (2, 2, 'we7_api', 49, 20191127, 'app', 4);
INSERT INTO `ims_stat_visit` VALUES (3, 2, 'we7_account', 86, 20191127, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (4, 2, '', 198, 20191127, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (5, 2, 'tiger_newhu', 284, 20191127, 'app', 8);
INSERT INTO `ims_stat_visit` VALUES (6, 2, 'tuike_jd', 23, 20191127, 'app', 1);
INSERT INTO `ims_stat_visit` VALUES (7, 2, 'tuike_pdd', 5, 20191127, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (8, 1, 'we7_account', 8, 20191127, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (9, 1, '', 42, 20191127, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (10, 2, 'tiger_wxdaili', 3, 20191127, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (11, 2, 'we7_api', 36, 20191128, 'app', 4);
INSERT INTO `ims_stat_visit` VALUES (12, 2, 'tiger_newhu', 203, 20191128, 'app', 7);
INSERT INTO `ims_stat_visit` VALUES (13, 2, '', 74, 20191128, 'web', 1);
INSERT INTO `ims_stat_visit` VALUES (14, 2, 'we7_account', 38, 20191128, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (15, 2, 'tuike_jd', 10, 20191128, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (16, 2, 'tuike_pdd', 4, 20191128, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (17, 0, '', 3, 20191128, 'web', 2);
INSERT INTO `ims_stat_visit` VALUES (18, 2, 'tiger_wxdaili', 4, 20191128, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (19, 2, 'tiger_newhu', 46, 20191129, 'app', 10);
INSERT INTO `ims_stat_visit` VALUES (20, 2, 'we7_api', 11, 20191129, 'app', 3);
INSERT INTO `ims_stat_visit` VALUES (21, 2, '', 2, 20191129, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (22, 2, 'tuike_jd', 8, 20191129, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (23, 2, 'tiger_newhu', 2, 20191130, 'app', 1);
INSERT INTO `ims_stat_visit` VALUES (24, 2, 'tiger_newhu', 11, 20191201, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (25, 2, 'tuike_jd', 3, 20191201, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (26, 2, 'we7_api', 8, 20191201, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (27, 2, 'tuike_pdd', 1, 20191201, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (28, 2, 'tiger_newhu', 20, 20191202, 'app', 5);
INSERT INTO `ims_stat_visit` VALUES (29, 2, 'we7_api', 10, 20191202, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (30, 2, 'tuike_jd', 2, 20191202, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (31, 2, 'tuike_pdd', 6, 20191202, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (32, 2, 'tiger_newhu', 4, 20191203, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (33, 2, 'we7_api', 2, 20191203, 'app', 1);
INSERT INTO `ims_stat_visit` VALUES (34, 2, 'tuike_jd', 2, 20191203, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (35, 2, 'we7_api', 1, 20191204, 'app', 1);
INSERT INTO `ims_stat_visit` VALUES (36, 2, 'tiger_newhu', 1, 20191204, 'app', 1);
INSERT INTO `ims_stat_visit` VALUES (37, 2, 'tiger_newhu', 8, 20191205, 'app', 1);
INSERT INTO `ims_stat_visit` VALUES (38, 2, 'tuike_jd', 1, 20191205, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (39, 2, 'tuike_pdd', 1, 20191205, 'app', 0);
INSERT INTO `ims_stat_visit` VALUES (40, 2, 'tiger_newhu', 1, 20191206, 'app', 1);
INSERT INTO `ims_stat_visit` VALUES (41, 2, 'tiger_newhu', 6, 20191207, 'app', 3);
INSERT INTO `ims_stat_visit` VALUES (42, 2, 'tiger_newhu', 1, 20191208, 'app', 1);
INSERT INTO `ims_stat_visit` VALUES (43, 0, '', 4, 20191208, 'web', 4);
INSERT INTO `ims_stat_visit` VALUES (44, 2, '', 60, 20191208, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (45, 2, 'we7_account', 33, 20191208, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (46, 2, 'we7_api', 12, 20191208, 'app', 3);
INSERT INTO `ims_stat_visit` VALUES (47, 0, '', 1, 20191209, 'web', 1);
INSERT INTO `ims_stat_visit` VALUES (48, 2, '', 10, 20191209, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (49, 2, 'we7_account', 11, 20191209, 'web', 1);
INSERT INTO `ims_stat_visit` VALUES (50, 2, 'we7_api', 4, 20191209, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (51, 2, 'we7_api', 7, 20191210, 'app', 3);
INSERT INTO `ims_stat_visit` VALUES (52, 2, '', 3, 20191210, 'web', 1);
INSERT INTO `ims_stat_visit` VALUES (53, 2, 'we7_account', 1, 20191210, 'web', 1);
INSERT INTO `ims_stat_visit` VALUES (54, 2, 'we7_account', 3, 20191211, 'web', 1);
INSERT INTO `ims_stat_visit` VALUES (55, 0, '', 4, 20191212, 'web', 3);
INSERT INTO `ims_stat_visit` VALUES (56, 2, '', 46, 20191212, 'web', 1);
INSERT INTO `ims_stat_visit` VALUES (57, 2, 'we7_account', 19, 20191212, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (58, 2, 'we7_api', 4, 20191212, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (59, 1, 'we7_account', 2, 20191212, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (60, 1, '', 1, 20191212, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (61, 2, 'we7_api', 2, 20191213, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (62, 2, 'we7_api', 5, 20191214, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (63, 2, 'we7_api', 1, 20191215, 'app', 1);
INSERT INTO `ims_stat_visit` VALUES (64, 2, 'we7_api', 19, 20191216, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (65, 2, 'we7_api', 1, 20191217, 'app', 1);
INSERT INTO `ims_stat_visit` VALUES (66, 2, 'we7_api', 17, 20191218, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (67, 0, '', 5, 20191218, 'web', 2);
INSERT INTO `ims_stat_visit` VALUES (68, 2, '', 1, 20191218, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (69, 2, 'we7_account', 20, 20191218, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (70, 2, 'we7_api', 55, 20191219, 'app', 4);
INSERT INTO `ims_stat_visit` VALUES (71, 0, '', 1, 20191219, 'web', 1);
INSERT INTO `ims_stat_visit` VALUES (72, 2, 'we7_api', 25, 20191220, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (73, 0, '', 1, 20191220, 'web', 1);
INSERT INTO `ims_stat_visit` VALUES (74, 2, 'we7_api', 17, 20191222, 'app', 4);
INSERT INTO `ims_stat_visit` VALUES (75, 2, 'we7_api', 15, 20191223, 'app', 3);
INSERT INTO `ims_stat_visit` VALUES (76, 2, 'we7_api', 25, 20191224, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (77, 2, 'we7_api', 17, 20191225, 'app', 4);
INSERT INTO `ims_stat_visit` VALUES (78, 0, '', 1, 20191225, 'web', 1);
INSERT INTO `ims_stat_visit` VALUES (79, 2, 'we7_api', 14, 20191226, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (80, 2, 'we7_api', 6, 20191227, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (81, 2, 'we7_api', 5, 20191228, 'app', 2);
INSERT INTO `ims_stat_visit` VALUES (82, 0, '', 6, 20191228, 'web', 2);
INSERT INTO `ims_stat_visit` VALUES (83, 2, '', 12, 20191228, 'web', 0);
INSERT INTO `ims_stat_visit` VALUES (84, 2, 'we7_account', 4, 20191228, 'web', 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_stat_visit_ip
-- ----------------------------
DROP TABLE IF EXISTS `ims_stat_visit_ip`;
CREATE TABLE `ims_stat_visit_ip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` int(10) unsigned NOT NULL,
  `uniacid` int(10) NOT NULL,
  `type` varchar(10) NOT NULL,
  `module` varchar(100) NOT NULL,
  `date` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ip_date_module_uniacid` (`ip`,`date`,`module`,`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=134 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_stat_visit_ip
-- ----------------------------
BEGIN;
INSERT INTO `ims_stat_visit_ip` VALUES (68, 1971857054, 2, 'app', 'tiger_newhu', 20191208);
INSERT INTO `ims_stat_visit_ip` VALUES (69, 3030552991, 0, 'web', '', 20191208);
INSERT INTO `ims_stat_visit_ip` VALUES (70, 3752255076, 2, 'app', 'we7_api', 20191208);
INSERT INTO `ims_stat_visit_ip` VALUES (71, 3752255087, 2, 'app', 'we7_api', 20191208);
INSERT INTO `ims_stat_visit_ip` VALUES (72, 2026669736, 0, 'web', '', 20191208);
INSERT INTO `ims_stat_visit_ip` VALUES (73, 3752255088, 2, 'app', 'we7_api', 20191208);
INSERT INTO `ims_stat_visit_ip` VALUES (74, 1700188964, 0, 'web', '', 20191208);
INSERT INTO `ims_stat_visit_ip` VALUES (75, 1883273010, 0, 'web', '', 20191208);
INSERT INTO `ims_stat_visit_ip` VALUES (76, 3030161438, 0, 'web', '', 20191209);
INSERT INTO `ims_stat_visit_ip` VALUES (77, 3752255076, 2, 'app', 'we7_api', 20191209);
INSERT INTO `ims_stat_visit_ip` VALUES (78, 3752255094, 2, 'app', 'we7_api', 20191209);
INSERT INTO `ims_stat_visit_ip` VALUES (79, 3082984029, 2, 'web', 'we7_account', 20191209);
INSERT INTO `ims_stat_visit_ip` VALUES (80, 3752255094, 2, 'app', 'we7_api', 20191210);
INSERT INTO `ims_stat_visit_ip` VALUES (81, 1700045442, 2, 'web', '', 20191210);
INSERT INTO `ims_stat_visit_ip` VALUES (82, 3752255087, 2, 'app', 'we7_api', 20191210);
INSERT INTO `ims_stat_visit_ip` VALUES (83, 3752255076, 2, 'app', 'we7_api', 20191210);
INSERT INTO `ims_stat_visit_ip` VALUES (84, 3082984029, 2, 'web', 'we7_account', 20191210);
INSERT INTO `ims_stat_visit_ip` VALUES (85, 3082984029, 2, 'web', 'we7_account', 20191211);
INSERT INTO `ims_stat_visit_ip` VALUES (86, 975561219, 0, 'web', '', 20191212);
INSERT INTO `ims_stat_visit_ip` VALUES (87, 3752255094, 2, 'app', 'we7_api', 20191212);
INSERT INTO `ims_stat_visit_ip` VALUES (88, 3030161438, 2, 'web', '', 20191212);
INSERT INTO `ims_stat_visit_ip` VALUES (89, 720112203, 0, 'web', '', 20191212);
INSERT INTO `ims_stat_visit_ip` VALUES (90, 3030637572, 0, 'web', '', 20191212);
INSERT INTO `ims_stat_visit_ip` VALUES (91, 3752255087, 2, 'app', 'we7_api', 20191212);
INSERT INTO `ims_stat_visit_ip` VALUES (92, 3752255087, 2, 'app', 'we7_api', 20191213);
INSERT INTO `ims_stat_visit_ip` VALUES (93, 3752255076, 2, 'app', 'we7_api', 20191213);
INSERT INTO `ims_stat_visit_ip` VALUES (94, 3752255088, 2, 'app', 'we7_api', 20191214);
INSERT INTO `ims_stat_visit_ip` VALUES (95, 3752255094, 2, 'app', 'we7_api', 20191214);
INSERT INTO `ims_stat_visit_ip` VALUES (96, 3752255087, 2, 'app', 'we7_api', 20191215);
INSERT INTO `ims_stat_visit_ip` VALUES (97, 3752255094, 2, 'app', 'we7_api', 20191216);
INSERT INTO `ims_stat_visit_ip` VALUES (98, 3752255088, 2, 'app', 'we7_api', 20191216);
INSERT INTO `ims_stat_visit_ip` VALUES (99, 3752255094, 2, 'app', 'we7_api', 20191217);
INSERT INTO `ims_stat_visit_ip` VALUES (100, 3752255088, 2, 'app', 'we7_api', 20191218);
INSERT INTO `ims_stat_visit_ip` VALUES (101, 3752255087, 2, 'app', 'we7_api', 20191218);
INSERT INTO `ims_stat_visit_ip` VALUES (102, 1780944365, 0, 'web', '', 20191218);
INSERT INTO `ims_stat_visit_ip` VALUES (103, 3030161438, 0, 'web', '', 20191218);
INSERT INTO `ims_stat_visit_ip` VALUES (104, 3752255087, 2, 'app', 'we7_api', 20191219);
INSERT INTO `ims_stat_visit_ip` VALUES (105, 3752255088, 2, 'app', 'we7_api', 20191219);
INSERT INTO `ims_stat_visit_ip` VALUES (106, 3752255076, 2, 'app', 'we7_api', 20191219);
INSERT INTO `ims_stat_visit_ip` VALUES (107, 1780944365, 0, 'web', '', 20191219);
INSERT INTO `ims_stat_visit_ip` VALUES (108, 3752255094, 2, 'app', 'we7_api', 20191219);
INSERT INTO `ims_stat_visit_ip` VALUES (109, 3752255088, 2, 'app', 'we7_api', 20191220);
INSERT INTO `ims_stat_visit_ip` VALUES (110, 3752255087, 2, 'app', 'we7_api', 20191220);
INSERT INTO `ims_stat_visit_ip` VALUES (111, 1780944365, 0, 'web', '', 20191220);
INSERT INTO `ims_stat_visit_ip` VALUES (112, 3752255088, 2, 'app', 'we7_api', 20191222);
INSERT INTO `ims_stat_visit_ip` VALUES (113, 3752255094, 2, 'app', 'we7_api', 20191222);
INSERT INTO `ims_stat_visit_ip` VALUES (114, 3752255087, 2, 'app', 'we7_api', 20191222);
INSERT INTO `ims_stat_visit_ip` VALUES (115, 3752255076, 2, 'app', 'we7_api', 20191222);
INSERT INTO `ims_stat_visit_ip` VALUES (116, 3752255076, 2, 'app', 'we7_api', 20191223);
INSERT INTO `ims_stat_visit_ip` VALUES (117, 3752255088, 2, 'app', 'we7_api', 20191223);
INSERT INTO `ims_stat_visit_ip` VALUES (118, 3752255094, 2, 'app', 'we7_api', 20191223);
INSERT INTO `ims_stat_visit_ip` VALUES (119, 3752255088, 2, 'app', 'we7_api', 20191224);
INSERT INTO `ims_stat_visit_ip` VALUES (120, 3752255087, 2, 'app', 'we7_api', 20191224);
INSERT INTO `ims_stat_visit_ip` VALUES (121, 3752255088, 2, 'app', 'we7_api', 20191225);
INSERT INTO `ims_stat_visit_ip` VALUES (122, 3752255087, 2, 'app', 'we7_api', 20191225);
INSERT INTO `ims_stat_visit_ip` VALUES (123, 3752255076, 2, 'app', 'we7_api', 20191225);
INSERT INTO `ims_stat_visit_ip` VALUES (124, 1780944365, 0, 'web', '', 20191225);
INSERT INTO `ims_stat_visit_ip` VALUES (125, 3752255094, 2, 'app', 'we7_api', 20191225);
INSERT INTO `ims_stat_visit_ip` VALUES (126, 3752255088, 2, 'app', 'we7_api', 20191226);
INSERT INTO `ims_stat_visit_ip` VALUES (127, 3752255087, 2, 'app', 'we7_api', 20191226);
INSERT INTO `ims_stat_visit_ip` VALUES (128, 3752255087, 2, 'app', 'we7_api', 20191227);
INSERT INTO `ims_stat_visit_ip` VALUES (129, 3752255088, 2, 'app', 'we7_api', 20191227);
INSERT INTO `ims_stat_visit_ip` VALUES (130, 3752255087, 2, 'app', 'we7_api', 20191228);
INSERT INTO `ims_stat_visit_ip` VALUES (131, 3752255094, 2, 'app', 'we7_api', 20191228);
INSERT INTO `ims_stat_visit_ip` VALUES (132, 1710527279, 0, 'web', '', 20191228);
INSERT INTO `ims_stat_visit_ip` VALUES (133, 2130706433, 0, 'web', '', 20191228);
COMMIT;

-- ----------------------------
-- Table structure for ims_system_stat_visit
-- ----------------------------
DROP TABLE IF EXISTS `ims_system_stat_visit`;
CREATE TABLE `ims_system_stat_visit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `modulename` varchar(100) NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `displayorder` int(10) NOT NULL,
  `createtime` int(10) NOT NULL,
  `updatetime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_app_hb
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_app_hb`;
CREATE TABLE `ims_tiger_app_hb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `type` varchar(250) DEFAULT '0',
  `title` varchar(250) DEFAULT '0',
  `pic` varchar(250) DEFAULT '0',
  `url` varchar(1000) DEFAULT '0',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_app_mobsend
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_app_mobsend`;
CREATE TABLE `ims_tiger_app_mobsend` (
  `tel` bigint(11) unsigned NOT NULL COMMENT '手机号',
  `weid` int(11) DEFAULT '0',
  `value` char(6) NOT NULL DEFAULT '' COMMENT '验证码',
  `total` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '发送次数',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`tel`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_app_tuanzhangset
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_app_tuanzhangset`;
CREATE TABLE `ims_tiger_app_tuanzhangset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `title` varchar(100) DEFAULT '0',
  `px` int(10) DEFAULT '0',
  `sjtype` int(10) DEFAULT '0',
  `jl` varchar(50) DEFAULT '0',
  `rmb` varchar(50) DEFAULT '0',
  `fsm` varchar(50) DEFAULT '0',
  `ordermsum` varchar(50) DEFAULT '0',
  `text` varchar(1000) DEFAULT '0',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tiger_app_tuanzhangset
-- ----------------------------
BEGIN;
INSERT INTO `ims_tiger_app_tuanzhangset` VALUES (1, 2, '团长', 1, 1, '10', '10000', '100', '0', '0', 1574851282);
COMMIT;

-- ----------------------------
-- Table structure for ims_tiger_newhu_ad
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_ad`;
CREATE TABLE `ims_tiger_newhu_ad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `type` varchar(250) DEFAULT '0',
  `title` varchar(250) DEFAULT '0',
  `pic` varchar(250) DEFAULT '0',
  `pidtype` varchar(10) DEFAULT '0' COMMENT '链接是否带PID',
  `url` varchar(1000) DEFAULT '0',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tiger_newhu_ad
-- ----------------------------
BEGIN;
INSERT INTO `ims_tiger_newhu_ad` VALUES (1, 2, '0', '热销', 'images/2/2019/11/d2922E9Mmm3zTm26MOz32mm77msmr2.jpg', '0', 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=sshottop1111&m=tiger_newhu', 1574850672);
INSERT INTO `ims_tiger_newhu_ad` VALUES (2, 2, '0', '红包天天领', 'images/2/2019/11/k8uCku56Kn6QZA9JuC2Q35jm2328AZ.png', '0', 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=cjdej1111&m=tiger_newhu', 1574850736);
COMMIT;

-- ----------------------------
-- Table structure for ims_tiger_newhu_appbottomdh
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_appbottomdh`;
CREATE TABLE `ims_tiger_newhu_appbottomdh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `px` int(10) DEFAULT '0',
  `fztype` int(10) DEFAULT '0' COMMENT '4底部菜单',
  `type` int(10) DEFAULT '0' COMMENT '1.H5链接  2.商品分类  3活动',
  `showtype` int(10) DEFAULT '0' COMMENT '菜单是否显示 1.显示 ',
  `xz` int(10) DEFAULT '0' COMMENT '是否要登录显示 1.需要登录 ',
  `title` varchar(100) DEFAULT '0' COMMENT '名称',
  `ftitle` varchar(100) DEFAULT '0' COMMENT '副名称',
  `hd` varchar(20) DEFAULT '0' COMMENT '1聚划算 2淘抢购  3秒杀  4 叮咚抢  5 视频单  6品牌团 7官方推荐 8好券直播 9小编力荐',
  `fqcat` int(11) DEFAULT '0' COMMENT '商品分类ID',
  `flname` varchar(100) DEFAULT '0' COMMENT '分类名称',
  `itemid` varchar(100) DEFAULT '0' COMMENT '商品ID',
  `headcolorleft` varchar(100) DEFAULT '0' COMMENT '头背景颜色1',
  `headcolorright` varchar(100) DEFAULT '0' COMMENT '头背景颜色2',
  `pic` varchar(250) DEFAULT '0',
  `pic1` varchar(250) DEFAULT '0' COMMENT '底部菜单按下去图片',
  `apppage1` varchar(1000) DEFAULT NULL,
  `apppage2` varchar(1000) DEFAULT '0',
  `url` varchar(1000) DEFAULT '0',
  `h5title` varchar(100) DEFAULT '0' COMMENT '网页标题',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `px` (`px`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tiger_newhu_appbottomdh
-- ----------------------------
BEGIN;
INSERT INTO `ims_tiger_newhu_appbottomdh` VALUES (1, 2, 0, 0, 4, 0, 0, '首页', '', '', 1, '女装', '', '', '', 'http://tbk.5ikh.com/attachment/images/2/2019/11/EIJBy2f6jfxjXQgxWthTBcc2qjCplF.jpg', 'http://tbk.5ikh.com/attachment/images/2/2019/11/dU8tUJkdyYIoUuDzS1DdOkI4Sdtugc.jpg', 'index', '', '', '', 1574849016);
COMMIT;

-- ----------------------------
-- Table structure for ims_tiger_newhu_appdh
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_appdh`;
CREATE TABLE `ims_tiger_newhu_appdh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `fztype` int(10) DEFAULT '0' COMMENT '1首页广告   2广告下面菜单  3图标下面图片 4底部菜单  5会员中心下方图标',
  `type` int(10) DEFAULT '0' COMMENT '1.H5链接  2.商品分类  3活动',
  `title` varchar(100) DEFAULT '0' COMMENT '名称',
  `ftitle` varchar(100) DEFAULT '0' COMMENT '副名称',
  `hd` varchar(20) DEFAULT '0' COMMENT '1聚划算 2淘抢购  3秒杀  4 叮咚抢  5 视频单  6品牌团 7官方推荐 8好券直播 9小编力荐',
  `fqcat` int(11) DEFAULT '0' COMMENT '商品分类ID',
  `flname` varchar(100) DEFAULT '0' COMMENT '分类名称',
  `pic` varchar(250) DEFAULT '0',
  `apppage1` varchar(1000) DEFAULT NULL,
  `apppage2` varchar(1000) DEFAULT '0',
  `url` varchar(1000) DEFAULT '0',
  `h5title` varchar(100) DEFAULT '0' COMMENT '网页标题',
  `createtime` int(10) NOT NULL,
  `itemid` varchar(100) DEFAULT '0' COMMENT '商品ID',
  `showtype` int(10) DEFAULT '0' COMMENT '菜单是否显示 1.显示 ',
  `xz` int(10) DEFAULT '0' COMMENT '是否要登录显示 1.需要登录 ',
  `headcolorleft` varchar(50) DEFAULT '0',
  `headcolorright` varchar(50) DEFAULT '0',
  `pic1` varchar(250) DEFAULT '0' COMMENT '底部菜单按下图',
  `px` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_appset
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_appset`;
CREATE TABLE `ims_tiger_newhu_appset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `appid` varchar(200) DEFAULT NULL COMMENT 'APP的APPID',
  `mchid` varchar(200) DEFAULT NULL COMMENT '商户号',
  `jiamistr` varchar(200) DEFAULT NULL COMMENT '加密字符',
  `appzfip` varchar(100) DEFAULT '' COMMENT 'IP',
  `appfximg` varchar(200) DEFAULT '',
  `appfxtitle` varchar(100) DEFAULT '',
  `appfxcontent` varchar(200) DEFAULT '',
  `smskeyid` varchar(100) DEFAULT '0',
  `smssecret` varchar(100) DEFAULT '0',
  `smsname` varchar(100) DEFAULT '0',
  `smscode` varchar(100) DEFAULT '0',
  `appkey` varchar(100) DEFAULT '0' COMMENT '秘钥',
  `tuanzhangtype` int(11) DEFAULT '0' COMMENT '1开启团长功能',
  `iossh` varchar(10) DEFAULT '0' COMMENT 'IOS审核状态 1审核中',
  `sjztype` int(5) DEFAULT '0' COMMENT '升级赚 1显示',
  `headclorleft` varchar(50) DEFAULT '0',
  `headclorright` varchar(50) DEFAULT '0',
  `tanchuangurl` varchar(400) DEFAULT '0',
  `tanchuangpic` varchar(200) DEFAULT '0',
  `tanchuangtitle` varchar(200) DEFAULT '0',
  `tanchuangjgtime` varchar(200) DEFAULT '0' COMMENT '弹窗间隔时间',
  `tanchuangtype` int(5) DEFAULT '0' COMMENT ' 1开启弹窗',
  `appxiaoxiurl` varchar(400) DEFAULT '0',
  `hyjftype` int(5) DEFAULT '0' COMMENT ' 会员中心积分是否显示 1 显示',
  `lbygz` varchar(100) DEFAULT NULL COMMENT '自定义预估赚名称',
  `lbsjz` varchar(100) DEFAULT NULL COMMENT '自定义升级赚名称',
  `tptype` int(5) DEFAULT '0' COMMENT '列表模版',
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_cdtype
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_cdtype`;
CREATE TABLE `ims_tiger_newhu_cdtype` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `px` int(10) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL,
  `fftype` int(3) NOT NULL DEFAULT '0' COMMENT '分类',
  `picurl` varchar(255) NOT NULL COMMENT '封面',
  `wlurl` varchar(255) NOT NULL COMMENT '外链',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `fftype` (`fftype`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tiger_newhu_cdtype
-- ----------------------------
BEGIN;
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (1, 2, 100, '菲彼生活', 7, 'images/2/2019/11/aWghNnINRsNBRzmPmTBwWs7unR4Tr9.png', 'http://www.phoebelife.com/index.php?go=mobile.index.index', 1574852015);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (2, 2, 94, '天猫', 7, 'images/2/2019/11/HgfxTsgz2vuZuUy7DX7Y73U6S44XX9.png', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&id=2&do=wnqtzgoods&m=tiger_newhu', 1575801332);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (3, 2, 96, '淘宝', 7, 'images/2/2019/11/Mw7poqkV1QX29uxxAGMmXWn82o0pXD.png', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&id=1&do=wnqtzgoods&m=tiger_newhu', 1575801400);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (4, 2, 98, '京东', 7, 'images/2/2019/11/SJJ64Ojj77oLps6l0shl1Jzc7sfhhJ.png', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=jdindex&m=tuike_jd', 1575801386);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (5, 2, 97, '拼多多', 7, 'images/2/2019/11/guczpic5s43uO4Cs9ms4uiw304W44z.png', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=pddindex&m=tuike_pdd', 1575801377);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (6, 2, 5, '首页', 1, 'images/2/2019/11/EIJBy2f6jfxjXQgxWthTBcc2qjCplF.jpg', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=index&m=tiger_newhu', 1575801369);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (7, 2, 4, '好货高佣', 1, 'images/2/2019/11/DcMRCerzp9DDVa9sYcReRZOXSpkdDY.jpg', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=hhgyb1111&m=tiger_newhu', 1575801360);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (8, 2, 3, '超级搜', 1, 'images/2/2019/11/G1mAVrkBKVoMAGke5CKcFGeRE2qoKB.jpg', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=lmsearch&m=tiger_newhu', 1575801326);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (9, 2, 2, '品牌榜', 1, 'images/2/2019/11/clB45OoBS8Sdbbvjf04CLWdo8W8bx0.jpg', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=pptop1111&m=tiger_newhu', 1575801350);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (10, 2, 1, '会员中心', 1, 'images/2/2019/11/pX0Ke4Bjd04PDJpbyLBPDjGGkLKjGd.jpg', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=member&m=tiger_newhu', 1575801312);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (11, 2, 93, '聚划算', 7, 'images/2/2019/11/IKFqIAqzAKXHKefFI0Ux6x8GixXgq4.png', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&hd=1&do=newcat&m=tiger_newhu', 1575801302);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (12, 2, 91, '实时热销', 7, 'images/2/2019/11/YnQ7Pef096TtqnfPN070zAmGQN06fF.png', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=sshottop1111&m=tiger_newhu', 1575801294);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (13, 2, 90, '叮咚抢', 7, 'images/2/2019/11/b0SlllKjj81dWrc01D81lDcPJ6168P.png', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=ddq&m=tiger_newhu', 1575801284);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (14, 2, 89, '9.9包邮', 7, 'images/2/2019/11/UQOs9seIOYYZx66hfqxe6eQqYxtM99.png', 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&price2=9.9&do=newcat&m=tiger_newhu', 1575801272);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (15, 1, 83, '饿了么', 7, 'images/1/2019/11/Jlx5nXxQlCAYqVQcZ7UuIZindPzCuz.gif', 'https://tb.ele.me/wow/zele/act/swwt15?wh_biz=tm&spm=a2ogi.13233138.click-share.1&sourceType=other&suid=b257b4d5-a1b1-442c-8f11-8f8087c1c82c&ut_sk=1.WQNTG88tZ3UDAGKPNRYCPn2k_21646297_1574240488333.DingTalk.eleme&un=0fc9cd2a93ea5bf64b68d5f77a161062&share_cr', 1574852992);
INSERT INTO `ims_tiger_newhu_cdtype` VALUES (16, 2, 83, '饿了么', 7, 'images/2/2019/11/OrLf5A8C41jg0mGN558J15U0GU47L4.jpg', 'https://tb.ele.me/wow/zele/act/swwt15?wh_biz=tm&spm=a2ogi.13233138.click-share.1&sourceType=other&suid=b257b4d5-a1b1-442c-8f11-8f8087c1c82c&ut_sk=1.WQNTG88tZ3UDAGKPNRYCPn2k_21646297_1574240488333.DingTalk.eleme&un=0fc9cd2a93ea5bf64b68d5f77a161062&share_cr', 1574904795);
COMMIT;

-- ----------------------------
-- Table structure for ims_tiger_newhu_ck
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_ck`;
CREATE TABLE `ims_tiger_newhu_ck` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `data` text,
  `taodata` text,
  `createtime` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_weid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_dborder
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_dborder`;
CREATE TABLE `ims_tiger_newhu_dborder` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT '0',
  `uid` int(10) NOT NULL COMMENT '用户ID',
  `bizId` varchar(30) NOT NULL COMMENT '订单号',
  `orderNum` varchar(255) NOT NULL COMMENT '兑吧订单号',
  `credits` int(20) NOT NULL COMMENT '积分',
  `params` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `ip` varchar(15) NOT NULL COMMENT '客户端ip',
  `starttimestamp` int(10) DEFAULT NULL COMMENT '下单时间',
  `endtimestamp` int(10) DEFAULT NULL COMMENT '成功时间',
  `waitAudit` int(8) DEFAULT '0' COMMENT '是否审核',
  `Audit` int(1) DEFAULT '0' COMMENT '审核状态',
  `actualPrice` int(11) DEFAULT '0' COMMENT '扣除费用',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `facePrice` int(11) DEFAULT '0' COMMENT '市场价值',
  `itemCode` varchar(255) NOT NULL COMMENT '商品编码',
  `Audituser` varchar(255) NOT NULL COMMENT '审核员',
  `status` int(1) DEFAULT '0' COMMENT '订单状态',
  `createtime` int(10) DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`uniacid`),
  KEY `indx_bizId` (`bizId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_dbrecord
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_dbrecord`;
CREATE TABLE `ims_tiger_newhu_dbrecord` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `uid` int(11) DEFAULT '0',
  `nickname` varchar(200) NOT NULL,
  `openid` varchar(50) NOT NULL,
  `orderNum` varchar(200) NOT NULL,
  `credits` varchar(200) NOT NULL,
  `params` varchar(255) NOT NULL,
  `type` varchar(200) NOT NULL,
  `ip` varchar(200) NOT NULL,
  `sign` varchar(255) NOT NULL,
  `timestamp` int(11) DEFAULT '0',
  `waitAudit` varchar(255) NOT NULL,
  `actualPrice` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `paramsTest4` varchar(255) NOT NULL,
  `facePrice` varchar(255) NOT NULL,
  `appKey` varchar(255) NOT NULL,
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_dianyuan
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_dianyuan`;
CREATE TABLE `ims_tiger_newhu_dianyuan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `openid` varchar(50) DEFAULT '0',
  `nickname` varchar(50) DEFAULT '0',
  `ename` varchar(50) DEFAULT '0',
  `tel` varchar(50) DEFAULT '0',
  `password` varchar(50) DEFAULT '0',
  `companyname` varchar(200) DEFAULT '0',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_dwz
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_dwz`;
CREATE TABLE `ims_tiger_newhu_dwz` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `url` varchar(1000) NOT NULL COMMENT '网址',
  `durl` varchar(1000) NOT NULL COMMENT '缩短网址',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`)
) ENGINE=MyISAM AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tiger_newhu_dwz
-- ----------------------------
BEGIN;
INSERT INTO `ims_tiger_newhu_dwz` VALUES (1, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=5I1MLO840lUGQASttHIRqeCkNhp3s3xW3O4uFNIlcehsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahER9bq7eDzAnw98ZbDY26rQ%3D%3D&traceId=0b154fca15748433863383091e&union_lens=lensId:0b1aff47_0c65_16eabfb0a0c_b701&xId=RHRvGdSUbEOExp2ndrCNGVzuwOdql5L68gqOGWFjyhSKQM9eVSq10kGjXpxiDWlnHzUdCwg2YR5Ak5eZJY4fZ7&activityId=115c2f2e2fca453696b3e942a5f78481', '', 1574843388);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (2, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=i6UOWwh9ycAE%2BdAb1JoOOgz3DSCDcADM3lq7b4fk8A5sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahER9bq7eDzAln%2FBACtOx%2Bew%3D%3D&traceId=0b14f65b15748439988192545e&union_lens=lensId:0b01c1f1_0c8c_16eac046285_9e8f&xId=PmQtOzdpspibkXiq6AUTgndCP00Ya2MFHO8nPaT9owkRyu7sE1JhQJolJ7y0xadyQXwx2R5G2urqnyPd31noGE&activityId=bd6bcc3fbda6461d90603fc9dc10847b', '', 1574843998);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (3, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=%2FF2nqM%2FdOPUGQASttHIRqXcRQ5kHkIAA2nR972JfLYBsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahFghRGjIgPx9fcgSu9ccj%2BQ%3D%3D&traceId=0b08683b15748440263096950e&union_lens=lensId:0b1b15bd_0c8f_16eac04cde6_7ef7&xId=IzzL7XUcXnNVHH9chAAiJkd89dt7t5Mw4BKuH7SGO5nfdewWUjIMQJJYX5xtKZ2couEwC6LjnTbveXeqkpOx7q&activityId=4382a734e7ab4439a39f8efddd4b7de1', '', 1574844025);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (4, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=CfVQtkwkjUwGQASttHIRqaCNdSvH8x50Vs7tEC6C46ZsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahFghRGjIgPx%2Bo3bX5kSP9Vg%3D%3D&traceId=0b14fe5315748440658423984e&union_lens=lensId:0b582879_0c5f_16eac056855_06a3&xId=bop9wl8c4bZgEdeAnCoBcWwmyXN4GU4wKBqdHlPPfwEcye8sQREhp7T60wbj9cEVEIxScIbfb7ZTnMignzHLQp&activityId=c22da9fe44ab46cc90df578e40beac2c', '', 1574844065);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (5, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=P1L5NzY4mwYGQASttHIRqaCNdSvH8x50Vs7tEC6C46ZsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahFghRGjIgPx98YheyOe99aQ%3D%3D&traceId=0b57b79715748440664215146e&union_lens=lensId:0b153bbd_0ca1_16eac056a97_9d6d&xId=Xp19avS5TaaftGi70oZMqtlaqsOURR3opzKKjDTjVR6cRHAHhilbB2Pl6AonJIJsx4CVKv2PUJpZYRmhjw4E05&activityId=c22da9fe44ab46cc90df578e40beac2c', '', 1574844066);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (6, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=HYwlcZbIonAGQASttHIRqeCkNhp3s3xW3O4uFNIlcegSS6FA8WxTVSswBtzVzRI%2BFWYKO98VEvCw1hpvk1ZrHsWK7KkQZC%2FeY1kWovEdEWP2fRjS0VbpI%2FsnwWZGSCD41ug731VBEQm0m3Ckm6GN2CwynAdGnOngMmnVmWO1H8uqlgzVL09go1LajOROSSHlbmDc3qvmTcLde5SD1gxb3A%3D%3D&traceId=0bb6999515748440903345226e&union_lens=lensId:0b183db1_0d27_16eac05c7fa_2b4b&xId=jijzj6QRavb6XINFGpwTv9PhW4BERqriA8Z3ysLhyz4EjZY9DSgggBluMOWSNhGsOOpi4nq1lqDTfyQjVV70KJ&activityId=115c2f2e2fca453696b3e942a5f78481', '', 1574844089);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (7, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=EI83oL21GVoGQASttHIRqQFP%2BOw%2B55H2TJ%2FWpBGGjtRsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahFghRGjIgPx%2B5YSr7Ckoa7w%3D%3D&traceId=0bb0801d15748441333262669e&union_lens=lensId:0b57b76e_0ca3_16eac066ff0_4bc9&xId=w7PivKWgoFaq1kIlCJSv1BaREkJaHnlahg8qrdvQMpppRkTpXoolFH1ZhW4lgz9Hu1ripfvsE9r3wTHbgIiBXu&activityId=e1d7949b577f4aa98a07bf0eb296918f', '', 1574844133);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (8, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=Yt6NmlVGU54GQASttHIRqSVjcC1LXmhsBn4MudbAnsVsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahFghRGjIgPx%2B1TJxSpb76Tg%3D%3D&traceId=0b0817ca15748445573305215e&union_lens=lensId:0b014932_0c59_16eac0ce847_92c9&xId=QR0L6LjzBWrqNmmUSETd1ahddf5xE892tyoSGCFoGtappTIxKwMbGk3AnSrIiEsNu2TrTPkpuQgHCqSeIFSzRz&activityId=9b35232af1fd4d74b7c1b2b108427d23', '', 1574844556);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (9, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=TseuJT4cn88GQASttHIRqQFP%2BOw%2B55H2TJ%2FWpBGGjtRsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahFghRGjIgPx%2FAjxFztbMnIA%3D%3D&traceId=0b17697f15748446813358900e&union_lens=lensId:0b82dabf_0c68_16eac0eccbd_6015&xId=tABjWgT0Jk4ghb3WChNnKbaICLebC9ZMEJHnxvniUooi2txfCea7W1YMfqvN1IzfOX7Sdqp1tjFTVLF9nkT3ZO&activityId=e1d7949b577f4aa98a07bf0eb296918f', '', 1574844680);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (10, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=XrhXngiohEAGQASttHIRqQFP%2BOw%2B55H2TJ%2FWpBGGjtRsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahFghRGjIgPx%2BBGq5ByH3vLA%3D%3D&traceId=0b0b75ed15748446823282089e&union_lens=lensId:0b153bbd_0ca1_16eac0ed07b_9e21&xId=P2xSSNQmgfbyLFF5wTW3ktiDXQzveY6eA4QiKHMFHkwgYH0zPYW2QBfhMxy8AfuB4snpgf5vqutBs3Q4FPkVS4&activityId=e1d7949b577f4aa98a07bf0eb296918f', '', 1574844681);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (11, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=6cMCf3TrogkGQASttHIRqXcRQ5kHkIAA2nR972JfLYBsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahFghRGjIgPx9UIuoQIgnsHA%3D%3D&traceId=0b183ba915748447804034526e&union_lens=lensId:0b582459_0c95_16eac104f95_0f75&xId=QAmrMQhI3BtBUGtixCUzaV5mrVwsFLu7ZoZjl5daADCSwBcqItTF90mzvJZg4Nqv9E4Dh0cCwY4OnDBXp3So1i&activityId=4382a734e7ab4439a39f8efddd4b7de1', '', 1574844780);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (12, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=I9EZx0tDDHkGQASttHIRqXcRQ5kHkIAA2nR972JfLYBsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahFghRGjIgPx%2FLt%2F0IZUzxig%3D%3D&traceId=0b092be915748448314227945e&union_lens=lensId:0b82dabf_0c68_16eac1116dd_cd6d&xId=6JMlQWn4i7oWiX0SzlExTBpR3XPwOT5VD6Hqxx2fTa9kdRPCrxKZdBUunlXLeVWCg4lmk9ri7qggWOiGLC3tJe&activityId=4382a734e7ab4439a39f8efddd4b7de1', '', 1574844831);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (13, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=zmWNu2xIgckGQASttHIRqQFP%2BOw%2B55H2TJ%2FWpBGGjtRsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahAYYzwLyJLOlRG0E35v3wAA%3D%3D&traceId=0b0b1ed615748456513475144e&union_lens=lensId:0b57b5a6_0c91_16eac1d99aa_56e7&xId=RwEjkpTSeKMtItqjlvrrkiB7ztK7knAaugVHK7vnDLxDhjZH0XmMULkWa0mKiHB4V5YjrITvBCDogLRuIngnvu&activityId=e1d7949b577f4aa98a07bf0eb296918f', '', 1574845650);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (14, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=5%2F%2BD317%2FK3QGQASttHIRqTYVhoxc3K7he3t7%2BiYzr1BsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahmjW7G1%2FpyHdJmapstg17hQ%3D%3D&traceId=0b57b78f15748466856791175e&union_lens=lensId:0b0b6466_0c8c_16eac2d6210_3bdf&xId=kTgyj1nTGGy0eO6UezAw8xHhSL5fbKu2zmRGTEET4ZIyXmJkIBa9ynQT9CM5r9TpMWXxwcUm1SGtvP121x2Xi1&activityId=5a35284c74114918a063f863fca96b78', '', 1574846684);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (15, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=kNAjTuDgRxYGQASttHIRqTYVhoxc3K7he3t7%2BiYzr1BsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahmjW7G1%2FpyHeP2Mf%2BVmkIxQ%3D%3D&traceId=0b0b3e7415748466866515672e&union_lens=lensId:0b14eee3_0c25_16eac2d65f4_25af&xId=aVa60vfZinDFxH1AbmZ974PxiecKnJFMk1Dmmqg6Gy4cwS1GGcufpXQjE53xfgkaQPsGigkf7DQARG9z90nORz&activityId=5a35284c74114918a063f863fca96b78', '', 1574846686);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (16, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=CN%2FG5W3hDHgGQASttHIRqTJWjg2slSXBqg8rDxDs9dxsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahewQ1KpnY5OsWjLVKjV4XqA%3D%3D&traceId=0b0826fd15748498495947703e&union_lens=lensId:0b582d96_0c1d_16eac5da91f_0cb3&xId=LUAdBhxoCcalPStdvgIuydBpmiHwqr80F3VbSEcyKWuK90JFWTt36HILH45JygGdIUfs4J2a2L67kc9jN0bcAy&activityId=ccff26b2dc284b3f82818ea5b1d5092e', '', 1574849849);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (17, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=QeOl0p6o25sGQASttHIRqTYVhoxc3K7he3t7%2BiYzr1BsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah%2FMtVV5cujlNeNeU7ZSt2bA%3D%3D&traceId=0b0b7a3415748506307097747e&union_lens=lensId:0b012f08_0c4b_16eac699452_1131&xId=tJyqvhsfuo3v33tpZRcNqo058wwbT3oWnHxqhovGIOPDd0xczOZhFpv85xsFUzwwxeROeSCqiZWsXdQGCCvawp&activityId=5a35284c74114918a063f863fca96b78', '', 1574850629);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (18, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=8zXlWRRqOFUGQASttHIRqTYVhoxc3K7he3t7%2BiYzr1BsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah%2FMtVV5cujlPtS%2F6%2BclOFtQ%3D%3D&traceId=0b0ad01d15748506318683465e&union_lens=lensId:0b1b15bd_0c8f_16eac6998d5_8771&xId=o5dObKcSfJTz5iwNdXd7Kng8wQF18gNftxb5qUd7ATMf5UWa148hXbrgrr4djMjavenHuwuorANFzWjWqLgqPT&activityId=5a35284c74114918a063f863fca96b78', '', 1574850631);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (19, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=DXL5zhAmimsGQASttHIRqTYVhoxc3K7he3t7%2BiYzr1BsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKaht6GeDn9sD1cCLEVJepXe%2Bg%3D%3D&traceId=0bb2696f15748513550948677e&union_lens=lensId:0b014932_0c59_16eac74a1ee_17a9&xId=S70x4ulEQbaLS68JB4N3iG8hXWKHrnckKdnbyz12x1xpPjUk2rQkaUwW63iulfspNvuJiMKTXBUpFcZAMldOoF&activityId=5a35284c74114918a063f863fca96b78', '', 1574851354);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (20, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=hcqlaOGZDMQGQASttHIRqTYVhoxc3K7he3t7%2BiYzr1BsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahRNXTEPpXBS8MK5Cr6FYe%2Bw%3D%3D&traceId=0b0fe15715748568388263616e&union_lens=lensId:0b0f79e2_0c71_16eacc84ed3_c8e5&xId=VJhXt8PINFnartYrN0M0g7ACwFoUWHFnUTncVoCQUgFuaYKG8d7BfFRbdmOgbAPxIgfZ4eLxNumhDaOo3Mx5XP&activityId=5a35284c74114918a063f863fca96b78', '', 1574856838);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (21, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=00PPZFC3oeAGQASttHIRqTYVhoxc3K7he3t7%2BiYzr1BsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahRNXTEPpXBS89L1YnYLRCxQ%3D%3D&traceId=0b0b2a3415748568694814201e&union_lens=lensId:0bb36656_0c6b_16eacc8c693_c471&xId=J0IWDka6VbDoPVEVN5d1ctOG21fo702SObjp5Wn1esFbh4KgyDTPYyvXTu3MTMpgwjNqhu6QoBhMhLZ6guA7KF&activityId=5a35284c74114918a063f863fca96b78', '', 1574856869);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (22, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=pXevC4CZ%2Be8E%2BdAb1JoOOreFGoYHup2jJc51m%2Brw9pBsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahRNXTEPpXBS9vpO0w7Be1yg%3D%3D&traceId=0baf7fc415748568727494822e&union_lens=lensId:0b5952e1_0c56_16eacc8d35b_6225&xId=ltM7cFh3XO2jjJh1Xu0gOxYUUSX7WkH5fWv87G2ZUpQfq4xXMWn2lXlnoGcAIjPm6Bt61rAyt0DOTIa43tY5b2&activityId=ed47af6905834c78b7f6ae0ff2682acb', '', 1574856872);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (23, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=EIxciXQB%2BlAE%2BdAb1JoOOreFGoYHup2jJc51m%2Brw9pBsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahRNXTEPpXBS%2Fge6GTcTSVPw%3D%3D&traceId=0bba882315748569202273839e&union_lens=lensId:0bb85046_10c6_16eacc98cce_5791&xId=Akd88PojzarQmqkDirAxAyTgIPJFuTAV9CNE0LN0XVcjPjEF3cxqoY1ezMSdSMZNHKe51K6mb8njAmTERlMMAE&activityId=ed47af6905834c78b7f6ae0ff2682acb', '', 1574856918);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (24, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1574857011);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (25, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1574857310);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (26, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=4UvBL49f9bYGQASttHIRqTJWjg2slSXBqg8rDxDs9dwSS6FA8WxTVSswBtzVzRI%2BFWYKO98VEvCw1hpvk1ZrHsWK7KkQZC%2FeY1kWovEdEWP2fRjS0VbpI%2FsnwWZGSCD41ug731VBEQm0m3Ckm6GN2CwynAdGnOngMmnVmWO1H8uqlgzVL09go1LajOROSSHlKN00%2BQ6lYCYawNK99n3zeA%3D%3D&traceId=0b08400815748575332808445e&union_lens=lensId:0b01e2ce_0c40_16eacd2e795_cbe9&xId=77Ibz5d9P9pBlB3j4xq7lnoH8hnvFuFYViCJsYcEewti4lWm3j7Xe11het51wIOda9dtHyrqpYIi3xs30TWSeS&activityId=ccff26b2dc284b3f82818ea5b1d5092e', '', 1574857532);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (27, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=D9XybjE5qQcGQASttHIRqTYVhoxc3K7he3t7%2BiYzr1BsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahAQGpDOJNiOnYfMv1y%2FzfTQ%3D%3D&traceId=0b0b761a15748622025896647e&union_lens=lensId:0b013a8d_0c6f_16ead1a26fa_e30f&xId=no2oNXJznj1IhEAwiWsfZWmzYKMH1cP0CuUprTQdxE1KfpyP06aLmuCMXW4chmhcbJZcCKWjapK70vh8SnYPxf&activityId=5a35284c74114918a063f863fca96b78', '', 1574862201);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (28, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=EkPMlnzYRWYE%2BdAb1JoOOqXXqjsxwZ3%2Fa2qROOeEP5NsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahAQGpDOJNiOkUfY0s36a9fg%3D%3D&traceId=0b15855615748622161858719e&union_lens=lensId:0b0840e9_0cf7_16ead1a5c10_8eef&xId=6YeK1eWRJbkUCfdVOMaWILIG1ftqjeMdUVP0hK9tBuZtiCeH0bMF4XxRhRfyPgps2XsjY0vn6nGaCFvIYXDWOc&activityId=b3eeeae0dbc2407c962ff91285bb6900', '', 1574862215);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (29, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=17ZdbdNd5NoE%2BdAb1JoOOqXXqjsxwZ3%2Fa2qROOeEP5NsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahAQGpDOJNiOkjU26FNXIxDw%3D%3D&traceId=0b0b28b615748622296723664e&union_lens=lensId:0b57b768_0c9f_16ead1a90c2_a28d&xId=rN8ytOdU6000JIHqckIcRVPcQiHrjhhmApLQefvL1LkC9LfHOzXjx1Iuvd2ObRyujoY44DQ0BqSpoossXU7ARW&activityId=b3eeeae0dbc2407c962ff91285bb6900', '', 1574862229);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (30, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=H9HIed4y0f0GQASttHIRqQZLkBHDGgzhmz8K6HCrSolsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgT9ak4eGtRysnTeN8hFe8A%3D%3D&traceId=0b080f3015748654124236039e&union_lens=lensId:0b14eee3_0c25_16ead4b215d_04c3&xId=FbGaBqdaHqkDIpY39SBK75QibIZmxPuT4jIcjbz1kPgYu9L9bllSpVdgcllTVs2vloM6sZdqNZ09QCAGrYMIBh&activityId=5d22213dca184a868d392e506346863c', '', 1574865411);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (31, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=H9HIed4y0f0GQASttHIRqQZLkBHDGgzhmz8K6HCrSolsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgT9ak4eGtRysnTeN8hFe8A%3D%3D&traceId=0b080f3015748654124236039e&union_lens=lensId:0b14eee3_0c25_16ead4b215d_04c3&xId=FbGaBqdaHqkDIpY39SBK75QibIZmxPuT4jIcjbz1kPgYu9L9bllSpVdgcllTVs2vloM6sZdqNZ09QCAGrYMIBh&activityId=5d22213dca184a868d392e506346863c', '', 1574865415);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (32, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=jAKn8wJQGSgGQASttHIRqQZLkBHDGgzhmz8K6HCrSolsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgT9ak4eGtRyoFAAlepQm8w%3D%3D&traceId=0bb04a5415748654423953693e&union_lens=lensId:0b0b97cd_0ce4_16ead4b967a_932f&xId=rBwV8us0eU8OwqHE7bS3AEJAKFKYVZcMc4noiWnWbc55bnlWPkRJdSOZc5VwGJD4hffcdQ9Xl7FpicJwvwG7Ur&activityId=5d22213dca184a868d392e506346863c', '', 1574865441);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (33, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=zQ45K%2FvxwjMGQASttHIRqQZLkBHDGgzhmz8K6HCrSolsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgT9ak4eGtRyCWkmDKbQC%2Fw%3D%3D&traceId=0bb0124a15748654732464467e&union_lens=lensId:0b57bdf1_0c61_16ead4c0f00_b44e&xId=rN3PSchyip0WK7FHgIUG2JIbl5jhOyEAyO0hoBszKglW99B9U3DBXsMHl7zxCs4Gm4b6lWNjcaG3P7vmHyN7QH&activityId=5d22213dca184a868d392e506346863c', '', 1574865472);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (34, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=zQ45K%2FvxwjMGQASttHIRqQZLkBHDGgzhmz8K6HCrSolsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgT9ak4eGtRyCWkmDKbQC%2Fw%3D%3D&traceId=0bb0124a15748654732464467e&union_lens=lensId:0b57bdf1_0c61_16ead4c0f00_b44e&xId=rN3PSchyip0WK7FHgIUG2JIbl5jhOyEAyO0hoBszKglW99B9U3DBXsMHl7zxCs4Gm4b6lWNjcaG3P7vmHyN7QH&activityId=5d22213dca184a868d392e506346863c', '', 1574865495);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (35, 2, 'https://mos.m.taobao.com/activity_newer?from=tool&sight=tiger&pid=mm_711720113_1065450073_109733950492', '', 1574865701);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (36, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1574865785);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (37, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1574865786);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (38, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=Vv6tWT0pQIMGQASttHIRqWfsi7VxxJtasehQiIfaTEtsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgT9ak4eGtRwDaEIQVnCJRQ%3D%3D&traceId=0b0b07b615748658346594824e&union_lens=lensId:0b0b97cd_0ce4_16ead5192be_b835&xId=4Tb1CMeEt83959z8yrthpsmaGFmredga5oPPC3DmeVwgf4WSbKpe7sgD2okiA9XDDY1yTT1z9Un3Vok4AEPOzh&activityId=22ca48d283d94412b7a3ba196d417291', '', 1574865834);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (39, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=Vv6tWT0pQIMGQASttHIRqWfsi7VxxJtasehQiIfaTEtsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgT9ak4eGtRwDaEIQVnCJRQ%3D%3D&traceId=0b0b07b615748658346594824e&union_lens=lensId:0b0b97cd_0ce4_16ead5192be_b835&xId=4Tb1CMeEt83959z8yrthpsmaGFmredga5oPPC3DmeVwgf4WSbKpe7sgD2okiA9XDDY1yTT1z9Un3Vok4AEPOzh&activityId=22ca48d283d94412b7a3ba196d417291', '', 1574865837);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (40, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1574866007);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (41, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1574866007);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (42, 2, 'https://u.jd.com/OiiFxY', '', 1574866111);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (43, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=dpZDX6yXuqwE%2BdAb1JoOOp8yNKnSOAG0y2D0uMbVenFsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahHAS6m7Wu3f0QHqYHZUj%2BYQ%3D%3D&traceId=0b832ca015748673173978998e&union_lens=lensId:0b014932_0c59_16ead6832b5_8919&xId=tIh8VMJbL3fgN4zSj7O7ZXqszpRdwSHeVg2pAOpazZzFkau5VQFL3dfGKA8YBKVgyyNVSlCFhBSaheWiYIbZIr&activityId=56367b706598401687df06da8ff3e075', '', 1574867316);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (44, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=pnUtgLrnZAcE%2BdAb1JoOOp8yNKnSOAG0y2D0uMbVenFsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahHAS6m7Wu3f0VOU1JHgbwAQ%3D%3D&traceId=0b0b7a2e15748673160891595e&union_lens=lensId:0bb698e5_0d49_16ead682d94_ccdb&xId=rRqK2xsNafPN46p7zlrSD8fYWcmRfVuDx0NOpNvJ3h1ilrfVEXt3YdcdRWpUxgZ2bNRKBx8Y1dUHWoJDJsGX0z&activityId=56367b706598401687df06da8ff3e075', '', 1574867315);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (45, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=%2BZJvum%2BkZkUGQASttHIRqVU5DHQeGdjIU2LfPd68wrFsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahlGSNph8kTG5eNeU7ZSt2bA%3D%3D&traceId=0b0adafc15749046304805255e&union_lens=lensId:0b0fc0d4_0d21_16eafa18d0a_877b&xId=LvWBOWJ6BeOicabpHZ9LTatubqgrmYL1WarRjDGT1qFcEjfxXJCn78qFFAlO4Dm7emS6bEjcW3eaCal8FECOHe&activityId=96a33611ad2a427d8ae406b3601691ae', '', 1574904630);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (46, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=%2BZJvum%2BkZkUGQASttHIRqVU5DHQeGdjIU2LfPd68wrFsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahlGSNph8kTG5eNeU7ZSt2bA%3D%3D&traceId=0b0adafc15749046304805255e&union_lens=lensId:0b0fc0d4_0d21_16eafa18d0a_877b&xId=LvWBOWJ6BeOicabpHZ9LTatubqgrmYL1WarRjDGT1qFcEjfxXJCn78qFFAlO4Dm7emS6bEjcW3eaCal8FECOHe&activityId=96a33611ad2a427d8ae406b3601691ae', '', 1574904635);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (47, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=FG%2B1i79MsYA8Clx5mXPEKrqEuV4coNaGzPAxVMlswPAbEmd6w9Yyv%2BVM7%2F26E6q7e2Y36qRLQJ%2BUuA93mugYte83bVesLljxY1kWovEdEWP2fRjS0VbpI%2BT3b4zuHjpz1ug731VBEQm1M7QmaYJz9PFaBe2GOkPYHvfjMSYvfkGji5Mwp8diMCy%2FFMi1cPZNepVc1Ap6UyHpcP5If8mAvPNcf7grepHB&traceId=0b14fe5115749048487492955e&union_lens=lensId:0b012f08_0c4b_16eafa4e18d_7dd9&xId=s1hCaDTvAmbgFhF9nIqXOsdYewu62GD35eCGcCBnar5gL8UO78sy8oN6lMCKJyE3GMDyI2uc85fOg50ll8mzGP&activityId=8d866f69638f4f73acf80a7a501fd4be', '', 1574904848);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (48, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1574909513);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (49, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1574909529);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (50, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=vXwLzM2X%2FugGQASttHIRqVU5DHQeGdjIU2LfPd68wrFsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah75rUjbFjYTkNnGSq0OnBQQ%3D%3D&traceId=0b0b232515749099503784025e&union_lens=lensId:0b0ad760_0c36_16eaff2b9d3_7bfd&xId=7znSD2BZ588atjDMZz2PDMOAkJ10razIbg3ANeWD4TOxdea8fcGG4xhfg6Wy1090TfRBxMYzWQj2EsbUuYntjq&activityId=96a33611ad2a427d8ae406b3601691ae', '', 1574909949);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (51, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1574909974);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (52, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1574910008);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (53, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1574910013);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (54, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=At4B03RhafYGQASttHIRqTYVhoxc3K7he3t7%2BiYzr1BsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah7kstxR9Y%2F24Yt26qoLof1Q%3D%3D&traceId=0b832d7715749100204035699e&union_lens=lensId:0bb36656_0c6b_16eaff3cb51_1b97&xId=Iv184closZsHZdeIbljwImsqsjsNY7KJURfPVXoqdvj58sVbu0dlJ79gqIgTk4XiYRaA3l8nMn943FclLcvuv7&activityId=5a35284c74114918a063f863fca96b78', '', 1574910019);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (55, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=LTey6p1jdm4GQASttHIRqTYVhoxc3K7he3t7%2BiYzr1BsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah7kstxR9Y%2F26Hdz8cOR%2FjuQ%3D%3D&traceId=0b0b69cf15749101587851676e&union_lens=lensId:0b00aee1_0c7d_16eaff5e7e1_7f55&xId=3ynrbt5y9lsfQyRgRgdA4B7RJG8SAmDtyUC0JKTWWWPdsfyDi64vW7S5rsqJfagQVHujohZT1F399cTwlGoo4h&activityId=5a35284c74114918a063f863fca96b78', '', 1574910158);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (56, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=At0apX5h6ZrsbecaumMgZF68hSvT3iD%2F4KezdStNPGgbEmd6w9Yyv%2BVM7%2F26E6q7e2Y36qRLQJ%2BUuA93mugYte83bVesLljxY1kWovEdEWP2fRjS0VbpI%2FsnwWZGSCD41ug731VBEQm0m3Ckm6GN2CwynAdGnOngMmnVmWO1H8uqlgzVL09go1LajOROSSHlc6MFvOg9WLybnWfs3E7hgQ%3D%3D&traceId=0b013c1915749126279745978e&union_lens=lensId:0b0b6466_0c8c_16eb01b9522_067f&xId=yMzYQOox4Dvcv1MZVB30AdNWH1ivod41kssArbCGoaxOwMQvtXBETVqvcHXuLgqjUaUBy6mOPCw5EnjAiEkEBE&activityId=3650d2cd24ff4a71829985775f665f99', '', 1574912627);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (57, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=HQEGqX7Lf5QGQASttHIRqbM1VKtCTl0Le73uc%2Bh3gT5sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahXrmNj7NRbEGB9fLTmnn0ow%3D%3D&traceId=0b0fbb8a15749175963035757e&union_lens=lensId:0b57b5a6_0c91_16eb06764a8_7e71&xId=zZSS7ezHxyYk3qyN7rXjz1ky2ZZ4pWCIbn32sWHVj4WiuU6HODsmXIxzUAJijvvBlYBODvutLzzu901Hd2Lktx&activityId=46744e6164c84b48b5439d201fa4726a', '', 1574917595);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (58, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=MCeVLxwbg3UGQASttHIRqbM1VKtCTl0Le73uc%2Bh3gT5sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahXrmNj7NRbEHlpdWMuhYIag%3D%3D&traceId=0b57cd0415749175974945571e&union_lens=lensId:0b1545dd_0c7b_16eb067695a_a34b&xId=fqzYcleB7hpMRJST5GOglaOTYap9oTIpbyODNHtPvAaMUwEUXpS10LxIOnN0UkF7qnj9M9QFqbNo9srkDZZ4Ob&activityId=46744e6164c84b48b5439d201fa4726a', '', 1574917597);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (59, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=CFsJJZE7GsgGQASttHIRqbM1VKtCTl0Le73uc%2Bh3gT5sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahXrmNj7NRbEGJzuKYPsBIcA%3D%3D&traceId=0b156b3115749176113612072e&union_lens=lensId:0b0fe08b_0c85_16eb0679f81_10b7&xId=LKFPhz1Q4LyWZQnC4ApWswTTgQ93QmoG9t7c9R3Abv6gVPljxPw15ZkDeuO7Utqlrj6XXdbTajpCRvRs7eH56f&activityId=46744e6164c84b48b5439d201fa4726a', '', 1574917610);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (60, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=ZGyra45bDA8GQASttHIRqTYVhoxc3K7he3t7%2BiYzr1BsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahcfZ1fA121I0ksdz81UVSJA%3D%3D&traceId=0b14cf5815749199690411589e&union_lens=lensId:0b0ae8da_0c96_16eb08b992b_93b7&xId=9cjtjCgSZnbujySEyAHUcfOPwmDLouCsm6CDaF2SNXIAha54kap4e4cbYfah3N54FxzWgq5edQ0nQ3KuaRdyyZ&activityId=5a35284c74114918a063f863fca96b78', '', 1574919968);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (61, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1574928813);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (62, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=CceMVQlMem4EShog3g6x7kJQL%2FQJa9b%2BMAf1jAXZeeMzrA2vOqDyN%2FtSeDIxLwOT%2FtYdkoEXV4UKUGGMnD1r38Nek1i42D7kGyW%2B9l4dctCyfnHY3fAg7Odth9k8bqqSHKTgBzHkoM7XTQC0vfau6E%2F9Zk7cDx8UPrKiYwdarE9GJENxHXZ8Anui%2Fn%2FQ7Z5VxGP21i1cI2EDCq9CrVftVg%3D%3D&traceId=0b1b169a15749377139792127e&union_lens=lensId:0b5797e3_0c67_16eb19a5d5a_818b&xId=lz529l1PCbcrcZBG41YrmqiAgB93u2j0uKvA9wloiZZYxw5qtE0ZP8DZVni1BQQa1nqRirxDYrOnZdMMs9ByQe&activityId=4104e10171b94e3893024989c43a47e3', '', 1574937713);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (63, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=v6pGnCSakbQGQASttHIRqQesCwuqWdu0gL9MdCDWBf1sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahVNO3YTqM8lt1sDoQFmfVCw%3D%3D&traceId=0b0b596f15749479079875757e&union_lens=lensId:0b5832d4_0c63_16eb235e9b4_bb9f&xId=WE6KdCK3kETZjOHJrzkrBMuGWZTDC1BNdCT0T5cwDnnEPDsdTPBMyVkkiUW4r0ASYnkYSEDlahZL6WYT89gJH8&activityId=9745ccaf761b43e68d3c8a821834eeab', '', 1574947907);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (64, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=naEmYlg%2B2WsGQASttHIRqQesCwuqWdu0gL9MdCDWBf1sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahVNO3YTqM8lvxz%2FfQWaMyTw%3D%3D&traceId=0b1b0aeb15749479094284391e&union_lens=lensId:0b015dd6_0c0f_16eb235ef51_42f7&xId=v6WT3dxqEXRDeUkiNMgzb4bkXbAwgoLe3wGNsDMggGoIhpojuWSjAmOL6SzqzqHLGHTJlQNKBwShnW73JNNtKS&activityId=9745ccaf761b43e68d3c8a821834eeab', '', 1574947909);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (65, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=CDXaiBjFg6ME%2BdAb1JoOOqGVP%2BRWZMB9FF3HX%2BiNLMlsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahVNO3YTqM8lvv3oQN5VvJJw%3D%3D&traceId=0b1747b615749479426711808e&union_lens=lensId:0b157056_0c6f_16eb236712d_d067&xId=1BTA2qjxRIb4OB7mdlAPjZbqCPpsKgRXdjjbjfUaWyOvM1KizChGyoMU4v3QhXy21vfKwm7O33VXbRDK0FWi8M&activityId=c70827860f8e4916990c6615454b1355', '', 1574947942);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (66, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=WNjYCDYwQc0GQASttHIRqSUCTfmMQTdbfeHgaWX4xA9sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gcqifT61JKFpRiRDcR12fAJ7ov5%2F0O2eVd3c2PiZShTVAwqvQq1X7VY%3D&traceId=0b14dd1c15749479941773324e&union_lens=lensId:0b57b5a6_0c91_16eb2373a5c_a52b&xId=dhNzuxHSsdz41NSjS8OGNUu8SI5Z6BK42yM7aCfdCoXl8wMuaMFwwFHfWXSct7QjcyuzisKPjjsBvivdJBMyGU&activityId=dade0cad239b4fc5bb1f731ed6665f52', '', 1574947993);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (67, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=AuP67yGkKVQE%2BdAb1JoOOkZQLK8yIjDnntdOE8tGc%2BZsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah9QqWs9J%2F%2BzruxmR7XTRu4Q%3D%3D&traceId=0b08470515749480807314262e&union_lens=lensId:0b57b768_0c9f_16eb2388c6f_4c71&xId=v1YWz0Jh3oTgfFjdXvjyOqgK794wm1YLkD7zNJnBEAx9sJRoKZD4nW7hpRmo853jWbTVFQ0gYl7cvDB7D1pLc4&activityId=d3aa49dce0d349bbaa032ad208379057', '', 1574948080);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (68, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=8crQKTVamOsE%2BdAb1JoOOqGQ4yDyZD9AtCM6x%2BsgUUdsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah9QqWs9J%2F%2BzrV12r43dG4Dg%3D%3D&traceId=0b57cd0715749485057851803e&union_lens=lensId:0b5952e0_0c37_16eb23f08d5_d41b&xId=JS7H2sYC42homBYTJXl4u9BAURVSC1NhNbhwX9bD34xFQvo0nSpvNLvYG52pIbOrbH5BRs9A0Ni3U4w1tRCifP&activityId=87ab8e466d0d4f928c63b92ea944e8bd', '', 1574948505);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (69, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=E2kFSgFzZI8GQASttHIRqY3zvte3dUGB%2BXupwiOyhM9sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah9QqWs9J%2F%2BzpxxUOSNz6Xhg%3D%3D&traceId=0b0b2a1715749485068314934e&union_lens=lensId:0bba83d1_0ca2_16eb23f0d20_7be1&xId=AhGGjMG2oKe3TLUTxCJnYSji7S5ET8xDrlXHkjMAsZEMkloty2rCAbUvXMyAsDAiUqg5wm0wRylGoTT7kXyotF&activityId=ffd3ffe373a34121ac18e3dde9337672', '', 1574948506);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (70, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=CKvbIUtwnbAGQASttHIRqZvH3lJV61oDus3FbrFquDRsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahdGgpSIVUp%2BoyBTdcvJ8N5A%3D%3D&traceId=0b0aeab715750294560546914e&union_lens=lensId:0b0fc0d4_0d21_16eb7123ce1_9212&xId=hPATFT48wVHasYwRVdkzWYKcb1s8I7DwuzHPiwe8XCtBT4Y298bDYE0ItTlMnxEpzImOAkbYjDSjPQqWFreC4e&activityId=bc739c6453214772ad963e0a1945aa1b', '', 1575029455);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (71, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=0Hs8%2F8%2BYbM8E%2BdAb1JoOOieJL4CDI2yy10pml2VcUGpsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahRV5tE54yvT8xWb7aVkR4Lw%3D%3D&traceId=0b00aa9315750346128062605e&union_lens=lensId:0b5797e3_0c67_16eb760ec67_29ef&xId=zf3AXuhKF5CpfM95fzl9sODNx9VViFb5VSWdRJpEG0ZgBw8gY3ixeSqQCXPsLt1ZSDli4XHCWrwV2p6Mznk6d6&activityId=446ff6cdce8448ae81b6ea83ea722371', '', 1575034612);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (72, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=3FY6xa1aahwEShog3g6x7kJQL%2FQJa9b%2BMAf1jAXZeeMzrA2vOqDyN%2FtSeDIxLwOT%2FtYdkoEXV4UKUGGMnD1r38Nek1i42D7kGyW%2B9l4dctCyfnHY3fAg7Odth9k8bqqSHKTgBzHkoM7XTQC0vfau6E%2F9Zk7cDx8UPrKiYwdarE9GJENxHXZ8Anui%2Fn%2FQ7Z5VhX4W51AfOZ8DCq9CrVftVg%3D%3D&traceId=0b1ae75815750418143114219e&union_lens=lensId:0b014932_0c59_16eb7cecf3d_105d&xId=dSi7sUtxvAXXwy2Wu1CULJuCTlcx5pBAzEYp4j5NdOBRVCSIVFz6KnKvvnx39wr0ZRJzXy1NWOpkRoTlicLwZ8&activityId=4104e10171b94e3893024989c43a47e3', '', 1575041813);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (73, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=bwmAMICELwgEShog3g6x7kJQL%2FQJa9b%2BMAf1jAXZeeMzrA2vOqDyN%2FtSeDIxLwOT%2FtYdkoEXV4UKUGGMnD1r38Nek1i42D7kGyW%2B9l4dctCyfnHY3fAg7Odth9k8bqqSHKTgBzHkoM7XTQC0vfau6E%2F9Zk7cDx8UPrKiYwdarE9GJENxHXZ8Anui%2Fn%2FQ7Z5VhX4W51AfOZ8Cn5vCjwCiqA%3D%3D&traceId=0b0b576715750418159922839e&union_lens=lensId:0b14eee3_0c25_16eb7ced5db_b4af&xId=LqWbOQpB2jykABIveGuIneiFzMfJvGGjo1HJMU2ZCsMXFw4bBhearR7OA5AvW5ZS9pIETBynLSv3m4ALB7QRT0&activityId=4104e10171b94e3893024989c43a47e3', '', 1575041815);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (74, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=vLSs8vUJnAAEShog3g6x7kJQL%2FQJa9b%2BMAf1jAXZeeMzrA2vOqDyN%2FtSeDIxLwOT%2FtYdkoEXV4UKUGGMnD1r38Nek1i42D7kGyW%2B9l4dctCyfnHY3fAg7Odth9k8bqqSHKTgBzHkoM7XTQC0vfau6E%2F9Zk7cDx8UPrKiYwdarE9GJENxHXZ8Anui%2Fn%2FQ7Z5VkC8CVbRfvrY86ds3Wskk0w%3D%3D&traceId=0b86c13915750418252805364e&union_lens=lensId:0b1aff47_0c65_16eb7cefa1e_a4af&xId=JF60EoMSu3TUqIoyET72oiUKQbqMM15Zr4tXhnhVLNbcH7KOLhVHOhhJdVtruQOz5umiNAC4dTFB4VE7Sa42HA&activityId=4104e10171b94e3893024989c43a47e3', '', 1575041824);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (75, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=KhxVASz0Xl8GQASttHIRqUF46pV%2FAmIBbdtKy4Ast24SS6FA8WxTVSswBtzVzRI%2BFWYKO98VEvCw1hpvk1ZrHsWK7KkQZC%2FeY1kWovEdEWP2fRjS0VbpI%2FsnwWZGSCD41ug731VBEQm0m3Ckm6GN2CwynAdGnOngMmnVmWO1H8uqlgzVL09go1LajOROSSHlQl9nnhesZNGTbyQzXAPfUA%3D%3D&traceId=0b0f6dc915750815547388762e&union_lens=lensId:0b5797e1_0c9c_16eba2d3346_283f&xId=FqBDT1voSdxb2WymoikHcwXA28TCsvDDd7KZedEL0CrafkiohlGkTsTGFv3MVx8dPqrpWIcBfySAaC3kxBEhvm&activityId=25ef56dc93ac4da9be420cb79e3cd2aa', '', 1575081554);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (76, 2, 'http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=SYB4wHH7yFMGQASttHIRqWxJYP19D7xxzTlmBU7yF6FsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go1jhj%2BCmrjkaJ47rYvIjaE0z0BKd%2F02MBtYUXgYx689d7an2rmmOoVAAm1XlITZNWmRn%2BBpYv0SdWHz9c%2F8na%2FvMd%2FyxxETsAKoYEhJMcyFy&traceId=0b0b67fc15752932820127382e&union_lens=lensId:0b14eee3_0c25_16ec6cbe6ff_8b81&xId=doICHhG86Xs6tE7IE4Qzt3xGs0U5Z15ji9B6dmlFELu4xERICWcgsccACZh6en5T6cJsZ0ikK73NRqjUZsjqYF&activityId=53acbb53b4c541ca83dc3c9e53ae8233', '', 1575293281);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (77, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1575808902);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (78, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?activityId=&itemId=&src=tiger_tiger&pid=mm_711720113_1065450073_109733950492', '', 1575808903);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (79, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=YZw0XtCLnUQGQASttHIRqfOHItcMB52jl%2BPkT%2FHzGXUSS6FA8WxTVSswBtzVzRI%2BFWYKO98VEvCw1hpvk1ZrHsWK7KkQZC%2FeY1kWovEdEWP2fRjS0VbpI%2FsnwWZGSCD41ug731VBEQm0m3Ckm6GN2CwynAdGnOngMmnVmWO1H8uqlgzVL09go1LajOROSSHledzPF6LlcT7cHRUKGy7yaw%3D%3D&traceId=0b177a1d15758620185204848e&union_lens=lensId:0b57b76e_649a_16ee8b221ee_59f5&xId=RqCWpEKJOgYtaBxo12gvLZVMNGADezVtwtje1jduinZTxIOxLM9tuAGpqIIPtqtjy5gwx0BWMUIvoz2xi1lPZy&activityId=b480ab7f3350417f8b8683dd660db8fd', '', 1575862017);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (80, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=X6sao2SLxpMGQASttHIRqfOHItcMB52jl%2BPkT%2FHzGXVsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgU1c76%2BEA6oBgLmX24Q3jA%3D%3D&traceId=0b00a89915758620198627629e&union_lens=lensId:0b57bdf0_a0bb_16ee8b22731_b27b&xId=u3qzV2qw5yA5FEkJvZctmdp7LOWIpFAreRAQLMSPLOJUFZPXQp7GjDDaFwxldYZGG3fWkFCUxLt07zbURsavKI&activityId=b480ab7f3350417f8b8683dd660db8fd', '', 1575862019);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (81, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=P2RPz2%2BjifUE%2BdAb1JoOOpASfJ1XbxKTINgbbcFjeXQSS6FA8WxTVSswBtzVzRI%2BFWYKO98VEvCw1hpvk1ZrHsWK7KkQZC%2FeY1kWovEdEWP2fRjS0VbpI%2FsnwWZGSCD41ug731VBEQm0m3Ckm6GN2CwynAdGnOngMmnVmWO1H8uqlgzVL09go1LajOROSSHl5I2stO2HVQ07cKmzsGca7w%3D%3D&traceId=0b0b239e15758624578217578e&union_lens=lensId:0b57b76f_72b1_16ee8b8d5f5_86d3&xId=XgxNfjRCNcse0UVYeE3WaM3wYIa00VRLoG1rjmm3mreYyiUuJ8Dep8SjnWljATwQZ53LBApkIMgHUGM9UIi6DE&activityId=dd180cffc2f74be79fa836afd851a90e', '', 1575862456);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (82, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=7f4V8FKKQooE%2BdAb1JoOOpASfJ1XbxKTINgbbcFjeXRsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgU1c76%2BEA6pkmzWYeBiUKw%3D%3D&traceId=0b0921b215758624707811629e&union_lens=lensId:0bb698e5_7c64_16ee8b9089f_5705&xId=e4AJESXqR2rhB6ZfZorh4XWyJ0lAzE11CA0zf73qzucBw1xYHuBhPJgIDoyh8lFkSFAAP5mzKrpAHkQDqoVQcO&activityId=dd180cffc2f74be79fa836afd851a90e', '', 1575862469);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (83, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=7f4V8FKKQooE%2BdAb1JoOOpASfJ1XbxKTINgbbcFjeXRsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgU1c76%2BEA6pkmzWYeBiUKw%3D%3D&traceId=0b0921b215758624707811629e&union_lens=lensId:0bb698e5_7c64_16ee8b9089f_5705&xId=e4AJESXqR2rhB6ZfZorh4XWyJ0lAzE11CA0zf73qzucBw1xYHuBhPJgIDoyh8lFkSFAAP5mzKrpAHkQDqoVQcO&activityId=dd180cffc2f74be79fa836afd851a90e', '', 1575862497);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (84, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=84E6fwYDfRUGQASttHIRqfljh0yg9kk7nJe4lmgDHllsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah5QY0B1k%2B9VMAsAsGrdpSCQ%3D%3D&traceId=0b093e3315759414046257749e&union_lens=lensId:0bb36656_2e29_16eed6d77f4_30b3&xId=sg7H5PIozBzBCakOCHVSn29x3I4S6arXJE3rahw1lKq4Cb0KsRFdSjDx0G0f8ADxRnZGVpPJGhSnaPe1ELgBqJ', '', 1575941403);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (85, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=4KEbXUG6zxcGQASttHIRqfljh0yg9kk7nJe4lmgDHlkSS6FA8WxTVSswBtzVzRI%2BFWYKO98VEvCw1hpvk1ZrHsWK7KkQZC%2FeY1kWovEdEWP2fRjS0VbpI%2FsnwWZGSCD41ug731VBEQm0m3Ckm6GN2CwynAdGnOngMmnVmWO1H8uqlgzVL09go1LajOROSSHliDPkFdlPRyRFC8KKyKjnOA%3D%3D&traceId=0b0b07b615759414060895301e&union_lens=lensId:0b01e6c4_6e21_16eed6d7da5_ae2d&xId=loVMB35Kazmu9x6cSMWnQ7SAj5ALbyJyk4VPMc1iIWTpQi1NhzOBEGuuvYTKPh1gzk5RcPrPL3hGpDr4125SmV', '', 1575941405);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (86, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=c%2F2gPpqsHmIE%2BdAb1JoOOvmwStYNWCDixTryyRId665sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahIGFKC1B655gACMkgm8S3uQ%3D%3D&traceId=0b832dcd15759740451987448e&union_lens=lensId:0b00aee1_69e1_16eef5f862a_1327&xId=09MGunv965Mr8oAdcyPFZUhSah3aX3EZhyEva9LELjXCMAweIUoz7rjmajE4652AfEBYkiSMhgXzzwEL7CG0Yi&activityId=e57302fd8ff847e298e800cad46724b9', '', 1575974044);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (87, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=t%2F6pjJGzNeQGQASttHIRqc9IQ8Znq14rmspToVQPSe1sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahmyG4W2NO2d%2BsW7HzdqpqqQ%3D%3D&traceId=0b174cf015761211827915751e&union_lens=lensId:0b0fe08b_5568_16ef824aa6f_e43f&xId=Tbci4XLQClyUtyBYDR7mhzX56dlMtMVnJ7kMjRkZoYo5z7x6NEl1T7I6GpJ3Zok8Ns3u4hT701cUk0QW86PAuj&activityId=db7e412c50a444aaad65d0e8791e8b6b', '', 1576121181);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (88, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=mDp%2FaYGvVEEE%2BdAb1JoOOkW97ec7Z294B0xVa7Hf8KBsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahYK%2B6eNpmfFTaHGFAJl9nlw%3D%3D&traceId=0b1da63115761591550473632e&union_lens=lensId:0b582d96_7ffb_16efa68138a_55a1&xId=B3V5CuWlEu87q6iJJiOU6GhFB5kSaMWndglmeexROsHsICpAu8woOmKVXIlxXrLmDqOrZ5q7m7fsWnLCPqj52Q&activityId=fe24447879534fbaa260e181a639a6bc', '', 1576159154);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (89, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=zcYiNu8XmEoGQASttHIRqTt6HRrgOI2J3H2r%2BseeL6JsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahYK%2B6eNpmfFTwLfJOp4v%2BTw%3D%3D&traceId=0b01f68b15761591681861891e&union_lens=lensId:0b012f08_6b06_16efa6846d5_10bf&xId=WZrt7Qivl6FGCqUHPZXhWORDNt85PSZFxLWAGTKkZhfK2IPaQMWOr7eAsLx7JhqjpPGcw7tcnulPnhf05rYYTT&activityId=e70e6103f57d40e7b64262282f2bed82', '', 1576159167);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (90, 2, 'https://mobile.yangkeduo.com/duo_coupon_landing.html?goods_id=2338511&pid=9391813_121444005&authDuoId=1001373&cpsSign=CC_191215_9391813_121444005_0e0ab2c3cad7aab8e357c7b17da7b64f&duoduo_type=2', '', 1576413536);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (91, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://s.click.taobao.com/t?e=m%3D2%26s%3DJKHGwgfwepRw4vFB6t2Z2ueEDrYVVa64K7Vc7tFgwiHLWlSKdGSYDr0sWfyT5c5HRitN3%2FurF3yGBz2tD%2FpfpwbMlHRpsjCw75PdPnwzXPmvUE6ezNlCTDGt%2F00fI8fXYrCcptlIW4jdMjc%2Fx7mjXAtkyqhBb5%2B4tXsyH%2FO6UgQtCX2YSKt8jwvK2qQWj9arTHhX%2FZB3y5iFi4V5KBpmMuuVexceiRQzDTh%2BmJT03glrfD56BouYD1EsGBpbm51r&union_lens=lensId:0b150f1b_34a9_16f0cb6c2ac_753f&xId=ShUn4plj5lBZ44L4ay4y2Tj6cdWYrXAOnzmnXcS7fNHF8wE0VYhNs8bk0gwkdKPpPIwLPChamVAL8gh1WDxSqF', '', 1576466300);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (92, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=yxzxEVBaXlsE%2BdAb1JoOOuxHA5Whh9%2FO%2Ft1yjd4dz4dsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah9mdV%2Bf8EwfZQgAJwRBXXOg%3D%3D&traceId=0b0f803e15764855485267647e&union_lens=lensId:0b083dd4_4fb5_16f0ddc7219_080d&xId=L3t9KsgqYL355h6sK8Tk60pfmAw4hwnXXKl7OSnqdiTPc1dUjev9AW1xeP8gyoa2JSFWUssRr9CNm8BdcgQRbl&activityId=f76c69e6124543148a8421889e1d065e', '', 1576485547);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (93, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=LLoSvxSWq8kGQASttHIRqRsqdw9O003Nu5fBdyjfLDhsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah0fSjr14ETPkRo6TxVub5cg%3D%3D&traceId=0b157ac615764872671258541e&union_lens=lensId:0b57bdf0_a0bb_16f0df6ab5d_869f&xId=wnMzkN8ayv37miBat9yJeNSaNHTSerrv80j0jEVvnqARyUCKrutBk0BgiBtknN6NFPmBPB8Ppyj8GGSKfYPCKX&activityId=291a96491f1e4ce0a6671e307564ff8d', '', 1576487266);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (94, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=7X8f5figysME%2BdAb1JoOOv10XkuBoEDkU%2BArtsFxtUBsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah5KAqMm9PxYc5Hygke27PAg%3D%3D&traceId=0b0f97c815764889328098316e&union_lens=lensId:0b82dabf_6078_16f0e1015eb_20bb&xId=NdyzUYYdMh2aj4RgpU7lQ5FiND4qA5JYxg1A5A1SvSiBvUi4xun90HMADxnwaNW3rwpnP9RTD4iEjIFa73sqzI&activityId=1db82163886d4661a7c00d80200bd9ad', '', 1576488931);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (95, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=GGS1tez8IL0E%2BdAb1JoOOs58vxVfpuC4GNbDNMCqaspsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahodi4A3l1%2F69BOeLrobqKow%3D%3D&traceId=0b0b15b115764897463826222e&union_lens=lensId:0b083dd4_4fb5_16f0e1c7feb_3c53&xId=HQeo1dBBgfdgcD6KWhmMSuoMXhkDQsLdvTk7WlObNzRRW6twvib5XoEhgjio5JyneHcsJxgLyN9Po7PJRveRP9&activityId=6cfc7aada1a546b9b7b90a7b6e5559bb', '', 1576489745);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (96, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=vJNGoaB4gAEGQASttHIRqVgqGE2p%2B27vSiilryai2qpsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahfrKR3CZXbbEBgLmX24Q3jA%3D%3D&traceId=0b86c3e615764910195116375e&union_lens=lensId:0b183db1_47a0_16f0e2fed0e_5c1b&xId=lUxZxu4rLRx2GkUrS7YZt2mjHRi6eZKldju7dc12PSEv1iDlKGZNRWJOeBWsISJoxt7vKRcZ8LH6QTFHYeoNFc&activityId=696e45a90cc14c0d91a2824f2335d1fc', '', 1576491018);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (97, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=WeSa2xVD3%2BwE%2BdAb1JoOOmm5xOqablD6Ys7FC%2F530ZJsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahfrKR3CZXbbFf0lCEHYowmA%3D%3D&traceId=0b08170e15764910644174595e&union_lens=lensId:0b5797e2_43cd_16f0e309c7b_2c5d&xId=m4GGaVecXca6HunsPFbsK9wQJVaeMRMVGABbxPV61BouY6NxTHOkMjpkNHpebmldIgZcB6aPYBBfFl2sxoHf3a&activityId=2bc79a86b96c44b69567b7c127b39378', '', 1576491063);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (98, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=xb2447YWlmcE%2BdAb1JoOOuxHA5Whh9%2FO%2Ft1yjd4dz4dsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgW5okDTZME3eNAVzwI4rOA%3D%3D&traceId=0b0143f615765023338381963e&union_lens=lensId:0b013a8d_77eb_16f0edc91aa_2871&xId=BIIdSTWX0OnoOPhVq2jc4bWjurDgQgEdZjJa8hxjzWDHFIlTK3lUqKMDoPCD06aqZfiguY4qTwkSc6iZPOAAQH&activityId=f76c69e6124543148a8421889e1d065e', '', 1576502329);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (99, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=tsYO68a1M18E%2BdAb1JoOOuxHA5Whh9%2FO%2Ft1yjd4dz4dsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgW5okDTZME1jL7LGP3h%2FlA%3D%3D&traceId=0b14cf5815765023488988466e&union_lens=lensId:0bb85046_722f_16f0edccc85_3abb&xId=SoavPz4WXWe1OLDf6gkudLUIALW6zrywOwKSVAt3DkKslSJisIovLeJPZPgOA0dkEDaifjs1mGbnfsNEsqII15&activityId=f76c69e6124543148a8421889e1d065e', '', 1576502347);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (100, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=Eli6L68CuVQE%2BdAb1JoOOuxHA5Whh9%2FO%2Ft1yjd4dz4dsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgW5okDTZME33EoXWfqfVew%3D%3D&traceId=0b1b94ff15765026202247174e&union_lens=lensId:0b0f79e2_7da7_16f0ee0f059_987f&xId=mZpOEzeL8pszxkD5qiti4h92D7QW6QB41duR7daJcopDLHE50KddYbe9IqcyxjLtfsLLdnh1VIjmA8XaYu1s9Z&activityId=f76c69e6124543148a8421889e1d065e', '', 1576502618);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (101, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=gBxUfa98lKYE%2BdAb1JoOOuxHA5Whh9%2FO%2Ft1yjd4dz4dsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahgW5okDTZME2BU2%2FLVK6s5A%3D%3D&traceId=0b01e26515765026384161028e&union_lens=lensId:0b0b275f_5df6_16f0ee13763_3557&xId=s2s2Olj7Tsj3jBKV6j4jR4uAUcHeKY00NczmA4R5m8Ljjgc7QxjNObz7ij5sQCszCm5IsNMVCFy2GIgoUAV5M7&activityId=f76c69e6124543148a8421889e1d065e', '', 1576502637);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (102, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=&activityId=7700ed41dc214af1b61df86ec1d7b504', '', 1576502733);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (103, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=&activityId=7700ed41dc214af1b61df86ec1d7b504', '', 1576502735);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (104, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=Aumx1BKAqPwGQASttHIRqSJNZuoPTw7Sp%2FZhdn8UiFZsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go1jhj%2BCmrjkaJ47rYvIjaE0z0BKd%2F02MBtYUXgYx689d7an2rmmOoVAAm1XlITZNWmRn%2BBpYv0SdWHz9c%2F8na%2Fv6ZSNG0kE7PEbgYDHkL9Ur&traceId=0b0f833d15765499971874226e&union_lens=lensId:0b1b15bd_71be_16f11b3dac3_aa81&xId=AzJaAaLGEYiGlMn8bVaifUs43qCcaRzlMbV8uGm6sHf05Iilb339E0UzS0beeOVBYJGYyK5CdfARtAbf08ngz6', '', 1576549996);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (105, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=Aumx1BKAqPwGQASttHIRqSJNZuoPTw7Sp%2FZhdn8UiFZsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go1jhj%2BCmrjkaJ47rYvIjaE0z0BKd%2F02MBtYUXgYx689d7an2rmmOoVAAm1XlITZNWmRn%2BBpYv0SdWHz9c%2F8na%2Fv6ZSNG0kE7PEbgYDHkL9Ur&traceId=0b1b0efd15765499979368910e&union_lens=lensId:0b0fe08b_5568_16f11b3dd91_117b&xId=X6zMEWgA8hHF2yj6Wxt9nruuvwK3I7u1Vb6egZCBxcVFPI8vqHwgDvx4GXnsCpmEzmQoAMsxHO9MjLoOEnPdC8', '', 1576549994);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (106, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=Bjfn9TvRCIQGQASttHIRqSJNZuoPTw7Sp%2FZhdn8UiFZsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go1jhj%2BCmrjkaJ47rYvIjaE0z0BKd%2F02MBtYUXgYx689d7an2rmmOoVAAm1XlITZNWmRn%2BBpYv0SdWHz9c%2F8na%2Fv6ZSNG0kE7PH0dbnDbNpDs&traceId=0b081fac15765499981574722e&union_lens=lensId:0b5952e0_6302_16f11b3de76_22d3&xId=nYmOQqa2ACo3GWnxu4NvhSWAuIzv0LWiDXz77TubWZNgqVmft9a86n2qgmwCb4bAr86PpUJbLaFM01YJXLc15u', '', 1576549997);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (107, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=U45Iad54XcIGQASttHIRqSJNZuoPTw7Sp%2FZhdn8UiFYSS6FA8WxTVSswBtzVzRI%2BFWYKO98VEvCw1hpvk1ZrHsWK7KkQZC%2FeY1kWovEdEWP2fRjS0VbpI%2BT3b4zuHjpz1ug731VBEQm1M7QmaYJz9PFaBe2GOkPYHvfjMSYvfkGji5Mwp8diMCy%2FFMi1cPZNepVc1Ap6UyHY3EZzr055yguWiZ0MXyye&traceId=0b08670d15765500695335985e&union_lens=lensId:0b5832d4_6f49_16f11b4f540_b7cd&xId=Qj4hPokDfXat58kdE33eKFe2z7voe4hcrrvAWLDbMikC2KVlboaMU5bObrIe6t4Pv3YGrHs7yprfURzlPErQwM', '', 1576550068);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (108, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=H4ZPIxZQRuME%2BdAb1JoOOswavHaVY2GISuNX%2F0cyFv5sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahd61iB31f05Fn%2FQZikygb6w%3D%3D&traceId=0b0122a515767266957178439e&union_lens=lensId:0b1b15bd_71be_16f1c3c0f49_5fbf&xId=cXZlYt0PEVod4Mebm3hJgoRRj9GgoD8UUyuHBLhFBTfygEwIAuH7M9T6OkCipaX6HnLQxIy0xccloAlwjxIBdw&activityId=e82584289a8e4a4d9a437d81c5e96eab', '', 1576726695);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (109, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://s.click.taobao.com/t?e=m%3D2%26s%3DuhMgCF6LYItw4vFB6t2Z2ueEDrYVVa64K7Vc7tFgwiHLWlSKdGSYDiOaEOp5nXTGxq3IhSJN6GSVCgCoxkL1og4U2XdZmJMV60xlcdW47GeY7%2Fg3QYXtB5KBFy8zQxr9wupL2gBKGFQk9yklUGJqQwtkyqhBb5%2B4HoaaUnJGJVO9Uzn8kFKPMTqppXJR3Z43Tc7jC1Dcr3Sqb0hWbxXnCfur4HDFUljv%2BwpebU79MB8uTTwloQrlsw%3D%3D&union_lens=lensId:0b0130fe_5abe_16f1dd93faf_0ce9&xId=rz2xqIDJ9NgWaKhlqcZ1cKekKNbNLHMdiIjVCskcn0u005h8IJIHz80C9gS8LWSB5QYRIMQHbD0XuvoifSx6H0', '', 1576753773);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (110, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://s.click.taobao.com/t?e=m%3D2%26s%3DGImfpw%2BXZRxw4vFB6t2Z2ueEDrYVVa64K7Vc7tFgwiHLWlSKdGSYDkUm%2BHNR120y1aH1Hk3GeOiGBz2tD%2FpfpwbMlHRpsjCw75PdPnwzXPmvUE6ezNlCTDGt%2F00fI8fXDhmMGhBF57I2BNMESeSpaKLWMw3EOEsyJN2owMjhufxnc1i%2FI%2FAECIkfiAi21bAmzsAzH1xYDH5Qptb2qHDv0uvAMvIONPI9%2FdUnJAYyniqO9H5y53Iy%2FqJn5AyUbPoV&union_lens=lensId:0b0f79e2_7da7_16f1dd96d12_25a9&xId=cuOB1wJprXy3NeipKjYfDI9BOWr9WrulTbQAV6FDZPrSqfZ2vv9y0AvNV8WWwsS3JYBnPtnsc2S1FLDwfDZTaa', '', 1576753785);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (111, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=e90rynzvMrkE%2BdAb1JoOOk7hjEvYZiHUv9PVQ2yckYVsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahuwLF5zEUMHd33iwYh4tvHw%3D%3D&traceId=0b0fe8b615767541102083763e&union_lens=lensId:0b0b97cd_906d_16f1dde5f21_a933&xId=LTNCVkkJ9Ka8ZI8ChzInwMlC7DvCvKzICifwldySZHOSFMMS88jwEhPbhnCMevsbqYdJYcujO1gxq94F0hJARM&activityId=75e01834aa99446a8d5014338bcb459f', '', 1576754109);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (112, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=V8rDguf2maoE%2BdAb1JoOOr6wk6zjPNNYd1D7F4FAvW9sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahuwLF5zEUMHfwHOC%2F2%2FstmQ%3D%3D&traceId=0b0aef1a15767541514224740e&union_lens=lensId:0b57bdf2_79c2_16f1ddf001b_8675&xId=Mjwu6h6PYrvpYA1yUn6Dy6b0t6EZ9RbGbOwESvGgXxWYSYpFPbnjy7SQ3YfdtAZZZMUk8xDVybuxbjgJXPMv4O&activityId=7a394f8277c64eb2aa940d28e036a6a9', '', 1576754150);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (113, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=UHTTxrZ%2FexsE%2BdAb1JoOOr6wk6zjPNNYd1D7F4FAvW9sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahuwLF5zEUMHchExKX01chlw%3D%3D&traceId=0b0822e915767544944013061e&union_lens=lensId:0b0130fe_5abe_16f1de43be5_3e8b&xId=O7BX5jLEoKBXrWWLDfnE9MoUJjNgAevJkdgswTUAtxPozywPCzOW1eqkR25DQE2f9CUhoer7ipF3zu9JbURJdA&activityId=7a394f8277c64eb2aa940d28e036a6a9', '', 1576754493);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (114, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=RvkwRK28aWEE%2BdAb1JoOOqsF1aQVuA8izWMIjw26OppsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahuwLF5zEUMHcS9nIN7ex%2FIg%3D%3D&traceId=0b885b1b15767545620762204e&union_lens=lensId:0b014932_720e_16f1de5443a_87a3&xId=Ud6k7UHHNmDxz3djQ32HRMt0IbdvRmMFLGZyQm9gXEXiIcKG5XGyrNaSE6HsxtEPxlzAC23hKTWMZc8IdfG3C7&activityId=6615439ac32f46dc9fefcba94c30d43e', '', 1576754561);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (115, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=F0n6lz0VhYUE%2BdAb1JoOOis1ZLso7h49ycDKs42h7DNsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahuwLF5zEUMHcRp59mYKp0jw%3D%3D&traceId=0b1839bb15767547945816949e&union_lens=lensId:0b083dd4_4fb5_16f1de8d086_cc89&xId=lPsf1W8ZwWXGFKnHDKY2kOpmnKUixOMkIMqgEQy9XngddP7Tvk6VB06GEmiG21KzxexBVNQ8jdVbfG92GqK0Hu', '', 1576754793);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (116, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=%2B4NKB2Ne2wIGQASttHIRqWdXCcn%2BgpkivrnohoZnkIFsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah1J0CCqiZo1sIK7j9oLXI1Q%3D%3D&traceId=0b0817ca15767563197932070e&union_lens=lensId:0b82dabf_6078_16f1e00164d_89dd&xId=RTzbymt8N2MhJLfA2YOY0OQ66BkSikuulDKJgX7rRvUf7oumTdbrTu2Me5bLQrWx87DiH2rzlw7GYofcefZjVd&activityId=9df9c0a13b69467389395a0cdc04a30f', '', 1576756316);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (117, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=KM%2F2ZQQaNUIGQASttHIRqSFOc4AEhaowbR7chLIYC%2FNsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah1J0CCqiZo1sWiQBtgka%2Beg%3D%3D&traceId=0b0ba65a15767566753567818e&union_lens=lensId:0b0b97cd_906d_16f1e05833b_8bb9&xId=lc9LCco0MjV9pJukKXVKA1Kqa377qE1lCBVnwExu7Qoci1or70k2Hn4oXCDl9ULwe3Bxw57MfDYeiIQ9NeZMn1&activityId=a42457751421417eaab7abebdecddbc2', '', 1576756674);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (118, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=0hpahkE1WIoE%2BdAb1JoOOpAlTy9GQI5M10pml2VcUGpsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKah1J0CCqiZo1tT8221oGF3cw%3D%3D&traceId=0b14f07415767568778404445e&union_lens=lensId:0b183db1_47a0_16f1e089a26_cc95&xId=rWPGylf0jNbKXV4wUn8yFnCIADCyFXct4Do155D70aeW7rEH3uCjAAVvUC5WjPxgXL8uNYzrr3O3Tseivph8wI&activityId=957b4d42d1e24489843baf5632c364f6', '', 1576756877);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (119, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=7DnM9%2BPI2WME%2BdAb1JoOOvIoqdGWVFnSk1xXpnFweJFsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahVG2feyfh5VOaZLYyV72J5w%3D%3D&traceId=0b085fd115767571187515201e&union_lens=lensId:0b0b275f_5df6_16f1e0c4732_06d5&xId=Vh5FWejMhGQyiQeNZwKrAVNBcOXga84OFdPFGsQzAIp1raGeeS30h0AOiy30cMNbRWiOJ5aeFWb1FKCuQwwi9j&activityId=1fbecd2db8f94aaea82673b9fd691776', '', 1576757118);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (120, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=vUPnoigEiYwE%2BdAb1JoOOhcJcpFtMe1lthekuInOhbxsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahoOC6q%2BH%2Fv7FvAOX06F9lsg%3D%3D&traceId=0b57cd0715767644596701312e&union_lens=lensId:0b835d09_1e7b_16f1e7c4aaf_388f&xId=qEHMOU93ZMqlMsEKKEToqdYAXxRkjNeCCwP3JJMHvUXsLcSLTrv9MbXxucMAVp8M5copNBkchLgSTWdQvlCud4&activityId=19d217e0c584420d9b3614f21397df0e', '', 1576764458);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (121, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=omQIA9VVqNME%2BdAb1JoOOjuQUQKB7bWGUTTguBF6FkZsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahFhYHLiYivj8OZXQerGyp0A%3D%3D&traceId=0b0b871415768405758526129e&union_lens=lensId:0bba83d1_531d_16f2305bb8f_6a39&xId=so6mjaQZvU6xw9ij2GdhRH4ILM0xZDiEIc3txCc2AAFQs9fNjPWHjglsGsUId17dWfWQixqVdbOZrrD0RFBWhi&activityId=836c898907dd409b94ed231259311053', '', 1576840574);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (122, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=OhY5MSPwpgEE%2BdAb1JoOOu5tUxLIMLikQaaFeuSHJdhsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahmuAy5kNMgLaePn9FZDoDZg%3D%3D&traceId=0b01ce8215769782566691620e&union_lens=lensId:0bb36656_2e29_16f2b3a9344_7c3b&xId=7rci3lE45YPVZU1Vz1zVm3j4mb4NiqXYyytBdiiPbSYD89FMQzruOyibvmbFyinuGQ5LbK3oZFMQ8Xd6RWWTxI&activityId=74bca62cf7f244d69810c96473d0e01e', '', 1576978254);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (123, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=WxertD6CQ2gE%2BdAb1JoOOu5tUxLIMLikQaaFeuSHJdhsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahmuAy5kNMgLZ1psqE%2Bf8f4w%3D%3D&traceId=0b0b45c915769782588437663e&union_lens=lensId:0b01c1f1_82ba_16f2b3a9bb6_c531&xId=MqilMrsLuk0OIY2MGxnOkQuf2WczVXvwvSqKrrdY5ZG39DiZSILLslNqfKjLycl3qy42afIRDs5JNRcej8MdRc&activityId=74bca62cf7f244d69810c96473d0e01e', '', 1576978258);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (124, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=yJTMZF%2BML5YE%2BdAb1JoOOt80Iiz%2BVMhNAH7Lw%2BR2iRVsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahsjvQ%2FEXD3j7%2Blgqe8Gifug%3D%3D&traceId=0b0fad8115771757028732246e&union_lens=lensId:0b57bdf1_45bd_16f36ff5d84_426f&xId=8WLgH2bugKAi4buF9Ezu8ySroc3wmHB4ZSEoQGi7YhPPT3nSXra1iyKrKIwNfmIboW5W9Vh5vgB58EqnKhJFTl&activityId=14e4e15d6c0d4cefa1e034eabcc007bc', '', 1577175702);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (125, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=qGo3MuUk%2BsoE%2BdAb1JoOOoOhPK6oQrkXRMenv0eIfVxsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahNUXjWi5lc9xdWu0eoWPBSQ%3D%3D&traceId=0b57b79515772483255221293e&union_lens=lensId:0b57b768_7d12_16f3b537fb5_ce67&xId=ii2uRtVV2aTeaHgZOIdl8n2mrLta7MoKsStGw9YjTh8PkklYecGjuVQyNN0tWdaNDJDjkPCNRToW7BvfXYehzB&activityId=8dde3cd2621946bcadf9b81e6e7b09bc', '', 1577248324);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (126, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=AcN6r9pj%2BzQGQASttHIRqTCpwg7IU4uOeE%2FZWGw7M21sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahNUXjWi5lc9yZnXNSa1ys1A%3D%3D&traceId=0b154b6315772484323208283e&union_lens=lensId:0b57b5a6_6387_16f3b5520e5_54e9&xId=yeQLEKRnji4snXlNUr1GWKU8bkQPb1VwtjvxqrQBFTX6tXd9fn9OVUAocsjMtYSbfLGqKc8liHHYdeYPjz5aou', '', 1577248431);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (127, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://s.click.taobao.com/t?e=m%3D2%26s%3D%2B8LODG8iOeRw4vFB6t2Z2ueEDrYVVa64LKpWJ%2Bin0XLLWlSKdGSYDoIsXZ3aCduu79%2FTFaMDK6SGBz2tD%2FpfpwbMlHRpsjCw75PdPnwzXPmvUE6ezNlCTDGt%2F00fI8fX6ttja8TfT1VguCj90BkcdaLWMw3EOEsyGtHDED2isd1r%2F%2Fuy%2FvaGLKGaKyVwGuhDA13NwUW6D5vHcEXMeyvVP3iufcvCu6QSVYIW1Uc%2BpRL%2BZbP3lfQuh8YOae24fhW0&union_lens=lensId:0b183db1_47a0_16f3b56e960_523d&xId=jXiCZU0jMWb8fd1sM2YZSkzEpGY4kh0GjgMKCG6miefmwLExkWM0Ve1Qcl2EwBqhIGPqKLPfbWHXwIe4I7y0qr', '', 1577248548);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (128, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://s.click.taobao.com/t?e=m%3D2%26s%3DvWM3ENrtACVw4vFB6t2Z2ueEDrYVVa64LKpWJ%2Bin0XLLWlSKdGSYDh7CSyiEevaOt4hWD5k2kjOGBz2tD%2FpfpwbMlHRpsjCw75PdPnwzXPmvUE6ezNlCTDGt%2F00fI8fX6ttja8TfT1VguCj90BkcdaLWMw3EOEsyGtHDED2isd1r%2F%2Fuy%2FvaGLKGaKyVwGuhDA13NwUW6D5vHcEXMeyvVP3iufcvCu6QSVYIW1Uc%2BpRL%2BZbP3lfQuh8YOae24fhW0&union_lens=lensId:0b582879_551c_16f3b5aa3e4_ba55&xId=W6awPepp8HS1aaUhS2440xWvGDVZ6tz2MtXm9ipaKApfti5A2zxzIhtH1VDFKqGnOXpWlg9GYYsNSk8SL1qUXZ', '', 1577248792);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (129, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://s.click.taobao.com/t?e=m%3D2%26s%3D1NmhBSf17eNw4vFB6t2Z2ueEDrYVVa64K7Vc7tFgwiHLWlSKdGSYDoYQl60LaHFd1aH1Hk3GeOiVCgCoxkL1og4U2XdZmJMV60xlcdW47GeY7%2Fg3QYXtB5KBFy8zQxr9O0uGuaEmMJyjNicLtMYZ%2BAtkyqhBb5%2B4tXsyH%2FO6UgQtCX2YSKt8jwvK2qQWj9arTHhX%2FZB3y5iFi4V5KBpmMgCnG3syJHYz6%2Ffn2N8t%2FsFrfD56BouYD1EsGBpbm51r&union_lens=lensId:0b183db1_47a0_16f3fe20c65_2eaf&xId=u7MTVZTK4TOOC1I9NxrHQfi8FD55Zp8DYmqiKO4ptOfh1l5b8i6UhqmHYq47g46Q9sbEZl6IEGE6VGBVVbxtk5', '', 1577324775);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (130, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=effeR6jT80EE%2BdAb1JoOOoCkbWUsENLX4KU0dh0BSTdsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahxvVmqyTmgZdfcgSu9ccj%2BQ%3D%3D&traceId=0b0b5e5d15773370268501242e&union_lens=lensId:0b0ad760_7f06_16f409cf949_4163&xId=MgwjVWmDmHqKMWzHNcCQzrjgHh7y91lfRK31c8iE3lIXtML2TkHfNXngs5uI2QVVH8zHh0TUyzyVqzdj6pFhLK', '', 1577337026);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (131, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=Oyuvpz%2FFq0EE%2BdAb1JoOOqwPvH6w4VTFeMG8Ji1zoO5sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go1jhj%2BCmrjkaJ47rYvIjaE2UV%2BXZNWcI1dBSRpWnAq%2BD1WozoFaXPfzZ2gTnT%2FCzypeXEGILbROWLDE0JxN1V29l8vv2xTbQKw%3D%3D&traceId=0b15138815773370966161338e&union_lens=lensId:0b183db1_47a0_16f409e09db_c621&xId=CCOpSU134LnGErCtyLUY4PX4ZCu2bLwLSEtTxbUJfZ1U9QV2BwIQek8BHOllwLVIn4fWB8B9Sn6V8M74D8XCfq', '', 1577337095);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (132, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=4VZJmp0z8PQGQASttHIRqYsVWpo2CFZPM4vO629MCH9sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go1jhj%2BCmrjkaJ47rYvIjaE0z0BKd%2F02MBtYUXgYx689d7an2rmmOoVAAm1XlITZNWmRn%2BBpYv0SdWHz9c%2F8na%2Ft9nkkRoQNU1o6tJAYwJB2M&traceId=0b0ad91815773370997412306e&union_lens=lensId:0b0ad760_7f06_16f409e160a_7ad1&xId=0dKCPdljV1qcr3JV50MLSNk9D8zgyalwqt7AnyVnMLloiN6DQn07PxxWXCCXEtp454ku9T38rbvWtG11jeherk', '', 1577337099);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (133, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=qQzNr9DhBv0GQASttHIRqYsVWpo2CFZPM4vO629MCH9sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go1jhj%2BCmrjkaJ47rYvIjaE0z0BKd%2F02MBtYUXgYx689d7an2rmmOoVAAm1XlITZNWmRn%2BBpYv0SdWHz9c%2F8na%2Ft9nkkRoQNU1qlr2RBufSJW&traceId=0bba882315773371545298909e&union_lens=lensId:0b582d96_7ffb_16f409eec15_3e0f&xId=7MAeEbIcosDVrxlABPixpNzGDp15tUULj1Kv0jn063uKO6hBKBkRow7nYJ6OOIkoDBckU32auAWGbFVOC20Mqy', '', 1577337153);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (134, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=9nVeMF161JIGQASttHIRqUff6EkyqlwN2z4OlYa4Ve0SS6FA8WxTVSswBtzVzRI%2BFWYKO98VEvCw1hpvk1ZrHsWK7KkQZC%2FeY1kWovEdEWP2fRjS0VbpI%2FsnwWZGSCD41ug731VBEQm0m3Ckm6GN2CwynAdGnOngMmnVmWO1H8uqlgzVL09go1LajOROSSHl9%2BNr2DRKbueY6yLLt5ZCZQ%3D%3D&traceId=0b176cea15773628890223749e&union_lens=lensId:0b01decb_4a69_16f42279961_8fb3&xId=I2qJozNHkY48rAgzHm54LXaUDQ9M54KO8nqTCHdijB0uJAIbehaNd2dayJmD0pVR0B49utF69qjyU17E8HjDWJ', '', 1577362888);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (135, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=6rQqTSJWu0AGQASttHIRqW%2Fz3SqxnqKt73OJeR7aF3FsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahFfomEHxYP7%2FClX05%2FgLQNA%3D%3D&traceId=0b0803e315773633852094823e&union_lens=lensId:0b5797e1_49d2_16f422f2ba2_3ac5&xId=dF47d9Icz8Xwy95ZT7OlcwaHLHggxgX0tBnUIa0kdh2yHoVtJqS2zGqLRy1MH3YJznzXm7mFMs7zXUHFz4m5gP', '', 1577363384);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (136, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://s.click.taobao.com/t?e=m%3D2%26s%3DyMgeGA7S%2FGVw4vFB6t2Z2ueEDrYVVa64K7Vc7tFgwiHLWlSKdGSYDkfKOUIOQz4Rlovu%2FCElQOuGBz2tD%2FpfpwbMlHRpsjCw75PdPnwzXPmvUE6ezNlCTDGt%2F00fI8fXn03vNUqH3UoSm%2FL%2BIH10WwtkyqhBb5%2B4tXsyH%2FO6UgQtCX2YSKt8jwvK2qQWj9arTHhX%2FZB3y5iFi4V5KBpmMt09SpEwYM5EoiGmDWsD9AVrfD56BouYD1EsGBpbm51r&union_lens=lensId:0b57b5a6_6387_16f42d42747_5563&xId=GPLRS4x4kCOr2NC4tmb8akzbhdNZJ8DxRuENNFJpZfQLYWkUHrQMjlJ5VbteLAW7ld0ye0gNuWUALPbwFiozWz', '', 1577374196);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (137, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=IZ8bn6og9pcE%2BdAb1JoOOnPUhASHv1qs5kpzhJzuHfNsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go1jhj%2BCmrjkaJ47rYvIjaE0z0BKd%2F02MBtYUXgYx689d7an2rmmOoVAAm1XlITZNWmRn%2BBpYv0SdWHz9c%2F8na%2Ft9nkkRoQNU1srbIIQprFgX&traceId=0b1534f515773751083115306e&union_lens=lensId:0b153bbd_7afb_16f42e20d07_293d&xId=lMdR4y0OWEytDG4C92ALlBgzNnAcYKUtCxtrqQR2DhaHIXrEKeJFx99aoGBy2gewxWJxPfb3R1cWAcFTO8JhY', '', 1577375107);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (138, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=YqaXg7qk%2B9QGQASttHIRqVgZVLnOP71ZIEdnRQZ2tqBsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahFEkscIbebdXeJ5ZYh70y8w%3D%3D&traceId=0baf7d5315773783726286815e&union_lens=lensId:0b582459_50b1_16f4313dc38_63cf&xId=lQStBkZGKMImPXC34qzFUhlp3UjhblTrKpD5k8we3BJfsI1NtUnccmEAHAmtf12ydVxchiXzwtfyUhn5JdMhga&activityId=38e9df13e46748c7b384bd94d5d77aef', '', 1577378372);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (139, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=EcRFOOuR1yY8Clx5mXPEKlC%2BBlnHs%2Fm7%2FGbGabemPNIbEmd6w9Yyv%2BVM7%2F26E6q7e2Y36qRLQJ%2BUuA93mugYte83bVesLljxY1kWovEdEWP2fRjS0VbpI%2FsnwWZGSCD41ug731VBEQm0m3Ckm6GN2CwynAdGnOngMmnVmWO1H8uqlgzVL09go1LajOROSSHl1qpD56H4LOfSJpyBtVc30g%3D%3D&traceId=0b0837d115773785179076444e&union_lens=lensId:0b153bbd_7afb_16f431613b7_ca0b&xId=ONO7Ftv9yRZJ4nxt4XMyrmvGbQYaV6Xw1cc9piYtxA3aDTXjGsftOGhqU1XHZR9nrKZAHyQJcNL9MQEqT4IzQL&activityId=f579bfd645f04cd193aa0c54014ccf57', '', 1577378516);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (140, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=BEVz0hQJVFAE%2BdAb1JoOOkhIMvgFUiBve9ayVR0DiTdsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahN1%2BpNXfLLzdKoDHeja4ItQ%3D%3D&traceId=0b0143f615773797778047073e&union_lens=lensId:0b1540db_7465_16f43294d28_bd0b&xId=bPDXOD8K5ZYr5qTIVm0TS2cS32dvjSZtLRgkwINgMeNCShCA9WgYcAHf2icH9jxYlGBfrdSw4jJZtxCsnTby45&activityId=142f93120df44e5c96c2283eeed77c48', '', 1577379777);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (141, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=I0bAW0vBtrQGQASttHIRqczqLopSN1eIrXxsxcZOZuRsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahN1%2BpNXfLLzcDaEIQVnCJRQ%3D%3D&traceId=0b09279715773798340373909e&union_lens=lensId:0b5952e0_6302_16f432a28d5_8529&xId=kSfURNvyZmkNwkiGrhRq5AIY4zj3Y2Tjr0PlKVA7GUtCM25Q5JZ8gjQGbCRBwScN1CtlGavjrEJzGgbuZX7NFg', '', 1577379833);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (142, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=X27LvUc48ywE%2BdAb1JoOOubZpfuGiK4UUciUtEerUJVsW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahk5yc1eRcfiZPkIuwPS4jVA%3D%3D&traceId=0b0b2a3415773807702923003e&union_lens=lensId:0b5952e0_6302_16f43387215_5dad&xId=Ei6w6YB5SeZs0AvPolc9kmARrgFji0mZhcQMGc4TZ470CQCuEUkbXpn5uGxAZLFayedQ3gwoSTTTzU9ovMvHuT', '', 1577380769);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (143, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=https://uland.taobao.com/coupon/edetail?e=oyiudiDMABAGQASttHIRqUff6EkyqlwN2z4OlYa4Ve1sW%2Fv38CNHVpgjv%2F7X5Wb71s3mf9HnqhLjcOHiC4k4CvAA9eU%2Fo2Q5SEyvAL3v9LKqlgzVL09go7CSyLFw4qsuJ47rYvIjaE20%2Bc5Gzwi6gW5us6IkMHWUSn4qX%2BrddxhiS4mWhXrmg9l4X1VWjKahaHyhiO7CzZVpjujTOBVijg%3D%3D&traceId=0b17769d15774183042602106e&union_lens=lensId:0b150f1b_34a9_16f45752b3a_6d55&xId=fA8cWXB3A1xzUwfNAce1IcEBRIpPzPG7UDoD7WkwvTec5Jv1BY9yF37rEN19PMcSFB3TJcbdWxxdpwJv6xJXCB', '', 1577418303);
INSERT INTO `ims_tiger_newhu_dwz` VALUES (144, 2, 'http://hztbk.wjlnfs.com/app/index.php?i=2&c=entry&do=openview&m=tiger_newhu&link=&activityId=', '', 1577507391);
COMMIT;

-- ----------------------------
-- Table structure for ims_tiger_newhu_faquan
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_faquan`;
CREATE TABLE `ims_tiger_newhu_faquan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `type` varchar(250) DEFAULT '0',
  `title` varchar(250) DEFAULT '0',
  `content` text,
  `piclist` text,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_fztype
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_fztype`;
CREATE TABLE `ims_tiger_newhu_fztype` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `px` int(10) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL,
  `fftype` int(3) NOT NULL DEFAULT '0' COMMENT '分类',
  `dtkcid` varchar(10) NOT NULL COMMENT '大淘客分类',
  `hlcid` varchar(10) NOT NULL COMMENT '互力分类',
  `picurl` varchar(255) NOT NULL COMMENT '封面',
  `picurl2` varchar(255) NOT NULL COMMENT '搜索界面图标',
  `wlurl` varchar(255) NOT NULL COMMENT '外链',
  `tag` varchar(250) NOT NULL COMMENT '男装 衬衫|男装 裤',
  `createtime` int(10) NOT NULL,
  `cid` varchar(100) DEFAULT NULL,
  `sokey` varchar(100) DEFAULT NULL,
  `shztype` varchar(10) DEFAULT '' COMMENT '实惠猪分类',
  `ysdtype` varchar(10) DEFAULT '' COMMENT '一手单分类',
  `tkzstype` varchar(10) DEFAULT '' COMMENT '淘客助手分类',
  `qtktype` varchar(10) DEFAULT '' COMMENT '轻淘客分类',
  `hpttype` varchar(10) DEFAULT '' COMMENT '好品推分类',
  `tkjdtype` varchar(10) DEFAULT '' COMMENT '淘客基地分类',
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `fftype` (`fftype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_fztype2
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_fztype2`;
CREATE TABLE `ims_tiger_newhu_fztype2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `px` int(10) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL COMMENT '二级分类名称',
  `cid` int(5) NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `picurl` varchar(255) NOT NULL COMMENT '封面',
  `wlurl` varchar(255) NOT NULL COMMENT '外链',
  `sokey` varchar(250) NOT NULL COMMENT '搜索关键词',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `cid` (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_gfhuodong
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_gfhuodong`;
CREATE TABLE `ims_tiger_newhu_gfhuodong` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `px` int(10) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL,
  `type` int(3) NOT NULL DEFAULT '0' COMMENT '分类',
  `picurl` varchar(255) NOT NULL COMMENT '图片',
  `turl` varchar(255) NOT NULL COMMENT '外链',
  `kouling` varchar(255) NOT NULL COMMENT '口令',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_goods
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_goods`;
CREATE TABLE `ims_tiger_newhu_goods` (
  `goods_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `px` int(10) NOT NULL DEFAULT '0',
  `shtype` int(2) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL,
  `hot` varchar(50) NOT NULL,
  `hotcolor` varchar(50) NOT NULL,
  `leibei` varchar(10) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `appurl` varchar(300) DEFAULT '0',
  `amount` int(11) NOT NULL DEFAULT '0',
  `day_sum` int(11) NOT NULL DEFAULT '0',
  `cardid` varchar(200) NOT NULL,
  `taokouling` varchar(200) NOT NULL,
  `deadline` datetime NOT NULL,
  `per_user_limit` int(11) NOT NULL DEFAULT '0',
  `starttime` varchar(12) DEFAULT NULL,
  `endtime` varchar(12) DEFAULT NULL,
  `cost` int(11) NOT NULL DEFAULT '0',
  `cost_type` int(11) NOT NULL DEFAULT '1' COMMENT '1系统积分 2会员积分 4,8等留作扩展',
  `price` decimal(10,2) NOT NULL DEFAULT '0.10' COMMENT '商品价格',
  `fxprice` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '返现',
  `vip_require` int(10) NOT NULL DEFAULT '0' COMMENT '兑换最低VIP级别',
  `content` text NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT '是否需要填写收货地址,1,实物需要填写地址,0虚拟物品不需要填写地址',
  `dj_link` varchar(255) NOT NULL,
  `wl_link` varchar(255) NOT NULL,
  `createtime` int(10) NOT NULL,
  `ordrsum` int(11) DEFAULT '0',
  `ordermsg` varchar(200) DEFAULT '',
  PRIMARY KEY (`goods_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_hexiao
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_hexiao`;
CREATE TABLE `ims_tiger_newhu_hexiao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `dianyanid` int(11) DEFAULT '0',
  `openid` varchar(50) DEFAULT '0',
  `nickname` varchar(50) DEFAULT '0',
  `ename` varchar(50) DEFAULT '0',
  `companyname` varchar(200) DEFAULT '0',
  `goodname` varchar(200) DEFAULT '0',
  `goodid` int(11) DEFAULT '0',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_jdorder
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_jdorder`;
CREATE TABLE `ims_tiger_newhu_jdorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `finishTime` varchar(100) DEFAULT '0' COMMENT '订单完成时间',
  `orderEmt` varchar(100) DEFAULT '0' COMMENT '下单设备(1:PC,2:无线)',
  `orderId` varchar(100) DEFAULT '0' COMMENT '订单ID',
  `orderTime` varchar(100) DEFAULT '0' COMMENT '下单时间',
  `parentId` varchar(255) DEFAULT '0' COMMENT '父单ID（订单拆分后,父单的订单号）',
  `payMonth` varchar(255) DEFAULT '0' COMMENT '结算日期（yyyyMMdd）',
  `plus` varchar(255) DEFAULT '0' COMMENT 'plus会员（0：不是，1：是）',
  `popId` varchar(255) DEFAULT '0' COMMENT '商家ID',
  `actualCommission` varchar(255) DEFAULT '0' COMMENT '实际佣金',
  `actualCosPrice` varchar(255) DEFAULT '0' COMMENT '实际计佣金额',
  `actualFee` varchar(255) DEFAULT '0' COMMENT '站长的实际佣金',
  `commissionRate` varchar(255) DEFAULT '0' COMMENT '佣金比例',
  `estimateCommission` varchar(255) DEFAULT '0' COMMENT '预估佣金',
  `estimateCosPrice` varchar(20) DEFAULT '0' COMMENT '预估计佣金额',
  `estimateFee` varchar(150) DEFAULT '0' COMMENT '站长的预估佣金',
  `finalRate` varchar(150) DEFAULT '0' COMMENT '最终比例 (一级分佣比例*二级分佣比例)',
  `firstLevel` varchar(150) DEFAULT '0' COMMENT '一级类目',
  `frozenSkuNum` varchar(150) DEFAULT '0' COMMENT '商品售后中数量',
  `payPrice` varchar(10) DEFAULT '0' COMMENT '实际支付金额',
  `pid` varchar(50) DEFAULT '0' COMMENT '子站长ID_子站长网站ID_子站长推广位ID',
  `price` varchar(20) DEFAULT '0' COMMENT '商品单价',
  `secondLevel` varchar(10) DEFAULT '0' COMMENT '二级类目',
  `siteId` varchar(20) DEFAULT '0' COMMENT '网站ID',
  `skuId` varchar(20) DEFAULT '0' COMMENT '商品ID',
  `skuName` varchar(300) DEFAULT '0' COMMENT '商品名称',
  `skuNum` varchar(100) DEFAULT '0' COMMENT '商品数量',
  `skuReturnNum` varchar(10) DEFAULT '0' COMMENT '商品已退货数量',
  `spId` varchar(50) DEFAULT '0' COMMENT '推广位ID',
  `subSideRate` varchar(50) DEFAULT '0' COMMENT '分成比例',
  `subUnionId` varchar(50) DEFAULT '0' COMMENT '子联盟ID',
  `subsidyRate` varchar(50) DEFAULT '0' COMMENT '补贴比例',
  `thirdLevel` varchar(50) DEFAULT '0' COMMENT '三级类目',
  `traceType` varchar(50) DEFAULT '0' COMMENT '2同店 3跨店',
  `unionAlias` varchar(50) DEFAULT '0' COMMENT '第三方服务来源',
  `unionTrafficGroup` varchar(50) DEFAULT '0' COMMENT '渠道组（1：1号店，其他：京东）',
  `unionTag` varchar(50) DEFAULT '0' COMMENT '联盟标签数据',
  `validCode` varchar(50) DEFAULT '0' COMMENT '有效码（-1：未知,2.无效-拆单,3.无效-取消,4.无效-京东帮帮主订单,5.无效-账号异常,6.无效-赠品类目不返佣,7.无效-校园订单,8.无效-企业订单,9.无效-团购订单,10.无效-开增值税专用发票订单,11.无效-乡村推广员下单,12.无效-自己推广自己下单,13.无效-违规订单,14.无效-来源与备案网址不符,15.待付款,16.已付款,17.已完成,18.已结算）',
  `unionId` varchar(50) DEFAULT '0' COMMENT '站长ID',
  `unionUserName` varchar(50) DEFAULT '0' COMMENT '扩展信息',
  `createtime` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ord_w_id` (`weid`,`orderId`,`skuId`),
  KEY `weid` (`weid`),
  KEY `orderTime` (`orderTime`),
  KEY `finishTime` (`finishTime`),
  KEY `spId` (`spId`),
  KEY `orderId` (`orderId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_jdtjorder
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_jdtjorder`;
CREATE TABLE `ims_tiger_newhu_jdtjorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '0',
  `nickname` varchar(255) DEFAULT '0',
  `avatar` varchar(255) DEFAULT '0',
  `jlnickname` varchar(255) DEFAULT '0' COMMENT '订单所有人',
  `jlavatar` varchar(255) DEFAULT '0' COMMENT '订单所有人',
  `memberid` varchar(255) DEFAULT '0' COMMENT '微擎会员编号',
  `uid` varchar(20) DEFAULT NULL COMMENT '用户UID share表',
  `orderid` varchar(255) DEFAULT '0' COMMENT '订单编号',
  `price` varchar(255) DEFAULT '0' COMMENT '奖励金额',
  `yongjin` varchar(255) DEFAULT '0' COMMENT '佣金',
  `type` varchar(255) DEFAULT '0' COMMENT '类型 0 自有  1级奖励 2级奖励',
  `sh` varchar(255) DEFAULT '0' COMMENT '是否审核 0  1待返 2已返 3审核 4失效',
  `msg` varchar(255) DEFAULT '0' COMMENT '留言',
  `itemid` varchar(100) DEFAULT '0' COMMENT '商品ID',
  `jl` varchar(20) DEFAULT '0' COMMENT '奖励金额或是积分',
  `jltype` int(10) DEFAULT '0' COMMENT '0积分 1余额',
  `createtime` varchar(255) NOT NULL,
  `cjdd` int(10) DEFAULT '0',
  `jluid` varchar(20) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `indx_weid` (`weid`),
  KEY `itemid` (`itemid`),
  KEY `indx_orderid` (`orderid`),
  KEY `indx_openid` (`openid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_jdyfgorder
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_jdyfgorder`;
CREATE TABLE `ims_tiger_newhu_jdyfgorder` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `uid` varchar(100) NOT NULL,
  `orderid` varchar(100) NOT NULL,
  `ordertime` varchar(50) NOT NULL,
  `finishtime` varchar(50) NOT NULL,
  `pid` varchar(50) NOT NULL,
  `goods_id` varchar(100) DEFAULT '0',
  `goods_name` varchar(200) NOT NULL,
  `goods_num` varchar(10) NOT NULL DEFAULT '0',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  `goods_frozennum` varchar(50) NOT NULL,
  `goods_returnnum` varchar(50) NOT NULL,
  `cosprice` varchar(20) NOT NULL,
  `subunionid` varchar(100) NOT NULL,
  `yn` varchar(10) NOT NULL,
  `sh` varchar(2) DEFAULT '0',
  `ynstatus` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_weid` (`weid`),
  KEY `orderid` (`orderid`),
  KEY `ordertime` (`ordertime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_jl
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_jl`;
CREATE TABLE `ims_tiger_newhu_jl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `weid` int(11) NOT NULL,
  `type` int(11) NOT NULL COMMENT '0 积分  1 余额',
  `typelx` tinyint(3) unsigned NOT NULL COMMENT '1签到    2关注邀请    3取消关注   4订单奖励',
  `num` decimal(30,2) NOT NULL DEFAULT '0.00' COMMENT '金额和积分 有正负',
  `createtime` int(10) unsigned NOT NULL COMMENT '创建时间',
  `remark` varchar(200) NOT NULL COMMENT '如：签到奖励',
  `orderid` varchar(200) NOT NULL COMMENT '订单号',
  PRIMARY KEY (`id`),
  UNIQUE KEY `wuncid` (`weid`,`uid`,`num`,`createtime`),
  KEY `weid` (`weid`),
  KEY `type` (`type`),
  KEY `typelx` (`typelx`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_lxorder
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_lxorder`;
CREATE TABLE `ims_tiger_newhu_lxorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `addtime` varchar(50) DEFAULT NULL,
  `jhtime` varchar(50) DEFAULT NULL,
  `sgtime` varchar(50) DEFAULT NULL,
  `newtel` varchar(50) DEFAULT NULL,
  `xrzt` varchar(100) DEFAULT NULL,
  `ddlx` varchar(100) DEFAULT NULL,
  `fxyh` varchar(100) DEFAULT NULL,
  `mtid` varchar(100) DEFAULT NULL,
  `mtname` varchar(100) DEFAULT NULL,
  `tgwid` varchar(100) DEFAULT NULL,
  `tgwname` varchar(100) DEFAULT NULL,
  `orderid` varchar(100) DEFAULT NULL,
  `createtime` int(10) NOT NULL,
  `qrshtime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `tgwid` (`tgwid`),
  KEY `addtime` (`addtime`),
  KEY `sgtime` (`sgtime`),
  KEY `xrzt` (`xrzt`),
  KEY `ddlx` (`ddlx`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_mdorder
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_mdorder`;
CREATE TABLE `ims_tiger_newhu_mdorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '0',
  `nickname` varchar(255) DEFAULT '0',
  `avatar` varchar(255) DEFAULT '0',
  `uid` varchar(20) DEFAULT NULL COMMENT '用户UID share表',
  `orderid` varchar(255) DEFAULT '0' COMMENT '订单编号',
  `price` varchar(255) DEFAULT '0' COMMENT '购买实付金额',
  `yongjin` varchar(255) DEFAULT '0' COMMENT '直实得到佣金',
  `type` varchar(255) DEFAULT '0' COMMENT '类型0新人免单  1邀请好友免单  2自购免单',
  `sh` varchar(255) DEFAULT '0' COMMENT '是否审核 0  1待返 2已返 3审核 4失效',
  `msg` varchar(255) DEFAULT '0' COMMENT '留言',
  `itemid` varchar(100) DEFAULT '0' COMMENT '商品ID',
  `jl` varchar(20) DEFAULT '0' COMMENT '奖励金额或是积分',
  `jltype` int(10) DEFAULT '0' COMMENT '0积分 1余额',
  `createtime` varchar(12) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `itemid` (`itemid`),
  KEY `orderid` (`orderid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_member
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_member`;
CREATE TABLE `ims_tiger_newhu_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL,
  `from_user` varchar(100) NOT NULL,
  `openid` varchar(100) NOT NULL,
  `helpid` int(11) NOT NULL,
  `unionid` varchar(100) NOT NULL,
  `nickname` varchar(100) NOT NULL,
  `sex` tinyint(1) NOT NULL DEFAULT '0',
  `follow` tinyint(1) NOT NULL DEFAULT '0',
  `headimgurl` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `time` int(13) DEFAULT NULL,
  `enable` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_miandangoods
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_miandangoods`;
CREATE TABLE `ims_tiger_newhu_miandangoods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `itemtitle` varchar(300) DEFAULT NULL,
  `shoptype` int(10) DEFAULT '0',
  `itemid` varchar(200) DEFAULT NULL,
  `itemprice` varchar(200) DEFAULT NULL,
  `itemendprice` varchar(200) DEFAULT NULL,
  `couponmoney` varchar(200) DEFAULT NULL,
  `itemsale` varchar(200) DEFAULT NULL,
  `rate` varchar(50) DEFAULT NULL COMMENT '佣金比例',
  `url` varchar(500) DEFAULT NULL,
  `shopTitle` varchar(300) DEFAULT '0',
  `itempic` varchar(300) DEFAULT '0',
  `pid` varchar(200) DEFAULT '0',
  `lm` int(10) DEFAULT '0',
  `rhyurl` varchar(500) DEFAULT '0',
  `tkl` varchar(200) DEFAULT '0',
  `couponnum` varchar(200) DEFAULT '0',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_weid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_miandanset
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_miandanset`;
CREATE TABLE `ims_tiger_newhu_miandanset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `mdtype` int(3) DEFAULT '0' COMMENT '免单开关1 开',
  `mdrensum` int(3) DEFAULT '0' COMMENT '免单几天内,算新用户',
  `starttime` varchar(200) DEFAULT NULL COMMENT '开始时间',
  `endtime` varchar(200) DEFAULT NULL COMMENT '结束时间',
  `miandanpid` varchar(200) DEFAULT NULL COMMENT '名单指定PID',
  `mdyaoqingcount` int(10) DEFAULT '0' COMMENT '邀请几个好友',
  `mdyaoqingsum` int(10) DEFAULT '0' COMMENT '邀请几个好友免单几次',
  `mdzgcount` int(10) DEFAULT '0' COMMENT '自购几单',
  `mdzgsum` int(10) DEFAULT '0' COMMENT '自购几单免单几次',
  `createtime` int(10) NOT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  KEY `idx_weid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_mobanmsg
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_mobanmsg`;
CREATE TABLE `ims_tiger_newhu_mobanmsg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `title` varchar(250) DEFAULT NULL COMMENT '模版标题',
  `mbid` varchar(250) DEFAULT NULL COMMENT '模版ID',
  `first` varchar(250) DEFAULT NULL COMMENT '头部内容',
  `firstcolor` varchar(100) DEFAULT NULL COMMENT '头部颜色',
  `zjvalue` text COMMENT '中间内容',
  `zjcolor` text COMMENT '中间颜色',
  `remark` varchar(250) DEFAULT NULL COMMENT '尾部内容',
  `remarkcolor` varchar(100) DEFAULT NULL COMMENT '尾部颜色',
  `turl` varchar(250) DEFAULT NULL COMMENT '模版链接',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_msg
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_msg`;
CREATE TABLE `ims_tiger_newhu_msg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` varchar(200) NOT NULL,
  `picurl` varchar(255) NOT NULL COMMENT '封面',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_news
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_news`;
CREATE TABLE `ims_tiger_newhu_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `px` int(11) DEFAULT '0',
  `type` varchar(250) DEFAULT '0' COMMENT '1 公告  2帮助中心',
  `title` varchar(250) DEFAULT '0',
  `content` text NOT NULL,
  `url` varchar(1000) DEFAULT '0',
  `createtime` int(10) NOT NULL,
  `pttype` int(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_newtbgoods
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_newtbgoods`;
CREATE TABLE `ims_tiger_newhu_newtbgoods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) NOT NULL DEFAULT '0' COMMENT 'weid',
  `zy` int(10) NOT NULL DEFAULT '0' COMMENT '1 大淘客  2互力 3鹊桥库',
  `itemid` varchar(50) NOT NULL COMMENT '宝贝ID ',
  `itemtitle` varchar(250) NOT NULL COMMENT '宝贝标题',
  `itemshorttitle` varchar(250) NOT NULL COMMENT '宝贝短标题',
  `itemdesc` varchar(250) NOT NULL COMMENT '宝贝推荐语',
  `itemprice` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '在售价 原价',
  `itemsale` int(20) NOT NULL DEFAULT '0' COMMENT '宝贝销量',
  `itemsale2` int(20) NOT NULL DEFAULT '0' COMMENT '宝贝最近2小时销量',
  `conversion_ratio` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '优惠券转化率',
  `itempic` varchar(250) NOT NULL COMMENT '宝贝主图原始图像',
  `fqcat` int(3) NOT NULL DEFAULT '0' COMMENT '商品类目',
  `itemendprice` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '宝贝最后价格 减去优惠券 券后价',
  `shoptype` varchar(10) NOT NULL COMMENT '店铺类型 天猫(B) C店(C) 企业店铺',
  `userid` varchar(50) NOT NULL COMMENT '店主的userid',
  `sellernick` varchar(100) NOT NULL COMMENT '店铺掌柜名',
  `tktype` varchar(100) NOT NULL COMMENT '佣金方式(鹊桥活动 定向计划 通用计划 隐藏计划 营销计划）',
  `tkrates` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '佣金比例',
  `ctrates` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '村淘佣金比例',
  `cuntao` int(10) NOT NULL DEFAULT '0' COMMENT '是否村淘（1是）',
  `tkmoney` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '预计可得(宝贝价格*佣金比率/100) ',
  `tkurl` varchar(250) NOT NULL COMMENT '定向计划链接',
  `couponurl` varchar(250) NOT NULL COMMENT '优惠券链接',
  `planlink` varchar(250) NOT NULL COMMENT '营销计划链接',
  `couponmoney` varchar(50) NOT NULL COMMENT '优惠券面额',
  `couponsurplus` int(20) NOT NULL DEFAULT '0' COMMENT '优惠券剩余数量',
  `couponreceive` int(20) NOT NULL DEFAULT '0' COMMENT '优惠券领取数量',
  `couponreceive2` int(20) NOT NULL DEFAULT '0' COMMENT '2小时内优惠券领取量',
  `couponnum` int(20) NOT NULL DEFAULT '0' COMMENT '优惠券总数量',
  `couponexplain` varchar(100) NOT NULL COMMENT '优惠券说明 使用条件',
  `couponstarttime` varchar(100) NOT NULL COMMENT '优惠券开始时间',
  `couponendtime` varchar(100) NOT NULL COMMENT '优惠券结束时间',
  `starttime` varchar(100) NOT NULL COMMENT '发布时间',
  `isquality` int(10) NOT NULL DEFAULT '0' COMMENT '是否优选 1为是',
  `item_status` int(10) NOT NULL DEFAULT '0' COMMENT '产品状态：0为正常',
  `report_status` int(10) NOT NULL DEFAULT '0' COMMENT '举报处理情况(1为待处理；2为忽略；3为下架)',
  `is_brand` int(10) NOT NULL DEFAULT '0' COMMENT '是否为品牌产品：1为是',
  `is_live` int(10) NOT NULL DEFAULT '0' COMMENT '是否为直播产品：1为是',
  `videoid` varchar(100) NOT NULL COMMENT '商品视频id',
  `activity_type` varchar(50) NOT NULL COMMENT '活动类型（普通活动、聚划算、淘抢购）',
  `createtime` int(10) NOT NULL,
  `quan_id` varchar(100) DEFAULT NULL COMMENT '优惠券ID',
  `tj` int(11) DEFAULT NULL COMMENT '1 秒杀 2 叮咚抢 ',
  `zt` int(10) NOT NULL DEFAULT '0' COMMENT '专题',
  `zd` int(10) NOT NULL DEFAULT '0' COMMENT '0不置顶  1置顶',
  `qf` int(10) NOT NULL DEFAULT '0' COMMENT '0不群发  1群发库',
  PRIMARY KEY (`id`),
  UNIQUE KEY `weid_num_iid` (`weid`,`itemid`),
  KEY `indx_weid` (`weid`),
  KEY `itemtitle` (`itemtitle`),
  KEY `itemid` (`itemid`),
  KEY `itemendprice` (`itemendprice`),
  KEY `is_brand` (`is_brand`),
  KEY `is_live` (`is_live`),
  KEY `fqcat` (`fqcat`),
  KEY `tj` (`tj`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_order
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_order`;
CREATE TABLE `ims_tiger_newhu_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '0',
  `nickname` varchar(255) DEFAULT '0',
  `avatar` varchar(255) DEFAULT '0',
  `jlnickname` varchar(255) DEFAULT '0' COMMENT '订单所有人',
  `jlavatar` varchar(255) DEFAULT '0' COMMENT '订单所有人',
  `memberid` varchar(255) DEFAULT '0' COMMENT '微擎会员编号',
  `uid` varchar(20) DEFAULT NULL COMMENT '用户UID share表',
  `orderid` varchar(255) DEFAULT '0' COMMENT '订单编号',
  `price` varchar(255) DEFAULT '0' COMMENT '奖励金额',
  `yongjin` varchar(255) DEFAULT '0' COMMENT '佣金',
  `type` varchar(255) DEFAULT '0' COMMENT '类型 0 自有  1级奖励 2级奖励',
  `sh` varchar(255) DEFAULT '0' COMMENT '是否审核 0  1待返 2已返 3审核 4失效',
  `msg` varchar(255) DEFAULT '0' COMMENT '留言',
  `itemid` varchar(100) DEFAULT '0' COMMENT '商品ID',
  `jl` varchar(20) DEFAULT '0' COMMENT '奖励金额或是积分',
  `jltype` int(10) DEFAULT '0' COMMENT '0积分 1余额',
  `createtime` varchar(255) NOT NULL,
  `cjdd` int(10) DEFAULT '0',
  `jluid` varchar(20) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `indx_weid` (`weid`),
  KEY `itemid` (`itemid`),
  KEY `indx_orderid` (`orderid`),
  KEY `indx_openid` (`openid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_paylog
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_paylog`;
CREATE TABLE `ims_tiger_newhu_paylog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `dwnick` varchar(255) DEFAULT NULL COMMENT '微信用户昵称',
  `dopenid` varchar(255) DEFAULT NULL COMMENT '微信用户openid',
  `dtime` int(11) DEFAULT NULL COMMENT '打款时间',
  `dcredit` int(11) DEFAULT NULL COMMENT '消耗积分',
  `dtotal_amount` int(11) DEFAULT NULL COMMENT '金额，分为单位',
  `dmch_billno` varchar(50) DEFAULT NULL COMMENT '生成的商户订单号',
  `dissuccess` tinyint(1) DEFAULT NULL COMMENT '是否打款成功',
  `dresult` varchar(255) DEFAULT NULL COMMENT '失败提示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_pddorder
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_pddorder`;
CREATE TABLE `ims_tiger_newhu_pddorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `order_sn` varchar(100) DEFAULT '0',
  `goods_id` varchar(100) DEFAULT '0',
  `goods_name` varchar(100) DEFAULT '0',
  `goods_thumbnail_url` varchar(255) DEFAULT '0',
  `goods_quantity` varchar(255) DEFAULT '0',
  `goods_price` varchar(255) DEFAULT '0',
  `order_amount` varchar(255) DEFAULT '0',
  `order_create_time` varchar(255) DEFAULT '0',
  `order_settle_time` varchar(255) DEFAULT '0',
  `order_verify_time` varchar(255) DEFAULT '0',
  `order_receive_time` varchar(255) DEFAULT '0',
  `order_pay_time` varchar(255) DEFAULT '0',
  `promotion_rate` varchar(100) DEFAULT '0',
  `promotion_amount` varchar(150) DEFAULT '0',
  `batch_no` varchar(150) DEFAULT '0',
  `order_status` varchar(150) DEFAULT '',
  `order_status_desc` varchar(150) DEFAULT '0',
  `verify_time` varchar(100) DEFAULT '0',
  `order_group_success_time` varchar(100) DEFAULT '0',
  `order_modify_at` varchar(100) DEFAULT '0',
  `status` varchar(100) DEFAULT '0',
  `type` varchar(100) DEFAULT '0',
  `group_id` varchar(100) DEFAULT '0',
  `auth_duo_id` varchar(100) DEFAULT '0',
  `custom_parameters` varchar(100) DEFAULT '0',
  `p_id` varchar(100) DEFAULT '0',
  `createtime` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `order_sn` (`order_sn`),
  KEY `p_id` (`p_id`),
  KEY `order_modify_at` (`order_modify_at`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_pddtjorder
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_pddtjorder`;
CREATE TABLE `ims_tiger_newhu_pddtjorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT '0',
  `nickname` varchar(255) DEFAULT '0',
  `avatar` varchar(255) DEFAULT '0',
  `jlnickname` varchar(255) DEFAULT '0' COMMENT '订单所有人',
  `jlavatar` varchar(255) DEFAULT '0' COMMENT '订单所有人',
  `memberid` varchar(255) DEFAULT '0' COMMENT '微擎会员编号',
  `uid` varchar(20) DEFAULT NULL COMMENT '用户UID share表',
  `orderid` varchar(255) DEFAULT '0' COMMENT '订单编号',
  `price` varchar(255) DEFAULT '0' COMMENT '奖励金额',
  `yongjin` varchar(255) DEFAULT '0' COMMENT '佣金',
  `type` varchar(255) DEFAULT '0' COMMENT '类型 0 自有  1级奖励 2级奖励',
  `sh` varchar(255) DEFAULT '0' COMMENT '是否审核 0  1待返 2已返 3审核 4失效',
  `msg` varchar(255) DEFAULT '0' COMMENT '留言',
  `itemid` varchar(100) DEFAULT '0' COMMENT '商品ID',
  `jl` varchar(20) DEFAULT '0' COMMENT '奖励金额或是积分',
  `jltype` int(10) DEFAULT '0' COMMENT '0积分 1余额',
  `createtime` varchar(255) NOT NULL,
  `cjdd` int(10) DEFAULT '0',
  `jluid` varchar(20) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `indx_weid` (`weid`),
  KEY `itemid` (`itemid`),
  KEY `indx_orderid` (`orderid`),
  KEY `indx_openid` (`openid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_poster
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_poster`;
CREATE TABLE `ims_tiger_newhu_poster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `type` int(1) DEFAULT NULL,
  `data` text,
  `createtime` varchar(12) DEFAULT NULL,
  `bg` varchar(200) DEFAULT NULL,
  `tzurl` varchar(250) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `doneurl` varchar(200) DEFAULT NULL,
  `tipsurl` varchar(200) DEFAULT NULL,
  `score` int(11) DEFAULT '0',
  `score2` int(11) DEFAULT '0',
  `cscore` int(11) DEFAULT '0',
  `cscore2` int(11) DEFAULT '0',
  `pscore` int(11) DEFAULT '0',
  `pscore2` int(11) DEFAULT '0',
  `scorehb` float DEFAULT '0',
  `cscorehb` float DEFAULT '0',
  `pscorehb` float DEFAULT '0',
  `mbfont` varchar(50) DEFAULT NULL,
  `gid` int(11) DEFAULT '0',
  `kdtype` tinyint(1) NOT NULL DEFAULT '0',
  `kword` varchar(20) DEFAULT NULL,
  `mtips` varchar(200) DEFAULT NULL,
  `sliders` text,
  `slideH` int(11) DEFAULT '0',
  `credit` int(1) DEFAULT '0',
  `winfo1` varchar(200) DEFAULT NULL,
  `winfo2` varchar(200) DEFAULT NULL,
  `winfo3` varchar(200) DEFAULT NULL,
  `sharekg` int(11) DEFAULT '0',
  `sharetitle` varchar(200) DEFAULT NULL,
  `sharegzurl` varchar(200) DEFAULT NULL,
  `sharedesc` varchar(200) DEFAULT NULL,
  `sharethumb` varchar(200) DEFAULT NULL,
  `stitle` text,
  `sthumb` text,
  `sdesc` text,
  `surl` text,
  `questions` text,
  `rid` int(11) DEFAULT '0',
  `rtype` int(1) DEFAULT '0',
  `ftips` text,
  `utips` text,
  `utips2` text,
  `wtips` text,
  `starttime` varchar(12) DEFAULT NULL,
  `endtime` varchar(12) DEFAULT NULL,
  `mbstyle` varchar(50) DEFAULT NULL,
  `mbcolor` varchar(50) DEFAULT NULL,
  `nostarttips` text,
  `endtips` text,
  `grouptips` text,
  `tztype` tinyint(1) NOT NULL DEFAULT '0',
  `groups` text,
  `rscore` int(11) DEFAULT '0',
  `rtips` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_qiandao
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_qiandao`;
CREATE TABLE `ims_tiger_newhu_qiandao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `uid` int(1) NOT NULL COMMENT '用户id',
  `num` int(11) NOT NULL COMMENT '签到次数',
  `addtime` int(11) NOT NULL COMMENT '签到时间',
  `formid` varchar(250) DEFAULT '0',
  `xcxopenid` varchar(250) DEFAULT '0',
  `type` int(5) DEFAULT '0',
  `nickname` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_qtzlist
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_qtzlist`;
CREATE TABLE `ims_tiger_newhu_qtzlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `px` int(10) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL,
  `type` int(3) NOT NULL DEFAULT '0' COMMENT '分类',
  `cate` varchar(400) NOT NULL COMMENT '124|154| 子栏目',
  `picurl` varchar(255) NOT NULL COMMENT '图片',
  `cateid` varchar(100) NOT NULL COMMENT '擎天 活动ID',
  `createtime` int(10) NOT NULL,
  `bjcolor` varchar(100) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tiger_newhu_qtzlist
-- ----------------------------
BEGIN;
INSERT INTO `ims_tiger_newhu_qtzlist` VALUES (1, 2, 10, '一淘大额券', 0, '独家券-18222|大额券-13671|5折券-13865|美食券-13851|美妆券-13852|女神券-13858|母婴券-13855|家居券-13854|数码券-13856|鞋包券-13853|内衣券-13857|男神券-13859', '', '18222', 1574849472, '0');
INSERT INTO `ims_tiger_newhu_qtzlist` VALUES (2, 2, 21, '天猫超市', 0, '奶品水饮-19542|粮油米面-19539|母婴用品-19540|家居日用-19543|护肤彩妆-19541', '', '19543', 1574909294, '0');
COMMIT;

-- ----------------------------
-- Table structure for ims_tiger_newhu_qudaolist
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_qudaolist`;
CREATE TABLE `ims_tiger_newhu_qudaolist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `uid` int(11) NOT NULL COMMENT '用户ID',
  `relation_app` varchar(100) DEFAULT '0' COMMENT '渠道备案 - 渠道推广的物料类型',
  `create_date` varchar(100) DEFAULT '0' COMMENT '渠道备案 - 备案日期',
  `account_name` varchar(100) DEFAULT '0' COMMENT '渠道备案 - 渠道昵称',
  `real_name` varchar(100) DEFAULT '0' COMMENT '渠道备案 - 渠道姓名',
  `relation_id` varchar(100) DEFAULT '0' COMMENT '	渠道备案 - 渠道关系ID',
  `offline_scene` varchar(100) DEFAULT '0' COMMENT '渠道备案 - 线下场景信息，1 - 门店，2- 学校，3 - 工厂，4 - 其他',
  `online_scene` varchar(100) DEFAULT '0' COMMENT '渠道备案 - 线上场景信息，1 - 微信群，2- QQ群，3 - 其他',
  `note` varchar(100) DEFAULT '0' COMMENT '	媒体侧渠道备注信息',
  `root_pid` varchar(100) DEFAULT '0' COMMENT '渠道专属pid',
  `rtag` varchar(50) DEFAULT '0' COMMENT '标识渠道原始身份信息',
  `createtime` int(10) NOT NULL COMMENT '入库时间',
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `rtag` (`rtag`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_qudaosign
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_qudaosign`;
CREATE TABLE `ims_tiger_newhu_qudaosign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `uid` int(11) DEFAULT '0' COMMENT '授权代理用户ID',
  `openid` varchar(50) DEFAULT NULL COMMENT 'openid',
  `sate` varchar(1000) DEFAULT NULL,
  `tbuid` varchar(50) DEFAULT NULL,
  `tbnickname` varchar(200) DEFAULT NULL,
  `sign` varchar(100) DEFAULT NULL,
  `endtime` varchar(30) DEFAULT NULL COMMENT '结束时间',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `uid` (`uid`),
  KEY `openid` (`openid`),
  KEY `tbuid` (`tbuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_record
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_record`;
CREATE TABLE `ims_tiger_newhu_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `openid` varchar(200) DEFAULT NULL,
  `score` int(11) DEFAULT '0',
  `surplus` int(11) DEFAULT '0',
  `createtime` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_request
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_request`;
CREATE TABLE `ims_tiger_newhu_request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `from_user_realname` varchar(50) NOT NULL,
  `from_user` varchar(50) NOT NULL,
  `openid` varchar(50) NOT NULL,
  `image` varchar(300) DEFAULT '0',
  `realname` varchar(200) NOT NULL,
  `mobile` varchar(200) NOT NULL,
  `residedist` varchar(200) NOT NULL,
  `alipay` varchar(200) NOT NULL,
  `note` varchar(200) NOT NULL,
  `tborder` varchar(200) NOT NULL,
  `goods_id` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  `cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `fxprice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` varchar(20) NOT NULL,
  `type` int(5) DEFAULT '0',
  `kuaidi` varchar(200) NOT NULL,
  `uid` varchar(100) NOT NULL COMMENT '用户UID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_sdorder
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_sdorder`;
CREATE TABLE `ims_tiger_newhu_sdorder` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `nickname` varchar(100) NOT NULL,
  `from_user` varchar(50) NOT NULL,
  `avatar` varchar(200) NOT NULL,
  `openid` varchar(50) NOT NULL,
  `image` varchar(300) DEFAULT '0',
  `order` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  `evaluation` varchar(250) NOT NULL,
  `pf` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `jljf` varchar(200) NOT NULL,
  `sjjl` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_set
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_set`;
CREATE TABLE `ims_tiger_newhu_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `hbsum` int(1) DEFAULT NULL COMMENT '红包总金额',
  `hbtext` varchar(200) DEFAULT NULL COMMENT '红包兑换结束提示',
  PRIMARY KEY (`id`),
  KEY `idx_weid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_share
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_share`;
CREATE TABLE `ims_tiger_newhu_share` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `openid` varchar(50) DEFAULT '0',
  `tel` varchar(15) DEFAULT NULL,
  `type` varchar(15) DEFAULT '0',
  `credit1` decimal(10,2) unsigned NOT NULL COMMENT '积分',
  `credit2` decimal(10,2) unsigned NOT NULL COMMENT '余额',
  `cqtype` varchar(10) NOT NULL COMMENT '0 不能查询  1 能查询',
  `dltype` varchar(10) NOT NULL COMMENT '0 不是代理  1 是代理',
  `dlsh` varchar(10) NOT NULL COMMENT '0 审核中 1通过',
  `dlbl` varchar(110) NOT NULL COMMENT '代理佣金比例-一级自购',
  `dlbl2` varchar(110) NOT NULL COMMENT '代理佣金比例-二级自购',
  `dlbl3` varchar(110) NOT NULL COMMENT '代理佣金比例-三级自购',
  `tgwid` varchar(250) NOT NULL COMMENT '渠道推广位ID',
  `dlqqpid` varchar(110) NOT NULL COMMENT '代理鹊桥PID',
  `dlptpid` varchar(110) NOT NULL COMMENT '代理普通',
  `apppid` varchar(110) NOT NULL COMMENT 'APP PID',
  `apptgw` varchar(110) NOT NULL COMMENT 'APP 推广位',
  `dlmsg` varchar(250) NOT NULL COMMENT '代理申请理由',
  `zfbuid` varchar(250) NOT NULL COMMENT '支付宝帐号',
  `tname` varchar(50) NOT NULL COMMENT '姓名',
  `qunname` varchar(100) NOT NULL COMMENT '群名称',
  `pclogo` varchar(250) NOT NULL COMMENT 'PCLOGO',
  `pctitle` varchar(250) NOT NULL COMMENT 'PC网站标题',
  `pckeywords` varchar(250) NOT NULL COMMENT 'PC网站关键词',
  `pcdescription` varchar(250) NOT NULL COMMENT 'PC网站描述',
  `pcsearchkey` varchar(250) NOT NULL COMMENT 'PC网站搜索框下面关键词',
  `pcewm1` varchar(250) NOT NULL COMMENT 'PC二维码1',
  `pcewm2` varchar(250) NOT NULL COMMENT 'PC二维码2',
  `pcbottom1` varchar(250) NOT NULL COMMENT 'PC网站底部1',
  `pcbottom2` varchar(250) NOT NULL COMMENT 'PC网站底部2',
  `pcuser` varchar(250) NOT NULL COMMENT '登录帐号',
  `pcpasswords` varchar(250) NOT NULL COMMENT '登录密码',
  `pcurl` varchar(250) NOT NULL COMMENT '代理独立域名',
  `lytype` int(3) DEFAULT '0' COMMENT '0 公众号 1APP',
  `dytype` int(3) DEFAULT '0' COMMENT '0已经订阅  1取消订阅',
  `weixin` varchar(100) DEFAULT NULL,
  `from_user` varchar(100) NOT NULL,
  `xcxopenid` varchar(100) NOT NULL,
  `pcopenid` varchar(100) NOT NULL,
  `appopenid` varchar(100) NOT NULL,
  `unionid` varchar(100) NOT NULL,
  `jqfrom_user` varchar(100) NOT NULL,
  `nickname` varchar(50) DEFAULT '0',
  `avatar` varchar(200) DEFAULT NULL,
  `tbnickname` varchar(50) DEFAULT '0',
  `tbavatar` varchar(500) DEFAULT NULL,
  `tbopenid` varchar(100) NOT NULL,
  `tbunionid` varchar(100) NOT NULL,
  `score` int(11) DEFAULT '0',
  `cscore` int(11) DEFAULT '0',
  `pscore` int(11) DEFAULT '0',
  `pid` int(11) DEFAULT '0',
  `sceneid` int(11) DEFAULT '0',
  `ticketid` varchar(200) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `parentid` int(11) DEFAULT '0',
  `helpid` int(11) DEFAULT '0',
  `follow` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(1) DEFAULT '0',
  `hasdel` int(1) DEFAULT '0',
  `createtime` varchar(50) DEFAULT NULL,
  `updatetime` varchar(50) DEFAULT '0',
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `tbsbuid6` varchar(10) DEFAULT NULL,
  `yaoqingma` varchar(10) DEFAULT NULL,
  `pddpid` varchar(100) NOT NULL COMMENT '多多PID',
  `jdpid` varchar(100) NOT NULL COMMENT '京东PID',
  `tbkpidtype` int(11) DEFAULT '0' COMMENT '1已经绑定tbuid 0未绑定',
  `tbuid` varchar(20) DEFAULT '0',
  `tztype` int(11) DEFAULT '0' COMMENT '1为团长',
  `tzpaytime` varchar(50) DEFAULT '0' COMMENT '团长支付时间',
  `tztime` varchar(50) DEFAULT '0' COMMENT '团长申请时间',
  `tzendtime` varchar(50) DEFAULT '0' COMMENT '团长到期时间',
  `qdid` varchar(50) DEFAULT '0',
  `hyid` int(10) DEFAULT '0',
  `qdname` varchar(50) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `helpid` (`helpid`),
  KEY `weid` (`weid`),
  KEY `dltype` (`dltype`),
  KEY `tgwid` (`tgwid`),
  KEY `pcuser` (`pcuser`),
  KEY `from_user` (`from_user`),
  KEY `unionid` (`unionid`),
  KEY `tbunionid` (`tbunionid`),
  KEY `pid` (`pid`),
  KEY `xcxopenid` (`xcxopenid`),
  KEY `appopenid` (`appopenid`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tiger_newhu_share
-- ----------------------------
BEGIN;
INSERT INTO `ims_tiger_newhu_share` VALUES (1, 2, '0', '13817661606', '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '13817661606', '123456', '', 0, 0, NULL, '13817661606_53177', '', '', '', '', '', '测试', NULL, '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, '1574850293', '1574850293', NULL, NULL, NULL, 'tk1', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (2, 2, '2', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxN12B-UAC92kuWMsCPUNpnk', '', '', '', '', '', '晴天', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWdqYhLCO119OTs3uZeH8mYRGq5wrWeSpU2XQIDa8riatDqnrVpSU97f1EkX58XCSsb0eMW1Y4KxUVgcLebHouPtC/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1574851922', '1574851922', NULL, NULL, NULL, 'tk2', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (3, 2, '1', '18739833066', '0', 0.00, 0.00, '1', '1', '', '', '', '', '', '', '', '', '', '挣钱', '', '任强强', '', '', '', '', '', '', '', '', '', '', '18739833066', '123456', '', 0, 0, 'wx1067474978', 'oyIJkxCB9hYjLKccpLfH8JHuLGQY', '', '', '', '', '', 'YOUSEESEEYOU', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWftBuxiac4kVlUZsCHsqQD7kIib2eeIXjOvZVaUh2kTvKCPoicCC9PExopM7ibKoueneUzpKRFrN74jibBmwh40hf9f2/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1574856922', '1574856922', NULL, NULL, NULL, 'tk3', '', '', 0, '0', 1, '0', '1574941767', '1574941767', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (4, 2, '11', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxJwyyIILPi1tJulp5SiXcLY', '', '', '', '', '', 'iyoung', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWdqYhLCO119Oa2WxIHBPxTbmWTSlTTlicuFhV7hfcFIbAvib73u84V2FHiciblxL0XfCq0ngqQ83d33Pk51IlzVmGHz/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1574928765', '1574928765', NULL, NULL, NULL, 'tk4', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (5, 2, '3', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxKRA-1SNFQ7eGhk4vbNYs1I', '', '', '', '', '', 'allen', 'https://thirdwx.qlogo.cn/mmopen/PiajxSqBRaEJAtuqGaFq5icJtNost6J0BT4rAc1JYtfZPqpibMKiaOgXKZIsPUuNKVz08lb5guiay2ZGDwziaOcmfRtg/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1574948451', '1574948451', NULL, NULL, NULL, 'tk5', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (6, 2, '4', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxDMJqc166acwBef98LsxQTk', '', '', '', '', '', '橙子', 'https://thirdwx.qlogo.cn/mmopen/g9nTv4YbEkXEYycwspc5iae2HfRBxYrLAoN7C1DP0GWWTI2z2bC4S7zbuqJqogATszIKZ0jRgv4IsIqGrCfF1wyRhkm32MdPl/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1575678907', '1575678907', NULL, NULL, NULL, 'tk6', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (7, 2, '18', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxCgS5sIIOHLREugdOEuBSGY', '', '', '', '', '', '维健乐商城客服~小维', 'http://thirdwx.qlogo.cn/mmopen/vi_32/E2E08icS1c1OUKafIoy76EFqBDymF5MibstQjn4F2bXOTnbOPZPbLFtEiaAPI59kH9Vp6GXxGJHbGGaMiaQ1f9St3Q/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1575862405', '1575862405', NULL, NULL, NULL, 'tk7', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (8, 2, '21', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxI6uICnC7A9EgzH2kaR4CM8', '', '', '', '', '', '师董会 客服 刘婷', 'http://thirdwx.qlogo.cn/mmopen/vi_32/rkPlX6T4KDmE2CfFXdcvjpuU4J8CviabONtSO1bia4QKnIhJOXRFmtJ6BANFe2P7XNyguMNh5Mh9toBLCD59wbWA/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1575941110', '1575941110', NULL, NULL, NULL, 'tk8', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (9, 2, '22', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxDrUZlqAOTTwcSrNEuK5gb8', '', '', '', '', '', '', 'http://thirdwx.qlogo.cn/mmopen/vi_32/EOYsicTeX861ItLyd1fd2ueTzCJ7LesnmpA4jFCHpGDpeTW3dsyDdCgaOeloMtW2vl9De67IxwufTH3sDX7abAQ/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1576027300', '1576027300', NULL, NULL, NULL, 'tk9', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (10, 2, '9', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxD8muNpYh6c4TrVYK2YtcLs', '', '', '', '', '', '乔鹏达', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLRPwcDWaOZiajnOK9U4ibVJqBWDKkIXf42rzxkqPOboFgVnVIU9X1LPcx6ibN0giaCdGDzGvjWRxp9sA/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1576253365', '1576253365', NULL, NULL, NULL, 'tk10', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (11, 2, '25', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxPQUDLj2dj8NZeX58Hsxryk', '', '', '', '', '', '东方郁华', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTL4iaNicCaM9zgoj4QicPqKgjJTicL3HGibA23aqYE1AhKibT9OHGR2TIUBFicX9H8XEibnvDfVmLVchTibxJQ/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1576467174', '1576467174', NULL, NULL, NULL, 'tk11', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (12, 2, '28', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxGeSDWUKzg5EcxLrG_wbm-s', '', '', '', '', '', 'Panda', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJrCta0BxlH8qfLZoXx8dsQZPVClKqwpvu5LnaK29MqGtqxbFiaVSjYBmibaibatCHToZY4aPM3pvZRA/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1576489716', '1576489716', NULL, NULL, NULL, 'tk12', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (13, 2, '29', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxGOGWL9WHRKkW5PeRZN4uhQ', '', '', '', '', '', '大白', 'http://thirdwx.qlogo.cn/mmopen/vi_32/IsQwBDluGH5bsVJibDr5eIicicW3bXY2X3zIykoFqxPIRJgA4iajxmLnWazicFiaF6MF7ARgZhZ6VRsGwfNCibhxxDY0Q/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1576550334', '1576550334', NULL, NULL, NULL, 'tk13', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (14, 2, '31', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxGhmim2MJe060lBsmnRcByc', '', '', '', '', '', '', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTIKKnTuUlLlgO6f7saegU5okXpY23KMLlJSbNZBOKQvfbQb7VltOwBOHPby64wVwbVB4UQpliaibuaA/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1576718449', '1576718449', NULL, NULL, NULL, 'tk14', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (15, 2, '34', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxEwZegHiYnx-6At2gzylBAQ', '', '', '', '', '', '韩宝音', 'https://thirdwx.qlogo.cn/mmopen/oibkjzpUkPNwYvk2RNxLBM2uX8s2NrvhVOImAcbn7V7D1KAiaX3jibSicwsxCcJWLAbWvbAYaUPH5Q8fYqeyEJ7XiaRQ1aBvIwpEc/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1576998609', '1576998609', NULL, NULL, NULL, 'tk15', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (16, 2, '36', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxD2zxZZd1Yi3nNOV51mPGws', '', '', '', '', '', '悦悦', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTIrZg3zI65LU5O1D875waIFweQrb5sEed0HYxHBWEKUdRaAIVOa8sCavwUjFrqvYfOQ8qFWP3DIUg/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1577059843', '1577059843', NULL, NULL, NULL, 'tk16', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (17, 2, '44', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxM2PN8YIYddNJYV26VD-9bU', '', '', '', '', '', '菲菲', 'http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLlbJWvrFONK9P9s9ib3fiattmA29muBGJcree0CZZqAmjrRx4BnFpHtjt7ic56HEdlCuES3D1SUKKbA/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1577421586', '1577421586', NULL, NULL, NULL, 'tk17', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
INSERT INTO `ims_tiger_newhu_share` VALUES (18, 2, '23', NULL, '0', 0.00, 0.00, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, NULL, 'oyIJkxC8MH55oRiEazaSsk6BejwM', '', '', '', '', '', '周月璞', 'https://thirdwx.qlogo.cn/mmopen/wQpAcAtREWdqYhLCO119OTZOk3JesYQ4bNz0KD5u0oupnkNzdsgsrOG7VPa4QtI66aBSUoXvjAOS9PX6VELour2GSntcSOZf/132', '0', NULL, '', '', 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 1, 0, 0, '1577529018', '1577529018', NULL, NULL, NULL, 'tk18', '', '', 0, '0', 0, '0', '0', '0', '0', 0, '0');
COMMIT;

-- ----------------------------
-- Table structure for ims_tiger_newhu_shoucang
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_shoucang`;
CREATE TABLE `ims_tiger_newhu_shoucang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `title` varchar(150) DEFAULT '0',
  `goodsid` varchar(50) DEFAULT '0',
  `picurl` varchar(250) DEFAULT '0',
  `openid` varchar(50) DEFAULT '0',
  `uid` varchar(50) DEFAULT '0',
  `createtime` int(10) NOT NULL,
  `itemendprice` varchar(50) DEFAULT '0',
  `itemprice` varchar(50) DEFAULT '0',
  `itemsale` varchar(50) DEFAULT '0',
  `couponmoney` varchar(50) DEFAULT '0',
  `rate` varchar(50) DEFAULT '0',
  `tkl` varchar(200) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_tbgoods
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_tbgoods`;
CREATE TABLE `ims_tiger_newhu_tbgoods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `px` int(10) NOT NULL DEFAULT '0',
  `zy` int(10) NOT NULL DEFAULT '0' COMMENT '1 大淘客  2互力 3鹊桥库',
  `tj` int(10) NOT NULL DEFAULT '0' COMMENT '秒杀 1  人气2',
  `zt` int(10) NOT NULL DEFAULT '0' COMMENT '专题',
  `zd` int(10) NOT NULL DEFAULT '0' COMMENT '0不置顶  1置顶',
  `qf` int(10) NOT NULL DEFAULT '0' COMMENT '0不群发  1群发库',
  `type` int(2) NOT NULL DEFAULT '0' COMMENT '分类',
  `lxtype` int(2) NOT NULL DEFAULT '0' COMMENT '佣金类别0普通  1定向  2鹊桥 用这个',
  `dxtime` int(13) NOT NULL COMMENT '定向申请时间',
  `yjtype` int(2) NOT NULL DEFAULT '0' COMMENT '佣金类别0普通  1定向  2鹊桥',
  `show_type` int(2) NOT NULL DEFAULT '0' COMMENT '前台是否展示 0 展示  1不展示',
  `title` varchar(250) NOT NULL COMMENT '商品名称',
  `videoid` varchar(50) NOT NULL COMMENT '视频ID',
  `istmall` varchar(5) NOT NULL COMMENT '0不是  1是天猫',
  `dsr` varchar(20) NOT NULL COMMENT 'dsr评分',
  `quan_id` varchar(100) NOT NULL COMMENT '优惠券ID',
  `quan_condition` varchar(200) NOT NULL COMMENT '优惠券使用条件',
  `org_price` varchar(50) NOT NULL COMMENT '商品原价',
  `dingxianurl` varchar(300) NOT NULL COMMENT '定向计划链接',
  `num_iid` varchar(50) NOT NULL COMMENT '商品ID',
  `pic_url` varchar(250) NOT NULL COMMENT '商品主图',
  `small_images` varchar(1000) NOT NULL COMMENT '商品多个小图',
  `item_url` varchar(250) NOT NULL COMMENT '商品详情页链接地址',
  `shop_title` varchar(250) NOT NULL COMMENT '店铺名称',
  `yprice` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '商品原价格',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '商品价格',
  `tk_rate` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '收入比率%',
  `yongjin` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '佣金',
  `goods_sale` varchar(100) NOT NULL COMMENT '商品月销售',
  `nick` varchar(50) NOT NULL COMMENT '卖家旺旺',
  `tk_durl` varchar(250) NOT NULL COMMENT '淘宝客短链接300天',
  `click_url` varchar(250) NOT NULL COMMENT '淘宝客长链接',
  `taokouling` varchar(100) NOT NULL COMMENT '淘口令 300天有效',
  `coupons_total` varchar(50) NOT NULL COMMENT '优惠券总量',
  `coupons_take` varchar(50) NOT NULL COMMENT '优惠券乘余',
  `coupons_price` varchar(100) NOT NULL COMMENT '优惠券面额',
  `coupons_start` varchar(50) NOT NULL COMMENT '优惠券开始时间',
  `coupons_end` varchar(50) NOT NULL COMMENT '优惠券结束时间',
  `coupons_url` varchar(500) NOT NULL COMMENT '优惠券链接',
  `coupons_tkl` varchar(150) NOT NULL COMMENT '优惠券淘口令',
  `provcity` varchar(100) NOT NULL COMMENT '广东 广州',
  `tjcontent` varchar(250) NOT NULL COMMENT '推荐内容',
  `event_end_time` varchar(100) NOT NULL COMMENT '活动结束时间',
  `event_start_time` varchar(100) NOT NULL COMMENT '活动开始时间',
  `event_zt` varchar(50) NOT NULL COMMENT '活动状态 推广中',
  `event_yjbl` varchar(50) NOT NULL COMMENT '活动佣金比例',
  `event_yj` varchar(50) NOT NULL COMMENT '活动佣金',
  `uptime` varchar(100) NOT NULL COMMENT '更新时间',
  `hot` varchar(50) NOT NULL,
  `hit` varchar(50) NOT NULL,
  `hotcolor` varchar(50) NOT NULL,
  `starttime` varchar(12) DEFAULT NULL,
  `endtime` varchar(12) DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `indx_num_iid` (`weid`,`num_iid`),
  KEY `indx_weid` (`weid`),
  KEY `title` (`title`),
  KEY `num_iid` (`num_iid`),
  KEY `indx_tj` (`tj`),
  KEY `indx_status` (`status`),
  KEY `indx_type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_tbgoodsqf
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_tbgoodsqf`;
CREATE TABLE `ims_tiger_newhu_tbgoodsqf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `qf` int(10) NOT NULL DEFAULT '0' COMMENT '0不群发  1群发库',
  `lxtype` int(2) NOT NULL DEFAULT '0' COMMENT '佣金类别0普通  1定向  2鹊桥 用这个',
  `title` varchar(250) NOT NULL COMMENT '商品名称',
  `videoid` varchar(50) NOT NULL COMMENT '视频ID',
  `quan_id` varchar(100) NOT NULL COMMENT '优惠券ID',
  `quan_condition` varchar(200) NOT NULL COMMENT '优惠券使用条件',
  `org_price` varchar(50) NOT NULL COMMENT '商品原价',
  `dingxianurl` varchar(300) NOT NULL COMMENT '定向计划链接',
  `num_iid` varchar(50) NOT NULL COMMENT '商品ID',
  `pic_url` varchar(250) NOT NULL COMMENT '商品主图',
  `item_url` varchar(250) NOT NULL COMMENT '商品详情页链接地址',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '商品价格',
  `tk_rate` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '收入比率%',
  `yongjin` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '佣金',
  `goods_sale` varchar(100) NOT NULL COMMENT '商品月销售',
  `coupons_take` varchar(50) NOT NULL COMMENT '优惠券乘余',
  `coupons_price` varchar(100) NOT NULL COMMENT '优惠券面额',
  `coupons_start` varchar(50) NOT NULL COMMENT '优惠券开始时间',
  `coupons_end` varchar(50) NOT NULL COMMENT '优惠券结束时间',
  `coupons_url` varchar(500) NOT NULL COMMENT '优惠券链接',
  `tjcontent` varchar(250) NOT NULL COMMENT '推荐内容',
  `uptime` varchar(100) NOT NULL COMMENT '更新时间',
  `weiqun` varchar(50) NOT NULL COMMENT '微信群名称',
  `qqqun` varchar(50) NOT NULL COMMENT 'QQ群名称',
  `qfzt` int(2) NOT NULL DEFAULT '0' COMMENT '0未群发  1已群发',
  `userid` varchar(50) NOT NULL COMMENT 'share表ID',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid_numid` (`userid`,`num_iid`),
  KEY `weid` (`weid`),
  KEY `title` (`title`),
  KEY `weiqun` (`weiqun`),
  KEY `qqqun` (`qqqun`),
  KEY `num_iid` (`num_iid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_ticket
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_ticket`;
CREATE TABLE `ims_tiger_newhu_ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `ticket` varchar(255) DEFAULT '0',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_tixianlog
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_tixianlog`;
CREATE TABLE `ims_tiger_newhu_tixianlog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) DEFAULT NULL,
  `dwnick` varchar(255) DEFAULT NULL COMMENT '微信用户昵称',
  `dopenid` varchar(255) DEFAULT NULL COMMENT '微信用户openid',
  `dtime` int(11) DEFAULT NULL COMMENT '打款时间',
  `dcredit` int(11) DEFAULT NULL COMMENT '消耗积分',
  `dtotal_amount` int(11) DEFAULT NULL COMMENT '金额，分为单位',
  `dmch_billno` varchar(50) DEFAULT NULL COMMENT '生成的商户订单号',
  `zfbuid` varchar(100) DEFAULT NULL COMMENT '支付宝帐号',
  `dissuccess` tinyint(1) DEFAULT NULL COMMENT '是否打款成功',
  `dresult` varchar(255) DEFAULT NULL COMMENT '失败提示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_tkorder
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_tkorder`;
CREATE TABLE `ims_tiger_newhu_tkorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `addtime` varchar(100) DEFAULT '0' COMMENT '创建时间',
  `orderid` varchar(100) DEFAULT '0' COMMENT '订单编号',
  `numid` varchar(100) DEFAULT '0' COMMENT '商品ID',
  `shopname` varchar(255) DEFAULT '0' COMMENT '店铺名称',
  `title` varchar(255) DEFAULT '0' COMMENT '商品标题',
  `orderzt` varchar(255) DEFAULT '0' COMMENT '订单状态',
  `srbl` varchar(255) DEFAULT '0' COMMENT '收入比例',
  `fcbl` varchar(255) DEFAULT '0' COMMENT '分成比例',
  `fkprice` varchar(255) DEFAULT '0' COMMENT '付款金额',
  `xgyg` varchar(255) DEFAULT '0' COMMENT '效果预估',
  `jstime` varchar(255) DEFAULT '0' COMMENT '结算时间',
  `pt` varchar(255) DEFAULT '0' COMMENT '平台',
  `type` varchar(20) DEFAULT '0' COMMENT '状态 0未奖励 1已奖励',
  `mtid` varchar(150) DEFAULT '0' COMMENT '媒体ID',
  `mttitle` varchar(150) DEFAULT '0' COMMENT '媒体名称',
  `tgwid` varchar(150) DEFAULT '0' COMMENT '推广ID',
  `tgwtitle` varchar(150) DEFAULT '0' COMMENT '推广位名称',
  `wq` varchar(10) DEFAULT '0' COMMENT '维权订单 1 维权订单',
  `createtime` varchar(255) NOT NULL,
  `tbsbuid6` varchar(10) DEFAULT NULL,
  `zdgd` int(10) DEFAULT '0',
  `forderid` varchar(100) DEFAULT '0' COMMENT '父订单编号',
  `ly` varchar(10) DEFAULT '0' COMMENT '来源0联盟表格 1 联盟API',
  `zorderid` varchar(100) DEFAULT '0' COMMENT '子订单编号',
  `relation_id` varchar(50) DEFAULT '0',
  `special_id` int(10) DEFAULT '0',
  `click_time` varchar(50) DEFAULT '0',
  `itempic` varchar(200) NOT NULL COMMENT '图片',
  `dsf` varchar(10) NOT NULL COMMENT ' 2:二方  3:三方',
  PRIMARY KEY (`id`),
  KEY `indx_weid` (`weid`),
  KEY `addtime` (`addtime`),
  KEY `jstime` (`jstime`),
  KEY `tgwid` (`tgwid`),
  KEY `indx_orderid` (`orderid`),
  KEY `orderid` (`weid`,`orderid`,`numid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_tksign
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_tksign`;
CREATE TABLE `ims_tiger_newhu_tksign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `tbuid` varchar(50) DEFAULT NULL,
  `sign` varchar(100) DEFAULT NULL,
  `endtime` varchar(30) DEFAULT NULL COMMENT '结束时间',
  `createtime` int(10) NOT NULL,
  `tbnickname` varchar(200) DEFAULT NULL,
  `siteid` varchar(100) DEFAULT '0',
  `memberid` varchar(100) DEFAULT '0',
  `qdtgurl` varchar(500) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `tbuid` (`tbuid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tiger_newhu_tksign
-- ----------------------------
BEGIN;
INSERT INTO `ims_tiger_newhu_tksign` VALUES (2, 2, '2206787978133', '700021005190f169ba77c9192c9f98715361d400f7bad8d8d5c9042d1a372498666d1fc2206787978133', '1577435514466', 1574843514, '菲彼寻常的生活', '0', '711720113', '0');
COMMIT;

-- ----------------------------
-- Table structure for ims_tiger_newhu_txlog
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_txlog`;
CREATE TABLE `ims_tiger_newhu_txlog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT NULL,
  `uid` varchar(255) DEFAULT NULL COMMENT '用户UID share表',
  `nickname` varchar(255) DEFAULT NULL COMMENT '微信用户昵称',
  `openid` varchar(255) DEFAULT NULL COMMENT '微信用户openid',
  `avatar` varchar(255) DEFAULT '0',
  `addtime` int(11) DEFAULT NULL COMMENT '打款时间',
  `credit1` int(11) DEFAULT NULL COMMENT '消耗积分',
  `credit2` varchar(100) DEFAULT NULL COMMENT '金额，分为单位',
  `zfbuid` varchar(100) DEFAULT NULL COMMENT '支付宝帐号',
  `dmch_billno` varchar(50) DEFAULT NULL COMMENT '生成的商户订单号',
  `sh` tinyint(1) DEFAULT NULL COMMENT '是否打款成功',
  `dresult` varchar(255) DEFAULT NULL COMMENT '失败提示',
  `createtime` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_xcxdh
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_xcxdh`;
CREATE TABLE `ims_tiger_newhu_xcxdh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `fztype` int(10) DEFAULT '0' COMMENT '1首页广告   2广告下面菜单  3图标下面4个图片',
  `type` int(10) DEFAULT '0' COMMENT '1.H5链接  2.商品分类  3活动',
  `title` varchar(100) DEFAULT '0' COMMENT '名称',
  `ftitle` varchar(100) DEFAULT '0' COMMENT '副名称',
  `hd` varchar(20) DEFAULT '0' COMMENT '1聚划算 2淘抢购  3秒杀  4 叮咚抢  5 视频单  6品牌团 7官方推荐 8好券直播 9小编力荐',
  `fqcat` int(11) DEFAULT '0' COMMENT '商品分类ID',
  `pic` varchar(250) DEFAULT '0',
  `xcxpage` varchar(1000) DEFAULT '0',
  `url` varchar(1000) DEFAULT '0',
  `appid` varchar(255) NOT NULL,
  `createtime` int(10) NOT NULL,
  `kfkey` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_xcxmobanmsg
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_xcxmobanmsg`;
CREATE TABLE `ims_tiger_newhu_xcxmobanmsg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `title` varchar(250) DEFAULT NULL COMMENT '模版标题',
  `mbid` varchar(250) DEFAULT NULL COMMENT '模版ID',
  `first` varchar(250) DEFAULT NULL COMMENT '头部内容',
  `firstcolor` varchar(100) DEFAULT NULL COMMENT '头部颜色',
  `zjvalue` text COMMENT '中间内容',
  `zjcolor` text COMMENT '中间颜色',
  `remark` varchar(250) DEFAULT NULL COMMENT '尾部内容',
  `remarkcolor` varchar(100) DEFAULT NULL COMMENT '尾部颜色',
  `turl` varchar(250) DEFAULT NULL COMMENT '模版链接',
  `createtime` int(10) NOT NULL,
  `emphasis_keyword` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_xcxsend
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_xcxsend`;
CREATE TABLE `ims_tiger_newhu_xcxsend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `kfkey` varchar(100) DEFAULT NULL COMMENT '关键词',
  `type` int(10) DEFAULT '0' COMMENT '类型 1 H5链接',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `content` varchar(1000) DEFAULT '0' COMMENT '介绍',
  `url` varchar(1000) DEFAULT '0' COMMENT 'H5链接',
  `picurl` varchar(1000) DEFAULT '0',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `kfkey` (`kfkey`),
  KEY `weid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_newhu_zttype
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_newhu_zttype`;
CREATE TABLE `ims_tiger_newhu_zttype` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `px` int(10) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL,
  `fftype` int(3) NOT NULL DEFAULT '0' COMMENT '分类',
  `picurl` varchar(255) NOT NULL COMMENT '封面',
  `wlurl` varchar(255) NOT NULL COMMENT '外链',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `fftype` (`fftype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_wxdaili_ad
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_wxdaili_ad`;
CREATE TABLE `ims_tiger_wxdaili_ad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `title` varchar(250) DEFAULT '0',
  `pic` varchar(250) DEFAULT '0',
  `url` varchar(250) DEFAULT '0',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_wxdaili_dlshuju
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_wxdaili_dlshuju`;
CREATE TABLE `ims_tiger_wxdaili_dlshuju` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `uid` int(11) DEFAULT '0' COMMENT '用户ID',
  `tb1` int(11) DEFAULT '0' COMMENT '本人-今天已付款订单数',
  `tb2` decimal(10,2) DEFAULT '0.00' COMMENT '本人-今天已付款佣预估金数',
  `tb3` int(11) DEFAULT '0' COMMENT '本人-昨天已付款订单',
  `tb4` decimal(10,2) DEFAULT '0.00' COMMENT '本人-昨天已付款预估佣金数',
  `tb5` int(11) DEFAULT '0' COMMENT '本人-本月已付款订单数',
  `tb6` decimal(10,2) DEFAULT '0.00' COMMENT '本人-本月已付款预估佣金数',
  `tb7` int(11) DEFAULT '0' COMMENT '本人-上月已结算订单数',
  `tb8` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已结算预估佣金数',
  `tb9` int(11) DEFAULT '0' COMMENT '本人-上月已付款订单数',
  `tb10` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已付款预估佣金数',
  `tb11` int(11) DEFAULT '0' COMMENT '二级-今天已付款订单数',
  `tb12` decimal(10,2) DEFAULT '0.00' COMMENT '本人-今天已付款佣预估金数',
  `tb13` int(11) DEFAULT '0' COMMENT '二级-昨天已付款订单',
  `tb14` decimal(10,2) DEFAULT '0.00' COMMENT '本人-昨天已付款预估佣金数',
  `tb15` int(11) DEFAULT '0' COMMENT '二级-本月已付款订单数',
  `tb16` decimal(10,2) DEFAULT '0.00' COMMENT '本人-本月已付款预估佣金数',
  `tb17` int(11) DEFAULT '0' COMMENT '二级-上月已结算订单数',
  `tb18` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已结算预估佣金数',
  `tb19` int(11) DEFAULT '0' COMMENT '二级-上月已付款订单数',
  `tb20` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已付款预估佣金数',
  `tb21` int(11) DEFAULT '0' COMMENT '三级-今天已付款订单数',
  `tb22` decimal(10,2) DEFAULT '0.00' COMMENT '本人-今天已付款佣预估金数',
  `tb23` int(11) DEFAULT '0' COMMENT '三级-昨天已付款订单',
  `tb24` decimal(10,2) DEFAULT '0.00' COMMENT '本人-昨天已付款预估佣金数',
  `tb25` int(11) DEFAULT '0' COMMENT '三级-本月已付款订单数',
  `tb26` decimal(10,2) DEFAULT '0.00' COMMENT '本人-本月已付款预估佣金数',
  `tb27` int(11) DEFAULT '0' COMMENT '三级-上月已结算订单数',
  `tb28` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已结算预估佣金数',
  `tb29` int(11) DEFAULT '0' COMMENT '三级-上月已付款订单数',
  `tb30` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已付款预估佣金数',
  `pdd1` int(11) DEFAULT '0' COMMENT '本人-今天已付款订单数',
  `pdd2` decimal(10,2) DEFAULT '0.00' COMMENT '本人-今天已付款佣预估金数',
  `pdd3` int(11) DEFAULT '0' COMMENT '本人-昨天已付款订单',
  `pdd4` decimal(10,2) DEFAULT '0.00' COMMENT '本人-昨天已付款预估佣金数',
  `pdd5` int(11) DEFAULT '0' COMMENT '本人-本月已付款订单数',
  `pdd6` decimal(10,2) DEFAULT '0.00' COMMENT '本人-本月已付款预估佣金数',
  `pdd7` int(11) DEFAULT '0' COMMENT '本人-上月已结算订单数',
  `pdd8` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已结算预估佣金数',
  `pdd9` int(11) DEFAULT '0' COMMENT '本人-上月已付款订单数',
  `pdd10` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已付款预估佣金数',
  `pdd11` int(11) DEFAULT '0' COMMENT '二级-今天已付款订单数',
  `pdd12` decimal(10,2) DEFAULT '0.00' COMMENT '本人-今天已付款佣预估金数',
  `pdd13` int(11) DEFAULT '0' COMMENT '二级-昨天已付款订单',
  `pdd14` decimal(10,2) DEFAULT '0.00' COMMENT '本人-昨天已付款预估佣金数',
  `pdd15` int(11) DEFAULT '0' COMMENT '二级-本月已付款订单数',
  `pdd16` decimal(10,2) DEFAULT '0.00' COMMENT '本人-本月已付款预估佣金数',
  `pdd17` int(11) DEFAULT '0' COMMENT '二级-上月已结算订单数',
  `pdd18` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已结算预估佣金数',
  `pdd19` int(11) DEFAULT '0' COMMENT '二级-上月已付款订单数',
  `pdd20` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已付款预估佣金数',
  `pdd21` int(11) DEFAULT '0' COMMENT '三级-今天已付款订单数',
  `pdd22` decimal(10,2) DEFAULT '0.00' COMMENT '本人-今天已付款佣预估金数',
  `pdd23` int(11) DEFAULT '0' COMMENT '三级-昨天已付款订单',
  `pdd24` decimal(10,2) DEFAULT '0.00' COMMENT '本人-昨天已付款预估佣金数',
  `pdd25` int(11) DEFAULT '0' COMMENT '三级-本月已付款订单数',
  `pdd26` decimal(10,2) DEFAULT '0.00' COMMENT '本人-本月已付款预估佣金数',
  `pdd27` int(11) DEFAULT '0' COMMENT '三级-上月已结算订单数',
  `pdd28` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已结算预估佣金数',
  `pdd29` int(11) DEFAULT '0' COMMENT '三级-上月已付款订单数',
  `pdd30` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已付款预估佣金数',
  `jd1` int(11) DEFAULT '0' COMMENT '本人-今天已付款订单数',
  `jd2` decimal(10,2) DEFAULT '0.00' COMMENT '本人-今天已付款佣预估金数',
  `jd3` int(11) DEFAULT '0' COMMENT '本人-昨天已付款订单',
  `jd4` decimal(10,2) DEFAULT '0.00' COMMENT '本人-昨天已付款预估佣金数',
  `jd5` int(11) DEFAULT '0' COMMENT '本人-本月已付款订单数',
  `jd6` decimal(10,2) DEFAULT '0.00' COMMENT '本人-本月已付款预估佣金数',
  `jd7` int(11) DEFAULT '0' COMMENT '本人-上月已结算订单数',
  `jd8` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已结算预估佣金数',
  `jd9` int(11) DEFAULT '0' COMMENT '本人-上月已付款订单数',
  `jd10` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已付款预估佣金数',
  `jd11` int(11) DEFAULT '0' COMMENT '二级-今天已付款订单数',
  `jd12` decimal(10,2) DEFAULT '0.00' COMMENT '本人-今天已付款佣预估金数',
  `jd13` int(11) DEFAULT '0' COMMENT '二级-昨天已付款订单',
  `jd14` decimal(10,2) DEFAULT '0.00' COMMENT '本人-昨天已付款预估佣金数',
  `jd15` int(11) DEFAULT '0' COMMENT '二级-本月已付款订单数',
  `jd16` decimal(10,2) DEFAULT '0.00' COMMENT '本人-本月已付款预估佣金数',
  `jd17` int(11) DEFAULT '0' COMMENT '二级-上月已结算订单数',
  `jd18` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已结算预估佣金数',
  `jd19` int(11) DEFAULT '0' COMMENT '二级-上月已付款订单数',
  `jd20` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已付款预估佣金数',
  `jd21` int(11) DEFAULT '0' COMMENT '三级-今天已付款订单数',
  `jd22` decimal(10,2) DEFAULT '0.00' COMMENT '本人-今天已付款佣预估金数',
  `jd23` int(11) DEFAULT '0' COMMENT '三级-昨天已付款订单',
  `jd24` decimal(10,2) DEFAULT '0.00' COMMENT '本人-昨天已付款预估佣金数',
  `jd25` int(11) DEFAULT '0' COMMENT '三级-本月已付款订单数',
  `jd26` decimal(10,2) DEFAULT '0.00' COMMENT '本人-本月已付款预估佣金数',
  `jd27` int(11) DEFAULT '0' COMMENT '三级-上月已结算订单数',
  `jd28` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已结算预估佣金数',
  `jd29` int(11) DEFAULT '0' COMMENT '三级-上月已付款订单数',
  `jd30` decimal(10,2) DEFAULT '0.00' COMMENT '本人-上月已付款预估佣金数',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `u_w` (`uid`,`weid`),
  KEY `weid` (`weid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tiger_wxdaili_dlshuju
-- ----------------------------
BEGIN;
INSERT INTO `ims_tiger_wxdaili_dlshuju` VALUES (1, 2, 3, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 0, 0.00, 1575862399);
COMMIT;

-- ----------------------------
-- Table structure for ims_tiger_wxdaili_jdpid
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_wxdaili_jdpid`;
CREATE TABLE `ims_tiger_wxdaili_jdpid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `px` int(11) DEFAULT '0',
  `type` int(1) DEFAULT '0' COMMENT '状态1 已分配 ',
  `nickname` varchar(200) DEFAULT NULL COMMENT '分配昵称',
  `uid` varchar(50) DEFAULT NULL COMMENT '分配会员ID',
  `pid` varchar(250) DEFAULT NULL COMMENT '淘客PID',
  `tgwname` varchar(100) DEFAULT NULL COMMENT '推广位名称',
  `fptime` varchar(50) DEFAULT NULL COMMENT '分配时间',
  `createtime` varchar(50) DEFAULT NULL COMMENT '生成时间',
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `pid` (`pid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_wxdaili_order
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_wxdaili_order`;
CREATE TABLE `ims_tiger_wxdaili_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `ddtype` int(2) DEFAULT '0' COMMENT '订单类型，代理订单0',
  `ffqdtype` int(2) DEFAULT '0' COMMENT '代理支付渠道',
  `memberid` int(11) unsigned DEFAULT NULL COMMENT 'member用户ID',
  `usernames` varchar(50) DEFAULT NULL,
  `nickname` varchar(100) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `tel` varchar(200) DEFAULT NULL,
  `openid` varchar(50) DEFAULT NULL COMMENT '自有OPENID',
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `goods_id` int(10) unsigned DEFAULT NULL,
  `orderno` varchar(50) DEFAULT NULL COMMENT '订单号',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  `price` decimal(10,4) DEFAULT '0.0000',
  `level1` decimal(10,4) DEFAULT '0.0000',
  `level2` decimal(10,4) DEFAULT '0.0000',
  `level3` decimal(10,4) DEFAULT '0.0000',
  `state` int(2) DEFAULT '0' COMMENT '状态',
  `paytime` int(10) unsigned DEFAULT '0',
  `txtime` int(10) unsigned DEFAULT '0' COMMENT '提现时间',
  `paystate` int(2) DEFAULT '0' COMMENT '支付状态 0 已支付1',
  `txtype` int(2) DEFAULT '0' COMMENT '未提现 0 已提现1 审核中2',
  `msg` varchar(200) DEFAULT NULL COMMENT '如：小虎的会员费奖励',
  `cengji` int(2) unsigned DEFAULT NULL COMMENT '层级 自购 0  一级 1 二级2 三级3',
  `kuaidi` varchar(200) DEFAULT NULL,
  `tzday` int(10) DEFAULT '0' COMMENT '团长支付天数',
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `openid` (`openid`),
  KEY `orderno` (`orderno`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_wxdaili_pddpid
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_wxdaili_pddpid`;
CREATE TABLE `ims_tiger_wxdaili_pddpid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `px` int(11) DEFAULT '0',
  `type` int(1) DEFAULT '0' COMMENT '状态1 已分配 ',
  `nickname` varchar(200) DEFAULT NULL COMMENT '分配昵称',
  `uid` varchar(50) DEFAULT NULL COMMENT '分配会员ID',
  `pid` varchar(250) DEFAULT NULL COMMENT '淘客PID',
  `tgwname` varchar(100) DEFAULT NULL COMMENT '推广位名称',
  `fptime` varchar(50) DEFAULT NULL COMMENT '分配时间',
  `createtime` varchar(50) DEFAULT NULL COMMENT '生成时间',
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `pid` (`pid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_wxdaili_qun
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_wxdaili_qun`;
CREATE TABLE `ims_tiger_wxdaili_qun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `px` int(11) DEFAULT '0',
  `type` int(1) DEFAULT '0' COMMENT '状态1 开始',
  `title` varchar(200) DEFAULT NULL COMMENT '群名称',
  `keyw` varchar(200) DEFAULT NULL COMMENT '关键词',
  `picurl` varchar(250) DEFAULT NULL COMMENT '二维码',
  `xzrs` varchar(200) DEFAULT NULL COMMENT '上线人数',
  `qtype` varchar(200) DEFAULT NULL COMMENT '群类型 1微信群 QQ群2',
  `createtime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `keyw` (`keyw`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_wxdaili_qunmember
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_wxdaili_qunmember`;
CREATE TABLE `ims_tiger_wxdaili_qunmember` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `quntitle` varchar(200) DEFAULT '0',
  `qunid` int(11) DEFAULT '0' COMMENT '所属群ID',
  `openid` varchar(50) DEFAULT '0',
  `nickname` varchar(200) DEFAULT NULL COMMENT '群名称',
  `avatar` varchar(200) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `sex` varchar(50) DEFAULT NULL,
  `createtime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `qunid` (`qunid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_wxdaili_set
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_wxdaili_set`;
CREATE TABLE `ims_tiger_wxdaili_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `dltype` int(11) DEFAULT '3' COMMENT '1 级 2级 3级',
  `dlname1` varchar(100) DEFAULT NULL COMMENT '一级名称',
  `dlname2` varchar(100) DEFAULT NULL COMMENT '二级名称',
  `dlname3` varchar(100) DEFAULT NULL COMMENT '三级名称',
  `dlbl1` int(11) DEFAULT NULL COMMENT '一级-自己产生佣金比率',
  `dlbl1t2` int(11) DEFAULT NULL COMMENT '一级-提取二级佣金比率',
  `dlbl1t3` int(11) DEFAULT NULL COMMENT '一级-提取三级佣金比率',
  `dlbl2` int(11) DEFAULT NULL COMMENT '二级-自己产生佣金比率',
  `dlbl2t3` int(11) DEFAULT NULL COMMENT '二级-提取三级佣金比率',
  `dlbl3` int(11) DEFAULT NULL COMMENT '三级-自己产生佣金比率',
  `dlfftype` int(11) DEFAULT '0' COMMENT '0不开启 1开启',
  `dlffprice` varchar(100) DEFAULT NULL COMMENT '付费金额',
  `fxtype` int(11) DEFAULT '0' COMMENT '0抽成模式 1普通分销',
  `ddtype` int(11) DEFAULT '0' COMMENT '0全显示 1显示一部分',
  `seartype` int(11) DEFAULT '0' COMMENT '超级搜0显示 1不显示',
  `dlzbtype` int(11) DEFAULT '0' COMMENT '直播 1显示',
  `fzname` varchar(100) DEFAULT NULL COMMENT '分站名称',
  `zfmsg0` varchar(1000) DEFAULT NULL COMMENT '支付提醒',
  `zfmsg1` varchar(1000) DEFAULT NULL COMMENT '一级支付提醒',
  `zfmsg2` varchar(1000) DEFAULT NULL COMMENT '二级支付提醒',
  `zfmsg3` varchar(1000) DEFAULT NULL COMMENT '三级支付提醒',
  `level1` varchar(50) DEFAULT NULL COMMENT '代理付费一级奖励',
  `level2` varchar(50) DEFAULT NULL COMMENT '代理付费二级奖励',
  `level3` varchar(50) DEFAULT NULL COMMENT '代理付费三级奖励',
  `glevel1` varchar(50) DEFAULT NULL COMMENT '代理付费固定一级奖励',
  `glevel2` varchar(50) DEFAULT NULL COMMENT '代理付费固定二级奖励',
  `glevel3` varchar(50) DEFAULT NULL COMMENT '代理付费固定三级奖励',
  `dlkcbl` varchar(30) DEFAULT NULL COMMENT '扣除佣金',
  `dlyjfltype` int(3) DEFAULT '0' COMMENT '提交订单是示开启返二级 0 不开启 1开启',
  `dlfxtype` int(11) DEFAULT '0' COMMENT '代理商是否支持提交订单反现 0 支持 1 不支持',
  `tztype` int(11) DEFAULT '0' COMMENT '1开启',
  PRIMARY KEY (`id`),
  KEY `idx_weid` (`weid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tiger_wxdaili_set
-- ----------------------------
BEGIN;
INSERT INTO `ims_tiger_wxdaili_set` VALUES (1, 2, 3, '', '', '', 30, 0, 0, 20, 0, 10, 0, '', 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', 0, 1, 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_tiger_wxdaili_tkpid
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_wxdaili_tkpid`;
CREATE TABLE `ims_tiger_wxdaili_tkpid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `px` int(11) DEFAULT '0',
  `type` int(1) DEFAULT '0' COMMENT '状态1 已分配 ',
  `nickname` varchar(200) DEFAULT NULL COMMENT '分配昵称',
  `uid` varchar(50) DEFAULT NULL COMMENT '分配会员ID',
  `tbuid` varchar(50) DEFAULT NULL COMMENT '淘宝ID',
  `pid` varchar(250) DEFAULT NULL COMMENT '淘客PID',
  `tgwname` varchar(100) DEFAULT NULL COMMENT '推广位名称',
  `fptime` varchar(50) DEFAULT NULL COMMENT '分配时间',
  `createtime` varchar(50) DEFAULT NULL COMMENT '生成时间',
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `pid` (`pid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_wxdaili_txlog
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_wxdaili_txlog`;
CREATE TABLE `ims_tiger_wxdaili_txlog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL COMMENT '微信用户昵称',
  `openid` varchar(255) DEFAULT NULL COMMENT '微信用户openid',
  `avatar` varchar(255) DEFAULT '0',
  `addtime` int(11) DEFAULT NULL COMMENT '打款时间',
  `credit1` int(11) DEFAULT NULL COMMENT '消耗积分',
  `credit2` varchar(100) DEFAULT NULL COMMENT '金额，分为单位',
  `zfbuid` varchar(100) DEFAULT NULL COMMENT '支付宝帐号',
  `dmch_billno` varchar(50) DEFAULT NULL COMMENT '生成的商户订单号',
  `sh` tinyint(1) DEFAULT '0' COMMENT '是否打款成功 0未审核 1已审核',
  `dresult` varchar(255) DEFAULT NULL COMMENT '失败提示',
  `createtime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_wxdaili_tzyjlog
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_wxdaili_tzyjlog`;
CREATE TABLE `ims_tiger_wxdaili_tzyjlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `uid` int(11) DEFAULT '0' COMMENT 'share表用户ID',
  `month` int(11) DEFAULT '0' COMMENT '结算月份 201701',
  `nickname` varchar(100) DEFAULT NULL COMMENT '粉丝昵称',
  `openid` varchar(100) DEFAULT NULL COMMENT '粉丝OPENID',
  `msg` varchar(100) DEFAULT NULL COMMENT '如：数据更新时间：2017-3-21',
  `tbbyfkprice` decimal(10,2) DEFAULT '0.00' COMMENT '本月付款',
  `tbsyjsprice` decimal(10,2) DEFAULT '0.00' COMMENT '上月结算',
  `tbjrfkprice` decimal(10,2) DEFAULT '0.00' COMMENT '今日付款',
  `tbzrfkprice` decimal(10,2) DEFAULT '0.00' COMMENT '昨日付款',
  `pddbyfkprice` decimal(10,2) DEFAULT '0.00' COMMENT '本月付款',
  `pddsyjsprice` decimal(10,2) DEFAULT '0.00' COMMENT '上月结算',
  `pddjrfkprice` decimal(10,2) DEFAULT '0.00' COMMENT '今日付款',
  `pddzrfkprice` decimal(10,2) DEFAULT '0.00' COMMENT '昨日付款',
  `jdbyfkprice` decimal(10,2) DEFAULT '0.00' COMMENT '本月付款',
  `jdsyjsprice` decimal(10,2) DEFAULT '0.00' COMMENT '上月结算',
  `jdjrfkprice` decimal(10,2) DEFAULT '0.00' COMMENT '今日付款',
  `jdzrfkprice` decimal(10,2) DEFAULT '0.00' COMMENT '昨日付款',
  `createtime` int(14) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid_month` (`uid`,`month`),
  KEY `weid` (`weid`),
  KEY `uid` (`uid`),
  KEY `month` (`month`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tiger_wxdaili_yjlog
-- ----------------------------
DROP TABLE IF EXISTS `ims_tiger_wxdaili_yjlog`;
CREATE TABLE `ims_tiger_wxdaili_yjlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `uid` int(11) DEFAULT '0' COMMENT 'share表ID',
  `month` varchar(20) DEFAULT NULL COMMENT '结算月份',
  `memberid` int(11) unsigned DEFAULT NULL COMMENT 'member用户ID',
  `nickname` varchar(100) DEFAULT NULL COMMENT '粉丝昵称',
  `openid` varchar(100) DEFAULT NULL COMMENT '粉丝OPENID',
  `msg` varchar(100) DEFAULT NULL COMMENT '如：2017年2月份佣金，自动结算时间：2017-3-21',
  `price` varchar(20) DEFAULT NULL COMMENT '提现佣金余额',
  `createtime` int(14) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `openid_createtime` (`openid`,`createtime`),
  KEY `weid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tuike_jd_jdset
-- ----------------------------
DROP TABLE IF EXISTS `ims_tuike_jd_jdset`;
CREATE TABLE `ims_tuike_jd_jdset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `appkey` varchar(200) DEFAULT NULL,
  `appsecret` varchar(200) DEFAULT NULL,
  `jduid` varchar(50) DEFAULT NULL,
  `jdpid` varchar(50) DEFAULT NULL,
  `unionid` varchar(50) DEFAULT NULL,
  `jdkey` varchar(200) DEFAULT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `jduid` (`jduid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tuike_jd_jdset
-- ----------------------------
BEGIN;
INSERT INTO `ims_tuike_jd_jdset` VALUES (1, 2, '4439a3c887de0f6075ffe6f86d223579', 'e17a50ae6e9b4426bfb99219e256585f', '', '1933717115', '1001983623', 'ece3b6ab1c8b87a7745e1ace8e185ec8918b4b64fdd17ea5444fe802f3a11b18d842c25a6df9ae51', 1574842325);
COMMIT;

-- ----------------------------
-- Table structure for ims_tuike_jd_jdsign
-- ----------------------------
DROP TABLE IF EXISTS `ims_tuike_jd_jdsign`;
CREATE TABLE `ims_tuike_jd_jdsign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `access_token` varchar(100) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `refresh_token` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  `token_type` varchar(50) DEFAULT NULL,
  `uid` varchar(50) DEFAULT NULL,
  `user_nick` varchar(50) DEFAULT NULL,
  `createtime` int(10) NOT NULL,
  `expires_in` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_tuike_pdd_pddsign
-- ----------------------------
DROP TABLE IF EXISTS `ims_tuike_pdd_pddsign`;
CREATE TABLE `ims_tuike_pdd_pddsign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `access_token` varchar(100) DEFAULT NULL COMMENT '结束时间',
  `expires_in` varchar(100) DEFAULT NULL COMMENT 'Access_Token过期时间',
  `refresh_token` varchar(50) DEFAULT NULL COMMENT '可用来刷新access_token',
  `scope` text COMMENT '授权接口范围',
  `owner_id` varchar(50) DEFAULT NULL COMMENT '拼多多店铺ID',
  `owner_name` varchar(50) DEFAULT NULL COMMENT '拼多多店铺账号名',
  `endtime` varchar(30) DEFAULT NULL COMMENT '结束时间',
  `client_id` varchar(100) DEFAULT NULL COMMENT 'client_id',
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `client_id` (`client_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tuike_pdd_pddsign
-- ----------------------------
BEGIN;
INSERT INTO `ims_tuike_pdd_pddsign` VALUES (1, 2, 'e4fc3a6a003144a58a082c9379da00d5b2e083ff', '15551998', '4698191648114bd8adb5ec442b031730185839a3', '', '9391813', '13310015380', '1590394576', '', 1574842578);
COMMIT;

-- ----------------------------
-- Table structure for ims_tuike_pdd_set
-- ----------------------------
DROP TABLE IF EXISTS `ims_tuike_pdd_set`;
CREATE TABLE `ims_tuike_pdd_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) DEFAULT '0',
  `pddpid` varchar(100) DEFAULT NULL COMMENT '默认推广位',
  `client_id` varchar(100) DEFAULT NULL,
  `ddjbbuid` varchar(100) DEFAULT NULL,
  `client_secret` varchar(50) DEFAULT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weid` (`weid`),
  KEY `ddjbbuid` (`ddjbbuid`),
  KEY `pddpid` (`pddpid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_tuike_pdd_set
-- ----------------------------
BEGIN;
INSERT INTO `ims_tuike_pdd_set` VALUES (1, 2, '9391813_121444005', NULL, '13310015380', NULL, 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_uni_account
-- ----------------------------
DROP TABLE IF EXISTS `ims_uni_account`;
CREATE TABLE `ims_uni_account` (
  `uniacid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupid` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `default_acid` int(10) unsigned NOT NULL,
  `rank` int(10) DEFAULT NULL,
  `title_initial` varchar(1) NOT NULL,
  PRIMARY KEY (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_uni_account
-- ----------------------------
BEGIN;
INSERT INTO `ims_uni_account` VALUES (1, -1, '易福团队', '一个朝气蓬勃的团队', 1, NULL, 'W');
INSERT INTO `ims_uni_account` VALUES (2, 0, '淘宝客', '', 2, NULL, 'T');
COMMIT;

-- ----------------------------
-- Table structure for ims_uni_account_group
-- ----------------------------
DROP TABLE IF EXISTS `ims_uni_account_group`;
CREATE TABLE `ims_uni_account_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `groupid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_uni_account_menus
-- ----------------------------
DROP TABLE IF EXISTS `ims_uni_account_menus`;
CREATE TABLE `ims_uni_account_menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `menuid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `title` varchar(30) NOT NULL,
  `sex` tinyint(3) unsigned NOT NULL,
  `group_id` int(10) NOT NULL,
  `client_platform_type` tinyint(3) unsigned NOT NULL,
  `area` varchar(50) NOT NULL,
  `data` text NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `isdeleted` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `menuid` (`menuid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_uni_account_menus
-- ----------------------------
BEGIN;
INSERT INTO `ims_uni_account_menus` VALUES (1, 2, 0, 1, '默认', 0, -1, 0, '', 'YToxOntzOjY6ImJ1dHRvbiI7YToyOntpOjA7YTozOntzOjQ6Im5hbWUiO3M6MTI6Iui/m+WFpeeCueWIuCI7czo0OiJ0eXBlIjtzOjQ6InZpZXciO3M6MzoidXJsIjtzOjcyOiJodHRwOi8vaHp0Ymsud2psbmZzLmNvbS9hcHAvaW5kZXgucGhwP2k9MiZjPWVudHJ5JmRvPWluZGV4Jm09dGlnZXJfbmV3aHUiO31pOjE7YTozOntzOjQ6Im5hbWUiO3M6MTI6IuW5s+WuieS/nemZqSI7czo0OiJ0eXBlIjtzOjQ6InZpZXciO3M6MzoidXJsIjtzOjU4OiJodHRwczovL2hlYWx0aC5waW5nYW4uY29tL20vaW5kZXguc2h0bWw/ZnJvbT1zaW5nbGVtZXNzYWdlIjt9fX0=', 1, 1576668186, 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_uni_account_modules
-- ----------------------------
DROP TABLE IF EXISTS `ims_uni_account_modules`;
CREATE TABLE `ims_uni_account_modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `module` varchar(50) NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL,
  `settings` text NOT NULL,
  `shortcut` tinyint(1) unsigned NOT NULL,
  `displayorder` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_module` (`module`),
  KEY `idx_uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_uni_account_modules
-- ----------------------------
BEGIN;
INSERT INTO `ims_uni_account_modules` VALUES (1, 2, 'tiger_newhu', 1, 'a:237:{s:6:\"ddcjxz\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:6:\"ddcjjl\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:5:\"fyrmb\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:4:\"zgfa\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:4:\"yjfa\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:4:\"ejfa\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:9:\"diyyjtype\";s:1:\"0\";s:10:\"dlgzsdtype\";s:1:\"1\";s:8:\"cjlxtype\";s:1:\"0\";s:8:\"dztypelx\";s:1:\"0\";s:19:\"tiger_newhu_fansnum\";N;s:15:\"tiger_newhu_usr\";s:361:\"认证订阅号设置：#领取积分# \r\n链接设置例如:<a href=\'#领取积分#\'>点我领取积分</a> \r\n粉丝昵称：#昵称# \r\n粉丝姓别：#性别# \r\n粉丝积分：#积分# \r\n粉丝余额：#余额# \r\n公众号名称：#公众号名称# \r\n国家：#国家# \r\n省份：#省# \r\n市/县：#市# \r\n链接:<a href=\'http://www.baidu.com\'>点击进入</a>\";s:14:\"nbfchangemoney\";N;s:13:\"nbfhelpgeturl\";N;s:12:\"nbfwxpaypath\";N;s:5:\"mchid\";s:0:\"\";s:6:\"apikey\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:6:\"secret\";s:0:\"\";s:6:\"txtype\";s:1:\"0\";s:10:\"jdppddtype\";s:1:\"0\";s:5:\"szurl\";N;s:9:\"client_ip\";s:0:\"\";s:7:\"szcolor\";N;s:7:\"rmb_num\";N;s:7:\"day_num\";N;s:6:\"tx_num\";N;s:7:\"tklleft\";s:0:\"\";s:8:\"tklright\";s:0:\"\";s:6:\"hztype\";s:0:\"\";s:6:\"qdcode\";N;s:8:\"regurlxy\";s:0:\"\";s:5:\"qdpid\";s:0:\"\";s:6:\"btjzcq\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:6:\"txinfo\";s:0:\"\";s:12:\"locationtype\";s:1:\"3\";s:7:\"jiequan\";s:1:\"0\";s:7:\"paihang\";s:1:\"0\";s:5:\"style\";s:6:\"style2\";s:4:\"head\";N;s:4:\"txon\";N;s:7:\"gztitle\";s:0:\"\";s:8:\"gzpicurl\";s:0:\"\";s:13:\"gzdescription\";s:0:\"\";s:5:\"gzurl\";s:0:\"\";s:6:\"towurl\";N;s:4:\"cjss\";N;s:9:\"serackkey\";s:42:\"长袖衬衫|连衣裙|内衣|毛绒衬衫\";s:9:\"logintype\";s:1:\"0\";s:8:\"hlAppKey\";s:0:\"\";s:6:\"cjddgz\";s:0:\"\";s:8:\"gdfxtype\";s:1:\"0\";s:13:\"choujiangtype\";s:1:\"0\";s:7:\"pddtjdd\";s:1:\"0\";s:8:\"pddwenan\";s:253:\"商品名称：#名称##换行#\r\n推荐理由：#推荐理由##换行#\r\n商品原价：#原价#元#换行#\r\n券后价：#券后价#元#换行#\r\n优惠券：#优惠券#元#换行#\r\n奖励：#奖励##换行#\r\n拼多多链接：#拼多多短网址##换行#\";s:11:\"jdviewwenan\";s:205:\"商品名称：#名称##换行#\r\n推荐理由：#推荐理由##换行#\r\n商品原价：#原价#元#换行#\r\n券后价：#券后价#元#换行#\r\n优惠券：#优惠券#元#换行#\r\n链接：#网址##换行#\";s:12:\"pddviewwenan\";s:205:\"商品名称：#名称##换行#\r\n推荐理由：#推荐理由##换行#\r\n商品原价：#原价#元#换行#\r\n券后价：#券后价#元#换行#\r\n优惠券：#优惠券#元#换行#\r\n链接：#网址##换行#\";s:11:\"yqycjiangli\";s:1:\"0\";s:11:\"kuaizhanurl\";s:0:\"\";s:5:\"tljfl\";s:0:\"\";s:6:\"qdtype\";s:1:\"0\";s:7:\"qdtgurl\";s:0:\"\";s:6:\"dxtype\";s:1:\"0\";s:7:\"smstype\";s:4:\"dayu\";s:6:\"juhesj\";N;s:8:\"cxsqtype\";i:2;s:8:\"dyAppKey\";s:0:\"\";s:11:\"dyAppSecret\";s:0:\"\";s:20:\"dysms_free_sign_name\";s:0:\"\";s:19:\"dysms_template_code\";s:0:\"\";s:8:\"jhappkey\";s:0:\"\";s:6:\"jhcode\";s:0:\"\";s:6:\"gzljcj\";s:1:\"2\";s:10:\"qiandaormb\";s:1:\"3\";s:6:\"hmyxtp\";s:0:\"\";s:5:\"pddcq\";s:1:\"1\";s:4:\"jdcq\";s:1:\"1\";s:10:\"appfxtltle\";N;s:12:\"appfxcontent\";N;s:5:\"ygzhf\";s:197:\"粉丝昵称：#昵称# \r\n粉丝积分：#积分# \r\n粉丝余额：#余额# \r\n公众号名称：#公众号名称# \r\n如：#昵称#您已经是#公众号名称#的粉丝了！当前积分是#积分#\";s:11:\"tbviewwenan\";N;s:5:\"gzewm\";s:0:\"\";s:5:\"kfewm\";s:0:\"\";s:7:\"hdtitle\";N;s:9:\"hdcontent\";N;s:7:\"qtstyle\";s:7:\"style99\";s:9:\"dhcontent\";N;s:9:\"dtkAppKey\";s:0:\"\";s:5:\"ptpid\";s:36:\"mm_711720113_1065450073_109733950492\";s:5:\"qqpid\";s:0:\"\";s:8:\"tkAppKey\";s:8:\"28111962\";s:11:\"tksecretKey\";s:32:\"654f07152ae3af11c7e4a84feb1df9b4\";s:10:\"jqtkAppKey\";s:0:\"\";s:13:\"jqtksecretKey\";s:0:\"\";s:6:\"sdjltx\";s:38:\"晒单成功!\\n奖励您#积分#积分\";s:6:\"sjjltx\";s:58:\"您的朋友#昵称#晒单成功!\\n奖励您#积分#积分\";s:5:\"miyao\";s:2:\"18\";s:10:\"qiandaourl\";s:0:\"\";s:7:\"jfscurl\";s:0:\"\";s:6:\"fxtype\";s:1:\"2\";s:3:\"zgf\";s:2:\"40\";s:3:\"yjf\";s:2:\"30\";s:3:\"ejf\";s:2:\"20\";s:4:\"fxkg\";s:1:\"1\";s:6:\"yjtype\";s:3:\"100\";s:9:\"cjssclass\";N;s:7:\"fxtitle\";s:0:\"\";s:9:\"fxcontent\";s:0:\"\";s:8:\"fxpicurl\";s:0:\"\";s:4:\"lbtx\";s:1:\"0\";s:5:\"gzhfl\";s:1:\"1\";s:5:\"flmsg\";s:396:\"昵称：#昵称#\r\n商品名称：#名称#\r\n商品原价：#原价#\r\n券后价：#券后价#\r\n总优惠后价：#惠后价# (选择返积分无效)\r\n总优惠金额：#总优惠# (选择返积分无效)\r\n优惠券：#优惠券# (优惠券如果没有提示，暂无优惠券)\r\n好评后优惠约：#返现金额#\r\n淘口令：#淘口令#\r\n购买地址：#短网址#\r\n同类产品：#同类产品#\";s:6:\"flmsg1\";s:0:\"\";s:5:\"jzcjq\";s:1:\"0\";s:8:\"newflmsg\";s:100:\"昵称：#昵称#你好\r\n你要找【#名称#】吗？\r\n点击查看更多相关内容：#短网址#\";s:8:\"adzoneid\";s:12:\"109733950492\";s:6:\"siteid\";s:10:\"1065450073\";s:5:\"ermsg\";s:70:\"http://tbk.5ikh.com/app/index.php?i=2&c=entry&do=newhelp&m=tiger_newhu\";s:7:\"zgtxmsg\";s:155:\"#昵称# 如：#昵称#，订单提交成功，客服会在24小时内审核订单，您奖获得#金额#奖励，请耐性等待。订单号：#订单号#\";s:7:\"yjtxmsg\";s:129:\"#昵称# 如：您的朋友#昵称#成功下单了，订单确认收货后，您奖获得#金额#奖励。订单号：#订单号#\";s:7:\"ejtxmsg\";s:138:\"#昵称# 如：您的朋友的朋友#昵称#成功下单了，订单确认收货后，您奖获得#金额#奖励。订单号：#订单号#\";s:4:\"jfbl\";s:1:\"1\";s:6:\"tttype\";s:1:\"1\";s:7:\"tttitle\";s:0:\"\";s:8:\"ttpicurl\";s:0:\"\";s:5:\"tturl\";s:0:\"\";s:5:\"ttsum\";s:0:\"\";s:9:\"yongjinjs\";s:1:\"2\";s:4:\"tkzs\";N;s:8:\"jqrflmsg\";s:398:\"HI，#昵称#\r\n【商品名称】\r\n商品名称#名称#\r\n原价：#原价# 元\r\n总优惠后价：#惠后价# 元\r\n券后价：#券后价#\r\n购买地址：#短网址#\r\n【优惠详情】\r\n优惠券：#优惠券#\r\n总优惠金额：#总优惠# 元\r\n好评后奖励：#返现金额#\r\n【下单】\r\n长按复制本条消息，打开【淘宝客户端】下单#淘口令#\r\n同类产品：#同类产品#\";s:4:\"wzcj\";s:1:\"0\";s:6:\"yetype\";s:0:\"\";s:7:\"phbtype\";s:1:\"0\";s:4:\"tbid\";s:13:\"2206787978133\";s:10:\"huiyuanurl\";s:0:\"\";s:3:\"hpx\";s:1:\"0\";s:10:\"hongbaourl\";s:0:\"\";s:6:\"yhlist\";s:1:\"0\";s:8:\"cjpicurl\";s:0:\"\";s:6:\"rxyjxs\";s:1:\"1\";s:10:\"hongbaoykg\";s:1:\"0\";s:10:\"cjsstypesy\";s:1:\"0\";s:10:\"cjsswzxsgs\";s:2:\"20\";s:9:\"glyopenid\";s:0:\"\";s:10:\"khgetorder\";s:1:\"0\";s:7:\"khgettx\";s:1:\"0\";s:5:\"ljcjk\";s:1:\"0\";s:6:\"sdtype\";N;s:7:\"fsjldsz\";N;s:7:\"llqtype\";s:1:\"0\";s:8:\"sdguangc\";s:1:\"0\";s:6:\"qfmbid\";s:1:\"0\";s:4:\"fcss\";s:1:\"1\";s:7:\"tkltype\";s:1:\"0\";s:4:\"cxrk\";s:1:\"0\";s:5:\"gzhtp\";s:1:\"1\";s:6:\"mmtype\";s:1:\"2\";s:13:\"dtkapp_secret\";s:32:\"ae039b1c9abe135952ae0a10d14cd157\";s:10:\"dtkapp_key\";s:13:\"5dc410eeaeb0c\";s:6:\"error1\";s:0:\"\";s:6:\"error2\";s:0:\"\";s:6:\"error3\";s:0:\"\";s:6:\"error4\";s:0:\"\";s:8:\"zbjgtime\";s:3:\"120\";s:10:\"zbtouxiang\";s:51:\"images/2/2019/11/RMeJJ1E7q24q11ZZ72M2X653Gccjzm.jpg\";s:5:\"wsurl\";s:24:\"ws://172.19.151.240:9502\";s:6:\"zblive\";s:1:\"0\";s:6:\"yktype\";s:1:\"1\";s:5:\"tbuid\";s:0:\"\";s:7:\"sylmkey\";N;s:6:\"cjsszn\";s:1:\"0\";s:5:\"jqrss\";N;s:6:\"gyspsj\";s:0:\"\";s:11:\"newflmsgjqr\";s:75:\"你要找【#名称#】吗？\r\n点击查看更多相关内容：#短网址#\";s:10:\"lbratetype\";s:1:\"1\";s:7:\"ldgzurl\";s:0:\"\";s:9:\"gzhcjtype\";s:1:\"1\";s:4:\"kfqq\";s:0:\"\";s:6:\"kftime\";s:0:\"\";s:8:\"mspicurl\";s:0:\"\";s:6:\"mstime\";N;s:5:\"cqmsg\";s:24:\"查券功能已关闭！\";s:8:\"topcolor\";s:7:\"#00ff00\";s:4:\"sy99\";s:1:\"1\";s:5:\"syjhs\";s:1:\"1\";s:4:\"syms\";s:1:\"1\";s:6:\"sybmmk\";s:1:\"1\";s:5:\"syddq\";N;s:9:\"newsstyle\";s:3:\"lb3\";s:5:\"tklmb\";s:321:\"商品名称：#名称##换行#\r\n推荐理由：#推荐理由##换行#\r\n商品原价：#原价#元#换行#\r\n券后价：#券后价#元#换行#\r\n优惠券：#优惠券#元#换行#\r\n淘口令：#淘口令##换行#\r\n拼多多链接：#拼多多短网址##换行#\r\n二合一链接：#二合一链接#\r\n短链接：#短链接#\";s:6:\"sinkey\";s:20:\"http://tbk.5ikh.com/\";s:5:\"dwzlj\";s:1:\"2\";s:8:\"zdgdtype\";s:1:\"1\";s:7:\"appname\";s:0:\"\";s:6:\"appico\";s:0:\"\";s:5:\"azurl\";s:0:\"\";s:6:\"iosurl\";s:0:\"\";s:6:\"apptxt\";s:0:\"\";s:8:\"qqtongji\";s:0:\"\";s:6:\"mftype\";s:1:\"1\";s:8:\"mfhhtype\";s:1:\"1\";s:11:\"unionidtype\";s:1:\"0\";s:4:\"logo\";s:51:\"images/2/2019/11/RMeJJ1E7q24q11ZZ72M2X653Gccjzm.jpg\";s:7:\"tljtype\";s:1:\"0\";s:5:\"tljyj\";s:0:\"\";s:6:\"tljsum\";s:0:\"\";s:5:\"tljsx\";s:0:\"\";s:8:\"tljtitle\";s:0:\"\";s:10:\"tljendtime\";N;s:12:\"tljadzone_id\";N;s:9:\"smskgtype\";s:1:\"0\";s:7:\"xqdwzxs\";s:1:\"1\";s:9:\"jhspicurl\";s:0:\"\";s:9:\"tqgpicurl\";s:0:\"\";s:6:\"dlhead\";s:1:\"1\";s:5:\"rjqqq\";N;s:6:\"viewtk\";s:1:\"1\";s:8:\"zhaotype\";s:1:\"0\";s:6:\"dlddfx\";s:1:\"0\";s:7:\"itemewm\";s:1:\"0\";s:8:\"ljqtzapp\";s:1:\"1\";s:10:\"tklnewtype\";N;s:8:\"tknewurl\";s:0:\"\";s:5:\"zydwz\";s:20:\"http://tbk.5ikh.com/\";s:6:\"zhaoxs\";s:1:\"0\";s:5:\"ewmlj\";N;s:12:\"hongbaoytype\";s:1:\"0\";s:4:\"mypy\";s:1:\"0\";s:8:\"cjsstype\";s:1:\"1\";s:8:\"hbsctime\";s:2:\"60\";s:7:\"hbcsmsg\";s:96:\"尊敬的粉丝：\\n1分钟之内只能生成1次海报\\n请稍后在试，感谢您的参与！\";s:5:\"rwurl\";N;s:6:\"AppKey\";s:0:\"\";s:9:\"appSecret\";s:0:\"\";s:6:\"jdtjdd\";s:1:\"0\";s:4:\"city\";s:0:\"\";}', 0, 0);
INSERT INTO `ims_uni_account_modules` VALUES (2, 1, 'tiger_newhu', 1, 'a:237:{s:6:\"ddcjxz\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:6:\"ddcjjl\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:5:\"fyrmb\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:4:\"zgfa\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:4:\"yjfa\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:4:\"ejfa\";s:17:\"a:1:{i:0;s:0:\"\";}\";s:9:\"diyyjtype\";s:1:\"0\";s:10:\"dlgzsdtype\";s:1:\"0\";s:8:\"cjlxtype\";s:1:\"0\";s:8:\"dztypelx\";s:1:\"0\";s:19:\"tiger_newhu_fansnum\";N;s:15:\"tiger_newhu_usr\";s:0:\"\";s:14:\"nbfchangemoney\";N;s:13:\"nbfhelpgeturl\";N;s:12:\"nbfwxpaypath\";N;s:5:\"mchid\";s:0:\"\";s:6:\"apikey\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:6:\"secret\";s:0:\"\";s:6:\"txtype\";s:1:\"0\";s:10:\"jdppddtype\";s:1:\"0\";s:5:\"szurl\";N;s:9:\"client_ip\";s:0:\"\";s:7:\"szcolor\";N;s:7:\"rmb_num\";N;s:7:\"day_num\";N;s:6:\"tx_num\";N;s:7:\"tklleft\";s:0:\"\";s:8:\"tklright\";s:0:\"\";s:6:\"hztype\";s:0:\"\";s:6:\"qdcode\";N;s:8:\"regurlxy\";s:0:\"\";s:5:\"qdpid\";s:0:\"\";s:6:\"btjzcq\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:6:\"txinfo\";s:0:\"\";s:12:\"locationtype\";s:1:\"3\";s:7:\"jiequan\";s:1:\"0\";s:7:\"paihang\";s:1:\"0\";s:5:\"style\";s:6:\"style2\";s:4:\"head\";N;s:4:\"txon\";N;s:7:\"gztitle\";s:0:\"\";s:8:\"gzpicurl\";s:0:\"\";s:13:\"gzdescription\";s:0:\"\";s:5:\"gzurl\";s:0:\"\";s:6:\"towurl\";N;s:4:\"cjss\";N;s:9:\"serackkey\";s:0:\"\";s:9:\"logintype\";s:1:\"0\";s:8:\"hlAppKey\";s:0:\"\";s:6:\"cjddgz\";s:0:\"\";s:8:\"gdfxtype\";s:1:\"0\";s:13:\"choujiangtype\";s:1:\"0\";s:7:\"pddtjdd\";s:1:\"0\";s:8:\"pddwenan\";s:0:\"\";s:11:\"jdviewwenan\";s:0:\"\";s:12:\"pddviewwenan\";s:0:\"\";s:11:\"yqycjiangli\";s:0:\"\";s:11:\"kuaizhanurl\";s:0:\"\";s:5:\"tljfl\";s:0:\"\";s:6:\"qdtype\";s:1:\"0\";s:7:\"qdtgurl\";s:0:\"\";s:6:\"dxtype\";s:1:\"0\";s:7:\"smstype\";s:4:\"dayu\";s:6:\"juhesj\";N;s:8:\"cxsqtype\";i:2;s:8:\"dyAppKey\";s:0:\"\";s:11:\"dyAppSecret\";s:0:\"\";s:20:\"dysms_free_sign_name\";s:0:\"\";s:19:\"dysms_template_code\";s:0:\"\";s:8:\"jhappkey\";s:0:\"\";s:6:\"jhcode\";s:0:\"\";s:6:\"gzljcj\";s:1:\"0\";s:10:\"qiandaormb\";s:0:\"\";s:6:\"hmyxtp\";s:0:\"\";s:5:\"pddcq\";s:1:\"0\";s:4:\"jdcq\";s:1:\"0\";s:10:\"appfxtltle\";N;s:12:\"appfxcontent\";N;s:5:\"ygzhf\";s:0:\"\";s:11:\"tbviewwenan\";N;s:5:\"gzewm\";s:0:\"\";s:5:\"kfewm\";s:0:\"\";s:7:\"hdtitle\";N;s:9:\"hdcontent\";N;s:7:\"qtstyle\";s:7:\"style99\";s:9:\"dhcontent\";N;s:9:\"dtkAppKey\";s:0:\"\";s:5:\"ptpid\";s:0:\"\";s:5:\"qqpid\";s:0:\"\";s:8:\"tkAppKey\";s:0:\"\";s:11:\"tksecretKey\";s:0:\"\";s:10:\"jqtkAppKey\";s:0:\"\";s:13:\"jqtksecretKey\";s:0:\"\";s:6:\"sdjltx\";s:0:\"\";s:6:\"sjjltx\";s:0:\"\";s:5:\"miyao\";s:0:\"\";s:10:\"qiandaourl\";s:0:\"\";s:7:\"jfscurl\";s:0:\"\";s:6:\"fxtype\";s:1:\"0\";s:3:\"zgf\";s:0:\"\";s:3:\"yjf\";s:0:\"\";s:3:\"ejf\";s:0:\"\";s:4:\"fxkg\";s:1:\"0\";s:6:\"yjtype\";s:0:\"\";s:9:\"cjssclass\";N;s:7:\"fxtitle\";s:0:\"\";s:9:\"fxcontent\";s:0:\"\";s:8:\"fxpicurl\";s:0:\"\";s:4:\"lbtx\";s:1:\"0\";s:5:\"gzhfl\";s:1:\"0\";s:5:\"flmsg\";s:0:\"\";s:6:\"flmsg1\";s:0:\"\";s:5:\"jzcjq\";s:1:\"0\";s:8:\"newflmsg\";s:0:\"\";s:8:\"adzoneid\";s:0:\"\";s:6:\"siteid\";s:0:\"\";s:5:\"ermsg\";s:0:\"\";s:7:\"zgtxmsg\";s:0:\"\";s:7:\"yjtxmsg\";s:0:\"\";s:7:\"ejtxmsg\";s:0:\"\";s:4:\"jfbl\";s:0:\"\";s:6:\"tttype\";s:1:\"0\";s:7:\"tttitle\";s:0:\"\";s:8:\"ttpicurl\";s:0:\"\";s:5:\"tturl\";s:0:\"\";s:5:\"ttsum\";s:0:\"\";s:9:\"yongjinjs\";s:0:\"\";s:4:\"tkzs\";N;s:8:\"jqrflmsg\";s:0:\"\";s:4:\"wzcj\";s:1:\"0\";s:6:\"yetype\";s:0:\"\";s:7:\"phbtype\";s:1:\"0\";s:4:\"tbid\";s:0:\"\";s:10:\"huiyuanurl\";s:0:\"\";s:3:\"hpx\";s:1:\"0\";s:10:\"hongbaourl\";s:0:\"\";s:6:\"yhlist\";s:1:\"0\";s:8:\"cjpicurl\";s:0:\"\";s:6:\"rxyjxs\";s:1:\"0\";s:10:\"hongbaoykg\";s:1:\"0\";s:10:\"cjsstypesy\";s:1:\"0\";s:10:\"cjsswzxsgs\";s:0:\"\";s:9:\"glyopenid\";s:0:\"\";s:10:\"khgetorder\";s:1:\"0\";s:7:\"khgettx\";s:1:\"0\";s:5:\"ljcjk\";s:1:\"0\";s:6:\"sdtype\";N;s:7:\"fsjldsz\";N;s:7:\"llqtype\";s:1:\"0\";s:8:\"sdguangc\";s:1:\"0\";s:6:\"qfmbid\";s:1:\"0\";s:4:\"fcss\";s:1:\"1\";s:7:\"tkltype\";s:1:\"0\";s:4:\"cxrk\";s:1:\"0\";s:5:\"gzhtp\";s:1:\"0\";s:6:\"mmtype\";s:1:\"0\";s:13:\"dtkapp_secret\";s:0:\"\";s:10:\"dtkapp_key\";s:0:\"\";s:6:\"error1\";s:0:\"\";s:6:\"error2\";s:0:\"\";s:6:\"error3\";s:0:\"\";s:6:\"error4\";s:0:\"\";s:8:\"zbjgtime\";s:0:\"\";s:10:\"zbtouxiang\";s:0:\"\";s:5:\"wsurl\";s:0:\"\";s:6:\"zblive\";s:1:\"0\";s:6:\"yktype\";s:1:\"0\";s:5:\"tbuid\";s:0:\"\";s:7:\"sylmkey\";N;s:6:\"cjsszn\";s:1:\"0\";s:5:\"jqrss\";N;s:6:\"gyspsj\";s:0:\"\";s:11:\"newflmsgjqr\";s:0:\"\";s:10:\"lbratetype\";s:1:\"0\";s:7:\"ldgzurl\";s:0:\"\";s:9:\"gzhcjtype\";s:1:\"0\";s:4:\"kfqq\";s:0:\"\";s:6:\"kftime\";s:0:\"\";s:8:\"mspicurl\";s:0:\"\";s:6:\"mstime\";N;s:5:\"cqmsg\";s:0:\"\";s:8:\"topcolor\";s:0:\"\";s:4:\"sy99\";s:1:\"0\";s:5:\"syjhs\";s:1:\"0\";s:4:\"syms\";s:1:\"0\";s:6:\"sybmmk\";s:1:\"0\";s:5:\"syddq\";N;s:9:\"newsstyle\";N;s:5:\"tklmb\";s:0:\"\";s:6:\"sinkey\";s:0:\"\";s:5:\"dwzlj\";s:1:\"0\";s:8:\"zdgdtype\";s:1:\"0\";s:7:\"appname\";s:0:\"\";s:6:\"appico\";s:0:\"\";s:5:\"azurl\";s:0:\"\";s:6:\"iosurl\";s:0:\"\";s:6:\"apptxt\";s:0:\"\";s:8:\"qqtongji\";s:0:\"\";s:6:\"mftype\";s:1:\"0\";s:8:\"mfhhtype\";s:1:\"0\";s:11:\"unionidtype\";s:1:\"0\";s:4:\"logo\";s:0:\"\";s:7:\"tljtype\";s:1:\"0\";s:5:\"tljyj\";s:0:\"\";s:6:\"tljsum\";s:0:\"\";s:5:\"tljsx\";s:0:\"\";s:8:\"tljtitle\";s:0:\"\";s:10:\"tljendtime\";N;s:12:\"tljadzone_id\";N;s:9:\"smskgtype\";s:1:\"0\";s:7:\"xqdwzxs\";s:1:\"0\";s:9:\"jhspicurl\";s:0:\"\";s:9:\"tqgpicurl\";s:0:\"\";s:6:\"dlhead\";s:1:\"0\";s:5:\"rjqqq\";N;s:6:\"viewtk\";s:1:\"0\";s:8:\"zhaotype\";s:1:\"0\";s:6:\"dlddfx\";s:1:\"0\";s:7:\"itemewm\";s:1:\"0\";s:8:\"ljqtzapp\";s:1:\"0\";s:10:\"tklnewtype\";N;s:8:\"tknewurl\";s:0:\"\";s:5:\"zydwz\";s:0:\"\";s:6:\"zhaoxs\";s:1:\"0\";s:5:\"ewmlj\";N;s:12:\"hongbaoytype\";s:1:\"0\";s:4:\"mypy\";s:1:\"0\";s:8:\"cjsstype\";s:1:\"0\";s:8:\"hbsctime\";s:0:\"\";s:7:\"hbcsmsg\";s:0:\"\";s:5:\"rwurl\";N;s:6:\"AppKey\";s:0:\"\";s:9:\"appSecret\";s:0:\"\";s:6:\"jdtjdd\";s:1:\"0\";s:4:\"city\";s:0:\"\";}', 0, 0);
INSERT INTO `ims_uni_account_modules` VALUES (3, 2, 'tiger_wxdaili', 1, 'a:59:{s:5:\"appid\";s:18:\"wx4ce1248fee1b6d3d\";s:6:\"secret\";s:32:\"1e2f6a4a33d751e23f817065607a60eb\";s:5:\"mchid\";N;s:6:\"apikey\";N;s:2:\"ip\";s:0:\"\";s:6:\"fytype\";s:1:\"0\";s:8:\"zdshtype\";s:1:\"0\";s:6:\"yjtype\";s:1:\"0\";s:8:\"adzoneid\";s:12:\"109733950492\";s:6:\"siteid\";s:10:\"1065450073\";s:5:\"flmsg\";s:288:\"商品名称：#名称##换行# \r\n推荐理由：#推荐理由##换行# \r\n商品原价：#原价#元#换行# \r\n券后价：#券后价#元#换行# \r\n优惠券：#优惠券#元#换行# \r\n淘口令：#淘口令##换行# \r\n二合一链接：#二合一链接##换行# \r\n短链接：#短链接#\";s:8:\"tkAppKey\";s:8:\"28111962\";s:11:\"tksecretKey\";s:32:\"654f07152ae3af11c7e4a84feb1df9b4\";s:4:\"tbid\";s:13:\"2206787978133\";s:4:\"jqzs\";N;s:5:\"jqmsg\";s:0:\"\";s:6:\"jlqmsg\";s:0:\"\";s:5:\"ptpid\";s:36:\"mm_711720113_1065450073_109733950492\";s:5:\"qqpid\";s:0:\"\";s:3:\"zgf\";s:0:\"\";s:8:\"dlpicurl\";s:0:\"\";s:8:\"dlmmtype\";s:1:\"2\";s:8:\"tknewurl\";s:0:\"\";s:7:\"orderys\";s:1:\"0\";s:5:\"dlnum\";N;s:5:\"fsnum\";s:0:\"\";s:8:\"dlsqtype\";s:1:\"0\";s:6:\"dlsqtx\";s:1:\"0\";s:9:\"glyopenid\";s:0:\"\";s:8:\"dlshtgtx\";s:1:\"0\";s:6:\"yktype\";s:1:\"0\";s:5:\"tbuid\";s:13:\"2206787978133\";s:9:\"ggcontent\";s:0:\"\";s:6:\"gglink\";s:0:\"\";s:4:\"jsms\";s:1:\"1\";s:7:\"sylmkey\";N;s:6:\"gyspsj\";s:0:\"\";s:9:\"txxzprice\";s:0:\"\";s:6:\"kqbdsj\";s:1:\"0\";s:7:\"bdteljl\";s:0:\"\";s:10:\"tklnewtype\";N;s:7:\"khgettx\";s:1:\"0\";s:7:\"pdddlxs\";s:1:\"0\";s:6:\"qdtype\";s:1:\"0\";s:5:\"qdpid\";s:0:\"\";s:6:\"qdcode\";N;s:7:\"qdtgurl\";s:0:\"\";s:5:\"zydwz\";s:0:\"\";s:6:\"sinkey\";s:0:\"\";s:5:\"dwzlj\";s:1:\"2\";s:7:\"xqdwzxs\";s:1:\"1\";s:9:\"logintype\";s:1:\"0\";s:8:\"lxddtype\";s:1:\"0\";s:7:\"lxjlrmb\";s:0:\"\";s:8:\"kfpicurl\";s:0:\"\";s:9:\"newdltype\";s:1:\"2\";s:8:\"dbcdtype\";s:1:\"0\";s:11:\"newdlxjtype\";s:1:\"0\";s:6:\"jddlxs\";s:1:\"0\";}', 0, 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_uni_account_modules_shortcut
-- ----------------------------
DROP TABLE IF EXISTS `ims_uni_account_modules_shortcut`;
CREATE TABLE `ims_uni_account_modules_shortcut` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `url` varchar(250) NOT NULL,
  `icon` varchar(200) NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `version_id` int(10) unsigned NOT NULL,
  `module_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_uni_account_users
-- ----------------------------
DROP TABLE IF EXISTS `ims_uni_account_users`;
CREATE TABLE `ims_uni_account_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `role` varchar(255) NOT NULL,
  `rank` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_memberid` (`uid`),
  KEY `uniacid` (`uniacid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_uni_group
-- ----------------------------
DROP TABLE IF EXISTS `ims_uni_group`;
CREATE TABLE `ims_uni_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner_uid` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `modules` text NOT NULL,
  `templates` varchar(5000) NOT NULL,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_uni_group
-- ----------------------------
BEGIN;
INSERT INTO `ims_uni_group` VALUES (1, 0, '体验套餐服务', 'N;', 'N;', 0, 0);
INSERT INTO `ims_uni_group` VALUES (2, 0, '', 'a:5:{s:7:\"modules\";a:4:{i:0;s:9:\"tuike_pdd\";i:1;s:8:\"tuike_jd\";i:2;s:13:\"tiger_wxdaili\";i:3;s:11:\"tiger_newhu\";}s:5:\"wxapp\";a:0:{}s:6:\"webapp\";a:0:{}s:5:\"xzapp\";a:0:{}s:8:\"phoneapp\";a:0:{}}', 'a:0:{}', 2, 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_uni_link_uniacid
-- ----------------------------
DROP TABLE IF EXISTS `ims_uni_link_uniacid`;
CREATE TABLE `ims_uni_link_uniacid` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `link_uniacid` int(10) NOT NULL,
  `version_id` int(10) NOT NULL,
  `module_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_uni_modules
-- ----------------------------
DROP TABLE IF EXISTS `ims_uni_modules`;
CREATE TABLE `ims_uni_modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `module_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_uni_modules
-- ----------------------------
BEGIN;
INSERT INTO `ims_uni_modules` VALUES (1, 2, 'tuike_pdd');
INSERT INTO `ims_uni_modules` VALUES (2, 2, 'tuike_jd');
INSERT INTO `ims_uni_modules` VALUES (3, 2, 'tiger_wxdaili');
INSERT INTO `ims_uni_modules` VALUES (4, 2, 'tiger_newhu');
INSERT INTO `ims_uni_modules` VALUES (5, 1, 'tuike_pdd');
INSERT INTO `ims_uni_modules` VALUES (6, 1, 'tuike_jd');
INSERT INTO `ims_uni_modules` VALUES (7, 1, 'tiger_wxdaili');
INSERT INTO `ims_uni_modules` VALUES (8, 1, 'tiger_newhu');
COMMIT;

-- ----------------------------
-- Table structure for ims_uni_settings
-- ----------------------------
DROP TABLE IF EXISTS `ims_uni_settings`;
CREATE TABLE `ims_uni_settings` (
  `uniacid` int(10) unsigned NOT NULL,
  `passport` varchar(200) NOT NULL,
  `oauth` varchar(100) NOT NULL,
  `jsauth_acid` int(10) unsigned NOT NULL,
  `uc` varchar(700) NOT NULL,
  `notify` varchar(2000) NOT NULL,
  `creditnames` varchar(500) NOT NULL,
  `creditbehaviors` varchar(500) NOT NULL,
  `welcome` varchar(60) NOT NULL,
  `default` varchar(60) NOT NULL,
  `default_message` varchar(2000) NOT NULL,
  `payment` text NOT NULL,
  `stat` varchar(300) NOT NULL,
  `default_site` int(10) unsigned DEFAULT NULL,
  `sync` tinyint(3) unsigned NOT NULL,
  `recharge` varchar(500) NOT NULL,
  `tplnotice` varchar(2000) NOT NULL,
  `grouplevel` tinyint(3) unsigned NOT NULL,
  `mcplugin` varchar(500) NOT NULL,
  `exchange_enable` tinyint(3) unsigned NOT NULL,
  `coupon_type` tinyint(3) unsigned NOT NULL,
  `menuset` text NOT NULL,
  `statistics` varchar(100) NOT NULL,
  `bind_domain` varchar(200) NOT NULL,
  `comment_status` tinyint(1) NOT NULL,
  `reply_setting` tinyint(4) NOT NULL,
  `default_module` varchar(100) NOT NULL,
  `attachment_limit` int(11) DEFAULT NULL,
  `attachment_size` varchar(20) DEFAULT NULL,
  `sync_member` tinyint(1) NOT NULL,
  PRIMARY KEY (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_uni_settings
-- ----------------------------
BEGIN;
INSERT INTO `ims_uni_settings` VALUES (1, 'a:3:{s:8:\"focusreg\";i:0;s:4:\"item\";s:5:\"email\";s:4:\"type\";s:8:\"password\";}', '', 0, 'a:1:{s:6:\"status\";i:0;}', 'a:1:{s:3:\"sms\";a:2:{s:7:\"balance\";i:0;s:9:\"signature\";s:0:\"\";}}', 'a:5:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}s:7:\"credit3\";a:2:{s:5:\"title\";s:0:\"\";s:7:\"enabled\";i:0;}s:7:\"credit4\";a:2:{s:5:\"title\";s:0:\"\";s:7:\"enabled\";i:0;}s:7:\"credit5\";a:2:{s:5:\"title\";s:0:\"\";s:7:\"enabled\";i:0;}}', 'a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}', '', '', '', 'a:4:{s:6:\"credit\";a:3:{s:6:\"switch\";b:0;s:15:\"recharge_switch\";b:0;s:10:\"pay_switch\";b:0;}s:6:\"alipay\";a:6:{s:6:\"switch\";b:0;s:7:\"account\";s:0:\"\";s:7:\"partner\";s:0:\"\";s:6:\"secret\";s:0:\"\";s:15:\"recharge_switch\";b:0;s:10:\"pay_switch\";b:0;}s:6:\"wechat\";a:7:{s:6:\"switch\";b:0;s:7:\"account\";b:0;s:7:\"signkey\";s:0:\"\";s:7:\"partner\";s:0:\"\";s:3:\"key\";s:0:\"\";s:15:\"recharge_switch\";b:0;s:10:\"pay_switch\";b:0;}s:8:\"delivery\";a:3:{s:6:\"switch\";b:0;s:15:\"recharge_switch\";b:0;s:10:\"pay_switch\";b:0;}}', '', 1, 0, '', '', 0, '', 0, 0, '', '', '', 0, 0, '', NULL, NULL, 0);
INSERT INTO `ims_uni_settings` VALUES (2, '', '', 0, '', '', 'a:2:{s:7:\"credit1\";a:2:{s:5:\"title\";s:6:\"积分\";s:7:\"enabled\";i:1;}s:7:\"credit2\";a:2:{s:5:\"title\";s:6:\"余额\";s:7:\"enabled\";i:1;}}', 'a:2:{s:8:\"activity\";s:7:\"credit1\";s:8:\"currency\";s:7:\"credit2\";}', '', '', '', '', '', 2, 0, '', '', 0, '', 0, 0, '', '', '', 0, 0, '', NULL, NULL, 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_uni_verifycode
-- ----------------------------
DROP TABLE IF EXISTS `ims_uni_verifycode`;
CREATE TABLE `ims_uni_verifycode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `receiver` varchar(50) NOT NULL,
  `verifycode` varchar(6) NOT NULL,
  `total` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `failed_count` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_userapi_cache
-- ----------------------------
DROP TABLE IF EXISTS `ims_userapi_cache`;
CREATE TABLE `ims_userapi_cache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(32) NOT NULL,
  `content` text NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_userapi_reply
-- ----------------------------
DROP TABLE IF EXISTS `ims_userapi_reply`;
CREATE TABLE `ims_userapi_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `description` varchar(300) NOT NULL,
  `apiurl` varchar(300) NOT NULL,
  `token` varchar(32) NOT NULL,
  `default_text` varchar(100) NOT NULL,
  `cachetime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_userapi_reply
-- ----------------------------
BEGIN;
INSERT INTO `ims_userapi_reply` VALUES (1, 1, '\"城市名+天气\", 如: \"北京天气\"', 'weather.php', '', '', 0);
INSERT INTO `ims_userapi_reply` VALUES (2, 2, '\"百科+查询内容\" 或 \"定义+查询内容\", 如: \"百科姚明\", \"定义自行车\"', 'baike.php', '', '', 0);
INSERT INTO `ims_userapi_reply` VALUES (3, 3, '\"@查询内容(中文或英文)\"', 'translate.php', '', '', 0);
INSERT INTO `ims_userapi_reply` VALUES (4, 4, '\"日历\", \"万年历\", \"黄历\"或\"几号\"', 'calendar.php', '', '', 0);
INSERT INTO `ims_userapi_reply` VALUES (5, 5, '\"新闻\"', 'news.php', '', '', 0);
INSERT INTO `ims_userapi_reply` VALUES (6, 6, '\"快递+单号\", 如: \"申通1200041125\"', 'express.php', '', '', 0);
COMMIT;

-- ----------------------------
-- Table structure for ims_users
-- ----------------------------
DROP TABLE IF EXISTS `ims_users`;
CREATE TABLE `ims_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner_uid` int(10) NOT NULL,
  `groupid` int(10) unsigned NOT NULL,
  `founder_groupid` tinyint(4) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(200) NOT NULL,
  `salt` varchar(10) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `joindate` int(10) unsigned NOT NULL,
  `joinip` varchar(15) NOT NULL,
  `lastvisit` int(10) unsigned NOT NULL,
  `lastip` varchar(15) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `starttime` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  `register_type` tinyint(3) NOT NULL,
  `openid` varchar(50) NOT NULL,
  `welcome_link` tinyint(4) NOT NULL,
  `is_bind` tinyint(1) NOT NULL,
  `notice_setting` varchar(5000) NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_users
-- ----------------------------
BEGIN;
INSERT INTO `ims_users` VALUES (1, 0, 1, 0, 'admin', 'ce7728dbb3028610c88e6375766af74781d0c131', 'c0dcf901', 0, 0, 1574840253, '', 1577540628, '127.0.0.1', '', 0, 0, 0, '', 0, 0, '');
COMMIT;

-- ----------------------------
-- Table structure for ims_users_bind
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_bind`;
CREATE TABLE `ims_users_bind` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `bind_sign` varchar(50) NOT NULL,
  `third_type` tinyint(4) NOT NULL,
  `third_nickname` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `bind_sign` (`bind_sign`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_create_group
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_create_group`;
CREATE TABLE `ims_users_create_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_name` varchar(50) NOT NULL,
  `maxaccount` int(10) unsigned NOT NULL,
  `maxwxapp` int(10) unsigned NOT NULL,
  `maxwebapp` int(10) unsigned NOT NULL,
  `maxphoneapp` int(10) unsigned NOT NULL,
  `maxxzapp` int(10) unsigned NOT NULL,
  `maxaliapp` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `maxbaiduapp` int(10) NOT NULL,
  `maxtoutiaoapp` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_extra_group
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_extra_group`;
CREATE TABLE `ims_users_extra_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `uni_group_id` int(10) unsigned NOT NULL,
  `create_group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `uni_group_id` (`uni_group_id`),
  KEY `create_group_id` (`create_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_extra_limit
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_extra_limit`;
CREATE TABLE `ims_users_extra_limit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `maxaccount` int(10) unsigned NOT NULL,
  `maxwxapp` int(10) unsigned NOT NULL,
  `maxwebapp` int(10) unsigned NOT NULL,
  `maxphoneapp` int(10) unsigned NOT NULL,
  `maxxzapp` int(10) unsigned NOT NULL,
  `maxaliapp` int(10) unsigned NOT NULL,
  `timelimit` int(10) unsigned NOT NULL,
  `maxbaiduapp` int(10) NOT NULL,
  `maxtoutiaoapp` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_extra_modules
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_extra_modules`;
CREATE TABLE `ims_users_extra_modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `module_name` varchar(100) NOT NULL,
  `support` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `module_name` (`module_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_extra_templates
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_extra_templates`;
CREATE TABLE `ims_users_extra_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `template_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `template_id` (`template_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_failed_login
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_failed_login`;
CREATE TABLE `ims_users_failed_login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL,
  `username` varchar(32) NOT NULL,
  `count` tinyint(1) unsigned NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ip_username` (`ip`,`username`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_founder_group
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_founder_group`;
CREATE TABLE `ims_users_founder_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `package` varchar(5000) NOT NULL,
  `maxaccount` int(10) unsigned NOT NULL,
  `maxsubaccount` int(10) unsigned NOT NULL,
  `timelimit` int(10) unsigned NOT NULL,
  `maxwxapp` int(10) unsigned NOT NULL,
  `maxwebapp` int(10) NOT NULL DEFAULT '0',
  `maxphoneapp` int(10) NOT NULL,
  `maxxzapp` int(10) NOT NULL,
  `maxaliapp` int(10) NOT NULL,
  `maxbaiduapp` int(10) NOT NULL,
  `maxtoutiaoapp` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_founder_own_create_groups
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_founder_own_create_groups`;
CREATE TABLE `ims_users_founder_own_create_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `founder_uid` int(10) unsigned NOT NULL,
  `create_group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `founder_uid` (`founder_uid`),
  KEY `create_group_id` (`create_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_founder_own_uni_groups
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_founder_own_uni_groups`;
CREATE TABLE `ims_users_founder_own_uni_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `founder_uid` int(10) unsigned NOT NULL,
  `uni_group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `founder_uid` (`founder_uid`),
  KEY `uni_group_id` (`uni_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_founder_own_users
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_founder_own_users`;
CREATE TABLE `ims_users_founder_own_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `founder_uid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `founder_uid` (`founder_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_founder_own_users_groups
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_founder_own_users_groups`;
CREATE TABLE `ims_users_founder_own_users_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `founder_uid` int(10) unsigned NOT NULL,
  `users_group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `founder_uid` (`founder_uid`),
  KEY `users_group_id` (`users_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_group
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_group`;
CREATE TABLE `ims_users_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner_uid` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `package` varchar(5000) NOT NULL,
  `maxaccount` int(10) unsigned NOT NULL,
  `maxsubaccount` int(10) unsigned NOT NULL,
  `timelimit` int(10) unsigned NOT NULL,
  `maxwxapp` int(10) unsigned NOT NULL,
  `maxwebapp` int(10) NOT NULL DEFAULT '0',
  `maxphoneapp` int(10) NOT NULL,
  `maxxzapp` int(10) NOT NULL,
  `maxaliapp` int(10) NOT NULL,
  `maxbaiduapp` int(10) NOT NULL,
  `maxtoutiaoapp` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_invitation
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_invitation`;
CREATE TABLE `ims_users_invitation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `fromuid` int(10) unsigned NOT NULL,
  `inviteuid` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_code` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_lastuse
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_lastuse`;
CREATE TABLE `ims_users_lastuse` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `uniacid` int(10) DEFAULT NULL,
  `modulename` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ims_users_lastuse
-- ----------------------------
BEGIN;
INSERT INTO `ims_users_lastuse` VALUES (1, 1, 2, '', 'account_display');
INSERT INTO `ims_users_lastuse` VALUES (2, 1, 2, 'tiger_newhu', 'module_display');
COMMIT;

-- ----------------------------
-- Table structure for ims_users_permission
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_permission`;
CREATE TABLE `ims_users_permission` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `type` varchar(100) NOT NULL,
  `permission` varchar(10000) NOT NULL,
  `url` varchar(255) NOT NULL,
  `modules` text NOT NULL,
  `templates` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_users_profile
-- ----------------------------
DROP TABLE IF EXISTS `ims_users_profile`;
CREATE TABLE `ims_users_profile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `edittime` int(10) NOT NULL,
  `realname` varchar(10) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `fakeid` varchar(30) NOT NULL,
  `vip` tinyint(3) unsigned NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `birthyear` smallint(6) unsigned NOT NULL,
  `birthmonth` tinyint(3) unsigned NOT NULL,
  `birthday` tinyint(3) unsigned NOT NULL,
  `constellation` varchar(10) NOT NULL,
  `zodiac` varchar(5) NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `idcard` varchar(30) NOT NULL,
  `studentid` varchar(50) NOT NULL,
  `grade` varchar(10) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `nationality` varchar(30) NOT NULL,
  `resideprovince` varchar(30) NOT NULL,
  `residecity` varchar(30) NOT NULL,
  `residedist` varchar(30) NOT NULL,
  `graduateschool` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `education` varchar(10) NOT NULL,
  `occupation` varchar(30) NOT NULL,
  `position` varchar(30) NOT NULL,
  `revenue` varchar(10) NOT NULL,
  `affectivestatus` varchar(30) NOT NULL,
  `lookingfor` varchar(255) NOT NULL,
  `bloodtype` varchar(5) NOT NULL,
  `height` varchar(5) NOT NULL,
  `weight` varchar(5) NOT NULL,
  `alipay` varchar(30) NOT NULL,
  `msn` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `taobao` varchar(30) NOT NULL,
  `site` varchar(30) NOT NULL,
  `bio` text NOT NULL,
  `interest` text NOT NULL,
  `workerid` varchar(64) NOT NULL,
  `is_send_mobile_status` tinyint(3) NOT NULL,
  `send_expire_status` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_video_reply
-- ----------------------------
DROP TABLE IF EXISTS `ims_video_reply`;
CREATE TABLE `ims_video_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `mediaid` varchar(255) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_voice_reply
-- ----------------------------
DROP TABLE IF EXISTS `ims_voice_reply`;
CREATE TABLE `ims_voice_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `mediaid` varchar(255) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_wechat_attachment
-- ----------------------------
DROP TABLE IF EXISTS `ims_wechat_attachment`;
CREATE TABLE `ims_wechat_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `acid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `media_id` varchar(255) NOT NULL,
  `width` int(10) unsigned NOT NULL,
  `height` int(10) unsigned NOT NULL,
  `type` varchar(15) NOT NULL,
  `model` varchar(25) NOT NULL,
  `tag` varchar(5000) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `module_upload_dir` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `media_id` (`media_id`),
  KEY `acid` (`acid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_wechat_news
-- ----------------------------
DROP TABLE IF EXISTS `ims_wechat_news`;
CREATE TABLE `ims_wechat_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned DEFAULT NULL,
  `attach_id` int(10) unsigned NOT NULL,
  `thumb_media_id` varchar(60) NOT NULL,
  `thumb_url` varchar(255) NOT NULL,
  `title` varchar(50) NOT NULL,
  `author` varchar(30) NOT NULL,
  `digest` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `content_source_url` varchar(200) NOT NULL,
  `show_cover_pic` tinyint(3) unsigned NOT NULL,
  `url` varchar(200) NOT NULL,
  `displayorder` int(2) NOT NULL,
  `need_open_comment` tinyint(1) NOT NULL,
  `only_fans_can_comment` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `attach_id` (`attach_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_wxapp_general_analysis
-- ----------------------------
DROP TABLE IF EXISTS `ims_wxapp_general_analysis`;
CREATE TABLE `ims_wxapp_general_analysis` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) NOT NULL,
  `session_cnt` int(10) NOT NULL,
  `visit_pv` int(10) NOT NULL,
  `visit_uv` int(10) NOT NULL,
  `visit_uv_new` int(10) NOT NULL,
  `type` tinyint(2) NOT NULL,
  `stay_time_uv` varchar(10) NOT NULL,
  `stay_time_session` varchar(10) NOT NULL,
  `visit_depth` varchar(10) NOT NULL,
  `ref_date` varchar(8) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `ref_date` (`ref_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_wxapp_versions
-- ----------------------------
DROP TABLE IF EXISTS `ims_wxapp_versions`;
CREATE TABLE `ims_wxapp_versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `multiid` int(10) unsigned NOT NULL,
  `version` varchar(10) NOT NULL,
  `description` varchar(255) NOT NULL,
  `modules` varchar(1000) NOT NULL,
  `design_method` tinyint(1) NOT NULL,
  `template` int(10) NOT NULL,
  `quickmenu` varchar(2500) NOT NULL,
  `createtime` int(10) NOT NULL,
  `type` int(2) NOT NULL DEFAULT '0',
  `entry_id` int(11) NOT NULL DEFAULT '0',
  `appjson` text NOT NULL,
  `default_appjson` text NOT NULL,
  `use_default` tinyint(1) NOT NULL DEFAULT '1',
  `redirect` varchar(300) NOT NULL,
  `connection` varchar(1000) NOT NULL,
  `last_modules` varchar(1000) DEFAULT NULL,
  `tominiprogram` varchar(1000) NOT NULL,
  `upload_time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `version` (`version`),
  KEY `uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ims_wxcard_reply
-- ----------------------------
DROP TABLE IF EXISTS `ims_wxcard_reply`;
CREATE TABLE `ims_wxcard_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL,
  `title` varchar(30) NOT NULL,
  `card_id` varchar(50) NOT NULL,
  `cid` int(10) unsigned NOT NULL,
  `brand_name` varchar(30) NOT NULL,
  `logo_url` varchar(255) NOT NULL,
  `success` varchar(255) NOT NULL,
  `error` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;
